/* Toggle menu mobile */
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.menu-toggle');
  const menu = document.querySelector('.mobile-menu');
  if (!toggle || !menu) return;

  let open = false;
  toggle.addEventListener('click', () => {
    open = !open;
    menu.classList.toggle('open', open);
    toggle.setAttribute('aria-expanded', String(open));
  });

  // Chiude il menu al click su un link
  menu.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      open = false;
      menu.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
    });
  });
});