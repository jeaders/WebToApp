/* Banner cookie - consenso semplice */
document.addEventListener('DOMContentLoaded', () => {
  const banner = document.getElementById('cookie-banner');
  if (!banner) return;

  const accepted = localStorage.getItem('cookie_consent');
  if (accepted === 'true') {
    banner.style.display = 'none';
    return;
  }

  const acceptBtn = banner.querySelector('.cookie-btn.accept');
  const settingsBtn = banner.querySelector('.cookie-btn.settings');

  acceptBtn.addEventListener('click', () => {
    localStorage.setItem('cookie_consent', 'true');
    banner.style.display = 'none';
  });

  settingsBtn.addEventListener('click', () => {
    // Per ora tratta come accettazione tecnica necessaria al funzionamento
    localStorage.setItem('cookie_consent', 'true');
    banner.style.display = 'none';
  });
});