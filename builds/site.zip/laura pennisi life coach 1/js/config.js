/* Tailwind CSS configurazione condivisa */
tailwind.config = {
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#FBF7F0',
          100: '#F1E9DC',
          200: '#E3D6C3',
          300: '#C9B79E',
          400: '#A98F6E',
          500: '#9C7A45', // Accento oro soft
          600: '#836539',
          700: '#6A502D',
          800: '#503C22',
          900: '#3A2B18',
        },
        sage: {
          50: '#F6F2EA',
          100: '#EBE4D7',
          200: '#D8CDBB',
          300: '#BCAC93',
          400: '#98866C',
          500: '#7A6A55',
          600: '#5F5242',
          700: '#463C30',
          800: '#2F2820',
          900: '#1D1812',
        },
        accent: '#9C7A45',
        cream: '#3A322B',
        paper: '#F1E9DD',
        ink: '#3A322B',
        ink2: '#7A6E5F',
        surface: '#FBF7F0',
        'text-muted': '#7A6E5F',
      },
      fontFamily: {
        serif: ['"Playfair Display"', 'serif'],
        sans: ['Inter', 'sans-serif'],
      },
      boxShadow: {
        soft: '0 8px 30px rgba(72, 58, 44, 0.08)',
        softHover: '0 16px 44px rgba(72, 58, 44, 0.14)',
        glow: '0 0 30px rgba(156, 122, 69, 0.18)',
        innerCard: 'inset 0 1px 0 rgba(255, 255, 255, 0.6)',
      },
      animation: {
        'fade-up': 'fadeUp 0.8s ease-out forwards',
        'float': 'float 10s ease-in-out infinite',
        'float-slow': 'float 16s ease-in-out infinite',
        'pulse-soft': 'pulseSoft 4s ease-in-out infinite',
        'pulse-slow': 'pulseSlow 6s ease-in-out infinite',
      },
      keyframes: {
        fadeUp: { '0%': { opacity: '0', transform: 'translateY(40px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        float: { '0%, 100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-20px)' } },
        pulseSoft: { '0%, 100%': { opacity: '0.5', transform: 'scale(0.96)' }, '50%': { opacity: '1', transform: 'scale(1)' } },
        pulseSlow: { '0%, 100%': { opacity: '0.4' }, '50%': { opacity: '1' } },
      },
    },
  },
};