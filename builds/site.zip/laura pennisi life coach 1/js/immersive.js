/* ==========================================================================
   Effetti immersivi: cursor follower, parallax, tilt, split-text
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  /* --- Split testo in caratteri per reveal --- */
  document.querySelectorAll('[data-split-text]').forEach(el => {
    const text = el.textContent.trim();
    el.innerHTML = '';
    [...text].forEach((char, i) => {
      const span = document.createElement('span');
      span.className = 'char';
      span.setAttribute('aria-hidden', 'true');
      span.style.setProperty('--i', i);
      span.textContent = char === ' ' ? '\u00A0' : char;
      el.appendChild(span);
    });
    el.setAttribute('aria-label', text);
  });

  /* --- Parallax su elementi con data-parallax --- */
  const parallaxEls = document.querySelectorAll('[data-parallax]');
  if (parallaxEls.length) {
    window.addEventListener('scroll', () => {
      const scrollY = window.scrollY;
      parallaxEls.forEach(el => {
        const speed = parseFloat(el.getAttribute('data-parallax')) || 0.05;
        const y = scrollY * speed;
        el.style.transform = `translateY(${y}px)`;
      });
    });
  }

  /* --- Tilt effect su .tilt-card --- */
  document.querySelectorAll('.tilt-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const rotateX = ((y - centerY) / centerY) * -3;
      const rotateY = ((x - centerX) / centerX) * 3;
      card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = `perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)`;
    });
  });

  /* --- Barra di avanzamento scroll --- */
  const progressBar = document.getElementById('progress-bar');
  if (progressBar) {
    window.addEventListener('scroll', () => {
      const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
      const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      const scrolled = (winScroll / height) * 100;
      progressBar.style.width = scrolled + '%';
    });
  }

  /* --- Effetto magnetico sui bottoni CTA --- */
  document.querySelectorAll('.btn-primary, .btn-nav').forEach(btn => {
    let tx = 0, ty = 0;
    btn.addEventListener('mousemove', (e) => {
      const rect = btn.getBoundingClientRect();
      const x = ((e.clientX - rect.left - rect.width / 2) / rect.width) * 14;
      const y = ((e.clientY - rect.top - rect.height / 2) / rect.height) * 14;
      tx = x;
      ty = y;
      btn.style.transform = `translate(${x}px, ${y}px)`;
      btn.style.transition = 'none';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.transition = 'transform 0.4s cubic-bezier(0.16, 1, 0.3, 1)';
      btn.style.transform = 'translate(0, 0)';
    });
  });

  /* --- Contatori animati su [data-counter] --- */
  document.querySelectorAll('[data-counter]').forEach(el => {
    const target = parseInt(el.getAttribute('data-counter'), 10) || 0;
    const suffix = el.getAttribute('data-suffix') || '';
    const duration = 1800;
    let started = false;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && !started) {
          started = true;
          const startTime = performance.now();
          function update(now) {
            const elapsed = now - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const ease = 1 - (1 - progress) * (1 - progress);
            el.textContent = Math.floor(ease * target) + suffix;
            if (progress < 1) {
              requestAnimationFrame(update);
            }
          }
          requestAnimationFrame(update);
          observer.unobserve(el);
        }
      });
    }, { threshold: 0.6 });
    observer.observe(el);
  });

  /* --- Carousel testimonianze orizzontale --- */
  const track = document.querySelector('.carousel-track');
  if (track) {
    const slides = Array.from(track.children);
    let index = 0;
    const prevBtn = document.querySelector('.carousel-btn[aria-label="Precedente"]');
    const nextBtn = document.querySelector('.carousel-btn[aria-label="Successivo"]');

    function update() {
      track.scrollTo({ left: slides[index].offsetLeft - track.offsetLeft - (track.clientWidth - slides[index].clientWidth) / 2, behavior: 'smooth' });
    }

    if (prevBtn) prevBtn.addEventListener('click', () => {
      index = (index - 1 + slides.length) % slides.length;
      update();
    });
    if (nextBtn) nextBtn.addEventListener('click', () => {
      index = (index + 1) % slides.length;
      update();
    });

    // Swipe touch
    let startX = 0;
    track.addEventListener('touchstart', (e) => { startX = e.touches[0].clientX; }, { passive: true });
    track.addEventListener('touchend', (e) => {
      const endX = e.changedTouches[0].clientX;
      if (startX - endX > 50) { index = (index + 1) % slides.length; update(); }
      else if (endX - startX > 50) { index = (index - 1 + slides.length) % slides.length; update(); }
    }, { passive: true });
  }

  /* --- Accordion FAQ --- */
  document.querySelectorAll('.faq-trigger').forEach(btn => {
    btn.addEventListener('click', () => {
      const expanded = btn.getAttribute('aria-expanded') === 'true';
      const panel = btn.nextElementSibling;
      btn.setAttribute('aria-expanded', String(!expanded));
      panel.classList.toggle('open', !expanded);
    });
  });
});
