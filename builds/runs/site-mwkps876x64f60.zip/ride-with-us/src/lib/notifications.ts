import { addDoc, collection } from "firebase/firestore";
import { db } from "@/lib/firebase";

export async function pushNotification(
  userId: string,
  title: string,
  message: string,
  rideId?: string
) {
  await addDoc(collection(db, "notifications"), {
    userId,
    title,
    message,
    rideId: rideId || null,
    read: false,
    createdAt: new Date().toISOString(),
  });
}
