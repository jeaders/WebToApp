import { collection, doc, getDoc, getDocs, setDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { DEFAULT_FARE_RULES } from "@/lib/fare";
import { AppSettings, FareRule, ServiceType } from "@/types/rideWithUs";

export async function fetchAppSettings(): Promise<AppSettings> {
  const snap = await getDoc(doc(db, "app_config", "settings"));
  if (snap.exists()) {
    const data = snap.data() as Partial<AppSettings>;
    return {
      app_name: data.app_name || "Ride With Us",
      currency: data.currency || "PKR",
      services: (data.services as ServiceType[]) || ["Bike", "Car", "Rickshaw"],
      supportPhone: data.supportPhone || "+92 300 0000000",
      commissionPercent: data.commissionPercent ?? 15,
    };
  }
  return {
    app_name: "Ride With Us",
    currency: "PKR",
    services: ["Bike", "Car", "Rickshaw"],
  };
}

export async function fetchFareRules(): Promise<Record<ServiceType, FareRule>> {
  const snap = await getDocs(collection(db, "fare_rules"));
  const merged: Record<ServiceType, FareRule> = { ...DEFAULT_FARE_RULES };
  snap.forEach((d) => {
    const rule = d.data() as FareRule;
    if (rule.serviceType) {
      merged[rule.serviceType] = rule;
    }
  });
  return merged;
}

// Called only by Admin to initialize missing fare_rules without overwriting app_config/settings
export async function ensureMissingFareRules(): Promise<void> {
  const existing = await getDocs(collection(db, "fare_rules"));
  const existingIds = new Set(existing.docs.map((d) => d.id));

  for (const key of Object.keys(DEFAULT_FARE_RULES) as ServiceType[]) {
    if (!existingIds.has(key)) {
      await setDoc(doc(db, "fare_rules", key), DEFAULT_FARE_RULES[key]);
    }
  }
}
