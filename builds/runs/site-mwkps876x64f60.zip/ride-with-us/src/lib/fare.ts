import { FareRule, ServiceType } from "@/types/rideWithUs";

export const DEFAULT_FARE_RULES: Record<ServiceType, FareRule> = {
  Bike: {
    serviceType: "Bike",
    baseFarePkr: 60,
    perKmPkr: 22,
    perMinPkr: 3,
    minimumFarePkr: 90,
    commissionPercent: 15,
    active: true,
    description: "Fast solo rides through traffic",
    etaMinutesBase: 3,
  },
  Rickshaw: {
    serviceType: "Rickshaw",
    baseFarePkr: 90,
    perKmPkr: 32,
    perMinPkr: 4,
    minimumFarePkr: 140,
    commissionPercent: 15,
    active: true,
    description: "Affordable open-air city rides (up to 3)",
    etaMinutesBase: 4,
  },
  Car: {
    serviceType: "Car",
    baseFarePkr: 160,
    perKmPkr: 48,
    perMinPkr: 6,
    minimumFarePkr: 250,
    commissionPercent: 20,
    active: true,
    description: "AC comfort for 1–4 passengers",
    etaMinutesBase: 5,
  },
};

export function calculateFarePkr(
  distanceKm: number,
  durationMin: number,
  rule: FareRule
) {
  const raw =
    rule.baseFarePkr + distanceKm * rule.perKmPkr + durationMin * rule.perMinPkr;
  const totalPkr = Math.max(rule.minimumFarePkr, Math.round(raw / 5) * 5);
  const commissionPkr = Math.round((totalPkr * rule.commissionPercent) / 100);
  const driverNetPkr = totalPkr - commissionPkr;

  return { totalPkr, commissionPkr, driverNetPkr };
}

export function formatPkr(amount: number): string {
  return `PKR ${Math.round(amount).toLocaleString("en-PK")}`;
}
