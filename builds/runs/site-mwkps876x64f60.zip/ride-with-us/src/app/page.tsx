"use client";

import React from "react";
import Link from "next/link";
import {
  ArrowRight,
  Bike,
  Car,
  CheckCircle2,
  MapPin,
  Shield,
  Sparkles,
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/context/AuthContext";
import { formatPkr } from "@/lib/fare";
import { ServiceType } from "@/types/rideWithUs";

export default function HomePage() {
  const { settings, fareRules, profile } = useAuth();

  const iconFor = (s: ServiceType) => {
    if (s === "Bike") return <Bike className="h-7 w-7 text-emerald-400" />;
    if (s === "Rickshaw") return <Sparkles className="h-7 w-7 text-amber-400" />;
    return <Car className="h-7 w-7 text-sky-400" />;
  };

  const primaryHref =
    profile?.role === "driver"
      ? "/driver"
      : profile?.role === "admin"
      ? "/admin"
      : "/customer";

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Navbar />

      <main className="mx-auto max-w-7xl px-4 py-12 sm:py-16">
        <section className="grid items-center gap-10 lg:grid-cols-2">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3.5 py-1 text-xs font-semibold text-emerald-400">
              <MapPin className="h-3.5 w-3.5" />
              Built for Pakistan • Fares in {settings.currency}
            </span>
            <h1 className="mt-5 text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
              {settings.app_name.toUpperCase()} — Move Smarter Across Your City
            </h1>
            <p className="mt-4 text-base text-slate-400 sm:text-lg">
              Book verified Bikes, Rickshaws, and AC Cars in seconds with live GPS
              tracking, transparent {settings.currency} fares, and instant driver matching.
            </p>

            <div className="mt-8 flex flex-wrap gap-4">
              <Link
                href={profile ? primaryHref : "/signup"}
                className="inline-flex items-center gap-2 rounded-xl bg-emerald-500 px-6 py-3.5 text-sm font-bold text-slate-950 shadow-lg shadow-emerald-500/25 transition hover:bg-emerald-400"
              >
                {profile ? "Open My Dashboard" : "Book Your First Ride"}
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                href="/signup?role=driver"
                className="inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-6 py-3.5 text-sm font-semibold text-white transition hover:border-emerald-500/50"
              >
                Drive & Earn in {settings.currency}
              </Link>
            </div>

            <div className="mt-8 grid grid-cols-3 gap-4 border-t border-slate-800 pt-6 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                Verified Drivers
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                Live Map Tracking
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-emerald-400" />
                Upfront {settings.currency} Fares
              </div>
            </div>
          </div>

          <div className="grid gap-4">
            {settings.services.map((service) => {
              const rule = fareRules[service];
              return (
                <div
                  key={service}
                  className="flex items-center justify-between rounded-2xl border border-slate-800 bg-slate-900/80 p-5 transition hover:border-emerald-500/40"
                >
                  <div className="flex items-center gap-4">
                    <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-slate-950 ring-1 ring-slate-800">
                      {iconFor(service)}
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-white">{service}</h3>
                      <p className="text-xs text-slate-400">
                        {rule?.description || "Reliable city ride"}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="block text-xs text-slate-400">Starts at</span>
                    <span className="text-lg font-extrabold text-emerald-400">
                      {formatPkr(rule?.minimumFarePkr || 100)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </main>
    </div>
  );
}
