"use client";

import React, { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Autocomplete } from "@react-google-maps/api";
import {
  addDoc,
  collection,
  doc,
  onSnapshot,
  orderBy,
  query,
  updateDoc,
  where,
} from "firebase/firestore";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import {
  Bike,
  Car,
  Clock,
  Crosshair,
  History,
  Loader2,
  MapPin,
  Navigation,
  Phone,
  Sparkles,
  Star,
  User,
  XCircle,
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { RideMap } from "@/components/RideMap";
import { useAuth } from "@/context/AuthContext";
import { calculateFarePkr, formatPkr } from "@/lib/fare";
import { db, storage } from "@/lib/firebase";
import { pushNotification } from "@/lib/notifications";
import { useGoogleMaps } from "@/lib/useGoogleMaps";
import {
  DriverProfile,
  LatLngPoint,
  RideRecord,
  ServiceType,
} from "@/types/rideWithUs";

export default function CustomerPage() {
  const router = useRouter();
  const { firebaseUser, profile, settings, fareRules, loading } = useAuth();
  const { isLoaded: mapsLoaded } = useGoogleMaps();

  const [tab, setTab] = useState<"book" | "history" | "profile">("book");
  const [pickup, setPickup] = useState<LatLngPoint | null>(null);
  const [dropoff, setDropoff] = useState<LatLngPoint | null>(null);
  const [pickupText, setPickupText] = useState("");
  const [dropoffText, setDropoffText] = useState("");
  const [selectMode, setSelectMode] = useState<"pickup" | "dropoff" | null>(null);

  const [distanceKm, setDistanceKm] = useState(0);
  const [durationMin, setDurationMin] = useState(0);
  const [selectedService, setSelectedService] = useState<ServiceType>("Bike");

  const [nearbyDrivers, setNearbyDrivers] = useState<DriverProfile[]>([]);
  const [rides, setRides] = useState<RideRecord[]>([]);
  const [requesting, setRequesting] = useState(false);
  const [error, setError] = useState("");

  // Review state
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [submittingReview, setSubmittingReview] = useState(false);

  // Profile edit state
  const [editName, setEditName] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);

  const pickupAutoRef = useRef<google.maps.places.Autocomplete | null>(null);
  const dropoffAutoRef = useRef<google.maps.places.Autocomplete | null>(null);

  useEffect(() => {
    if (!loading && !firebaseUser) router.push("/login");
  }, [loading, firebaseUser, router]);

  useEffect(() => {
    if (profile) {
      setEditName(profile.fullName);
      setEditPhone(profile.phone);
    }
  }, [profile]);

  // Listen to online approved drivers
  useEffect(() => {
    if (!firebaseUser) return;
    const dq = query(
      collection(db, "drivers"),
      where("approvalStatus", "==", "approved"),
      where("isOnline", "==", true)
    );
    return onSnapshot(dq, (snap) => {
      setNearbyDrivers(snap.docs.map((d) => d.data() as DriverProfile));
    });
  }, [firebaseUser]);

  // Listen to customer's rides in real time
  useEffect(() => {
    if (!firebaseUser) return;
    const rq = query(
      collection(db, "rides"),
      where("customerId", "==", firebaseUser.uid),
      orderBy("createdAt", "desc")
    );
    return onSnapshot(rq, (snap) => {
      setRides(
        snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<RideRecord, "id">),
        }))
      );
    });
  }, [firebaseUser]);

  const activeRide = rides.find((r) =>
    ["requested", "accepted", "arrived", "in_progress"].includes(r.status)
  );
  const unreviewedCompletedRide = rides.find(
    (r) => r.status === "completed" && !r.hasReviewed
  );

  const useMyLocation = () => {
    if (!navigator.geolocation) {
      setError("Geolocation is not supported by your browser.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const pt: LatLngPoint = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          address: "Current GPS Location",
        };
        setPickup(pt);
        setPickupText("Current GPS Location");
        setError("");
      },
      () => setError("Unable to retrieve your GPS location. Please search or click map.")
    );
  };

  const handleRequestRide = async () => {
    if (!firebaseUser || !profile || !pickup || !dropoff || distanceKm <= 0) {
      setError("Please select both Pickup and Destination on the map.");
      return;
    }
    setError("");
    setRequesting(true);

    try {
      const rule = fareRules[selectedService];
      const { totalPkr, commissionPkr, driverNetPkr } = calculateFarePkr(
        distanceKm,
        durationMin,
        rule
      );

      const rideRef = await addDoc(collection(db, "rides"), {
        customerId: firebaseUser.uid,
        customerName: profile.fullName,
        customerPhone: profile.phone,
        serviceType: selectedService,
        pickup,
        dropoff,
        distanceKm,
        durationMin,
        estimatedFarePkr: totalPkr,
        commissionPkr,
        driverNetPkr,
        paymentMethod: "cash",
        paymentStatus: "pending",
        status: "requested",
        hasReviewed: false,
        createdAt: new Date().toISOString(),
      });

      const matchingDrivers = nearbyDrivers.filter(
        (d) => d.vehicleType === selectedService
      );
      await Promise.all(
        matchingDrivers.slice(0, 10).map((d) =>
          pushNotification(
            d.uid,
            `New ${selectedService} Ride Request`,
            `${pickup.address || "Pickup"} → ${dropoff.address || "Dropoff"} (${formatPkr(totalPkr)})`,
            rideRef.id
          )
        )
      );
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Could not create ride request.");
    } finally {
      setRequesting(false);
    }
  };

  const handleCancelRide = async (ride: RideRecord) => {
    await updateDoc(doc(db, "rides", ride.id), {
      status: "cancelled",
      cancelledBy: "customer",
      cancelReason: "Cancelled by customer",
    });
    if (ride.driverId) {
      await pushNotification(
        ride.driverId,
        "Ride Cancelled",
        `${profile?.fullName || "Customer"} cancelled the ride.`,
        ride.id
      );
    }
  };

  const handleSubmitReview = async (ride: RideRecord) => {
    if (!firebaseUser || !profile || !ride.driverId) return;
    setSubmittingReview(true);
    try {
      await addDoc(collection(db, "reviews"), {
        rideId: ride.id,
        customerId: firebaseUser.uid,
        customerName: profile.fullName,
        driverId: ride.driverId,
        rating,
        comment: comment.trim() || "Great ride!",
        createdAt: new Date().toISOString(),
      });
      await updateDoc(doc(db, "rides", ride.id), { hasReviewed: true });
      await pushNotification(
        ride.driverId,
        "New Rider Rating",
        `You received ${rating}★ from ${profile.fullName}.`,
        ride.id
      );
      setComment("");
      setRating(5);
    } finally {
      setSubmittingReview(false);
    }
  };

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser) return;
    setSavingProfile(true);
    try {
      await updateDoc(doc(db, "users", firebaseUser.uid), {
        fullName: editName.trim(),
        phone: editPhone.trim(),
      });
    } finally {
      setSavingProfile(false);
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !firebaseUser) return;
    const storageRef = ref(storage, `avatars/${firebaseUser.uid}/${Date.now()}_${file.name}`);
    await uploadBytes(storageRef, file);
    const url = await getDownloadURL(storageRef);
    await updateDoc(doc(db, "users", firebaseUser.uid), { avatarUrl: url });
  };

  if (loading || !profile) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 text-slate-400">
        <Loader2 className="mr-2 h-5 w-5 animate-spin text-emerald-500" />
        Loading Customer Portal...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Navbar />

      <div className="mx-auto max-w-7xl px-4 py-6">
        {/* Tabs */}
        <div className="mb-6 flex flex-wrap gap-2">
          <button
            onClick={() => setTab("book")}
            className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition ${
              tab === "book"
                ? "bg-emerald-500 text-slate-950"
                : "border border-slate-800 bg-slate-900 text-slate-300 hover:text-white"
            }`}
          >
            <Navigation className="h-4 w-4" /> Book & Live Track
          </button>
          <button
            onClick={() => setTab("history")}
            className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition ${
              tab === "history"
                ? "bg-emerald-500 text-slate-950"
                : "border border-slate-800 bg-slate-900 text-slate-300 hover:text-white"
            }`}
          >
            <History className="h-4 w-4" /> Ride History ({rides.length})
          </button>
          <button
            onClick={() => setTab("profile")}
            className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition ${
              tab === "profile"
                ? "bg-emerald-500 text-slate-950"
                : "border border-slate-800 bg-slate-900 text-slate-300 hover:text-white"
            }`}
          >
            <User className="h-4 w-4" /> Profile
          </button>
        </div>

        {/* Review Modal Banner for just-completed ride */}
        {unreviewedCompletedRide && !activeRide && (
          <div className="mb-6 rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-5">
            <h3 className="text-base font-bold text-white">
              Rate Your Completed Ride with {unreviewedCompletedRide.driverName}
            </h3>
            <p className="mt-1 text-xs text-slate-300">
              Final Fare:{" "}
              <strong className="text-emerald-400">
                {formatPkr(
                  unreviewedCompletedRide.finalFarePkr ||
                    unreviewedCompletedRide.estimatedFarePkr
                )}
              </strong>
            </p>
            <div className="mt-3 flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  className="p-1"
                >
                  <Star
                    className={`h-6 w-6 ${
                      star <= rating
                        ? "fill-amber-400 text-amber-400"
                        : "text-slate-600"
                    }`}
                  />
                </button>
              ))}
            </div>
            <div className="mt-3 flex flex-col gap-3 sm:flex-row">
              <input
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Write feedback about your driver..."
                className="flex-1 rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white outline-none"
              />
              <button
                disabled={submittingReview}
                onClick={() => handleSubmitReview(unreviewedCompletedRide)}
                className="rounded-xl bg-emerald-500 px-5 py-2 text-sm font-bold text-slate-950 hover:bg-emerald-400"
              >
                {submittingReview ? "Saving..." : "Submit Review"}
              </button>
            </div>
          </div>
        )}

        {tab === "book" && (
          <div className="grid gap-6 lg:grid-cols-12">
            {/* Left Panel */}
            <div className="space-y-4 lg:col-span-5">
              {activeRide ? (
                <div className="rounded-2xl border border-emerald-500/40 bg-slate-900 p-5 shadow-xl">
                  <div className="flex items-center justify-between">
                    <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-bold uppercase text-emerald-400">
                      Status: {activeRide.status.replace("_", " ")}
                    </span>
                    <span className="text-base font-extrabold text-white">
                      {formatPkr(activeRide.estimatedFarePkr)}
                    </span>
                  </div>

                  <div className="mt-4 space-y-2 text-xs text-slate-300">
                    <p>
                      <strong className="text-slate-400">Service:</strong>{" "}
                      {activeRide.serviceType}
                    </p>
                    <p>
                      <strong className="text-slate-400">Pickup:</strong>{" "}
                      {activeRide.pickup.address}
                    </p>
                    <p>
                      <strong className="text-slate-400">Dropoff:</strong>{" "}
                      {activeRide.dropoff.address}
                    </p>
                    <p>
                      <strong className="text-slate-400">Trip:</strong>{" "}
                      {activeRide.distanceKm} km • ~{activeRide.durationMin} min
                    </p>
                  </div>

                  {activeRide.driverId ? (
                    <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950 p-4">
                      <p className="text-xs font-semibold uppercase text-emerald-400">
                        Driver Assigned
                      </p>
                      <p className="mt-1 text-base font-bold text-white">
                        {activeRide.driverName}
                      </p>
                      <p className="text-xs text-slate-400">{activeRide.vehicleInfo}</p>
                      {activeRide.driverPhone && (
                        <a
                          href={`tel:${activeRide.driverPhone}`}
                          className="mt-3 inline-flex items-center gap-2 rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-semibold text-white hover:bg-slate-700"
                        >
                          <Phone className="h-3.5 w-3.5 text-emerald-400" />
                          {activeRide.driverPhone}
                        </a>
                      )}
                    </div>
                  ) : (
                    <div className="mt-4 flex items-center gap-3 rounded-xl border border-slate-800 bg-slate-950 p-4 text-xs text-slate-300">
                      <Loader2 className="h-5 w-5 animate-spin text-emerald-400" />
                      Finding available {activeRide.serviceType} drivers nearby...
                    </div>
                  )}

                  {["requested", "accepted"].includes(activeRide.status) && (
                    <button
                      onClick={() => handleCancelRide(activeRide)}
                      className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-red-500/40 bg-red-500/10 py-2.5 text-sm font-semibold text-red-400 hover:bg-red-500/20"
                    >
                      <XCircle className="h-4 w-4" /> Cancel Ride
                    </button>
                  )}
                </div>
              ) : (
                <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5 shadow-xl">
                  <h2 className="text-lg font-extrabold text-white">
                    Where are you going?
                  </h2>
                  {error && (
                    <div className="mt-3 rounded-xl border border-red-500/40 bg-red-500/10 p-3 text-xs text-red-300">
                      {error}
                    </div>
                  )}

                  <div className="mt-4 space-y-3">
                    <div>
                      <div className="mb-1 flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-300">
                          Pickup Location
                        </span>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={useMyLocation}
                            className="flex items-center gap-1 text-emerald-400 hover:underline"
                          >
                            <Crosshair className="h-3 w-3" /> GPS
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setSelectMode(selectMode === "pickup" ? null : "pickup")
                            }
                            className="text-sky-400 hover:underline"
                          >
                            {selectMode === "pickup" ? "Cancel Pin" : "Pin on Map"}
                          </button>
                        </div>
                      </div>
                      {mapsLoaded ? (
                        <Autocomplete
                          options={{ componentRestrictions: { country: "pk" } }}
                          onLoad={(a) => (pickupAutoRef.current = a)}
                          onPlaceChanged={() => {
                            const place = pickupAutoRef.current?.getPlace();
                            const loc = place?.geometry?.location;
                            if (loc) {
                              const addr = place.formatted_address || place.name || "";
                              setPickup({ lat: loc.lat(), lng: loc.lng(), address: addr });
                              setPickupText(addr);
                            }
                          }}
                        >
                          <input
                            value={pickupText}
                            onChange={(e) => setPickupText(e.target.value)}
                            placeholder="Search pickup in Pakistan..."
                            className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white outline-none focus:border-emerald-500"
                          />
                        </Autocomplete>
                      ) : (
                        <input
                          disabled
                          placeholder="Waiting for Google Maps..."
                          className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm text-slate-500"
                        />
                      )}
                    </div>

                    <div>
                      <div className="mb-1 flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-300">
                          Destination
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setSelectMode(selectMode === "dropoff" ? null : "dropoff")
                          }
                          className="text-sky-400 hover:underline"
                        >
                          {selectMode === "dropoff" ? "Cancel Pin" : "Pin on Map"}
                        </button>
                      </div>
                      {mapsLoaded ? (
                        <Autocomplete
                          options={{ componentRestrictions: { country: "pk" } }}
                          onLoad={(a) => (dropoffAutoRef.current = a)}
                          onPlaceChanged={() => {
                            const place = dropoffAutoRef.current?.getPlace();
                            const loc = place?.geometry?.location;
                            if (loc) {
                              const addr = place.formatted_address || place.name || "";
                              setDropoff({ lat: loc.lat(), lng: loc.lng(), address: addr });
                              setDropoffText(addr);
                            }
                          }}
                        >
                          <input
                            value={dropoffText}
                            onChange={(e) => setDropoffText(e.target.value)}
                            placeholder="Search destination in Pakistan..."
                            className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white outline-none focus:border-emerald-500"
                          />
                        </Autocomplete>
                      ) : (
                        <input
                          disabled
                          placeholder="Waiting for Google Maps..."
                          className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm text-slate-500"
                        />
                      )}
                    </div>
                  </div>

                  {distanceKm > 0 && (
                    <div className="mt-4 flex items-center justify-between rounded-xl bg-slate-950 px-3.5 py-2.5 text-xs text-slate-300">
                      <span className="flex items-center gap-1.5">
                        <MapPin className="h-3.5 w-3.5 text-emerald-400" />
                        {distanceKm} km
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Clock className="h-3.5 w-3.5 text-emerald-400" />
                        ~{durationMin} min
                      </span>
                    </div>
                  )}

                  {/* Service Cards */}
                  <div className="mt-4 space-y-2.5">
                    {settings.services.map((service) => {
                      const rule = fareRules[service];
                      if (rule && !rule.active) return null;
                      const est =
                        distanceKm > 0
                          ? calculateFarePkr(distanceKm, durationMin, rule).totalPkr
                          : rule.minimumFarePkr;
                      const availCount = nearbyDrivers.filter(
                        (d) => d.vehicleType === service
                      ).length;
                      const active = selectedService === service;

                      return (
                        <button
                          key={service}
                          type="button"
                          onClick={() => setSelectedService(service)}
                          className={`flex w-full items-center justify-between rounded-xl border p-3.5 text-left transition ${
                            active
                              ? "border-emerald-500 bg-emerald-500/10"
                              : "border-slate-800 bg-slate-950 hover:border-slate-700"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-900">
                              {service === "Bike" ? (
                                <Bike className="h-5 w-5 text-emerald-400" />
                              ) : service === "Rickshaw" ? (
                                <Sparkles className="h-5 w-5 text-amber-400" />
                              ) : (
                                <Car className="h-5 w-5 text-sky-400" />
                              )}
                            </div>
                            <div>
                              <p className="text-sm font-bold text-white">{service}</p>
                              <p className="text-[11px] text-slate-400">
                                {availCount} online nearby • {rule.etaMinutesBase} min ETA
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-extrabold text-emerald-400">
                              {formatPkr(est)}
                            </p>
                            <p className="text-[10px] text-slate-500">
                              {distanceKm > 0 ? "Est. Fare" : "Min. Fare"}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  <button
                    type="button"
                    disabled={requesting || !pickup || !dropoff || distanceKm <= 0}
                    onClick={handleRequestRide}
                    className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3.5 text-sm font-bold text-slate-950 shadow-lg shadow-emerald-500/20 transition hover:bg-emerald-400 disabled:opacity-40"
                  >
                    {requesting && <Loader2 className="h-4 w-4 animate-spin" />}
                    Request {selectedService} Now
                  </button>
                </div>
              )}
            </div>

            {/* Right Panel: Interactive Map */}
            <div className="lg:col-span-7">
              <RideMap
                pickup={activeRide ? activeRide.pickup : pickup}
                dropoff={activeRide ? activeRide.dropoff : dropoff}
                driverLocation={activeRide?.driverLocation || null}
                nearbyDrivers={nearbyDrivers}
                selectMode={activeRide ? null : selectMode}
                onMapSelect={(pt) => {
                  if (selectMode === "pickup") {
                    setPickup(pt);
                    setPickupText(pt.address || "");
                  } else if (selectMode === "dropoff") {
                    setDropoff(pt);
                    setDropoffText(pt.address || "");
                  }
                  setSelectMode(null);
                }}
                onRouteCalculated={(km, min) => {
                  setDistanceKm(km);
                  setDurationMin(min);
                }}
              />
            </div>
          </div>
        )}

        {tab === "history" && (
          <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
            <h2 className="text-lg font-bold text-white">Your Ride History</h2>
            {rides.length === 0 ? (
              <p className="mt-6 text-sm text-slate-400">You have not booked any rides yet.</p>
            ) : (
              <div className="mt-4 space-y-3">
                {rides.map((r) => (
                  <div
                    key={r.id}
                    className="flex flex-col justify-between gap-3 rounded-xl border border-slate-800 bg-slate-950 p-4 sm:flex-row sm:items-center"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="rounded-md bg-slate-800 px-2 py-0.5 text-xs font-bold text-white">
                          {r.serviceType}
                        </span>
                        <span className="text-xs font-semibold uppercase text-emerald-400">
                          {r.status}
                        </span>
                        <span className="text-xs text-slate-500">
                          {new Date(r.createdAt).toLocaleString()}
                        </span>
                      </div>
                      <p className="mt-1.5 text-xs text-slate-300">
                        {r.pickup.address} → {r.dropoff.address}
                      </p>
                      {r.driverName && (
                        <p className="mt-1 text-[11px] text-slate-400">
                          Driver: {r.driverName} ({r.vehicleInfo})
                        </p>
                      )}
                    </div>
                    <div className="text-right">
                      <p className="text-base font-extrabold text-emerald-400">
                        {formatPkr(r.finalFarePkr || r.estimatedFarePkr)}
                      </p>
                      <p className="text-[11px] text-slate-500">{r.distanceKm} km</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === "profile" && (
          <div className="mx-auto max-w-lg rounded-2xl border border-slate-800 bg-slate-900 p-6">
            <h2 className="text-lg font-bold text-white">Customer Profile</h2>
            <div className="mt-4 flex items-center gap-4">
              <img
                src={
                  profile.avatarUrl ||
                  "https://ui-avatars.com/api/?name=" + encodeURIComponent(profile.fullName)
                }
                alt={profile.fullName}
                className="h-16 w-16 rounded-full border border-slate-700 object-cover"
              />
              <label className="cursor-pointer rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-xs font-semibold text-slate-200 hover:border-emerald-500">
                Upload Photo
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarUpload}
                  className="hidden"
                />
              </label>
            </div>

            <form onSubmit={handleProfileSave} className="mt-5 space-y-4">
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-300">
                  Full Name
                </label>
                <input
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white outline-none"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-300">
                  Phone Number
                </label>
                <input
                  value={editPhone}
                  onChange={(e) => setEditPhone(e.target.value)}
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white outline-none"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-300">
                  Email (Read-Only)
                </label>
                <input
                  disabled
                  value={profile.email}
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm text-slate-500"
                />
              </div>
              <button
                type="submit"
                disabled={savingProfile}
                className="w-full rounded-xl bg-emerald-500 py-2.5 text-sm font-bold text-slate-950 hover:bg-emerald-400"
              >
                {savingProfile ? "Saving..." : "Save Profile"}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
