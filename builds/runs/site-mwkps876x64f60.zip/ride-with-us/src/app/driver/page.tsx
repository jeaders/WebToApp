"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  addDoc,
  collection,
  doc,
  getDoc,
  increment,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  updateDoc,
  where,
} from "firebase/firestore";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  DollarSign,
  FileCheck,
  History,
  Loader2,
  Navigation,
  Phone,
  Power,
  ShieldAlert,
  Star,
  Upload,
  XCircle,
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { RideMap } from "@/components/RideMap";
import { useAuth } from "@/context/AuthContext";
import { formatPkr } from "@/lib/fare";
import { db, storage } from "@/lib/firebase";
import { pushNotification } from "@/lib/notifications";
import {
  DriverPrivateDocs,
  DriverProfile,
  ReviewRecord,
  RideRecord,
  ServiceType,
} from "@/types/rideWithUs";

export default function DriverPage() {
  const router = useRouter();
  const { firebaseUser, profile, settings, loading } = useAuth();

  const [driverProfile, setDriverProfile] = useState<DriverProfile | null>(null);
  const [driverLoading, setDriverLoading] = useState(true);
  const [tab, setTab] = useState<"console" | "earnings" | "history">("console");

  // Onboarding form
  const [vehicleType, setVehicleType] = useState<ServiceType>("Bike");
  const [vehicleModel, setVehicleModel] = useState("");
  const [vehiclePlate, setVehiclePlate] = useState("");
  const [vehicleColor, setVehicleColor] = useState("");
  const [cnicNumber, setCnicNumber] = useState("");
  const [licenseNumber, setLicenseNumber] = useState("");
  const [cnicFile, setCnicFile] = useState<File | null>(null);
  const [licenseFile, setLicenseFile] = useState<File | null>(null);
  const [regFile, setRegFile] = useState<File | null>(null);
  const [submittingDocs, setSubmittingDocs] = useState(false);
  const [formError, setFormError] = useState("");

  // Operational state
  const [openRequests, setOpenRequests] = useState<RideRecord[]>([]);
  const [rejectedIds, setRejectedIds] = useState<string[]>([]);
  const [myRides, setMyRides] = useState<RideRecord[]>([]);
  const [reviews, setReviews] = useState<ReviewRecord[]>([]);
  const [actionBusy, setActionBusy] = useState(false);
  const [gpsError, setGpsError] = useState("");

  useEffect(() => {
    if (!loading && !firebaseUser) router.push("/login");
    if (!loading && profile && profile.role === "customer") router.push("/customer");
  }, [loading, firebaseUser, profile, router]);

  // Listen to Driver Profile
  useEffect(() => {
    if (!firebaseUser) return;
    return onSnapshot(doc(db, "drivers", firebaseUser.uid), (snap) => {
      setDriverProfile(snap.exists() ? (snap.data() as DriverProfile) : null);
      setDriverLoading(false);
    });
  }, [firebaseUser]);

  // Listen to My Rides
  useEffect(() => {
    if (!firebaseUser) return;
    const q = query(
      collection(db, "rides"),
      where("driverId", "==", firebaseUser.uid),
      orderBy("createdAt", "desc")
    );
    return onSnapshot(q, (snap) => {
      setMyRides(
        snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<RideRecord, "id">),
        }))
      );
    });
  }, [firebaseUser]);

  // Listen to Reviews
  useEffect(() => {
    if (!firebaseUser) return;
    const q = query(
      collection(db, "reviews"),
      where("driverId", "==", firebaseUser.uid)
    );
    return onSnapshot(q, (snap) => {
      setReviews(
        snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<ReviewRecord, "id">),
        }))
      );
    });
  }, [firebaseUser]);

  // Listen to Incoming Requests matching vehicleType when Approved & Online
  useEffect(() => {
    if (
      !firebaseUser ||
      !driverProfile ||
      driverProfile.approvalStatus !== "approved" ||
      !driverProfile.isOnline
    ) {
      setOpenRequests([]);
      return;
    }

    const q = query(
      collection(db, "rides"),
      where("status", "==", "requested"),
      where("serviceType", "==", driverProfile.vehicleType),
      orderBy("createdAt", "desc")
    );

    return onSnapshot(q, (snap) => {
      setOpenRequests(
        snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<RideRecord, "id">),
        }))
      );
    });
  }, [firebaseUser, driverProfile]);

  const activeRide = myRides.find((r) =>
    ["accepted", "arrived", "in_progress"].includes(r.status)
  );

  // Live GPS Watch when Approved & Online
  useEffect(() => {
    if (
      !firebaseUser ||
      !driverProfile ||
      driverProfile.approvalStatus !== "approved" ||
      !driverProfile.isOnline
    ) {
      return;
    }
    if (!navigator.geolocation) {
      setGpsError("Geolocation is not supported by your browser.");
      return;
    }

    const watchId = navigator.geolocation.watchPosition(
      async (pos) => {
        setGpsError("");
        const coords = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        };
        await updateDoc(doc(db, "drivers", firebaseUser.uid), {
          currentLocation: { ...coords, updatedAt: new Date().toISOString() },
        });
        if (activeRide) {
          await updateDoc(doc(db, "rides", activeRide.id), {
            driverLocation: coords,
          });
        }
      },
      () => setGpsError("Enable location permissions so riders can see your live position."),
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, [firebaseUser, driverProfile?.approvalStatus, driverProfile?.isOnline, activeRide?.id]);

  const uploadDocFile = async (uid: string, label: string, file: File) => {
    const r = ref(storage, `drivers/${uid}/documents/${label}_${Date.now()}_${file.name}`);
    await uploadBytes(r, file);
    return getDownloadURL(r);
  };

  const handleOnboardingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser || !profile) return;
    if (!cnicFile || !licenseFile || !regFile) {
      setFormError("Please upload all 3 required documents (CNIC, License, Vehicle Registration).");
      return;
    }

    setFormError("");
    setSubmittingDocs(true);

    try {
      const [cnicFrontUrl, licenseUrl, vehicleRegUrl] = await Promise.all([
        uploadDocFile(firebaseUser.uid, "cnic", cnicFile),
        uploadDocFile(firebaseUser.uid, "license", licenseFile),
        uploadDocFile(firebaseUser.uid, "registration", regFile),
      ]);

      const driverDoc: DriverProfile = {
        uid: firebaseUser.uid,
        fullName: profile.fullName,
        phone: profile.phone,
        vehicleType,
        vehicleModel: vehicleModel.trim(),
        vehiclePlate: vehiclePlate.trim().toUpperCase(),
        vehicleColor: vehicleColor.trim(),
        approvalStatus: "pending",
        isOnline: false,
        ratingAvg: 5,
        ratingCount: 0,
        totalRides: 0,
        totalEarningsPkr: 0,
        createdAt: new Date().toISOString(),
      };

      const privateDocs: DriverPrivateDocs = {
        cnicNumber: cnicNumber.trim(),
        licenseNumber: licenseNumber.trim(),
        cnicFrontUrl,
        licenseUrl,
        vehicleRegUrl,
        submittedAt: new Date().toISOString(),
      };

      await setDoc(doc(db, "drivers", firebaseUser.uid), driverDoc);
      await setDoc(
        doc(db, "drivers", firebaseUser.uid, "private_docs", "documents"),
        privateDocs
      );
    } catch (err: unknown) {
      setFormError(err instanceof Error ? err.message : "Failed to submit documents.");
    } finally {
      setSubmittingDocs(false);
    }
  };

  const toggleOnline = async () => {
    if (!firebaseUser || !driverProfile) return;
    if (driverProfile.approvalStatus !== "approved") return;
    await updateDoc(doc(db, "drivers", firebaseUser.uid), {
      isOnline: !driverProfile.isOnline,
    });
  };

  const handleAcceptRide = async (ride: RideRecord) => {
    if (!firebaseUser || !driverProfile || activeRide) return;
    setActionBusy(true);
    try {
      const fresh = await getDoc(doc(db, "rides", ride.id));
      if (!fresh.exists() || fresh.data().status !== "requested") {
        return;
      }
      await updateDoc(doc(db, "rides", ride.id), {
        status: "accepted",
        driverId: firebaseUser.uid,
        driverName: driverProfile.fullName,
        driverPhone: driverProfile.phone,
        vehicleInfo: `${driverProfile.vehicleColor} ${driverProfile.vehicleModel} (${driverProfile.vehiclePlate})`,
        driverLocation: driverProfile.currentLocation
          ? {
              lat: driverProfile.currentLocation.lat,
              lng: driverProfile.currentLocation.lng,
            }
          : null,
        acceptedAt: new Date().toISOString(),
      });

      await pushNotification(
        ride.customerId,
        "Driver Accepted Your Ride",
        `${driverProfile.fullName} (${driverProfile.vehicleModel} • ${driverProfile.vehiclePlate}) is on the way.`,
        ride.id
      );
    } finally {
      setActionBusy(false);
    }
  };

  const handleUpdateRideStatus = async (
    ride: RideRecord,
    nextStatus: "arrived" | "in_progress" | "completed" | "cancelled"
  ) => {
    if (!firebaseUser) return;
    setActionBusy(true);
    try {
      const updates: Record<string, unknown> = { status: nextStatus };

      if (nextStatus === "in_progress") {
        updates.startedAt = new Date().toISOString();
      }

      if (nextStatus === "cancelled") {
        updates.cancelledBy = "driver";
        updates.cancelReason = "Cancelled by driver";
      }

      if (nextStatus === "completed") {
        const finalFare = ride.estimatedFarePkr;
        const commission = ride.commissionPkr || Math.round(finalFare * 0.15);
        const driverNet = ride.driverNetPkr || finalFare - commission;

        updates.completedAt = new Date().toISOString();
        updates.finalFarePkr = finalFare;
        updates.paymentStatus = "paid";

        await addDoc(collection(db, "payments"), {
          rideId: ride.id,
          customerId: ride.customerId,
          driverId: firebaseUser.uid,
          serviceType: ride.serviceType,
          amountPkr: finalFare,
          commissionPkr: commission,
          driverNetPkr: driverNet,
          method: "cash",
          status: "settled",
          createdAt: new Date().toISOString(),
        });

        await updateDoc(doc(db, "drivers", firebaseUser.uid), {
          totalRides: increment(1),
          totalEarningsPkr: increment(driverNet),
        });
      }

      await updateDoc(doc(db, "rides", ride.id), updates);

      const titleMap: Record<string, string> = {
        arrived: "Driver Arrived",
        in_progress: "Ride Started",
        completed: "Ride Completed",
        cancelled: "Ride Cancelled",
      };
      await pushNotification(
        ride.customerId,
        titleMap[nextStatus],
        nextStatus === "completed"
          ? `Ride completed. Fare: ${formatPkr(ride.estimatedFarePkr)}. Please rate your driver.`
          : `Your ride status is now: ${nextStatus.replace("_", " ")}.`,
        ride.id
      );
    } finally {
      setActionBusy(false);
    }
  };

  if (loading || driverLoading || !profile) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 text-slate-400">
        <Loader2 className="mr-2 h-5 w-5 animate-spin text-emerald-500" />
        Loading Driver Portal...
      </div>
    );
  }

  const completedRides = myRides.filter((r) => r.status === "completed");
  const avgReview =
    reviews.length > 0
      ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
      : "5.0";
  const todayStr = new Date().toISOString().slice(0, 10);
  const todayEarnings = completedRides
    .filter((r) => (r.completedAt || r.createdAt).startsWith(todayStr))
    .reduce((sum, r) => sum + (r.driverNetPkr || r.estimatedFarePkr), 0);

  const visibleRequests = openRequests.filter((r) => !rejectedIds.includes(r.id));

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Navbar />

      <div className="mx-auto max-w-7xl px-4 py-6">
        {/* Step 1: Vehicle & Document Registration if not submitted yet */}
        {!driverProfile ? (
          <div className="mx-auto max-w-2xl rounded-2xl border border-slate-800 bg-slate-900 p-7 shadow-xl">
            <h1 className="text-2xl font-extrabold text-white">
              Driver & Vehicle Registration
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              Register your vehicle and upload KYC documents for admin approval.
            </p>

            {formError && (
              <div className="mt-4 rounded-xl border border-red-500/40 bg-red-500/10 p-3 text-xs text-red-300">
                {formError}
              </div>
            )}

            <form onSubmit={handleOnboardingSubmit} className="mt-6 space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-300">
                    Vehicle Type
                  </label>
                  <select
                    value={vehicleType}
                    onChange={(e) => setVehicleType(e.target.value as ServiceType)}
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white"
                  >
                    {settings.services.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-300">
                    Vehicle Model
                  </label>
                  <input
                    required
                    value={vehicleModel}
                    onChange={(e) => setVehicleModel(e.target.value)}
                    placeholder="Honda CD 70 / Suzuki Alto"
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-300">
                    Number Plate
                  </label>
                  <input
                    required
                    value={vehiclePlate}
                    onChange={(e) => setVehiclePlate(e.target.value)}
                    placeholder="LEA-2024"
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-300">
                    Vehicle Color
                  </label>
                  <input
                    required
                    value={vehicleColor}
                    onChange={(e) => setVehicleColor(e.target.value)}
                    placeholder="White / Red"
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-300">
                    CNIC Number
                  </label>
                  <input
                    required
                    value={cnicNumber}
                    onChange={(e) => setCnicNumber(e.target.value)}
                    placeholder="35202-1234567-1"
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-300">
                    Driving License Number
                  </label>
                  <input
                    required
                    value={licenseNumber}
                    onChange={(e) => setLicenseNumber(e.target.value)}
                    placeholder="DL-LHR-998877"
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white"
                  />
                </div>
              </div>

              <div className="grid gap-3 pt-2 sm:grid-cols-3">
                <label className="flex cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-slate-700 bg-slate-950 p-4 text-center hover:border-emerald-500">
                  <Upload className="mb-1.5 h-5 w-5 text-emerald-400" />
                  <span className="text-xs font-semibold text-white">CNIC Front</span>
                  <span className="mt-1 truncate text-[10px] text-slate-400">
                    {cnicFile ? cnicFile.name : "Image or PDF"}
                  </span>
                  <input
                    type="file"
                    accept="image/*,application/pdf"
                    onChange={(e) => setCnicFile(e.target.files?.[0] || null)}
                    className="hidden"
                  />
                </label>

                <label className="flex cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-slate-700 bg-slate-950 p-4 text-center hover:border-emerald-500">
                  <Upload className="mb-1.5 h-5 w-5 text-emerald-400" />
                  <span className="text-xs font-semibold text-white">License</span>
                  <span className="mt-1 truncate text-[10px] text-slate-400">
                    {licenseFile ? licenseFile.name : "Image or PDF"}
                  </span>
                  <input
                    type="file"
                    accept="image/*,application/pdf"
                    onChange={(e) => setLicenseFile(e.target.files?.[0] || null)}
                    className="hidden"
                  />
                </label>

                <label className="flex cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-slate-700 bg-slate-950 p-4 text-center hover:border-emerald-500">
                  <Upload className="mb-1.5 h-5 w-5 text-emerald-400" />
                  <span className="text-xs font-semibold text-white">Vehicle Reg</span>
                  <span className="mt-1 truncate text-[10px] text-slate-400">
                    {regFile ? regFile.name : "Image or PDF"}
                  </span>
                  <input
                    type="file"
                    accept="image/*,application/pdf"
                    onChange={(e) => setRegFile(e.target.files?.[0] || null)}
                    className="hidden"
                  />
                </label>
              </div>

              <button
                type="submit"
                disabled={submittingDocs}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3.5 text-sm font-bold text-slate-950 hover:bg-emerald-400 disabled:opacity-50"
              >
                {submittingDocs && <Loader2 className="h-4 w-4 animate-spin" />}
                Submit Vehicle & Documents for Approval
              </button>
            </form>
          </div>
        ) : driverProfile.approvalStatus !== "approved" ? (
          /* Step 2: Approval Gate */
          <div className="mx-auto max-w-lg rounded-2xl border border-amber-500/40 bg-slate-900 p-8 text-center">
            {driverProfile.approvalStatus === "pending" ? (
              <>
                <Clock className="mx-auto h-12 w-12 text-amber-400" />
                <h2 className="mt-4 text-xl font-extrabold text-white">
                  Pending Admin Approval
                </h2>
                <p className="mt-2 text-sm text-slate-400">
                  Your vehicle ({driverProfile.vehicleType} • {driverProfile.vehicleModel}{" "}
                  • {driverProfile.vehiclePlate}) and KYC documents have been submitted.
                  Once an admin approves your profile, you can go online and accept rides.
                </p>
              </>
            ) : (
              <>
                <ShieldAlert className="mx-auto h-12 w-12 text-red-400" />
                <h2 className="mt-4 text-xl font-extrabold text-white">
                  Application Rejected
                </h2>
                <p className="mt-2 text-sm text-red-300">
                  Reason: {driverProfile.rejectionReason || "Documents could not be verified."}
                </p>
              </>
            )}
          </div>
        ) : (
          /* Step 3: Approved Driver Operations Dashboard */
          <>
            {/* Top Status & Availability Bar */}
            <div className="mb-6 flex flex-col justify-between gap-4 rounded-2xl border border-slate-800 bg-slate-900 p-5 sm:flex-row sm:items-center">
              <div>
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-xs font-bold text-emerald-400">
                    <FileCheck className="h-3.5 w-3.5" /> Approved Driver
                  </span>
                  <span className="text-xs text-slate-400">
                    {driverProfile.vehicleType} • {driverProfile.vehicleModel} (
                    {driverProfile.vehiclePlate})
                  </span>
                </div>
                <h1 className="mt-1 text-xl font-extrabold text-white">
                  Hello, {driverProfile.fullName}
                </h1>
              </div>

              <button
                onClick={toggleOnline}
                className={`flex items-center justify-center gap-2 rounded-xl px-6 py-3 text-sm font-bold transition ${
                  driverProfile.isOnline
                    ? "bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/25"
                    : "border border-slate-700 bg-slate-950 text-slate-300 hover:border-emerald-500"
                }`}
              >
                <Power className="h-4 w-4" />
                {driverProfile.isOnline ? "ONLINE (Receiving Rides)" : "OFFLINE (Go Online)"}
              </button>
            </div>

            {gpsError && (
              <div className="mb-4 flex items-center gap-2 rounded-xl border border-amber-500/40 bg-amber-500/10 p-3 text-xs text-amber-300">
                <AlertCircle className="h-4 w-4 shrink-0" />
                {gpsError}
              </div>
            )}

            {/* Tabs */}
            <div className="mb-6 flex flex-wrap gap-2">
              <button
                onClick={() => setTab("console")}
                className={`flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold ${
                  tab === "console"
                    ? "bg-emerald-500 text-slate-950"
                    : "border border-slate-800 bg-slate-900 text-slate-300"
                }`}
              >
                <Navigation className="h-4 w-4" /> Ride Console
              </button>
              <button
                onClick={() => setTab("earnings")}
                className={`flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold ${
                  tab === "earnings"
                    ? "bg-emerald-500 text-slate-950"
                    : "border border-slate-800 bg-slate-900 text-slate-300"
                }`}
              >
                <DollarSign className="h-4 w-4" /> Earnings
              </button>
              <button
                onClick={() => setTab("history")}
                className={`flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold ${
                  tab === "history"
                    ? "bg-emerald-500 text-slate-950"
                    : "border border-slate-800 bg-slate-900 text-slate-300"
                }`}
              >
                <History className="h-4 w-4" /> Ride History ({myRides.length})
              </button>
            </div>

            {tab === "console" && (
              <div className="grid gap-6 lg:grid-cols-12">
                <div className="space-y-4 lg:col-span-5">
                  {activeRide ? (
                    <div className="rounded-2xl border border-emerald-500/40 bg-slate-900 p-5">
                      <div className="flex items-center justify-between">
                        <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-bold uppercase text-emerald-400">
                          {activeRide.status.replace("_", " ")}
                        </span>
                        <span className="text-lg font-extrabold text-white">
                          {formatPkr(activeRide.estimatedFarePkr)}
                        </span>
                      </div>

                      <div className="mt-4 space-y-2 text-xs text-slate-300">
                        <p>
                          <strong className="text-slate-400">Customer:</strong>{" "}
                          {activeRide.customerName}
                        </p>
                        <p>
                          <strong className="text-slate-400">Pickup:</strong>{" "}
                          {activeRide.pickup.address}
                        </p>
                        <p>
                          <strong className="text-slate-400">Destination:</strong>{" "}
                          {activeRide.dropoff.address}
                        </p>
                        <p>
                          <strong className="text-slate-400">Distance:</strong>{" "}
                          {activeRide.distanceKm} km (~{activeRide.durationMin} min)
                        </p>
                        <p className="text-emerald-400">
                          <strong>Your Net Payout:</strong>{" "}
                          {formatPkr(
                            activeRide.driverNetPkr || activeRide.estimatedFarePkr
                          )}
                        </p>
                      </div>

                      {activeRide.customerPhone && (
                        <a
                          href={`tel:${activeRide.customerPhone}`}
                          className="mt-4 inline-flex items-center gap-2 rounded-lg bg-slate-800 px-3 py-2 text-xs font-semibold text-white"
                        >
                          <Phone className="h-3.5 w-3.5 text-emerald-400" />
                          Call {activeRide.customerPhone}
                        </a>
                      )}

                      <div className="mt-5 space-y-2.5">
                        {activeRide.status === "accepted" && (
                          <button
                            disabled={actionBusy}
                            onClick={() => handleUpdateRideStatus(activeRide, "arrived")}
                            className="w-full rounded-xl bg-sky-500 py-3 text-sm font-bold text-slate-950 hover:bg-sky-400"
                          >
                            Mark Arrived at Pickup
                          </button>
                        )}
                        {activeRide.status === "arrived" && (
                          <button
                            disabled={actionBusy}
                            onClick={() =>
                              handleUpdateRideStatus(activeRide, "in_progress")
                            }
                            className="w-full rounded-xl bg-emerald-500 py-3 text-sm font-bold text-slate-950 hover:bg-emerald-400"
                          >
                            Start Ride
                          </button>
                        )}
                        {activeRide.status === "in_progress" && (
                          <button
                            disabled={actionBusy}
                            onClick={() => handleUpdateRideStatus(activeRide, "completed")}
                            className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3 text-sm font-bold text-slate-950 hover:bg-emerald-400"
                          >
                            <CheckCircle2 className="h-4 w-4" />
                            Complete Ride & Collect Cash ({formatPkr(activeRide.estimatedFarePkr)})
                          </button>
                        )}
                        {["accepted", "arrived"].includes(activeRide.status) && (
                          <button
                            disabled={actionBusy}
                            onClick={() => handleUpdateRideStatus(activeRide, "cancelled")}
                            className="w-full rounded-xl border border-red-500/40 bg-red-500/10 py-2.5 text-xs font-semibold text-red-400"
                          >
                            Cancel Ride
                          </button>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
                      <h2 className="text-base font-bold text-white">
                        Incoming {driverProfile.vehicleType} Requests
                      </h2>
                      {!driverProfile.isOnline ? (
                        <p className="mt-4 text-xs text-slate-400">
                          Switch your status to <strong>ONLINE</strong> above to receive live ride requests.
                        </p>
                      ) : visibleRequests.length === 0 ? (
                        <p className="mt-4 text-xs text-slate-400">
                          Listening for nearby {driverProfile.vehicleType} requests...
                        </p>
                      ) : (
                        <div className="mt-4 space-y-3">
                          {visibleRequests.map((req) => (
                            <div
                              key={req.id}
                              className="rounded-xl border border-slate-800 bg-slate-950 p-4"
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-sm font-bold text-white">
                                  {req.customerName}
                                </span>
                                <span className="text-base font-extrabold text-emerald-400">
                                  {formatPkr(req.estimatedFarePkr)}
                                </span>
                              </div>
                              <p className="mt-2 text-xs text-slate-300">
                                <strong>Pickup:</strong> {req.pickup.address}
                              </p>
                              <p className="mt-1 text-xs text-slate-400">
                                <strong>Dropoff:</strong> {req.dropoff.address}
                              </p>
                              <p className="mt-1 text-[11px] text-slate-500">
                                {req.distanceKm} km • Net Earnings:{" "}
                                {formatPkr(req.driverNetPkr || req.estimatedFarePkr)}
                              </p>
                              <div className="mt-3 grid grid-cols-2 gap-2">
                                <button
                                  disabled={actionBusy}
                                  onClick={() => handleAcceptRide(req)}
                                  className="flex items-center justify-center gap-1 rounded-lg bg-emerald-500 py-2 text-xs font-bold text-slate-950 hover:bg-emerald-400"
                                >
                                  <CheckCircle2 className="h-3.5 w-3.5" /> Accept
                                </button>
                                <button
                                  onClick={() =>
                                    setRejectedIds((prev) => [...prev, req.id])
                                  }
                                  className="flex items-center justify-center gap-1 rounded-lg border border-slate-700 py-2 text-xs font-semibold text-slate-300 hover:border-red-500/40 hover:text-red-400"
                                >
                                  <XCircle className="h-3.5 w-3.5" /> Reject
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="lg:col-span-7">
                  <RideMap
                    pickup={activeRide ? activeRide.pickup : null}
                    dropoff={activeRide ? activeRide.dropoff : null}
                    driverLocation={
                      driverProfile.currentLocation
                        ? {
                            lat: driverProfile.currentLocation.lat,
                            lng: driverProfile.currentLocation.lng,
                          }
                        : null
                    }
                  />
                </div>
              </div>
            )}

            {tab === "earnings" && (
              <div className="space-y-6">
                <div className="grid gap-4 sm:grid-cols-4">
                  <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
                    <span className="text-xs text-slate-400">Today&apos;s Net Earnings</span>
                    <p className="mt-1 text-2xl font-extrabold text-emerald-400">
                      {formatPkr(todayEarnings)}
                    </p>
                  </div>
                  <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
                    <span className="text-xs text-slate-400">Total Net Earnings</span>
                    <p className="mt-1 text-2xl font-extrabold text-white">
                      {formatPkr(driverProfile.totalEarningsPkr)}
                    </p>
                  </div>
                  <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
                    <span className="text-xs text-slate-400">Completed Rides</span>
                    <p className="mt-1 text-2xl font-extrabold text-white">
                      {driverProfile.totalRides}
                    </p>
                  </div>
                  <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
                    <span className="text-xs text-slate-400">Rider Rating</span>
                    <p className="mt-1 flex items-center gap-1.5 text-2xl font-extrabold text-amber-400">
                      <Star className="h-5 w-5 fill-amber-400" /> {avgReview}
                    </p>
                  </div>
                </div>

                <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
                  <h3 className="text-base font-bold text-white">Recent Rider Reviews</h3>
                  {reviews.length === 0 ? (
                    <p className="mt-3 text-xs text-slate-400">No reviews yet.</p>
                  ) : (
                    <div className="mt-4 space-y-3">
                      {reviews.map((rev) => (
                        <div
                          key={rev.id}
                          className="rounded-xl border border-slate-800 bg-slate-950 p-3.5 text-xs"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-white">{rev.customerName}</span>
                            <span className="text-amber-400">{"★".repeat(rev.rating)}</span>
                          </div>
                          <p className="mt-1 text-slate-300">{rev.comment}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {tab === "history" && (
              <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
                <h2 className="text-lg font-bold text-white">Driver Ride History</h2>
                <div className="mt-4 space-y-3">
                  {myRides.map((r) => (
                    <div
                      key={r.id}
                      className="flex flex-col justify-between gap-2 rounded-xl border border-slate-800 bg-slate-950 p-4 sm:flex-row sm:items-center"
                    >
                      <div>
                        <span className="text-xs font-bold uppercase text-emerald-400">
                          {r.status}
                        </span>
                        <p className="mt-1 text-xs text-slate-300">
                          {r.pickup.address} → {r.dropoff.address}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          Customer: {r.customerName} •{" "}
                          {new Date(r.createdAt).toLocaleString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-extrabold text-emerald-400">
                          Net: {formatPkr(r.driverNetPkr || r.estimatedFarePkr)}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          Gross: {formatPkr(r.finalFarePkr || r.estimatedFarePkr)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
