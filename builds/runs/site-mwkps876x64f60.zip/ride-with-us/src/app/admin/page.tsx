"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  updateDoc,
} from "firebase/firestore";
import {
  Activity,
  BarChart3,
  Car,
  CheckCircle2,
  CreditCard,
  ExternalLink,
  Loader2,
  Settings,
  ShieldAlert,
  Users,
  XCircle,
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/context/AuthContext";
import { ensureMissingFareRules } from "@/lib/bootstrap";
import { formatPkr } from "@/lib/fare";
import { db } from "@/lib/firebase";
import { pushNotification } from "@/lib/notifications";
import {
  DriverPrivateDocs,
  DriverProfile,
  FareRule,
  PaymentRecord,
  RideRecord,
  ServiceType,
  UserProfile,
} from "@/types/rideWithUs";

type AdminTab =
  | "overview"
  | "customers"
  | "drivers"
  | "rides"
  | "fares"
  | "payments"
  | "settings";

export default function AdminPage() {
  const router = useRouter();
  const { firebaseUser, profile, settings, fareRules, loading } = useAuth();

  const [tab, setTab] = useState<AdminTab>("overview");
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [drivers, setDrivers] = useState<DriverProfile[]>([]);
  const [rides, setRides] = useState<RideRecord[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);

  // Driver KYC inspector
  const [selectedDriver, setSelectedDriver] = useState<DriverProfile | null>(null);
  const [driverDocs, setDriverDocs] = useState<DriverPrivateDocs | null>(null);
  const [rejectReason, setRejectReason] = useState("");

  // Editable fares state
  const [editableFares, setEditableFares] =
    useState<Record<ServiceType, FareRule>>(fareRules);
  const [savingFare, setSavingFare] = useState<string>("");

  // Editable app_config/settings state
  const [appName, setAppName] = useState(settings.app_name);
  const [currency, setCurrency] = useState(settings.currency);
  const [supportPhone, setSupportPhone] = useState(settings.supportPhone || "");
  const [servicesList, setServicesList] = useState<ServiceType[]>(settings.services);
  const [savingSettings, setSavingSettings] = useState(false);

  useEffect(() => {
    setEditableFares(fareRules);
  }, [fareRules]);

  useEffect(() => {
    setAppName(settings.app_name);
    setCurrency(settings.currency);
    setSupportPhone(settings.supportPhone || "");
    setServicesList(settings.services);
  }, [settings]);

  useEffect(() => {
    if (!loading && !firebaseUser) router.push("/login");
  }, [loading, firebaseUser, router]);

  useEffect(() => {
    if (!profile || profile.role !== "admin") return;

    const u1 = onSnapshot(collection(db, "users"), (snap) =>
      setUsers(snap.docs.map((d) => d.data() as UserProfile))
    );
    const u2 = onSnapshot(collection(db, "drivers"), (snap) =>
      setDrivers(snap.docs.map((d) => d.data() as DriverProfile))
    );
    const u3 = onSnapshot(
      query(collection(db, "rides"), orderBy("createdAt", "desc")),
      (snap) =>
        setRides(
          snap.docs.map((d) => ({
            id: d.id,
            ...(d.data() as Omit<RideRecord, "id">),
          }))
        )
    );
    const u4 = onSnapshot(
      query(collection(db, "payments"), orderBy("createdAt", "desc")),
      (snap) =>
        setPayments(
          snap.docs.map((d) => ({
            id: d.id,
            ...(d.data() as Omit<PaymentRecord, "id">),
          }))
        )
    );

    return () => {
      u1();
      u2();
      u3();
      u4();
    };
  }, [profile]);

  const inspectDriver = async (driver: DriverProfile) => {
    setSelectedDriver(driver);
    setRejectReason("");
    const docSnap = await getDoc(
      doc(db, "drivers", driver.uid, "private_docs", "documents")
    );
    setDriverDocs(docSnap.exists() ? (docSnap.data() as DriverPrivateDocs) : null);
  };

  const handleDriverDecision = async (
    driver: DriverProfile,
    decision: "approved" | "rejected"
  ) => {
    await updateDoc(doc(db, "drivers", driver.uid), {
      approvalStatus: decision,
      isOnline: false,
      rejectionReason: decision === "rejected" ? rejectReason || "Verification failed" : "",
    });
    await pushNotification(
      driver.uid,
      decision === "approved" ? "Driver Account Approved" : "Driver Application Rejected",
      decision === "approved"
        ? "Congratulations! Your vehicle & KYC documents are approved. You can now go online."
        : `Rejected: ${rejectReason || "Please contact support."}`
    );
    setSelectedDriver(null);
  };

  const toggleUserBlock = async (u: UserProfile) => {
    await updateDoc(doc(db, "users", u.uid), { isBlocked: !u.isBlocked });
  };

  const handleSaveFare = async (serviceType: ServiceType) => {
    setSavingFare(serviceType);
    try {
      await setDoc(doc(db, "fare_rules", serviceType), editableFares[serviceType]);
    } finally {
      setSavingFare("");
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      await setDoc(
        doc(db, "app_config", "settings"),
        {
          app_name: appName.trim(),
          currency: currency.trim(),
          services: servicesList,
          supportPhone: supportPhone.trim(),
        },
        { merge: true }
      );
    } finally {
      setSavingSettings(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 text-slate-400">
        <Loader2 className="mr-2 h-5 w-5 animate-spin text-emerald-500" />
        Loading Admin Panel...
      </div>
    );
  }

  if (!profile || profile.role !== "admin") {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100">
        <Navbar />
        <div className="mx-auto max-w-md px-4 py-16 text-center">
          <ShieldAlert className="mx-auto h-12 w-12 text-amber-400" />
          <h1 className="mt-4 text-2xl font-extrabold text-white">
            Admin Access Required
          </h1>
          <p className="mt-2 text-sm text-slate-400">
            Your account does not have the <code>admin</code> role. In Firebase Console
            → Firestore → <code>users/{firebaseUser?.uid}</code>, set{" "}
            <code>role: &quot;admin&quot;</code> for your authorized admin account.
          </p>
        </div>
      </div>
    );
  }

  const customers = users.filter((u) => u.role === "customer");
  const activeRides = rides.filter((r) =>
    ["requested", "accepted", "arrived", "in_progress"].includes(r.status)
  );
  const completedRides = rides.filter((r) => r.status === "completed");
  const grossRevenue = payments.reduce((s, p) => s + p.amountPkr, 0);
  const totalCommission = payments.reduce((s, p) => s + p.commissionPkr, 0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Navbar />

      <div className="mx-auto max-w-7xl px-4 py-6">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold text-white">
              RIDE WITH US — Admin Command Center
            </h1>
            <p className="text-xs text-slate-400">
              Manage customers, drivers, rides, {settings.currency} fares, payments & app settings
            </p>
          </div>
          <button
            onClick={() => ensureMissingFareRules()}
            className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-xs font-bold text-emerald-400 hover:bg-emerald-500/20"
          >
            Initialize Missing Fare Rules
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="mb-6 flex flex-wrap gap-2">
          {(
            [
              ["overview", "Analytics", BarChart3],
              ["drivers", `Drivers (${drivers.length})`, Car],
              ["customers", `Customers (${customers.length})`, Users],
              ["rides", `Rides (${rides.length})`, Activity],
              ["fares", "Vehicles & Fares", Settings],
              ["payments", `Payments (${payments.length})`, CreditCard],
              ["settings", "App Settings", Settings],
            ] as const
          ).map(([id, label, Icon]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition sm:text-sm ${
                tab === id
                  ? "bg-emerald-500 text-slate-950"
                  : "border border-slate-800 bg-slate-900 text-slate-300 hover:text-white"
              }`}
            >
              <Icon className="h-4 w-4" /> {label}
            </button>
          ))}
        </div>

        {/* Overview & Reports */}
        {tab === "overview" && (
          <div className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
                <span className="text-xs text-slate-400">Gross Ride Revenue</span>
                <p className="mt-1 text-2xl font-extrabold text-emerald-400">
                  {formatPkr(grossRevenue)}
                </p>
                <span className="text-[11px] text-slate-500">
                  Commission: {formatPkr(totalCommission)}
                </span>
              </div>
              <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
                <span className="text-xs text-slate-400">Active / Total Rides</span>
                <p className="mt-1 text-2xl font-extrabold text-white">
                  {activeRides.length} / {rides.length}
                </p>
                <span className="text-[11px] text-slate-500">
                  Completed: {completedRides.length}
                </span>
              </div>
              <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
                <span className="text-xs text-slate-400">Drivers (Pending / Approved)</span>
                <p className="mt-1 text-2xl font-extrabold text-amber-400">
                  {drivers.filter((d) => d.approvalStatus === "pending").length} /{" "}
                  {drivers.filter((d) => d.approvalStatus === "approved").length}
                </p>
              </div>
              <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
                <span className="text-xs text-slate-400">Registered Customers</span>
                <p className="mt-1 text-2xl font-extrabold text-white">
                  {customers.length}
                </p>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
              <h2 className="text-base font-bold text-white">
                Service Performance Breakdown (PKR)
              </h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-3">
                {(["Bike", "Rickshaw", "Car"] as ServiceType[]).map((svc) => {
                  const svcRides = completedRides.filter((r) => r.serviceType === svc);
                  const svcRev = svcRides.reduce(
                    (s, r) => s + (r.finalFarePkr || r.estimatedFarePkr),
                    0
                  );
                  return (
                    <div
                      key={svc}
                      className="rounded-xl border border-slate-800 bg-slate-950 p-4"
                    >
                      <p className="text-sm font-bold text-white">{svc}</p>
                      <p className="mt-1 text-xl font-extrabold text-emerald-400">
                        {formatPkr(svcRev)}
                      </p>
                      <p className="text-xs text-slate-400">
                        {svcRides.length} completed rides
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Drivers & Approval */}
        {tab === "drivers" && (
          <div className="space-y-6">
            {selectedDriver && (
              <div className="rounded-2xl border border-emerald-500/40 bg-slate-900 p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-white">
                      Inspect Driver: {selectedDriver.fullName}
                    </h3>
                    <p className="text-xs text-slate-400">
                      {selectedDriver.vehicleType} • {selectedDriver.vehicleModel} (
                      {selectedDriver.vehiclePlate}) • {selectedDriver.phone}
                    </p>
                  </div>
                  <button
                    onClick={() => setSelectedDriver(null)}
                    className="text-xs text-slate-400 hover:text-white"
                  >
                    Close
                  </button>
                </div>

                {driverDocs ? (
                  <div className="mt-4 grid gap-4 sm:grid-cols-2">
                    <div className="text-xs text-slate-300">
                      <p>CNIC: {driverDocs.cnicNumber}</p>
                      <p className="mt-1">License: {driverDocs.licenseNumber}</p>
                    </div>
                    <div className="flex flex-wrap gap-2 text-xs">
                      <a
                        href={driverDocs.cnicFrontUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 rounded-lg bg-slate-800 px-3 py-2 text-emerald-400"
                      >
                        CNIC <ExternalLink className="h-3 w-3" />
                      </a>
                      <a
                        href={driverDocs.licenseUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 rounded-lg bg-slate-800 px-3 py-2 text-emerald-400"
                      >
                        License <ExternalLink className="h-3 w-3" />
                      </a>
                      <a
                        href={driverDocs.vehicleRegUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 rounded-lg bg-slate-800 px-3 py-2 text-emerald-400"
                      >
                        Vehicle Reg <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  </div>
                ) : (
                  <p className="mt-3 text-xs text-amber-400">No private KYC documents found.</p>
                )}

                <div className="mt-5 flex flex-col gap-3 sm:flex-row">
                  <button
                    onClick={() => handleDriverDecision(selectedDriver, "approved")}
                    className="flex items-center justify-center gap-1.5 rounded-xl bg-emerald-500 px-5 py-2.5 text-xs font-bold text-slate-950"
                  >
                    <CheckCircle2 className="h-4 w-4" /> Approve Driver
                  </button>
                  <input
                    value={rejectReason}
                    onChange={(e) => setRejectReason(e.target.value)}
                    placeholder="Rejection reason (if rejecting)..."
                    className="flex-1 rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
                  />
                  <button
                    onClick={() => handleDriverDecision(selectedDriver, "rejected")}
                    className="flex items-center justify-center gap-1.5 rounded-xl border border-red-500/40 bg-red-500/10 px-5 py-2.5 text-xs font-bold text-red-400"
                  >
                    <XCircle className="h-4 w-4" /> Reject
                  </button>
                </div>
              </div>
            )}

            <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
              <h2 className="text-lg font-bold text-white">All Drivers</h2>
              <div className="mt-4 space-y-3">
                {drivers.map((d) => (
                  <div
                    key={d.uid}
                    className="flex flex-col justify-between gap-3 rounded-xl border border-slate-800 bg-slate-950 p-4 sm:flex-row sm:items-center"
                  >
                    <div>
                      <p className="text-sm font-bold text-white">
                        {d.fullName}{" "}
                        <span className="ml-2 rounded bg-slate-800 px-2 py-0.5 text-[11px] uppercase text-emerald-400">
                          {d.approvalStatus}
                        </span>
                        {d.isOnline && (
                          <span className="ml-2 text-[11px] text-emerald-400">● Online</span>
                        )}
                      </p>
                      <p className="mt-1 text-xs text-slate-400">
                        {d.vehicleType} • {d.vehicleModel} ({d.vehiclePlate}) • {d.phone}
                      </p>
                    </div>
                    <button
                      onClick={() => inspectDriver(d)}
                      className="rounded-lg bg-slate-800 px-4 py-2 text-xs font-bold text-white hover:bg-slate-700"
                    >
                      Inspect & Manage
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Customers */}
        {tab === "customers" && (
          <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
            <h2 className="text-lg font-bold text-white">Customer Accounts</h2>
            <div className="mt-4 space-y-3">
              {customers.map((c) => (
                <div
                  key={c.uid}
                  className="flex flex-col justify-between gap-3 rounded-xl border border-slate-800 bg-slate-950 p-4 sm:flex-row sm:items-center"
                >
                  <div>
                    <p className="text-sm font-bold text-white">{c.fullName}</p>
                    <p className="text-xs text-slate-400">
                      {c.email} • {c.phone}
                    </p>
                  </div>
                  <button
                    onClick={() => toggleUserBlock(c)}
                    className={`rounded-lg px-4 py-2 text-xs font-bold ${
                      c.isBlocked
                        ? "bg-emerald-500 text-slate-950"
                        : "border border-red-500/40 bg-red-500/10 text-red-400"
                    }`}
                  >
                    {c.isBlocked ? "Unblock User" : "Block User"}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Rides */}
        {tab === "rides" && (
          <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
            <h2 className="text-lg font-bold text-white">
              Active & Historical Rides ({activeRides.length} active)
            </h2>
            <div className="mt-4 space-y-3">
              {rides.map((r) => (
                <div
                  key={r.id}
                  className="flex flex-col justify-between gap-3 rounded-xl border border-slate-800 bg-slate-950 p-4 sm:flex-row sm:items-center"
                >
                  <div>
                    <div className="flex items-center gap-2 text-xs">
                      <span className="rounded bg-slate-800 px-2 py-0.5 font-bold text-white">
                        {r.serviceType}
                      </span>
                      <span className="font-bold uppercase text-emerald-400">
                        {r.status}
                      </span>
                      <span className="text-slate-500">
                        {new Date(r.createdAt).toLocaleString()}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-slate-300">
                      {r.customerName} → Driver: {r.driverName || "Unassigned"}
                    </p>
                    <p className="text-[11px] text-slate-400">
                      {r.pickup.address} → {r.dropoff.address}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-extrabold text-emerald-400">
                      {formatPkr(r.finalFarePkr || r.estimatedFarePkr)}
                    </span>
                    {["requested", "accepted", "arrived", "in_progress"].includes(
                      r.status
                    ) && (
                      <button
                        onClick={() =>
                          updateDoc(doc(db, "rides", r.id), {
                            status: "cancelled",
                            cancelledBy: "admin",
                            cancelReason: "Cancelled by Admin",
                          })
                        }
                        className="rounded-lg border border-red-500/40 px-3 py-1.5 text-xs font-bold text-red-400"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Vehicles, Fares & Commissions */}
        {tab === "fares" && (
          <div className="grid gap-6 md:grid-cols-3">
            {(["Bike", "Rickshaw", "Car"] as ServiceType[]).map((svc) => {
              const r = editableFares[svc];
              const updateField = (field: keyof FareRule, val: number | boolean | string) =>
                setEditableFares((prev) => ({
                  ...prev,
                  [svc]: { ...prev[svc], [field]: val },
                }));

              return (
                <div
                  key={svc}
                  className="rounded-2xl border border-slate-800 bg-slate-900 p-5"
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-extrabold text-white">{svc}</h3>
                    <label className="flex items-center gap-2 text-xs text-slate-300">
                      <input
                        type="checkbox"
                        checked={r.active}
                        onChange={(e) => updateField("active", e.target.checked)}
                      />
                      Active
                    </label>
                  </div>

                  <div className="mt-4 space-y-3 text-xs">
                    {(
                      [
                        ["baseFarePkr", "Base Fare (PKR)"],
                        ["perKmPkr", "Per KM (PKR)"],
                        ["perMinPkr", "Per Min (PKR)"],
                        ["minimumFarePkr", "Minimum Fare (PKR)"],
                        ["commissionPercent", "Platform Commission (%)"],
                      ] as const
                    ).map(([key, label]) => (
                      <div key={key}>
                        <label className="mb-1 block text-slate-400">{label}</label>
                        <input
                          type="number"
                          value={r[key]}
                          onChange={(e) => updateField(key, Number(e.target.value))}
                          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
                        />
                      </div>
                    ))}
                  </div>

                  <button
                    disabled={savingFare === svc}
                    onClick={() => handleSaveFare(svc)}
                    className="mt-5 w-full rounded-xl bg-emerald-500 py-2.5 text-xs font-bold text-slate-950 hover:bg-emerald-400"
                  >
                    {savingFare === svc ? "Saving..." : `Save ${svc} Fares`}
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {/* Payments */}
        {tab === "payments" && (
          <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
            <h2 className="text-lg font-bold text-white">Payments & Commission Ledger</h2>
            <div className="mt-4 space-y-3">
              {payments.map((p) => (
                <div
                  key={p.id}
                  className="flex flex-col justify-between gap-2 rounded-xl border border-slate-800 bg-slate-950 p-4 sm:flex-row sm:items-center"
                >
                  <div className="text-xs">
                    <p className="font-bold text-white">
                      {p.serviceType} Ride • {p.method.toUpperCase()}
                    </p>
                    <p className="text-slate-400">
                      Gross: {formatPkr(p.amountPkr)} | Commission:{" "}
                      {formatPkr(p.commissionPkr)} | Driver Net: {formatPkr(p.driverNetPkr)}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="rounded bg-emerald-500/20 px-2.5 py-1 text-xs font-bold uppercase text-emerald-400">
                      {p.status}
                    </span>
                    {p.status !== "settled" && (
                      <button
                        onClick={() =>
                          updateDoc(doc(db, "payments", p.id), { status: "settled" })
                        }
                        className="rounded-lg bg-emerald-500 px-3 py-1.5 text-xs font-bold text-slate-950"
                      >
                        Mark Settled
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* App Settings (app_config/settings) */}
        {tab === "settings" && (
          <form
            onSubmit={handleSaveSettings}
            className="mx-auto max-w-lg rounded-2xl border border-slate-800 bg-slate-900 p-6 space-y-4"
          >
            <h2 className="text-lg font-bold text-white">
              App Config (<code>app_config/settings</code>)
            </h2>
            <div>
              <label className="mb-1 block text-xs text-slate-300">App Name</label>
              <input
                value={appName}
                onChange={(e) => setAppName(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs text-slate-300">Currency</label>
              <input
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs text-slate-300">Support Phone</label>
              <input
                value={supportPhone}
                onChange={(e) => setSupportPhone(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs text-slate-300">Enabled Services</label>
              <div className="flex gap-4 text-sm">
                {(["Bike", "Car", "Rickshaw"] as ServiceType[]).map((s) => (
                  <label key={s} className="flex items-center gap-1.5">
                    <input
                      type="checkbox"
                      checked={servicesList.includes(s)}
                      onChange={(e) =>
                        setServicesList((prev) =>
                          e.target.checked ? [...prev, s] : prev.filter((x) => x !== s)
                        )
                      }
                    />
                    {s}
                  </label>
                ))}
              </div>
            </div>
            <button
              type="submit"
              disabled={savingSettings}
              className="w-full rounded-xl bg-emerald-500 py-3 text-sm font-bold text-slate-950 hover:bg-emerald-400"
            >
              {savingSettings ? "Saving..." : "Save Settings"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
