"use client";

import React, { createContext, useContext, useEffect, useState } from "react";
import { User, onAuthStateChanged, signOut } from "firebase/auth";
import {
  collection,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
  updateDoc,
  where,
} from "firebase/firestore";
import { auth, db } from "@/lib/firebase";
import { fetchAppSettings, fetchFareRules } from "@/lib/bootstrap";
import { DEFAULT_FARE_RULES } from "@/lib/fare";
import {
  AppSettings,
  FareRule,
  NotificationItem,
  ServiceType,
  UserProfile,
} from "@/types/rideWithUs";

interface AuthContextValue {
  firebaseUser: User | null;
  profile: UserProfile | null;
  settings: AppSettings;
  fareRules: Record<ServiceType, FareRule>;
  notifications: NotificationItem[];
  loading: boolean;
  logout: () => Promise<void>;
  markNotificationRead: (id: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [settings, setSettings] = useState<AppSettings>({
    app_name: "Ride With Us",
    currency: "PKR",
    services: ["Bike", "Car", "Rickshaw"],
  });
  const [fareRules, setFareRules] =
    useState<Record<ServiceType, FareRule>>(DEFAULT_FARE_RULES);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAppSettings().then(setSettings).catch(() => {});
    fetchFareRules().then(setFareRules).catch(() => {});

    const unsubSettings = onSnapshot(doc(db, "app_config", "settings"), (snap) => {
      if (snap.exists()) {
        const d = snap.data() as Partial<AppSettings>;
        setSettings({
          app_name: d.app_name || "Ride With Us",
          currency: d.currency || "PKR",
          services: (d.services as ServiceType[]) || ["Bike", "Car", "Rickshaw"],
          supportPhone: d.supportPhone,
          commissionPercent: d.commissionPercent,
        });
      }
    });

    const unsubFares = onSnapshot(collection(db, "fare_rules"), (snap) => {
      if (!snap.empty) {
        const next = { ...DEFAULT_FARE_RULES };
        snap.forEach((d) => {
          const r = d.data() as FareRule;
          if (r.serviceType) next[r.serviceType] = r;
        });
        setFareRules(next);
      }
    });

    let unsubProfile: (() => void) | null = null;
    let unsubNotifs: (() => void) | null = null;

    const unsubAuth = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      if (unsubProfile) unsubProfile();
      if (unsubNotifs) unsubNotifs();

      if (!user) {
        setProfile(null);
        setNotifications([]);
        setLoading(false);
        return;
      }

      unsubProfile = onSnapshot(doc(db, "users", user.uid), (snap) => {
        setProfile(snap.exists() ? (snap.data() as UserProfile) : null);
        setLoading(false);
      });

      const nq = query(
        collection(db, "notifications"),
        where("userId", "==", user.uid),
        orderBy("createdAt", "desc"),
        limit(20)
      );
      unsubNotifs = onSnapshot(nq, (snap) => {
        setNotifications(
          snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<NotificationItem, "id">) }))
        );
      });
    });

    return () => {
      unsubAuth();
      unsubSettings();
      unsubFares();
      if (unsubProfile) unsubProfile();
      if (unsubNotifs) unsubNotifs();
    };
  }, []);

  const logout = async () => {
    await signOut(auth);
  };

  const markNotificationRead = async (id: string) => {
    await updateDoc(doc(db, "notifications", id), { read: true });
  };

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        profile,
        settings,
        fareRules,
        notifications,
        loading,
        logout,
        markNotificationRead,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
