export type ServiceType = "Bike" | "Car" | "Rickshaw";
export type UserRole = "customer" | "driver" | "admin";
export type ApprovalStatus = "pending" | "approved" | "rejected";
export type RideStatus =
  | "requested"
  | "accepted"
  | "arrived"
  | "in_progress"
  | "completed"
  | "cancelled";

export interface AppSettings {
  app_name: string;
  currency: string;
  services: ServiceType[];
  supportPhone?: string;
  commissionPercent?: number;
}

export interface FareRule {
  serviceType: ServiceType;
  baseFarePkr: number;
  perKmPkr: number;
  perMinPkr: number;
  minimumFarePkr: number;
  commissionPercent: number;
  active: boolean;
  description: string;
  etaMinutesBase: number;
}

export interface LatLngPoint {
  lat: number;
  lng: number;
  address?: string;
}

export interface UserProfile {
  uid: string;
  fullName: string;
  email: string;
  phone: string;
  role: UserRole;
  avatarUrl?: string;
  isBlocked: boolean;
  ratingAvg?: number;
  totalRides?: number;
  createdAt: string;
}

export interface DriverProfile {
  uid: string;
  fullName: string;
  phone: string;
  vehicleType: ServiceType;
  vehicleModel: string;
  vehiclePlate: string;
  vehicleColor: string;
  approvalStatus: ApprovalStatus;
  rejectionReason?: string;
  isOnline: boolean;
  currentLocation?: { lat: number; lng: number; updatedAt: string };
  ratingAvg: number;
  ratingCount: number;
  totalRides: number;
  totalEarningsPkr: number;
  createdAt: string;
}

export interface DriverPrivateDocs {
  cnicNumber: string;
  licenseNumber: string;
  cnicFrontUrl: string;
  licenseUrl: string;
  vehicleRegUrl: string;
  submittedAt: string;
}

export interface RideRecord {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  driverId?: string;
  driverName?: string;
  driverPhone?: string;
  vehicleInfo?: string;
  serviceType: ServiceType;
  pickup: LatLngPoint;
  dropoff: LatLngPoint;
  distanceKm: number;
  durationMin: number;
  estimatedFarePkr: number;
  finalFarePkr?: number;
  commissionPkr?: number;
  driverNetPkr?: number;
  paymentMethod: "cash";
  paymentStatus: "pending" | "paid";
  status: RideStatus;
  driverLocation?: { lat: number; lng: number };
  cancelReason?: string;
  cancelledBy?: UserRole;
  hasReviewed?: boolean;
  createdAt: string;
  acceptedAt?: string;
  startedAt?: string;
  completedAt?: string;
}

export interface ReviewRecord {
  id: string;
  rideId: string;
  customerId: string;
  customerName: string;
  driverId: string;
  rating: number;
  comment: string;
  createdAt: string;
}

export interface PaymentRecord {
  id: string;
  rideId: string;
  customerId: string;
  driverId: string;
  serviceType: ServiceType;
  amountPkr: number;
  commissionPkr: number;
  driverNetPkr: number;
  method: "cash";
  status: "settled" | "pending";
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  read: boolean;
  rideId?: string;
  createdAt: string;
}
