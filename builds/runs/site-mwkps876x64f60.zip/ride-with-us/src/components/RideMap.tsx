"use client";

import React, { useEffect, useState } from "react";
import {
  DirectionsRenderer,
  DirectionsService,
  GoogleMap,
  Marker,
} from "@react-google-maps/api";
import { AlertTriangle } from "lucide-react";
import { useGoogleMaps } from "@/lib/useGoogleMaps";
import { DriverProfile, LatLngPoint } from "@/types/rideWithUs";

interface RideMapProps {
  pickup: LatLngPoint | null;
  dropoff: LatLngPoint | null;
  driverLocation?: { lat: number; lng: number } | null;
  nearbyDrivers?: DriverProfile[];
  selectMode?: "pickup" | "dropoff" | null;
  onMapSelect?: (point: LatLngPoint) => void;
  onRouteCalculated?: (distanceKm: number, durationMin: number) => void;
  heightClass?: string;
}

const DEFAULT_CENTER = { lat: 31.5204, lng: 74.3587 }; // Lahore, Pakistan

export function RideMap({
  pickup,
  dropoff,
  driverLocation,
  nearbyDrivers = [],
  selectMode = null,
  onMapSelect,
  onRouteCalculated,
  heightClass = "h-[420px] lg:h-[560px]",
}: RideMapProps) {
  const { isLoaded, loadError } = useGoogleMaps();
  const [directions, setDirections] =
    useState<google.maps.DirectionsResult | null>(null);
  const [routeKey, setRouteKey] = useState<string>("");

  const activeRouteKey =
    pickup && dropoff
      ? `${pickup.lat.toFixed(5)},${pickup.lng.toFixed(5)}-${dropoff.lat.toFixed(5)},${dropoff.lng.toFixed(5)}`
      : "";

  useEffect(() => {
    if (!pickup || !dropoff) {
      setDirections(null);
      setRouteKey("");
    }
  }, [pickup, dropoff]);

  if (!process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY) {
    return (
      <div
        className={`flex flex-col items-center justify-center rounded-2xl border border-amber-500/40 bg-slate-900 p-6 text-center ${heightClass}`}
      >
        <AlertTriangle className="mb-2 h-8 w-8 text-amber-400" />
        <p className="text-sm font-semibold text-white">
          Google Maps API Key Required
        </p>
        <p className="mt-1 max-w-md text-xs text-slate-400">
          Add <code className="text-emerald-400">NEXT_PUBLIC_GOOGLE_MAPS_API_KEY</code>{" "}
          to <code>.env.local</code> with Maps JavaScript, Places, and Directions APIs enabled.
        </p>
      </div>
    );
  }

  if (loadError) {
    return (
      <div
        className={`flex items-center justify-center rounded-2xl border border-red-500/40 bg-slate-900 p-6 text-sm text-red-400 ${heightClass}`}
      >
        Failed to load Google Maps: {loadError.message}
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div
        className={`flex animate-pulse items-center justify-center rounded-2xl border border-slate-800 bg-slate-900 text-sm text-slate-400 ${heightClass}`}
      >
        Loading interactive map...
      </div>
    );
  }

  const center =
    driverLocation ||
    pickup ||
    dropoff ||
    DEFAULT_CENTER;

  const handleMapClick = (e: google.maps.MapMouseEvent) => {
    if (!selectMode || !onMapSelect || !e.latLng) return;
    const lat = e.latLng.lat();
    const lng = e.latLng.lng();

    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ location: { lat, lng } }, (results, status) => {
      const address =
        status === "OK" && results && results[0]
          ? results[0].formatted_address
          : `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
      onMapSelect({ lat, lng, address });
    });
  };

  return (
    <div className={`relative overflow-hidden rounded-2xl border border-slate-800 ${heightClass}`}>
      {selectMode && (
        <div className="pointer-events-none absolute left-1/2 top-3 z-10 -translate-x-1/2 rounded-full bg-slate-950/90 px-4 py-1.5 text-xs font-semibold text-emerald-400 shadow-lg ring-1 ring-emerald-500/40">
          Click anywhere on the map to set{" "}
          {selectMode === "pickup" ? "Pickup" : "Destination"}
        </div>
      )}

      <GoogleMap
        mapContainerStyle={{ width: "100%", height: "100%" }}
        center={center}
        zoom={13}
        onClick={handleMapClick}
        options={{
          streetViewControl: false,
          mapTypeControl: false,
          fullscreenControl: true,
        }}
      >
        {pickup && (
          <Marker
            position={{ lat: pickup.lat, lng: pickup.lng }}
            label={{ text: "P", color: "#ffffff", fontWeight: "bold" }}
            title="Pickup"
          />
        )}

        {dropoff && (
          <Marker
            position={{ lat: dropoff.lat, lng: dropoff.lng }}
            label={{ text: "D", color: "#ffffff", fontWeight: "bold" }}
            title="Destination"
          />
        )}

        {driverLocation && (
          <Marker
            position={driverLocation}
            label={{ text: "🚗", fontSize: "18px" }}
            title="Your Driver (Live)"
          />
        )}

        {!driverLocation &&
          nearbyDrivers.map((d) =>
            d.currentLocation ? (
              <Marker
                key={d.uid}
                position={{
                  lat: d.currentLocation.lat,
                  lng: d.currentLocation.lng,
                }}
                label={{
                  text:
                    d.vehicleType === "Bike"
                      ? "🏍"
                      : d.vehicleType === "Rickshaw"
                      ? "🛺"
                      : "🚕",
                  fontSize: "16px",
                }}
                title={`${d.vehicleType} • ${d.vehicleModel}`}
              />
            ) : null
          )}

        {pickup && dropoff && activeRouteKey !== routeKey && (
          <DirectionsService
            options={{
              origin: { lat: pickup.lat, lng: pickup.lng },
              destination: { lat: dropoff.lat, lng: dropoff.lng },
              travelMode: google.maps.TravelMode.DRIVING,
            }}
            callback={(result, status) => {
              if (status === "OK" && result) {
                setDirections(result);
                setRouteKey(activeRouteKey);
                const leg = result.routes[0]?.legs[0];
                if (leg && onRouteCalculated) {
                  const km = Number(((leg.distance?.value || 1000) / 1000).toFixed(2));
                  const min = Math.max(1, Math.round((leg.duration?.value || 180) / 60));
                  onRouteCalculated(km, min);
                }
              }
            }}
          />
        )}

        {directions && (
          <DirectionsRenderer
            options={{
              directions,
              suppressMarkers: true,
              polylineOptions: {
                strokeColor: "#10b981",
                strokeWeight: 5,
              },
            }}
          />
        )}
      </GoogleMap>
    </div>
  );
}
