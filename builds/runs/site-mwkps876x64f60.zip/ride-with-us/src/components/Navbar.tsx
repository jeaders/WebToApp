"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Bell,
  Car,
  CheckCheck,
  LogOut,
  ShieldCheck,
  User,
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";

export function Navbar() {
  const { profile, settings, notifications, logout, markNotificationRead } =
    useAuth();
  const [openNotif, setOpenNotif] = useState(false);
  const router = useRouter();

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleLogout = async () => {
    await logout();
    router.push("/login");
  };

  return (
    <header className="sticky top-0 z-40 border-b border-slate-800 bg-slate-950/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
        <Link href="/" className="flex items-center gap-2.5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20">
            <Car className="h-6 w-6" />
          </div>
          <div>
            <span className="block text-base font-extrabold tracking-tight text-white">
              {settings.app_name.toUpperCase()}
            </span>
            <span className="block text-[11px] font-medium text-emerald-400">
              Pakistan • {settings.currency}
            </span>
          </div>
        </Link>

        <nav className="flex items-center gap-2 sm:gap-3">
          {!profile ? (
            <>
              <Link
                href="/login"
                className="rounded-lg px-3 py-2 text-sm font-medium text-slate-300 hover:bg-slate-800 hover:text-white"
              >
                Login
              </Link>
              <Link
                href="/signup"
                className="rounded-lg bg-emerald-500 px-4 py-2 text-sm font-semibold text-slate-950 transition hover:bg-emerald-400"
              >
                Sign Up
              </Link>
            </>
          ) : (
            <>
              {profile.role === "customer" && (
                <Link
                  href="/customer"
                  className="rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-semibold text-emerald-400 hover:bg-slate-700 sm:text-sm"
                >
                  Book Ride
                </Link>
              )}
              {profile.role === "driver" && (
                <Link
                  href="/driver"
                  className="rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-semibold text-emerald-400 hover:bg-slate-700 sm:text-sm"
                >
                  Driver Portal
                </Link>
              )}
              {profile.role === "admin" && (
                <Link
                  href="/admin"
                  className="flex items-center gap-1 rounded-lg bg-amber-500/20 px-3 py-1.5 text-xs font-semibold text-amber-300 hover:bg-amber-500/30 sm:text-sm"
                >
                  <ShieldCheck className="h-4 w-4" /> Admin
                </Link>
              )}

              {/* Notifications */}
              <div className="relative">
                <button
                  onClick={() => setOpenNotif((v) => !v)}
                  className="relative rounded-lg border border-slate-800 bg-slate-900 p-2 text-slate-300 hover:border-slate-700 hover:text-white"
                  aria-label="Notifications"
                >
                  <Bell className="h-4 w-4" />
                  {unreadCount > 0 && (
                    <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-emerald-500 text-[10px] font-bold text-slate-950">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {openNotif && (
                  <div className="absolute right-0 mt-2 w-80 rounded-xl border border-slate-800 bg-slate-900 p-3 shadow-2xl">
                    <div className="mb-2 flex items-center justify-between border-b border-slate-800 pb-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                        Notifications
                      </span>
                      <button
                        onClick={() => setOpenNotif(false)}
                        className="text-xs text-slate-400 hover:text-white"
                      >
                        Close
                      </button>
                    </div>
                    <div className="max-h-72 space-y-2 overflow-y-auto">
                      {notifications.length === 0 ? (
                        <p className="py-4 text-center text-xs text-slate-500">
                          No notifications yet.
                        </p>
                      ) : (
                        notifications.map((n) => (
                          <div
                            key={n.id}
                            onClick={() => markNotificationRead(n.id)}
                            className={`cursor-pointer rounded-lg border p-2.5 text-xs transition ${
                              n.read
                                ? "border-slate-800 bg-slate-950/50 text-slate-400"
                                : "border-emerald-500/40 bg-emerald-500/10 text-slate-100"
                            }`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <p className="font-semibold">{n.title}</p>
                              {!n.read && (
                                <CheckCheck className="h-3.5 w-3.5 shrink-0 text-emerald-400" />
                              )}
                            </div>
                            <p className="mt-1 text-[11px] opacity-90">{n.message}</p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div className="hidden items-center gap-2 rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-1.5 sm:flex">
                <User className="h-4 w-4 text-emerald-400" />
                <span className="max-w-[120px] truncate text-xs font-medium text-slate-200">
                  {profile.fullName}
                </span>
              </div>

              <button
                onClick={handleLogout}
                className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-2 text-xs font-medium text-slate-300 hover:border-red-500/40 hover:text-red-400"
              >
                <LogOut className="h-4 w-4" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
