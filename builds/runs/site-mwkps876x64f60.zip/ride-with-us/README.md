# Ride With Us

This project contains three role-based experiences in one Next.js app:

- Customer: `/customer`
- Driver: `/driver`
- Admin: `/admin`

It is linked to the existing Firebase project `ride-with-us-49269` through `.firebaserc`. The supplied `app_config/settings` document is not part of this source extraction and should be kept in Firestore.

## Before running

1. Copy `.env.local.example` to `.env.local`.
2. Fill in the Firebase **Web app** config and Google Maps browser key. Do not put a Firebase service-account private key in this file.
3. Install dependencies with `npm install`.
4. Start locally with `npm run dev`, then open `http://localhost:3000`.

## Important

This is a web app, not an Android APK. It has not been built, deployed, or live-tested in your Firebase project. Review Firestore and Storage rules before deploying them. Do not overwrite existing Firestore data.
