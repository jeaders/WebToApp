import type { Prayer, PrayerData } from "./types";
const rad = (n: number) => n * Math.PI / 180;
const deg = (n: number) => n * 180 / Math.PI;
export function timeZoneOffset(timezone: string, date: Date) {
  const value = new Intl.DateTimeFormat("en-US", { timeZone: timezone, timeZoneName: "longOffset" }).formatToParts(date).find(p => p.type === "timeZoneName")?.value ?? "GMT";
  const match = value.match(/GMT([+-])(\d{1,2})(?::(\d{2}))?/);
  return match ? (match[1] === "-" ? -1 : 1) * (Number(match[2]) * 60 + Number(match[3] ?? 0)) / 60 : 0;
}
export function dateKey(timezone = "Europe/London", date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(date);
  return `${parts.find(p => p.type === "year")!.value}-${parts.find(p => p.type === "month")!.value}-${parts.find(p => p.type === "day")!.value}`;
}
export function hijriDate(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura", { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" }).formatToParts(date);
  return { day: parts.find(p => p.type === "day")?.value ?? "1", month: parts.find(p => p.type === "month")?.value ?? "Muharram", year: parts.find(p => p.type === "year")?.value ?? "1448" };
}
export function calculatePrayerData(latitude: number, longitude: number, timezone: string, method = 2, school = 0, selectedDate = new Date()): PrayerData {
  const year = Number(dateKey("UTC", selectedDate).slice(0, 4));
  const month = Number(dateKey("UTC", selectedDate).slice(5, 7));
  const day = Number(dateKey("UTC", selectedDate).slice(8, 10));
  const n = Math.floor((Date.UTC(year, month - 1, day) - Date.UTC(year, 0, 0)) / 86400000);
  const b = 2 * Math.PI * (n - 81) / 364;
  const equation = 9.87 * Math.sin(2 * b) - 7.53 * Math.cos(b) - 1.5 * Math.sin(b);
  const declination = 23.45 * Math.sin(2 * Math.PI * (284 + n) / 365);
  const noonUTC = Date.UTC(year, month - 1, day, 12) - longitude * 4 * 60000 - equation * 60000;
  const noon = noonUTC + timeZoneOffset(timezone, new Date(noonUTC)) * 3600000;
  const latitudeRad = rad(latitude), declinationRad = rad(declination);
  const angleFor = (angle: number) => {
    const numerator = Math.sin(rad(angle)) - Math.sin(latitudeRad) * Math.sin(declinationRad);
    const denominator = Math.cos(latitudeRad) * Math.cos(declinationRad);
    return deg(Math.acos(Math.min(1, Math.max(-1, numerator / denominator))));
  };
  const dawnAngle = ({ 1: 15, 2: 15, 3: 18, 4: 18, 5: 19.5, 8: 18.2, 11: 18, 12: 18, 13: 18.8, 14: 18.5, 15: 18, 16: 18.5, 21: 18 } as Record<number, number>)[method] ?? 18;
  let fajr = noon - angleFor(-dawnAngle) * 240000;
  const sunrise = noon - angleFor(-0.833) * 240000;
  const sunset = noon + angleFor(-0.833) * 240000;
  let isha = [1, 2, 3, 4, 14, 15].includes(method) ? sunset + 90 * 60000 : noon + angleFor(-18) * 240000;
  const shadowLength = school === 1 ? 2 : 1;
  const difference = rad(Math.abs(latitude - declination));
  const asrAltitude = deg(Math.atan(1 / (shadowLength + Math.tan(difference))));
  const asr = noon + angleFor(asrAltitude) * 240000;
  const nightDuration = Math.max(0, 24 - 2 * angleFor(-0.833) / 15);
  if (!Number.isFinite(fajr)) fajr = sunrise - nightDuration / 7 * 3600000;
  if (!Number.isFinite(isha)) isha = sunset + nightDuration / 7 * 3600000;
  const names = [["Fajr", "الفجر", fajr], ["Sunrise", "الشروق", sunrise], ["Dhuhr", "الظهر", noon + 2 * 60000], ["Asr", "العصر", asr], ["Maghrib", "المغرب", sunset], ["Isha", "العشاء", isha]] as const;
  const prayers: Prayer[] = names.map(([name, arabic, time]) => ({ name, arabic, time: Number.isFinite(time) ? new Intl.DateTimeFormat("en-GB", { timeZone: timezone, hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date(time)) : "--:--", timestamp: Number.isFinite(time) ? time : 0 }));
  const h = hijriDate(selectedDate);
  return { prayers, hijri: `${h.day} ${h.month} ${h.year} AH`, hijriDay: h.day, hijriMonth: h.month, hijriYear: h.year, timezone, date: dateKey(timezone, selectedDate), source: "Calculated locally · May differ from your local mosque" };
}
export function qiblaBearing(lat: number, lng: number) {
  const p1 = rad(lat), p2 = rad(21.4225), delta = rad(39.8262 - lng);
  const y = Math.sin(delta);
  const x = Math.cos(p1) * Math.tan(p2) - Math.sin(p1) * Math.cos(delta);
  return (deg(Math.atan2(y, x)) + 360) % 360;
}
