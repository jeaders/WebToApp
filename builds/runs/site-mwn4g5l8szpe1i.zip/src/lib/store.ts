import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles, content, bookmarks, counters, reminders, dailyLogs, notes, quizAttempts, zakatRecords, lessonProgress } from "@/db/schema";
import { seedContent } from "./content";
import { currentUser } from "./auth";
import type { Workspace } from "./types";

let seedPromise: Promise<void> | null = null;
export async function ensureSeeded() {
  if (!seedPromise) seedPromise = (async () => {
    await db.insert(content).values(seedContent).onConflictDoNothing();
  })().catch(error => { seedPromise = null; throw error; });
  await seedPromise;
}
export function dateKey(timezone = "Europe/London") {
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  return `${parts.find(p => p.type === "year")!.value}-${parts.find(p => p.type === "month")!.value}-${parts.find(p => p.type === "day")!.value}`;
}
export async function initializeUser(userId: string) {
  const date = dateKey();
  await db.transaction(async tx => {
    await tx.insert(counters).values([
      { userId, title: "Morning remembrance", arabic: "سُبْحَانَ اللَّهِ", count: 24, target: 100 },
      { userId, title: "Alhamdulillah", arabic: "الْحَمْدُ لِلَّهِ", count: 18, target: 100 },
      { userId, title: "Salawat", arabic: "صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ", count: 8, target: 50 }
    ]);
    await tx.insert(reminders).values([
      { userId, title: "Start your day with Quran", time: "08:00", frequency: "daily" },
      { userId, title: "Evening remembrance", time: "18:30", frequency: "daily" },
      { userId, title: "A moment of reflection", time: "21:00", frequency: "daily", enabled: false }
    ]);
    await tx.insert(bookmarks).values([
      { userId, resourceType: "ayah", resourceId: "94:5", title: "Indeed, with hardship comes ease", subtitle: "Surah Ash-Sharh · Ayah 5" },
      { userId, resourceType: "hadith", resourceId: "bukhari-1", title: "Actions are judged by intentions", subtitle: "Sahih al-Bukhari · Hadith 1" },
      { userId, resourceType: "dua", resourceId: "dua-morning", title: "Morning remembrance", subtitle: "Daily adhkar · Sahih Muslim 2723" }
    ]);
    await tx.insert(dailyLogs).values({ userId, date, prayers: ["Fajr", "Dhuhr"], quranRead: 2, zikrCount: 50 });
    const history = [3, 5, 4, 5, 2, 5];
    for (let i = 0; i < history.length; i++) {
      const d = new Date(`${date}T12:00:00Z`); d.setUTCDate(d.getUTCDate() - i - 1);
      await tx.insert(dailyLogs).values({ userId, date: d.toISOString().slice(0, 10), prayers: Array.from({ length: history[i] }, (_, n) => ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"][n]), quranRead: 1 + i % 3, zikrCount: 30 + i * 15 });
    }
    await tx.insert(quizAttempts).values({ userId, quizId: "kids", score: 4, total: 5 });
  });
}
export async function getWorkspace(): Promise<Workspace | null> {
  const user = await currentUser();
  if (!user) return null;
  await ensureSeeded();
  const [allContent, saved, myCounters, myReminders, logs, myNotes, attempts, records, progress] = await Promise.all([
    db.select().from(content).orderBy(asc(content.sortOrder)),
    db.select().from(bookmarks).where(eq(bookmarks.userId, user.id)).orderBy(asc(bookmarks.createdAt)),
    db.select().from(counters).where(eq(counters.userId, user.id)).orderBy(asc(counters.createdAt)),
    db.select().from(reminders).where(eq(reminders.userId, user.id)).orderBy(asc(reminders.time)),
    db.select().from(dailyLogs).where(eq(dailyLogs.userId, user.id)),
    db.select().from(notes).where(eq(notes.userId, user.id)).orderBy(asc(notes.createdAt)),
    db.select().from(quizAttempts).where(eq(quizAttempts.userId, user.id)),
    db.select().from(zakatRecords).where(eq(zakatRecords.userId, user.id)),
    db.select().from(lessonProgress).where(eq(lessonProgress.userId, user.id))
  ]);
  return JSON.parse(JSON.stringify({ user, content: allContent, bookmarks: saved, counters: myCounters, reminders: myReminders, logs, notes: myNotes, attempts, zakatRecords: records, progress })) as Workspace;
}
export async function getDailyLog(userId: string) {
  const date = dateKey();
  await db.insert(dailyLogs).values({ userId, date }).onConflictDoNothing();
  const [log] = await db.select().from(dailyLogs).where(and(eq(dailyLogs.userId, userId), eq(dailyLogs.date, date))).limit(1);
  return log;
}
