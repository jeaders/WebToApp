"use client";
import { Clock3, MapPin, Check, ArrowRight, Sunrise, Sun, Sunset, Moon, CloudSun } from "lucide-react";
import { useApp } from "./app-context";
import { TextLink } from "./ui";
import { dateKey, timeZoneOffset } from "@/lib/prayer";
export function PrayerCard({ expanded = false }: { expanded?: boolean }) {
  const { prayer, workspace, now, navigate, setLocationOpen, togglePrayer } = useApp();
  const prayers = prayer.prayers.filter(p => p.name !== "Sunrise");
  const next = prayer.prayers.find(p => p.timestamp > now);
  const tomorrow = new Date(`${prayer.date}T12:00:00Z`); tomorrow.setUTCDate(tomorrow.getUTCDate() + 1);
  const [fajrHour, fajrMinute] = prayer.prayers[0].time.split(":").map(Number);
  const fajrUTC = Date.UTC(tomorrow.getUTCFullYear(), tomorrow.getUTCMonth(), tomorrow.getUTCDate(), fajrHour, fajrMinute);
  const tomorrowFajr = fajrUTC - timeZoneOffset(workspace?.user.timezone ?? "Europe/London", new Date(fajrUTC)) * 3600000;
  const target = next?.timestamp ?? tomorrowFajr;
  const remaining = Math.max(0, Math.floor((target - now) / 1000));
  const countdown = [Math.floor(remaining / 3600), Math.floor(remaining % 3600 / 60), remaining % 60];
  const completed = workspace?.logs.find(l => l.date === dateKey(workspace.user.timezone))?.prayers ?? [];
  const icons = [Moon, Sunrise, Sun, CloudSun, Sunset, Moon];
  return <section className={`card prayer-card ${expanded ? "prayer-card-expanded" : ""}`}>
    <div className="card-heading"><div className="card-heading-title"><span className="icon-tile green"><Clock3 size={19}/></span><div><h3>Prayer times</h3><button className="location-label" onClick={() => setLocationOpen(true)}><MapPin size={12}/>{workspace?.user.city ?? "London"}, {workspace?.user.country ?? "United Kingdom"}</button></div></div><span className="badge neutral">{workspace?.user.method === 2 ? "ISNA" : "Calculated"}</span></div>
    <div className="next-prayer"><div className="next-prayer-label"><span className="live-dot"/><div><span className="eyebrow">UP NEXT</span><strong>{next?.name ?? "Fajr"}<small>{next ? " prayer" : " tomorrow"}</small></strong></div></div><div className="countdown" aria-label="Time until next prayer">{countdown.map((n, i) => <div key={i}><strong>{String(n).padStart(2, "0")}</strong>{i < 2 && <span>:</span>}</div>)}</div></div>
    <div className="prayer-times">{prayer.prayers.map((p, i) => { const Icon = icons[prayer.prayers.indexOf(p)]; const done = completed.includes(p.name); return <div key={p.name} className={`prayer-time ${next?.name === p.name ? "is-next" : ""}`}><span className="prayer-name">{done ? <Check size={12}/> : <Icon size={14}/>}<button disabled={p.name === "Sunrise"} onClick={() => togglePrayer(p.name)} title={p.name === "Sunrise" ? "Sunrise marks the end of Fajr time" : done ? `Mark ${p.name} as not prayed` : `Mark ${p.name} as prayed`}>{p.name}</button></span><strong>{p.time}</strong>{expanded && <span className="prayer-arabic" lang="ar">{p.arabic}</span>}</div>; })}</div>
    <div className="prayer-footer"><span><span className="tiny-green-dot"/>{completed.length} of 5 prayers completed</span><TextLink onClick={() => navigate("prayer")}>View prayer times</TextLink></div>
  </section>;
}
