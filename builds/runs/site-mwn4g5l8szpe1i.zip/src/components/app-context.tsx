"use client";
import { createContext, useContext, useState, useEffect, useCallback, useMemo, type ReactNode } from "react";
import type { Workspace, View, PrayerData, Bookmark, Counter, User, DailyLog } from "@/lib/types";
import { calculatePrayerData, dateKey } from "@/lib/prayer";
import { cities } from "@/lib/content";

type Result = { item?: { id: string; [key: string]: unknown }; removed?: string; removedType?: "bookmarks" | "counters" | "reminders" | "notes" | "zakatRecords"; ok?: boolean };
type Toast = { message: string; type: "success" | "error" | "info" };
type BookmarkInput = { resourceType: string; resourceId: string; title: string; subtitle?: string };
type InstallEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };
type Context = {
  workspace: Workspace | null; loading: boolean; error: string | null; now: number;
  prayer: PrayerData; prayerDate: string; setPrayerDate: (date: string) => void;
  view: View; resource: string; navigate: (view: View, resource?: string) => void;
  refresh: () => Promise<void>; mutate: (action: string, payload?: Record<string, unknown>, message?: string) => Promise<Result>;
  toggleBookmark: (input: BookmarkInput) => Promise<void>; incrementCounter: (counter: Counter) => Promise<void>;
  togglePrayer: (name: string) => Promise<void>; notify: (message: string, type?: Toast["type"]) => void;
  toast: Toast | null; dismissToast: () => void;
  locationOpen: boolean; setLocationOpen: (open: boolean) => void;
  authOpen: boolean; setAuthOpen: (open: boolean) => void;
  searchOpen: boolean; setSearchOpen: (open: boolean) => void;
  authenticate: (mode: string, values: Record<string, string>) => Promise<void>;
  logout: () => Promise<void>; updateLocation: (city: typeof cities[number]) => Promise<void>;
  useGeolocation: () => Promise<void>; enableNotifications: () => Promise<void>;
  installApp: () => Promise<void>; canInstall: boolean;
};
const AppContext = createContext<Context | null>(null);
export function useApp() { const value = useContext(AppContext); if (!value) throw new Error("App provider is required"); return value; }
async function requestJSON(url: string, options?: RequestInit) { const response = await fetch(url, { ...options, headers: { "Content-Type": "application/json", ...options?.headers } }); const data = await response.json(); if (!response.ok) throw new Error(data.error || "Something went wrong. Please try again."); return data; }
export function AppProvider({ children }: { children: ReactNode }) {
  const [workspace, setWorkspace] = useState<Workspace | null>(null);
  const [loading, setLoading] = useState(true); const [error, setError] = useState<string | null>(null);
  const [now, setNow] = useState(Date.now()); const [toast, setToast] = useState<Toast | null>(null);
  const [view, setView] = useState<View>("dashboard"); const [resource, setResource] = useState("");
  const [locationOpen, setLocationOpen] = useState(false); const [authOpen, setAuthOpen] = useState(false); const [searchOpen, setSearchOpen] = useState(false);
  const [prayerDate, setPrayerDate] = useState(() => dateKey()); const [remotePrayer, setRemotePrayer] = useState<PrayerData | null>(null);
  const [canInstall, setCanInstall] = useState(false); const [installEvent, setInstallEvent] = useState<InstallEvent | null>(null);
  const user = workspace?.user;
  const notify = useCallback((message: string, type: Toast["type"] = "success") => setToast({ message, type }), []);
  const refresh = useCallback(async () => {
    try { const data = await requestJSON("/api/workspace"); setWorkspace(data); setError(null); }
    catch (e) { if (e instanceof Error && e.message === "Please sign in.") { setWorkspace(null); } else setError(e instanceof Error ? e.message : "Unable to load your workspace."); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { void (async () => { try { await refresh(); } catch {} })(); }, [refresh]);
  useEffect(() => { const timer = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(timer); }, []);
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(null), 4200); return () => clearTimeout(timer); }, [toast]);
  const navigate = useCallback((next: View, nextResource = "") => { setView(next); setResource(nextResource); window.history.pushState(null, "", `#${next}${nextResource ? `/${encodeURIComponent(nextResource)}` : ""}`); window.scrollTo({ top: 0, behavior: "smooth" }); }, []);
  useEffect(() => {
    const sync = () => { const [next, id] = window.location.hash.slice(1).split("/"); setView(next in defaultViews ? next as View : "dashboard"); setResource(id ? decodeURIComponent(id) : ""); };
    sync(); window.addEventListener("popstate", sync); window.addEventListener("hashchange", sync);
    const key = (event: KeyboardEvent) => { if ((event.metaKey || event.ctrlKey) && event.key === "k") { event.preventDefault(); setSearchOpen(true); } if (event.key === "Escape") { setSearchOpen(false); setAuthOpen(false); setLocationOpen(false); } };
    window.addEventListener("keydown", key); return () => { window.removeEventListener("popstate", sync); window.removeEventListener("hashchange", sync); window.removeEventListener("keydown", key); };
  }, []);
  useEffect(() => {
    const handler = (event: Event) => { event.preventDefault(); setInstallEvent(event as InstallEvent); setCanInstall(true); };
    window.addEventListener("beforeinstallprompt", handler); if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {}); return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);
  const mutate = useCallback(async (action: string, payload: Record<string, unknown> = {}, message?: string): Promise<Result> => {
    const result = await requestJSON("/api/workspace", { method: "POST", body: JSON.stringify({ action, ...payload }) }) as Result;
    if (result.item && action === "updateProfile") {
      const updated = result.item as unknown as User;
      setWorkspace(current => current ? { ...current, user: { ...current.user, ...updated } } : current);
    }
    if (result.item && action !== "updateProfile" && "userId" in result.item) {
      const item = result.item;
      const mapping: Record<string, "bookmarks" | "counters" | "reminders" | "notes" | "zakatRecords" | "progress" | "attempts" | "logs"> = {
        createCounter: "counters", updateCounter: "counters", createReminder: "reminders", updateReminder: "reminders",
        createNote: "notes", updateNote: "notes", saveZakat: "zakatRecords", markZakatPaid: "zakatRecords",
        setLessonProgress: "progress", recordQuiz: "attempts", toggleBookmark: "bookmarks", trackReading: "logs", togglePrayer: "logs"
      };
      const key = mapping[action];
      if (key) setWorkspace(current => {
        if (!current) return current;
        const collectionItems = current[key] as { id: string }[];
        const nextItems = collectionItems.some(entry => entry.id === item.id)
          ? collectionItems.map(entry => entry.id === item.id ? item : entry)
          : [...collectionItems, item];
        return { ...current, [key]: nextItems } as Workspace;
      });
    }
    if (result.removed) {
      const id = result.removed;
      const key = result.removedType ?? "bookmarks";
      setWorkspace(current => current ? { ...current, [key]: (current[key] as { id: string }[]).filter(entry => entry.id !== id) } as Workspace : current);
    }
    if (message) notify(message);
    return result;
  }, [notify]);
  const toggleBookmark = useCallback(async (input: BookmarkInput) => {
    if (!workspace) return;
    const existing = workspace.bookmarks.find(b => b.resourceType === input.resourceType && b.resourceId === input.resourceId);
    const tempId = `temp-${Date.now()}`;
    setWorkspace(current => current ? { ...current, bookmarks: existing ? current.bookmarks.filter(b => b.id !== existing.id) : [...current.bookmarks, { id: tempId, userId: current.user.id, ...input, subtitle: input.subtitle ?? "", createdAt: new Date().toISOString() }] } : current);
    try { const result = await mutate("toggleBookmark", input); setWorkspace(current => current ? { ...current, bookmarks: current.bookmarks.map(b => b.id === tempId && result.item ? result.item as unknown as Bookmark : b) } : current); await refresh(); notify(existing ? "Bookmark removed" : "Saved to your bookmarks"); }
    catch (e) { setWorkspace(current => current ? { ...current, bookmarks: existing ? [...current.bookmarks.filter(b => b.id !== tempId), existing] : current.bookmarks.filter(b => b.id !== tempId) } : current); notify(e instanceof Error ? e.message : "Couldn't save bookmark.", "error"); }
  }, [workspace, mutate, notify, refresh]);
  const incrementCounter = useCallback(async (counter: Counter) => {
    setWorkspace(current => current ? { ...current, counters: current.counters.map(c => c.id === counter.id ? { ...c, count: Math.min(c.count + 1, 1000000) } : c), logs: current.logs.map(l => l.date === dateKey(current.user.timezone) ? { ...l, zikrCount: l.zikrCount + 1 } : l) } : current);
    try { await mutate("incrementZikr", { id: counter.id }); if (counter.count + 1 === counter.target) notify("Beautifully done. Your zikr goal is complete!"); }
    catch (e) { setWorkspace(current => current ? { ...current, counters: current.counters.map(c => c.id === counter.id ? counter : c), logs: current.logs.map(l => l.date === dateKey(current!.user.timezone) ? { ...l, zikrCount: Math.max(0, l.zikrCount - 1) } : l) } : current); notify(e instanceof Error ? e.message : "Couldn't save your count.", "error"); }
  }, [mutate, notify]);
  const togglePrayer = useCallback(async (name: string) => {
    const log = workspace?.logs.find(l => l.date === dateKey(user?.timezone)); if (!log) return;
    const prayers = log.prayers.includes(name) ? log.prayers.filter(p => p !== name) : [...log.prayers, name];
    setWorkspace(current => current ? { ...current, logs: current.logs.map(l => l.id === log.id ? { ...l, prayers } : l) } : current);
    try { await mutate("togglePrayer", { name }); } catch (e) { setWorkspace(current => current ? { ...current, logs: current.logs.map(l => l.id === log.id ? log : l) } : current); notify(e instanceof Error ? e.message : "Couldn't update prayer.", "error"); }
  }, [workspace, user?.timezone, mutate, notify]);
  const localPrayer = useMemo(() => calculatePrayerData(Number(user?.latitude ?? 51.5074), Number(user?.longitude ?? -0.1278), user?.timezone ?? "Europe/London", user?.method ?? 2, user?.school ?? 0, new Date(`${prayerDate}T12:00:00Z`)), [user?.latitude, user?.longitude, user?.timezone, user?.method, user?.school, prayerDate]);
  const prayer = remotePrayer?.date === prayerDate ? remotePrayer : localPrayer;
  useEffect(() => {
    const controller = new AbortController(); if (!user) return;
    const p = new URLSearchParams({ lat: user.latitude, lng: user.longitude, timezone: user.timezone, date: prayerDate, method: String(user.method), school: String(user.school) });
    fetch(`/api/prayer?${p}`, { signal: controller.signal }).then(r => r.json()).then(data => { if (!data.error) setRemotePrayer(data); }).catch(() => {}); return () => controller.abort();
  }, [user?.latitude, user?.longitude, user?.timezone, user?.method, user?.school, prayerDate, !!user]);
  useEffect(() => { if (!user?.notifications || !("Notification" in window) || Notification.permission !== "granted") return;
    const check = async () => {
      const current = new Date(); const time = `${String(current.getHours()).padStart(2, "0")}:${String(current.getMinutes()).padStart(2, "0")}`;
      const reminders = (await fetch("/api/workspace").then(r => r.json()).catch(() => null))?.reminders ?? [];
      for (const reminder of reminders) { const day = current.getDay(); const applies = reminder.frequency === "daily" || (reminder.frequency === "weekdays" && day > 0 && day < 6) || (reminder.frequency === "weekends" && (day === 0 || day === 6)); const key = `sakina-notified-${user.id}-${reminder.id}-${current.toDateString()}`; if (reminder.enabled && applies && reminder.time === time && !localStorage.getItem(key)) { localStorage.setItem(key, "1"); const notification = new Notification(reminder.title, { body: "A little pause for your heart. Your reminder from Sakina.", icon: "/icon-192.png" }); notification.onclick = () => { window.focus(); navigate("reminders"); }; } }
    };
    void check(); const timer = setInterval(() => void check(), 30000); return () => clearInterval(timer);
  }, [user?.id, user?.notifications, navigate]);
  const authenticate = async (mode: string, values: Record<string, string>) => { await requestJSON("/api/auth", { method: "POST", body: JSON.stringify({ mode, ...values }) }); await refresh(); setAuthOpen(false); notify(mode === "demo" ? "Welcome to your demo workspace" : "Welcome back. Your journey continues."); };
  const logout = async () => { await requestJSON("/api/auth", { method: "DELETE" }); setWorkspace(null); setAuthOpen(false); notify("You've been signed out.", "info"); };
  const updateLocation = async (city: typeof cities[number]) => { const item = await mutate("updateProfile", city, `Prayer times updated for ${city.city}`); if (item.item) setWorkspace(current => current ? { ...current, user: { ...current.user, ...item.item } as User } : current); setLocationOpen(false); };
  const useGeolocation = async () => { if (!navigator.geolocation) throw new Error("Location is not supported on this device."); const position = await new Promise<GeolocationPosition>((resolve, reject) => navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 15000, enableHighAccuracy: false })); const city = { city: "Current location", country: "GPS coordinates", latitude: String(position.coords.latitude), longitude: String(position.coords.longitude), timezone: Intl.DateTimeFormat().resolvedOptions().timeZone }; await updateLocation(city); };
  const enableNotifications = async () => { if (!("Notification" in window)) throw new Error("This browser doesn't support notifications."); const permission = await Notification.requestPermission(); if (permission === "granted") { if ("serviceWorker" in navigator) { const registration = await navigator.serviceWorker.ready; await registration.showNotification("A little peace, every day", { body: "Your reminders are ready. May your day be filled with blessings.", icon: "/icon-192.png" }); } notify("Daily reminders are enabled while Sakina is open."); await refresh(); } else throw new Error("Notifications are blocked. You can allow them in your browser settings."); };
  const installApp = async () => { if (installEvent) { await installEvent.prompt(); const choice = await installEvent.userChoice; if (choice.outcome === "accepted") notify("Sakina is ready on your home screen."); setInstallEvent(null); setCanInstall(false); } else notify("To install: open your browser menu and choose 'Install app' or 'Add to Home Screen'.", "info"); };
  const value: Context = { workspace, loading, error, now, prayer, prayerDate, setPrayerDate, view, resource, navigate, refresh, mutate, toggleBookmark, incrementCounter, togglePrayer, notify, toast, dismissToast: () => setToast(null), locationOpen, setLocationOpen, authOpen, setAuthOpen, searchOpen, setSearchOpen, authenticate, logout, updateLocation, useGeolocation, enableNotifications, installApp, canInstall };
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
const defaultViews: Record<string, boolean> = { dashboard: true, prayer: true, quran: true, qibla: true, zikr: true, duas: true, calendar: true, zakat: true, hadith: true, lessons: true, names: true, quizzes: true, bookmarks: true, reminders: true, settings: true };
export type { BookmarkInput };
