import { pgTable, uuid, text, integer, boolean, timestamp, jsonb, uniqueIndex, doublePrecision } from "drizzle-orm/pg-core";

export const profiles = pgTable("profiles", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull().default("Yusuf Ahmed"),
  email: text("email").unique(),
  passwordHash: text("password_hash"),
  city: text("city").notNull().default("London"),
  country: text("country").notNull().default("United Kingdom"),
  latitude: text("latitude").notNull().default("51.5074"),
  longitude: text("longitude").notNull().default("-0.1278"),
  timezone: text("timezone").notNull().default("Europe/London"),
  method: integer("method").notNull().default(2),
  school: integer("school").notNull().default(0),
  dailyGoal: integer("daily_goal").notNull().default(100),
  notifications: boolean("notifications").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sessions = pgTable("sessions", {
  tokenHash: text("token_hash").primaryKey(),
  userId: uuid("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at").notNull(),
});

export const content = pgTable("content_items", {
  id: text("id").primaryKey(),
  kind: text("kind").notNull(),
  title: text("title").notNull(),
  arabic: text("arabic"),
  body: jsonb("body").$type<Record<string, unknown>>().notNull().default({}),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const bookmarks = pgTable("bookmarks", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  resourceType: text("resource_type").notNull(),
  resourceId: text("resource_id").notNull(),
  title: text("title").notNull(),
  subtitle: text("subtitle").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => [uniqueIndex("bookmark_unique").on(table.userId, table.resourceType, table.resourceId)]);

export const counters = pgTable("zikr_counters", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  arabic: text("arabic").notNull().default("سُبْحَانَ اللَّهِ"),
  target: integer("target").notNull().default(100),
  count: integer("count").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reminders = pgTable("reminders", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  time: text("time").notNull(),
  frequency: text("frequency").notNull().default("daily"),
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const dailyLogs = pgTable("daily_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  date: text("date").notNull(),
  prayers: jsonb("prayers").$type<string[]>().notNull().default([]),
  quranRead: integer("quran_read").notNull().default(0),
  zikrCount: integer("zikr_count").notNull().default(0),
}, (table) => [uniqueIndex("daily_log_unique").on(table.userId, table.date)]);

export const notes = pgTable("personal_notes", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  arabic: text("arabic").notNull().default(""),
  translation: text("translation").notNull().default(""),
  category: text("category").notNull().default("Personal dua"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const quizAttempts = pgTable("quiz_attempts", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  quizId: text("quiz_id").notNull(),
  score: integer("score").notNull(),
  total: integer("total").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const lessonProgress = pgTable("lesson_progress", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  lessonId: text("lesson_id").notNull(),
  completed: boolean("completed").notNull().default(true),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => [uniqueIndex("lesson_progress_unique").on(table.userId, table.lessonId)]);

export const zakatRecords = pgTable("zakat_records", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  year: text("year").notNull(),
  assets: jsonb("assets").$type<Record<string, number>>().notNull(),
  due: doublePrecision("due").notNull(),
  paid: boolean("paid").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
