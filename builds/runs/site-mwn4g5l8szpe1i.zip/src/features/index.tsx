"use client";
import { QuranPage } from "./quran";
import { ZikrPage } from "./zikr";
import { DuasPage } from "./duas";
import { PrayerPage, QiblaPage } from "./prayer";
import { CalendarPage } from "./calendar";
import { ZakatPage } from "./zakat";
import { HadithPage } from "./hadith";
import { LessonsPage } from "./lessons";
import { NamesPage } from "./names";
import { QuizzesPage } from "./quizzes";
import { BookmarksPage, RemindersPage } from "./personal";
import { SettingsPage } from "./settings";
import type { View } from "@/lib/types";
export function FeatureRenderer({ view }: { view: View }) {
  switch (view) {
    case "quran": return <QuranPage/>;
    case "zikr": return <ZikrPage/>;
    case "duas": return <DuasPage/>;
    case "prayer": return <PrayerPage/>;
    case "qibla": return <QiblaPage/>;
    case "calendar": return <CalendarPage/>;
    case "zakat": return <ZakatPage/>;
    case "hadith": return <HadithPage/>;
    case "lessons": return <LessonsPage/>;
    case "names": return <NamesPage/>;
    case "quizzes": return <QuizzesPage/>;
    case "bookmarks": return <BookmarksPage/>;
    case "reminders": return <RemindersPage/>;
    case "settings": return <SettingsPage/>;
    default: return null;
  }
}
