"use client";
import { useState, type FormEvent } from "react";
import { Wallet, Banknote, Gem, TrendingUp, Building2, CreditCard, Save, Trash2, Check, Info, HandHeart } from "lucide-react";
import { useApp } from "@/components/app-context";
import { PageHeader, Button, IconButton, SectionHeading, EmptyState, Modal } from "@/components/ui";
const assetFields = [
  { key: "cash", title: "Cash in hand & bank balances", icon: Banknote },
  { key: "savings", title: "Savings & current accounts", icon: Wallet },
  { key: "gold", title: "Gold & silver value", icon: Gem },
  { key: "investments", title: "Stocks & investments", icon: TrendingUp },
  { key: "business", title: "Business assets & inventory", icon: Building2 },
  { key: "debts", title: "Money owed & short-term liabilities", icon: CreditCard }
];
type AssetValues = Record<string, number>;
export function ZakatPage() {
  const { workspace, mutate, notify } = useApp();
  const [assetValues, setAssetValues] = useState<AssetValues>({ cash: 0, savings: 0, gold: 0, silver: 0, investments: 0, business: 0, debts: 0 });
  const [goldPrice, setGoldPrice] = useState(78);
  const [silverPrice, setSilverPrice] = useState(1.2);
  const [standard, setStandard] = useState("silver");
  const [year, setYear] = useState(String(new Date().getFullYear()));
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [busy, setBusy] = useState("");
  const updateAsset = (key: string, value: number) => setAssetValues(previous => ({ ...previous, [key]: value }));
  const totalAssets = assetValues.cash + assetValues.savings + assetValues.gold + assetValues.silver + assetValues.investments + assetValues.business;
  const netAssets = totalAssets - assetValues.debts;
  const nisab = Math.min(goldPrice * 85, silverPrice * 613.35);
  const eligible = netAssets >= nisab && netAssets > 0;
  const due = eligible ? Math.round(netAssets * 25) / 1000 : 0;
  const money = (value: number) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(value);
  const save = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setSaving(true);
    try { await mutate("saveZakat", { assets: assetValues, goldPrice, silverPrice, year }, "Your Zakat calculation has been saved."); }
    catch (error) { notify(error instanceof Error ? error.message : "Couldn't save calculation.", "error"); }
    finally { setSaving(false); }
  };
  return <div className="page-intro">
    <PageHeader title="Give with intention." subtitle="A simple Zakat calculator. A meaningful act of care."><span className="badge green-badge">2.5% of qualifying wealth</span></PageHeader>
    <div className="zakat-layout">
      <form className="card zakat-form-card" onSubmit={save}>
        <h3>Your Zakat calculation</h3><p>Enter the current value of your qualifying assets in GBP (£).</p>
        {assetFields.map(field => <div className="asset-input" key={field.key}>
          <span className="icon-tile sage"><field.icon size={16}/></span>
          <label htmlFor={`asset-${field.key}`}>{field.title}</label>
          <input id={`asset-${field.key}`} type="number" min={0} max={1000000000000} step="0.01" value={assetValues[field.key]} onChange={event => updateAsset(field.key, Number(event.target.value))} required/>
        </div>)}
        <div className="asset-input"><span className="icon-tile gold"><Gem size={16}/></span><label htmlFor="asset-silver">Value of silver separately</label><input id="asset-silver" type="number" min={0} value={assetValues.silver} onChange={event => updateAsset("silver", Number(event.target.value))}/></div>
        <div className="zakat-price-row">
          <label className="field"><span>Gold price / gram (£)</span><input type="number" min="0.01" step="0.01" value={goldPrice} onChange={event => setGoldPrice(Number(event.target.value))} required/></label>
          <label className="field"><span>Silver price / gram (£)</span><input type="number" min="0.01" step="0.01" value={silverPrice} onChange={event => setSilverPrice(Number(event.target.value))} required/></label>
        </div>
        <label className="field"><span>Choose your nisab threshold</span><select value={standard} onChange={event => setStandard(event.target.value)}><option value="silver">Silver · 613.35 grams (lower threshold)</option><option value="gold">Gold · 85 grams</option></select></label>
        <label className="field"><span>Lunar year of calculation</span><input value={year} onChange={event => setYear(event.target.value)} placeholder="2026" required/></label>
        <p className="form-hint"><Info size={13}/>Market prices are entered by you, not fetched live.</p>
        <Button type="submit" loading={saving} className="full-width" style={{ marginTop: 23 }}><Save size={15}/>Save calculation</Button>
      </form>
      <section className="card zakat-result">
        <span className="icon-tile green" style={{ marginBottom: 16 }}><HandHeart size={24}/></span>
        <h3>{eligible ? "Your Zakat, with intention" : "Your current Zakat estimate"}</h3>
        <div className="amount">{money(due)}</div>
        <span className="currency-label">{eligible ? "Your estimated Zakat due" : netAssets <= 0 ? "No positive net assets to calculate" : "Below the nisab threshold · No Zakat due"}</span>
        <div className="result-breakdown">
          <div><span>Total assets</span><strong>{money(totalAssets)}</strong></div>
          <div><span>Deductible liabilities</span><strong>− {money(assetValues.debts)}</strong></div>
          <div><span>Net qualifying wealth</span><strong>{money(netAssets)}</strong></div>
          <div><span>{standard === "silver" ? "Silver" : "Gold"} nisab threshold</span><strong>{money(standard === "silver" ? silverPrice * 613.35 : goldPrice * 85)}</strong></div>
          <div><span>Zakat rate</span><strong>2.5%</strong></div>
        </div>
        <p className="zakat-disclaimer">This is an educational estimate, not a religious ruling. Asset eligibility, nisab, and payment depend on your circumstances and the lunar year. Consult a trusted scholar for personalized guidance.</p>
      </section>
    </div>
    <SectionHeading title="Your giving history" subtitle="Keep a record of your intention and payment"/>
    <div className="card" style={{ padding: "0 24px" }}>
      {!workspace!.zakatRecords.length ? <EmptyState icon={HandHeart} title="Your first act of intention" description="Save a calculation to begin your Zakat record. You can mark it as paid when you have given."/> : workspace!.zakatRecords.map(record => <div className="zakat-history-row" key={record.id}>
        <span className="icon-tile sage"><Wallet size={18}/></span>
        <div><h4>{record.year} Zakat calculation</h4><p>{money(record.due)} · {record.paid ? "Payment completed" : "Saved, awaiting payment"}</p></div>
        <Button small variant={record.paid ? "secondary" : "primary"} disabled={busy === record.id} onClick={async () => { setBusy(record.id); try { await mutate("markZakatPaid", { id: record.id, paid: !record.paid }, record.paid ? "Record marked as unpaid." : "May your generosity be rewarded."); } catch (error) { notify(error instanceof Error ? error.message : "Couldn't update record.", "error"); } finally { setBusy(""); } }}><Check size={13}/>{record.paid ? "Paid" : "Mark as paid"}</Button>
        <IconButton label="Delete calculation" onClick={() => setDeleting(record.id)}><Trash2 size={16}/></IconButton>
      </div>)}
    </div>
    {deleting && <Modal title="Delete this calculation?" subtitle="This saved Zakat record will be permanently removed." onClose={() => setDeleting(null)}><div className="modal-footer"><Button variant="secondary" onClick={() => setDeleting(null)}>Keep record</Button><Button variant="danger" onClick={async () => { try { await mutate("deleteZakat", { id: deleting }, "Calculation deleted."); setDeleting(null); } catch (error) { notify(error instanceof Error ? error.message : "Couldn't delete record.", "error"); } }}>Delete record</Button></div></Modal>}
  </div>;
}
