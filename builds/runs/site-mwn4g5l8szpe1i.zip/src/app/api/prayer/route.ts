import { NextRequest } from "next/server";
import { calculatePrayerData, timeZoneOffset } from "@/lib/prayer";
import type { PrayerData } from "@/lib/types";
export async function GET(request: NextRequest) {
  const p = new URL(request.url).searchParams;
  const latitude = Number(p.get("lat") ?? 51.5074), longitude = Number(p.get("lng") ?? -0.1278);
  const timezone = p.get("timezone") || "Europe/London", method = Number(p.get("method") ?? 2), school = Number(p.get("school") ?? 0);
  try { new Intl.DateTimeFormat("en", { timeZone: timezone }); } catch { return Response.json({ error: "Invalid timezone." }, { status: 400 }); }
  if (!Number.isFinite(latitude) || Math.abs(latitude) > 90 || !Number.isFinite(longitude) || Math.abs(longitude) > 180) return Response.json({ error: "Invalid coordinates." }, { status: 400 });
  const date = p.get("date") && /^\d{4}-\d{2}-\d{2}$/.test(p.get("date")!) ? new Date(p.get("date")! + "T12:00:00Z") : new Date();
  if (Number.isNaN(date.getTime()) || ![0, 1].includes(school)) return Response.json({ error: "Invalid date or calculation method." }, { status: 400 });
  const dd = String(date.getUTCDate()).padStart(2, "0"), mm = String(date.getUTCMonth() + 1).padStart(2, "0");
  const url = new URL(`https://api.aladhan.com/v1/timings/${dd}-${mm}-${date.getUTCFullYear()}`);
  url.search = new URLSearchParams({ latitude: String(latitude), longitude: String(longitude), method: String(method), school: String(school), timezonestring: timezone }).toString();
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(12000), next: { revalidate: 900 } });
    if (!response.ok) throw new Error("Prayer service unavailable");
    const json = await response.json(); if (json.code !== 200) throw new Error("Invalid prayer response");
    const data = json.data;
    const names = [["Fajr", "الفجر"], ["Sunrise", "الشروق"], ["Dhuhr", "الظهر"], ["Asr", "العصر"], ["Maghrib", "المغرب"], ["Isha", "العشاء"]] as const;
    const prayers = names.map(([name, arabic]) => {
      const time = String(data.timings[name]).split(" ")[0]; const [hour, minute] = time.split(":").map(Number);
      if (!Number.isFinite(hour) || !Number.isFinite(minute)) throw new Error("Invalid prayer time");
      const utc = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), hour, minute);
      let timestamp = utc;
      for (let i = 0; i < 2; i++) { const local = new Date(timestamp); timestamp = utc - timeZoneOffset(timezone, local) * 3600000; }
      return { name, arabic, time, timestamp };
    });
    const result: PrayerData = { prayers, hijri: data.date.hijri.date, hijriDay: data.date.hijri.day, hijriMonth: data.date.hijri.month.en, hijriYear: data.date.hijri.year, timezone, date: p.get("date") ?? date.toISOString().slice(0, 10), source: "AlAdhan" };
    return Response.json(result);
  } catch { return Response.json(calculatePrayerData(latitude, longitude, timezone, method, school, date)); }
}
