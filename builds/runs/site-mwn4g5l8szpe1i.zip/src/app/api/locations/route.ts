import { NextRequest } from "next/server";
import { cities } from "@/lib/content";
export async function GET(request: NextRequest) { const query = (new URL(request.url).searchParams.get("q") ?? "").toLowerCase(); return Response.json({ cities: cities.filter(c => `${c.city} ${c.country}`.toLowerCase().includes(query)).slice(0, 20) }); }
