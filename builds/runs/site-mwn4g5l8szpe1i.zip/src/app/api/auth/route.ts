import { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { hashPassword, verifyPassword, createSession, destroySession, currentUser } from "@/lib/auth";
import { initializeUser, ensureSeeded } from "@/lib/store";
export const dynamic = "force-dynamic";
export async function GET() { try { return Response.json({ user: await currentUser() }); } catch { return Response.json({ error: "Unable to load account." }, { status: 500 }); } }
export async function POST(request: NextRequest) {
  try {
    await ensureSeeded(); const body = await request.json();
    if (body.mode === "demo") {
      let [demo] = await db.select().from(profiles).where(eq(profiles.email, "demo@sakina.app"));
      if (!demo) { [demo] = await db.insert(profiles).values({ email: "demo@sakina.app", passwordHash: hashPassword("Sakina123!") }).returning(); await initializeUser(demo.id); }
      await createSession(demo.id); return Response.json({ ok: true });
    }
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const password = typeof body.password === "string" ? body.password : "";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 8 || password.length > 128) return Response.json({ error: "Enter a valid email and a password of at least 8 characters." }, { status: 400 });
    const [existing] = await db.select().from(profiles).where(eq(profiles.email, email));
    if (body.mode === "signup") {
      if (existing) return Response.json({ error: "An account with this email already exists. Please sign in." }, { status: 409 });
      const name = typeof body.name === "string" ? body.name.trim().slice(0, 100) : "";
      if (!name) return Response.json({ error: "Please enter your name." }, { status: 400 });
      const [user] = await db.insert(profiles).values({ name, email, passwordHash: hashPassword(password) }).returning();
      await initializeUser(user.id); await createSession(user.id); return Response.json({ ok: true });
    }
    if (!existing?.passwordHash || !verifyPassword(password, existing.passwordHash)) return Response.json({ error: "The email or password is incorrect." }, { status: 401 });
    await createSession(existing.id); return Response.json({ ok: true });
  } catch (error) { console.error("Authentication error", error); return Response.json({ error: "We couldn't complete that. Please try again." }, { status: 500 }); }
}
export async function DELETE() { try { await destroySession(); return Response.json({ ok: true }); } catch { return Response.json({ error: "Unable to sign out." }, { status: 500 }); } }
