import { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { content } from "@/db/schema";
import { seedContent, translations, reciters } from "@/lib/content";
import type { QuranChapter, Ayah } from "@/lib/types";
type ApiAyah = { number: number; text: string; numberInSurah?: number };
type ApiChapter = { number: number; name: string; englishName: string; englishNameTranslation?: string; revelationType: string; ayahs: ApiAyah[] };
async function getEdition(surah: number, edition: string) { const response = await fetch(`https://api.alquran.cloud/v1/surah/${surah}/${edition}`, { signal: AbortSignal.timeout(14000), next: { revalidate: 86400 } }); if (!response.ok) throw new Error("Quran service unavailable"); const json = await response.json(); if (json.code !== 200) throw new Error("Invalid Quran response"); return json.data as ApiChapter | ApiChapter[]; }
export async function GET(request: NextRequest) {
  const p = new URL(request.url).searchParams;
  try {
    const number = Number(p.get("surah") ?? 1);
    if (!Number.isInteger(number) || number < 1 || number > 114) return Response.json({ error: "Choose a surah from 1 to 114." }, { status: 400 });
    const translation = p.get("translation") || "en.sahih"; const reciter = p.get("reciter") || "ar.alafasy";
    if (!translations.some(t => t.id === translation)) return Response.json({ error: "Unsupported translation." }, { status: 400 });
    if (!reciters.some(r => r.id === reciter)) return Response.json({ error: "Unsupported reciter." }, { status: 400 });
    const [cached] = await db.select().from(content).where(eq(content.id, `quran-${number}`));
    const cachedChapter = cached?.body.chapter as QuranChapter | undefined;
    if (cachedChapter?.ayahs?.length && cached.body.translation === translation) return Response.json({ ...cachedChapter, source: "Quran reference", ayahs: cachedChapter.ayahs.map(a => ({ ...a, audio: `https://cdn.islamic.network/quran/audio/128/${reciter}/${a.global}.mp3` })) });
    const results = await Promise.allSettled([getEdition(number, "quran-uthmani"), getEdition(number, translation)]);
    const arabic: ApiChapter | undefined = results[0].status === "fulfilled" && !Array.isArray(results[0].value) ? results[0].value : cachedChapter as ApiChapter | undefined;
    if (!arabic) return Response.json({ error: "The Quran service is temporarily unavailable. Please try again." }, { status: 503 });
    const translated = results[1].status === "fulfilled" && !Array.isArray(results[1].value) ? results[1].value as ApiChapter : null;
    const ayahs: Ayah[] = arabic.ayahs.map((a, i) => ({ number: a.numberInSurah ?? i + 1, global: a.number, arabic: a.text.replace(/^\uFEFF/, ""), translation: translated?.ayahs[i]?.text ?? cachedChapter?.ayahs[i]?.translation ?? "", audio: `https://cdn.islamic.network/quran/audio/128/${reciter}/${a.number}.mp3` }));
    const chapter: QuranChapter = { number, name: arabic.englishName, arabic: arabic.name, englishName: arabic.englishNameTranslation ?? arabic.englishName, revelation: arabic.revelationType, ayahs, source: "Al Quran Cloud" };
    await db.insert(content).values({ id: `quran-${number}`, kind: "quran", title: chapter.name, arabic: ayahs.map(a => a.arabic).join("\n"), body: { chapter, translation }, sortOrder: number }).onConflictDoUpdate({ target: content.id, set: { body: { chapter, translation }, title: chapter.name } });
    return Response.json(chapter);
  } catch { const number = Number(new URL(request.url).searchParams.get("surah") ?? 1); const fallback = seedContent.find(c => c.id === `quran-${number}`); if (fallback) { const chapter = fallback.body.chapter as QuranChapter; return Response.json({ ...chapter, source: "Offline Quran reference" }); } return Response.json({ error: "Unable to load this surah. Please try again." }, { status: 503 }); }
}
