import { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { content } from "@/db/schema";
import { quranSeed } from "@/lib/content";
export async function GET(request: NextRequest) {
  const p = new URL(request.url).searchParams; const surah = Number(p.get("surah") ?? 1);
  if (!Number.isInteger(surah) || surah < 1 || surah > 114) return Response.json({ error: "Invalid surah." }, { status: 400 });
  try {
    const [cached] = await db.select().from(content).where(eq(content.id, `quran-${surah}`));
    const chapter = cached?.body.chapter as { ayahs: { number: number; tafsir?: string }[] } | undefined;
    if (chapter?.ayahs.every(a => a.tafsir)) return Response.json({ tafsir: Object.fromEntries(chapter.ayahs.map(a => [a.number, a.tafsir])), source: "Tafsir al-Jalalayn · cached" });
    const response = await fetch(`https://api.alquran.cloud/v1/surah/${surah}/en.jalalayn`, { signal: AbortSignal.timeout(14000), next: { revalidate: 86400 } });
    if (!response.ok) throw new Error("Tafsir unavailable"); const json = await response.json(); if (json.code !== 200) throw new Error("Invalid tafsir");
    const tafsir = Object.fromEntries(json.data.ayahs.map((a: { numberInSurah: number; text: string }) => [a.numberInSurah, a.text.trim()]));
    if (cached) await db.update(content).set({ body: { ...cached.body, tafsir } }).where(eq(content.id, cached.id));
    else { const seed = quranSeed.find(c => c.id === `quran-${surah}`); if (seed) await db.insert(content).values({ ...seed, body: { chapter: seed.body.verses, tafsir } }).onConflictDoUpdate({ target: content.id, set: { body: { chapter: seed.body.verses, tafsir } } }); }
    return Response.json({ tafsir, source: "Tafsir al-Jalalayn" });
  } catch {
    const seed = quranSeed.find(c => c.id === `quran-${surah}`);
    if (surah === 1) return Response.json({ tafsir: Object.fromEntries((seed!.body.verses as { number: number; tafsir: string }[]).map((a: { number: number; tafsir: string }) => [a.number, a.tafsir])), source: "Curated tafsir summary" });
    return Response.json({ error: "Tafsir is temporarily unavailable. Try again shortly." }, { status: 503 });
  }
}
