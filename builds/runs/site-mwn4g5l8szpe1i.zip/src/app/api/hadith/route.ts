import { NextRequest } from "next/server";
import { seedContent } from "@/lib/content";
type Hadith = { id: string; collection: string; number: number; title: string; text: string; narrator: string; category: string; arabic: string; source: string };
export async function GET(request: NextRequest) {
  const p = new URL(request.url).searchParams; const collection = p.get("collection") || "bukhari";
  const collections: Record<string, string> = { bukhari: "Sahih al-Bukhari", muslim: "Sahih Muslim", abudawud: "Sunan Abu Dawud", tirmidhi: "Jami` at-Tirmidhi", nasai: "Sunan an-Nasa'i" };
  if (!collections[collection]) return Response.json({ error: "Unknown collection." }, { status: 400 });
  const local: Hadith[] = seedContent.filter(c => c.kind === "hadith" && c.body.collection === collection).map(c => ({ id: c.id, collection, number: Number(c.body.number), title: c.title, text: String(c.body.text), narrator: String(c.body.narrator), category: String(c.body.category), arabic: c.arabic ?? "", source: "Curated reference" }));
  const number = Number(p.get("number")); const start = p.has("start") ? Number(p.get("start")) : number;
  if (!Number.isInteger(start) || start < 1) return Response.json({ hadiths: local, source: "Curated reference" });
  try {
    const end = Math.min(start + 19, collection === "bukhari" ? 7563 : collection === "muslim" ? 5362 : 10000);
    void end;
    const response = await fetch(`https://hadithapi.pages.dev/api/${collection}/${start}`, { signal: AbortSignal.timeout(10000), next: { revalidate: 86400 } });
    if (!response.ok) throw new Error("Hadith unavailable"); const data = await response.json();
    if (typeof data.hadith_english !== "string") throw new Error("Invalid hadith");
    const hadith: Hadith = { id: `${collection}-${data.id ?? start}`, collection, number: data.id ?? start, title: data.chapterName?.replace(/^Chapter:\s*/i, "").slice(0, 100) || collections[collection], text: data.hadith_english.trim(), narrator: data.header?.replace(/^Narrated\s+/i, "").replace(/:$/, "") || "Companion of the Prophet ﷺ", category: data.bookName?.trim() || "Hadith", arabic: "", source: "English translation" };
    const localInRange = local.filter(h => h.number < start || h.number > start);
    return Response.json({ hadiths: [hadith, ...localInRange], source: "Hadith API" });
  } catch { return Response.json({ hadiths: local.filter(h => !start || h.number >= start), source: "Curated reference" }); }
}
