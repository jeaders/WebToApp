import { NextRequest } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { profiles, bookmarks, counters, reminders, dailyLogs, notes, quizAttempts, zakatRecords, lessonProgress } from "@/db/schema";
import { currentUser, createSession } from "@/lib/auth";
import { getWorkspace, getDailyLog, dateKey, initializeUser, ensureSeeded } from "@/lib/store";
import { quizzes } from "@/lib/content";
export const dynamic = "force-dynamic";
const fail = (message: string, status = 400) => Response.json({ error: message }, { status });
function text(value: unknown, max = 200) { return typeof value === "string" ? value.trim().slice(0, max) : ""; }
function integer(value: unknown, min: number, max: number) { const n = Number(value); if (!Number.isInteger(n) || n < min || n > max) throw new Error("Please enter a valid whole number."); return n; }
function uuid(value: unknown) { const s = text(value); if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s)) throw new Error("Invalid item."); return s; }
export async function GET() {
  try {
    await ensureSeeded();
    if (!(await currentUser())) {
      const [guest] = await db.insert(profiles).values({ name: "Yusuf Ahmed" }).returning();
      await initializeUser(guest.id);
      await createSession(guest.id);
    }
    const workspace = await getWorkspace();
    return workspace ? Response.json(workspace) : fail("Please sign in.", 401);
  } catch (error) { console.error("Workspace error", error); return fail("We couldn't load your workspace. Please try again.", 500); }
}
export async function POST(request: NextRequest) {
  try {
    const user = await currentUser(); if (!user) return fail("Please sign in.", 401);
    const body = await request.json(); const userId = user.id; const owned = userId;
    switch (body.action) {
      case "toggleBookmark": {
        const resourceType = text(body.resourceType); const resourceId = text(body.resourceId); const title = text(body.title);
        if (!resourceType || !resourceId || !title) return fail("A title and resource are required.");
        const where = and(eq(bookmarks.userId, owned), eq(bookmarks.resourceType, resourceType), eq(bookmarks.resourceId, resourceId));
        const [existing] = await db.select().from(bookmarks).where(where);
        if (existing) { await db.delete(bookmarks).where(where); return Response.json({ removed: existing.id }); }
        const [saved] = await db.insert(bookmarks).values({ userId, resourceType, resourceId, title, subtitle: text(body.subtitle) }).onConflictDoNothing().returning();
        return Response.json({ item: saved });
      }
      case "deleteBookmark": { await db.delete(bookmarks).where(and(eq(bookmarks.id, uuid(body.id)), eq(bookmarks.userId, owned))); break; }
      case "createCounter": {
        const title = text(body.title); if (!title) return fail("Give your zikr a name.");
        const [item] = await db.insert(counters).values({ userId, title, arabic: text(body.arabic, 500) || "سُبْحَانَ اللَّهِ", target: integer(body.target ?? 100, 1, 1000000) }).returning(); return Response.json({ item }); }
      case "updateCounter": {
        const values: Partial<typeof counters.$inferInsert> = {};
        if (body.title !== undefined) { values.title = text(body.title); if (!values.title) return fail("A title is required."); }
        if (body.arabic !== undefined) values.arabic = text(body.arabic, 500);
        if (body.target !== undefined) values.target = integer(body.target, 1, 1000000);
        if (body.count !== undefined) values.count = integer(body.count, 0, 1000000);
        const [item] = await db.update(counters).set(values).where(and(eq(counters.id, uuid(body.id)), eq(counters.userId, owned))).returning();
        if (!item) return fail("Counter not found.", 404); return Response.json({ item });
      }
      case "deleteCounter": { const id = uuid(body.id); await db.delete(counters).where(and(eq(counters.id, id), eq(counters.userId, owned))); return Response.json({ ok: true, removed: id, removedType: "counters" }); }
      case "incrementZikr": {
        await db.transaction(async tx => {
          const [item] = await tx.select().from(counters).where(and(eq(counters.id, uuid(body.id)), eq(counters.userId, owned))).for("update");
          if (!item) throw new Error("Counter not found.");
          const count = Math.min(item.count + 1, 1000000);
          await tx.update(counters).set({ count }).where(eq(counters.id, item.id));
          await tx.update(dailyLogs).set({ zikrCount: sql`${dailyLogs.zikrCount} + ${count - item.count}` }).where(and(eq(dailyLogs.userId, owned), eq(dailyLogs.date, dateKey(user.timezone))));
        }); break;
      }
      case "createReminder": case "updateReminder": {
        const values = { title: text(body.title), time: text(body.time), frequency: ["daily", "weekdays", "weekends"].includes(body.frequency) ? body.frequency : "daily", enabled: body.enabled !== false };
        if (!values.title) return fail("Give your reminder a title.");
        if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(values.time)) return fail("Choose a valid time.");
        if (body.action === "updateReminder") { const [item] = await db.update(reminders).set(values).where(and(eq(reminders.id, uuid(body.id)), eq(reminders.userId, owned))).returning(); if (!item) return fail("Reminder not found.", 404); return Response.json({ item }); }
        const [item] = await db.insert(reminders).values({ userId, ...values }).returning(); return Response.json({ item });
      }
      case "deleteReminder": { const id = uuid(body.id); await db.delete(reminders).where(and(eq(reminders.id, id), eq(reminders.userId, owned))); return Response.json({ ok: true, removed: id, removedType: "reminders" }); }
      case "togglePrayer": {
        const prayer = text(body.name); if (!["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"].includes(prayer)) return fail("Invalid prayer.");
        const log = await getDailyLog(userId);
        const prayers = log.prayers.includes(prayer) ? log.prayers.filter(p => p !== prayer) : [...log.prayers, prayer];
        const [item] = await db.update(dailyLogs).set({ prayers }).where(eq(dailyLogs.id, log.id)).returning(); return Response.json({ item });
      }
      case "trackReading": {
        const log = await getDailyLog(userId);
        const [item] = await db.update(dailyLogs).set({ quranRead: log.quranRead + 1 }).where(eq(dailyLogs.id, log.id)).returning(); return Response.json({ item });
      }
      case "createNote": case "updateNote": {
        const values = { title: text(body.title), arabic: text(body.arabic, 5000), translation: text(body.translation, 5000), category: text(body.category) || "Personal dua" };
        if (!values.title) return fail("Give your dua a title.");
        if (!values.arabic && !values.translation) return fail("Add Arabic text or a translation.");
        if (body.action === "updateNote") { const [item] = await db.update(notes).set(values).where(and(eq(notes.id, uuid(body.id)), eq(notes.userId, owned))).returning(); if (!item) return fail("Dua not found.", 404); return Response.json({ item }); }
        const [item] = await db.insert(notes).values({ userId, ...values }).returning(); return Response.json({ item });
      }
      case "deleteNote": { const id = uuid(body.id); await db.transaction(async tx => { await tx.delete(notes).where(and(eq(notes.id, id), eq(notes.userId, owned))); await tx.delete(bookmarks).where(and(eq(bookmarks.userId, owned), eq(bookmarks.resourceType, "dua"), eq(bookmarks.resourceId, id))); }); return Response.json({ ok: true, removed: id, removedType: "notes" }); }
      case "updateProfile": {
        const values: Partial<typeof profiles.$inferInsert> = {};
        for (const key of ["name", "city", "country", "latitude", "longitude", "timezone"] as const) if (body[key] !== undefined) values[key] = text(body[key], 150);
        if (values.name !== undefined && !values.name) return fail("Please enter your name.");
        if (body.method !== undefined) values.method = integer(body.method, 1, 23);
        if (body.school !== undefined) values.school = integer(body.school, 0, 1);
        if (body.dailyGoal !== undefined) values.dailyGoal = integer(body.dailyGoal, 1, 100000);
        if (body.notifications !== undefined) values.notifications = Boolean(body.notifications);
        if (values.latitude !== undefined && (!Number.isFinite(Number(values.latitude)) || Math.abs(Number(values.latitude)) > 90)) return fail("Invalid latitude.");
        if (values.longitude !== undefined && (!Number.isFinite(Number(values.longitude)) || Math.abs(Number(values.longitude)) > 180)) return fail("Invalid longitude.");
        if (values.timezone !== undefined) { try { new Intl.DateTimeFormat("en", { timeZone: values.timezone }); } catch { return fail("Invalid timezone."); } }
        const [item] = await db.update(profiles).set(values).where(eq(profiles.id, owned)).returning(); return Response.json({ item });
      }
      case "recordQuiz": {
        const quiz = quizzes.find(q => q.id === body.quizId); if (!quiz) return fail("Quiz not found.");
        const score = integer(body.score, 0, quiz.questions.length);
        const [item] = await db.insert(quizAttempts).values({ userId, quizId: quiz.id, score, total: quiz.questions.length }).returning(); return Response.json({ item });
      }
      case "setLessonProgress": {
        const lessonId = text(body.lessonId); if (!lessonId.startsWith("lesson-")) return fail("Invalid lesson.");
        const [item] = await db.insert(lessonProgress).values({ userId, lessonId, completed: body.completed !== false }).onConflictDoUpdate({ target: [lessonProgress.userId, lessonProgress.lessonId], set: { completed: body.completed !== false, updatedAt: new Date() } }).returning(); return Response.json({ item });
      }
      case "saveZakat": {
        const assets: Record<string, number> = {};
        for (const key of ["cash", "savings", "gold", "silver", "investments", "business", "debts"]) { assets[key] = integer(body.assets?.[key] ?? 0, 0, 1000000000000); }
        const goldPrice = Number(body.goldPrice); const silverPrice = Number(body.silverPrice);
        if (!Number.isFinite(goldPrice) || goldPrice <= 0 || !Number.isFinite(silverPrice) || silverPrice <= 0) return fail("Enter valid market prices.");
        const nisab = Math.min(goldPrice * 85, silverPrice * 613.35);
        const net = Object.values(assets).reduce((a, b) => a + b, 0) - assets.debts;
        const due = net >= nisab ? Math.round(net * 25) / 1000 : 0;
        const [item] = await db.insert(zakatRecords).values({ userId, year: text(body.year) || String(new Date().getFullYear()), assets, due }).returning(); return Response.json({ item });
      }
      case "markZakatPaid": { const [item] = await db.update(zakatRecords).set({ paid: body.paid === true }).where(and(eq(zakatRecords.id, uuid(body.id)), eq(zakatRecords.userId, owned))).returning(); if (!item) return fail("Record not found.", 404); return Response.json({ item }); break; }
      case "deleteZakat": { const id = uuid(body.id); await db.delete(zakatRecords).where(and(eq(zakatRecords.id, id), eq(zakatRecords.userId, owned))); return Response.json({ ok: true, removed: id, removedType: "zakatRecords" }); }
      default: return fail("Unknown action.");
    }
    return Response.json({ ok: true });
  } catch (error) { console.error("Workspace mutation", error); return fail(error instanceof Error && !error.message.includes("query:") ? error.message : "We couldn't save that. Please try again.", 400); }
}
