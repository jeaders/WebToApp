import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
export const metadata: Metadata = {
  title: "Sakina — Peace in every moment",
  description: "Your daily Islamic companion. Prayer times, Quran, Qibla, zikr, authentic hadith, and meaningful moments of faith.",
  applicationName: "Sakina",
  manifest: "/manifest.webmanifest",
  icons: { icon: "/icon.svg", apple: "/icon-192.png" },
  appleWebApp: { capable: true, statusBarStyle: "default", title: "Sakina" },
};
export const viewport: Viewport = { themeColor: "#28664f", width: "device-width", initialScale: 1 };
export default function RootLayout({ children }: { children: ReactNode }) { return <html lang="en"><body>{children}</body></html>; }
