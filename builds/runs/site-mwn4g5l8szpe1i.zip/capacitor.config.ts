import type { CapacitorConfig } from "@capacitor/cli";
const config: CapacitorConfig = {
  appId: "app.sakina.companion",
  appName: "Sakina",
  webDir: "native-assets",
  server: {
    url: process.env.CAPACITOR_SERVER_URL || "https://e0001a9d5509bc.lhr.life",
    cleartext: false,
  },
  android: {
    backgroundColor: "#f7f8f5",
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
};
export default config;
