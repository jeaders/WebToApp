import { test, expect } from "@playwright/test";
import { calculatePrayerData, timeZoneOffset, qiblaBearing } from "../src/lib/prayer";
const screens = ["Prayer Times", "The Holy Quran", "Qibla Compass", "Zikr Counter", "Duas & Azkar", "Islamic Calendar", "Zakat Calculator", "Hadith Collections", "Tafsir & Tajweed", "99 Names of Allah", "Islamic Quizzes", "My Bookmarks", "My Reminders", "Settings"];
test("every navigation screen renders without runtime errors", async ({ page }) => {
  const errors: string[] = []; page.on("pageerror", e => errors.push(e.message));
  await page.goto("/"); await page.getByRole("heading", { name: /Assalamu Alaikum/ }).waitFor();
  for (const screen of screens) { await page.locator(".sidebar .nav-item").filter({ hasText: screen }).click(); await expect(page.locator("main h1")).toBeVisible(); }
  expect(errors).toEqual([]);
});
test("mobile screens have no horizontal overflow", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 }); await page.goto("/"); await page.getByRole("heading", { name: /Assalamu Alaikum/ }).waitFor();
  for (const screen of screens) {
    await page.getByRole("button", { name: "Open navigation", exact: true }).click(); await page.locator(".sidebar .nav-item").filter({ hasText: screen }).click(); await expect(page.locator("main h1")).toBeVisible();
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), `No overflow on ${screen}`).toBeTruthy();
  }
});
test("offline prayer fallback handles timezone offsets and Qibla geometry", () => {
  expect(timeZoneOffset("Europe/London", new Date("2026-07-01T12:00:00Z"))).toBe(1);
  expect(timeZoneOffset("Asia/Kolkata", new Date("2026-07-01T12:00:00Z"))).toBe(5.5);
  for (const [lat, lng, timezone] of [[51.5074, -0.1278, "Europe/London"], [28.6139, 77.209, "Asia/Kolkata"], [40.7128, -74.006, "America/New_York"]]) {
    const data = calculatePrayerData(Number(lat), Number(lng), String(timezone), 2, 0, new Date("2026-11-12T12:00:00Z"));
    for (const prayer of data.prayers) { expect(Number.isFinite(prayer.timestamp)).toBeTruthy(); expect(prayer.time).not.toBe("--:--"); const formatted = new Intl.DateTimeFormat("en-GB", { timeZone: String(timezone), hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date(prayer.timestamp)); expect(formatted).toBe(prayer.time); }
  }
  expect(qiblaBearing(51.5074, -0.1278)).toBeGreaterThan(118); expect(qiblaBearing(51.5074, -0.1278)).toBeLessThan(120);
});
