import { test, expect, type Page } from "@playwright/test";
const nav = (page: Page, label: string) => page.locator(".sidebar .nav-item").filter({ hasText: label }).click();
async function openApp(page: Page) { await page.goto("/"); await expect(page.getByRole("heading", { name: /Assalamu Alaikum, Yusuf/ })).toBeVisible(); }
test.beforeEach(async ({ page }) => { await openApp(page); });
test("dashboard, live prayer data and seeded library", async ({ page }) => {
  await expect(page.locator(".hero-art img")).toBeVisible();
  expect(await page.locator(".hero-art img").evaluate((img: HTMLImageElement) => img.complete && img.naturalWidth > 0)).toBeTruthy();
  await expect(page.locator(".prayer-time")).toHaveCount(6);
  await expect(page.locator(".feature-card")).toHaveCount(4);
  const state = await (await page.request.get("/api/workspace")).json();
  expect(state.content.filter((c: { kind: string }) => c.kind === "surah")).toHaveLength(114);
  expect(state.content.filter((c: { kind: string }) => c.kind === "name")).toHaveLength(99);
  expect(state.counters).toHaveLength(3); expect(state.bookmarks).toHaveLength(3);
  const prayer = await (await page.request.get("/api/prayer?lat=51.5074&lng=-0.1278&timezone=Europe/London")).json();
  expect(prayer.prayers.every((p: { timestamp: number }) => Number.isFinite(p.timestamp))).toBeTruthy();
});
test("zikr create, optimistic increment, edit, reset and delete", async ({ page }) => {
  await nav(page, "Zikr Counter"); await page.getByRole("button", { name: "New zikr", exact: true }).click();
  await page.getByLabel("Zikr name").fill("Test dhikr"); await page.getByLabel("Your target").fill("3");
  await page.getByRole("button", { name: "Create zikr", exact: true }).click(); await expect(page.getByRole("dialog")).toHaveCount(0);
  const card = page.locator(".zikr-card").filter({ hasText: "Test dhikr" });
  for (let i = 0; i < 3; i++) await card.getByRole("button", { name: "Add remembrance", exact: true }).click();
  await expect(card.locator(".zikr-count")).toHaveText("3 / 3"); await expect(card.getByRole("button", { name: "Alhamdulillah, complete" })).toBeDisabled();
  await page.reload(); await expect(card.locator(".zikr-count")).toHaveText("3 / 3");
  await card.getByRole("button", { name: "Edit Test dhikr", exact: true }).click(); await page.getByLabel("Zikr name").fill("Updated dhikr"); await page.getByLabel("Your target").fill("5"); await page.getByRole("button", { name: "Save changes", exact: true }).click();
  const updated = page.locator(".zikr-card").filter({ hasText: "Updated dhikr" }); await expect(updated.locator(".zikr-count")).toHaveText("3 / 5");
  await updated.getByRole("button", { name: "Reset Updated dhikr", exact: true }).click(); await expect(updated.locator(".zikr-count")).toHaveText("0 / 5");
  await updated.getByRole("button", { name: "Delete Updated dhikr", exact: true }).click(); await page.getByRole("button", { name: "Delete zikr", exact: true }).click(); await expect(updated).toHaveCount(0);
});
test("reminder create, edit, pause, persistence and delete", async ({ page }) => {
  await nav(page, "My Reminders"); await page.getByRole("button", { name: "New reminder", exact: true }).click();
  await page.getByLabel("Reminder title").fill("Test Quran reminder"); await page.getByLabel("Time", { exact: true }).fill("07:15"); await page.getByRole("button", { name: "Create reminder", exact: true }).click();
  const card = page.locator(".reminder-card").filter({ hasText: "Test Quran reminder" }); await expect(card).toBeVisible();
  await card.getByRole("switch").click(); await expect(card.getByRole("switch")).toHaveAttribute("aria-checked", "false");
  await page.reload(); await expect(card.getByRole("switch")).toHaveAttribute("aria-checked", "false");
  await card.getByRole("button", { name: "Edit reminder", exact: true }).click(); await page.getByLabel("Time", { exact: true }).fill("08:15"); await page.getByRole("button", { name: "Save changes", exact: true }).click(); await expect(card.locator(".reminder-time")).toHaveText("08:15");
  await card.getByRole("button", { name: "Delete reminder", exact: true }).click(); await page.getByRole("dialog").getByRole("button", { name: "Delete reminder", exact: true }).click(); await expect(card).toHaveCount(0);
});
test("Quran translations, tafsir, bookmarks and reflection", async ({ page }) => {
  await nav(page, "The Holy Quran"); await expect(page.locator(".ayah-card")).toHaveCount(7);
  await page.getByLabel("Quran translation language").selectOption("ur.jalandhry"); await expect(page.locator(".ayah-translation").first()).toHaveAttribute("dir", "rtl"); await expect(page.locator(".ayah-translation").first()).not.toContainText("Translation is unavailable");
  await page.getByRole("button", { name: "Tafsir", exact: true }).click(); await expect(page.locator(".tafsir-box")).toHaveCount(7);
  await page.locator(".ayah-card").first().getByRole("button", { name: "Bookmark ayah", exact: true }).click(); await expect(page.locator(".toast")).toContainText("Saved to your bookmarks");
  await page.getByRole("button", { name: "Mark as read", exact: true }).click(); await expect(page.getByRole("button", { name: "Surah read today", exact: true })).toBeDisabled();
  await page.locator(".ayah-card").first().getByRole("button", { name: "Write a reflection", exact: true }).click(); await page.getByLabel("Your reflection").fill("A test reflection on Allah’s mercy."); await page.getByRole("button", { name: "Save reflection", exact: true }).click();
  await nav(page, "Duas & Azkar"); await page.getByRole("button", { name: "Personal", exact: true }).click(); await expect(page.getByRole("heading", { name: "Reflection on 1:1", exact: true })).toBeVisible();
});
test("Hadith search and collection switching", async ({ page }) => {
  await nav(page, "Hadith Collections"); await page.getByPlaceholder("Search meanings, teachings, or narrators...").fill("intention"); await expect(page.getByRole("heading", { name: "Actions are judged by intentions", exact: true })).toBeVisible();
  await page.locator(".collection-button").filter({ hasText: "Sahih Muslim" }).click(); await expect(page.getByRole("heading", { name: "Love for your brother", exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Load more hadith", exact: true }).click();
});
test("99 Names search and reflection bookmark", async ({ page }) => {
  await nav(page, "99 Names of Allah"); await page.getByPlaceholder("Search a name or meaning...").fill("Ar-Rahman"); await expect(page.locator(".name-card")).toHaveCount(1);
  await page.locator(".name-card button").first().click(); await expect(page.getByRole("dialog")).toBeVisible(); await page.getByRole("button", { name: "Save for reflection", exact: true }).click(); await page.getByRole("button", { name: "Close dialog", exact: true }).click();
  await nav(page, "My Bookmarks"); await expect(page.locator(".bookmark-card").filter({ hasText: "The Beneficent" })).toBeVisible();
});
test("kids quiz saves a perfect result", async ({ page }) => {
  await nav(page, "Islamic Quizzes"); await page.locator(".quiz-card").filter({ hasText: "Little believers" }).getByRole("button", { name: /^(Begin the adventure|Try again)$/, exact: true }).click();
  for (const [index, answer] of [1, 2, 1, 2, 0].entries()) { await page.locator(".quiz-answer").nth(answer).click(); await page.getByRole("button", { name: "Check my answer", exact: true }).click(); await page.getByRole("button", { name: index === 4 ? "See my results" : "Next question", exact: true }).click(); }
  await expect(page.locator(".quiz-result-score")).toContainText("5"); await page.getByRole("button", { name: "Back to quizzes", exact: true }).click(); await page.reload(); await expect(page.locator(".quiz-card").filter({ hasText: "Little believers" }).locator(".quiz-meta")).toContainText("Best score: 5/5");
});
test("Zakat calculation, saved payment and deletion", async ({ page }) => {
  await nav(page, "Zakat Calculator"); await page.locator("#asset-cash").fill("10000"); await page.locator("#asset-debts").fill("1000"); await expect(page.locator(".zakat-result .amount")).toHaveText("£225.00");
  await page.getByRole("button", { name: "Save calculation", exact: true }).click(); await expect(page.locator(".zakat-history-row")).toHaveCount(1);
  await page.getByRole("button", { name: "Mark as paid", exact: true }).click(); await page.reload(); await expect(page.locator(".zakat-history-row")).toContainText("Payment completed");
  await page.getByRole("button", { name: "Delete calculation", exact: true }).click(); await page.getByRole("button", { name: "Delete record", exact: true }).click(); await expect(page.locator(".zakat-history-row")).toHaveCount(0);
});
test("profile preferences and lesson progress persist", async ({ page }) => {
  await nav(page, "Settings"); await page.getByLabel("Your name", { exact: true }).fill("Yusuf Test"); await page.getByLabel("Daily zikr intention").fill("150"); await page.getByRole("button", { name: "Save my preferences", exact: true }).click(); await expect(page.locator(".toast")).toContainText("preferences have been saved");
  await nav(page, "Tafsir & Tajweed"); await page.locator(".lesson-card").filter({ hasText: "The art of recitation" }).getByRole("button", { name: "Begin lesson", exact: true }).click(); await page.getByRole("button", { name: "Mark complete", exact: true }).click(); await expect(page.getByRole("button", { name: "Completed", exact: true })).toBeDisabled(); await page.getByRole("button", { name: "Close dialog", exact: true }).click(); await page.reload();
  const state = await (await page.request.get("/api/workspace")).json(); expect(state.user.dailyGoal).toBe(150); expect(state.progress.some((p: { lessonId: string; completed: boolean }) => p.lessonId === "lesson-tajweed" && p.completed)).toBeTruthy();
});
test("mobile layout and installable app metadata", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 }); await page.reload();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBeTruthy();
  await page.getByRole("button", { name: "Open navigation", exact: true }).click(); await expect(page.locator(".sidebar")).toHaveClass(/sidebar-open/); await nav(page, "The Holy Quran"); await expect(page.locator(".ayah-card")).toHaveCount(7); expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBeTruthy();
  const manifest = await (await page.request.get("/manifest.webmanifest")).json(); expect(manifest.display).toBe("standalone"); expect(manifest.icons.length).toBeGreaterThanOrEqual(2);
});
test("authentication, account isolation and sign out", async ({ page, playwright }) => {
  const email = `test-${Date.now()}@sakina.app`;
  await page.locator(".sidebar-profile").click(); await page.getByRole("button", { name: "Create account", exact: true }).click(); await page.getByLabel("Your name", { exact: true }).fill("Test Muslim"); await page.getByLabel("Email address", { exact: true }).fill(email); await page.getByLabel("Password", { exact: true }).fill("TestPass123!"); await page.getByRole("button", { name: "Create my account", exact: true }).click(); await expect(page.getByRole("dialog")).toHaveCount(0);
  const state = await (await page.request.get("/api/workspace")).json(); expect(state.user.email).toBe(email); expect(state.counters).toHaveLength(3);
  const other = await playwright.request.newContext({ baseURL: "http://localhost:3000" }); await other.get("/api/workspace"); const forbidden = await other.post("/api/workspace", { data: { action: "updateCounter", id: state.counters[0].id, count: 999 } }); expect(forbidden.status()).toBe(404); await other.dispose();
  await nav(page, "Settings"); await page.getByRole("button", { name: "Sign out", exact: true }).click(); await expect(page.getByRole("button", { name: "Sign in to Sakina", exact: true })).toBeVisible();
  await page.getByLabel("Email address", { exact: true }).fill(email); await page.getByLabel("Password", { exact: true }).fill("WrongPass123"); await page.getByRole("button", { name: "Sign in to Sakina", exact: true }).click(); await expect(page.locator(".form-error")).toContainText("incorrect");
  await page.getByLabel("Password", { exact: true }).fill("TestPass123!"); await page.getByRole("button", { name: "Sign in to Sakina", exact: true }).click(); await nav(page, "Dashboard"); await expect(page.getByRole("heading", { name: /Assalamu Alaikum, Test/ })).toBeVisible();
});
