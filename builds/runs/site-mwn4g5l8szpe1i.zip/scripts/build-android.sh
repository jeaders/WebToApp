#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}}"
export JAVA_HOME="${JAVA_HOME:-/tmp/sakina-android-jdk}"
if ! "$JAVA_HOME/bin/java" -version >/dev/null 2>&1; then
  echo "Set JAVA_HOME to a JDK 21 installation and ANDROID_HOME to your Android SDK."
  exit 1
fi
npx cap sync android
node -e 'const fs=require("fs");const config=JSON.parse(fs.readFileSync("android/app/src/main/assets/capacitor.config.json","utf8"));const path="native-assets/connect.html";fs.writeFileSync(path,fs.readFileSync(path,"utf8").replace("__SAKINA_SERVER_URL__",config.server.url));'
npx cap sync android
(cd android && ./gradlew assembleDebug --no-daemon)
mkdir -p public/downloads
cp android/app/build/outputs/apk/debug/app-debug.apk public/downloads/sakina-debug.apk
echo "APK ready: public/downloads/sakina-debug.apk"
