const CACHE = 'sakina-static-v1';
self.addEventListener('install', event => { event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(['/', '/icon.svg', '/icon-192.png', '/icon-512.png', '/images/mosque-hero.png', '/fonts/dm-sans-regular.ttf', '/fonts/dm-sans-medium.ttf', '/fonts/dm-sans-semibold.ttf', '/fonts/dm-sans-bold.ttf', '/fonts/amiri.ttf'])).then(() => self.skipWaiting())); });
self.addEventListener('activate', event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== self.location.origin || new URL(event.request.url).pathname.startsWith('/api/')) return;
  if (event.request.mode === 'navigate') { event.respondWith(fetch(event.request).catch(() => caches.match('/'))); return; }
  if (['image', 'font', 'style', 'script'].includes(event.request.destination)) event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => { if (response.ok) { const clone = response.clone(); caches.open(CACHE).then(cache => cache.put(event.request, clone)); } return response; })));
});
self.addEventListener('notificationclick', event => { event.notification.close(); event.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clients => { const client = clients.find(c => c.url.includes('/#reminders')) || clients[0]; if (client) return client.focus(); return self.clients.openWindow('/#reminders'); })); });
