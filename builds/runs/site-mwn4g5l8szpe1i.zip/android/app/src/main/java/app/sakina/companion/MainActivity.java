package app.sakina.companion;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
  private String pendingOrigin;
  private GeolocationPermissions.Callback pendingLocationCallback;
  private boolean connecting = false;
  private final String connectionPage = "file:///android_asset/public/connect.html";
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    bridge.getWebView().setWebChromeClient(new WebChromeClient() {
      @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
        pendingOrigin = origin; pendingLocationCallback = callback;
        if (ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) { callback.invoke(origin, true, false); pendingLocationCallback = null; }
        else ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 2001);
      }
    });
    bridge.getWebView().setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { if (url.startsWith("https://") || url.startsWith("file://")) connecting = true; return false; }
      @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceError error) { if (request.isForMainFrame() && connecting) { connecting = false; view.loadUrl(connectionPage + "?error=server"); } }
    });
    connecting = false; bridge.getWebView().loadUrl(connectionPage);
  }
  @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    if (requestCode == 2001 && pendingLocationCallback != null) { boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED; pendingLocationCallback.invoke(pendingOrigin, granted, false); pendingLocationCallback = null; }
  }
}
