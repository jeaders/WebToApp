# Sakina for Android

This Capacitor project packages the deployed Sakina web app in a native Android WebView. The APK includes the Sakina launcher icon, Java-based location permission handling, and Android network access.

## Build a debug APK

Requirements: Node.js 22+, JDK 21, and Android SDK 36 with build-tools 36.0.0.

Set `JAVA_HOME` to your JDK 21 installation and `ANDROID_HOME` to your Android SDK. Run:

```sh
npx cap sync android
cd android
./gradlew assembleDebug
```

The output is `android/app/build/outputs/apk/debug/app-debug.apk`.

The included `scripts/build-android.sh` automates this and copies the APK to `public/downloads/sakina-debug.apk`.

## Install

Transfer the APK to your Android phone and open it. If prompted, allow installation from that source. Android may call this an unknown/developer app because it is a debug build, not a Play Store release. Android 7.0+ is supported.

## Backend configuration

The app uses `CAPACITOR_SERVER_URL` from the build environment, or the deployed preview URL in `capacitor.config.ts`. Set this to your own HTTPS deployment before distributing the app. The preview URL is not intended for a permanent production release.

Authentication, bookmarks, counters, notes, quiz results, and Zakat records remain in the PostgreSQL backend. The APK is a native wrapper, not an offline bundle: an internet connection is required to load the app and live content.

Web reminders remain limited to the open app. Exact alarms and notifications when the app is closed require a native reminder plugin and a release implementation. This debug APK does not include that plugin.

For Play Store distribution, use a signed release build with your own signing key, a stable production backend, a privacy policy, and the store's target SDK and permission requirements.
