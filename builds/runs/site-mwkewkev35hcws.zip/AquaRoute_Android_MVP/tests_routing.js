"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { effectiveState, findRoute } = require("./app/routing.js");

const NOW = Date.parse("2026-11-17T07:00:00.000Z");
const fresh = (id, state, depth = 5, updatedAt = new Date(NOW).toISOString()) => ({ id, state, depth, updatedAt });
const nodes = ["base", "A", "B", "dest"];
const twoPaths = [
  { a: "base", b: "A", c: 1, s: "sA" },
  { a: "A", b: "dest", c: 1 },
  { a: "base", b: "B", c: 2 },
  { a: "B", b: "dest", c: 2 }
];

 test("invalid, missing, negative-depth, future and stale readings fail closed to UNKNOWN", () => {
  assert.equal(effectiveState(null, NOW), "unknown");
  assert.equal(effectiveState(fresh("x", "green", -1), NOW), "unknown");
  assert.equal(effectiveState({ ...fresh("x", "green"), updatedAt: "not-a-date" }, NOW), "unknown");
  assert.equal(effectiveState(fresh("x", "green", 5, new Date(NOW + 31_000).toISOString()), NOW), "unknown");
  assert.equal(effectiveState(fresh("x", "green", 5, new Date(NOW - 90_001).toISOString()), NOW), "unknown");
 });

test("GREEN sensor segment can be used and lowest-cost route is returned", () => {
  const result = findRoute({ nodes, edges: twoPaths, sensors: [fresh("sA", "green")], start: "base", end: "dest", vehicle: "Ambulance", nowMs: NOW });
  assert.deepEqual(result.route.nodes, ["base", "A", "dest"]);
  assert.equal(result.route.cost, 2);
});

test("RED sensor segment is excluded and alternate path is selected", () => {
  const result = findRoute({ nodes, edges: twoPaths, sensors: [fresh("sA", "red", 20)], start: "base", end: "dest", vehicle: "Ambulance", nowMs: NOW });
  assert.deepEqual(result.route.nodes, ["base", "B", "dest"]);
  assert.ok(result.blocked.red > 0);
});

test("stale or UNKNOWN monitored segments are excluded", () => {
  const stale = fresh("sA", "green", 5, new Date(NOW - 90_001).toISOString());
  const result = findRoute({ nodes, edges: twoPaths, sensors: [stale], start: "base", end: "dest", vehicle: "Ambulance", nowMs: NOW });
  assert.deepEqual(result.route.nodes, ["base", "B", "dest"]);
  assert.ok(result.blocked.unknown > 0);
});

test("ORANGE is blocked unless an explicit approved vehicle-specific rule exists", () => {
  const result = findRoute({ nodes, edges: [{ a: "base", b: "A", c: 1, s: "sA" }, { a: "A", b: "dest", c: 1 }], sensors: [fresh("sA", "orange", 10)], start: "base", end: "dest", vehicle: "Ambulance", nowMs: NOW });
  assert.equal(result.route, null);
  assert.ok(result.blocked.orange_unapproved > 0);
});

test("ORANGE may be considered only when approved depth limit covers the measured depth", () => {
  const args = {
    nodes, edges: [{ a: "base", b: "A", c: 1, s: "sA" }, { a: "A", b: "dest", c: 1 }],
    sensors: [fresh("sA", "orange", 10)], start: "base", end: "dest", vehicle: "Ambulance", nowMs: NOW
  };
  const allowed = findRoute({ ...args, policy: { orange: { approved: true, maxApprovedWaterDepthCmByVehicle: { Ambulance: 12 } }, orangePenalty: 7 } });
  assert.deepEqual(allowed.route.nodes, ["base", "A", "dest"]);
  assert.ok(allowed.route.warnings.includes("ORANGE_SEGMENT_INCLUDED_UNDER_APPROVED_VEHICLE_RULE"));
  const denied = findRoute({ ...args, policy: { orange: { approved: true, maxApprovedWaterDepthCmByVehicle: { Ambulance: 8 } } } });
  assert.equal(denied.route, null);
  assert.ok(denied.blocked.orange_clearance > 0);
});

test("unmonitored roads are labelled in route warnings", () => {
  const result = findRoute({ nodes, edges: [{ a: "base", b: "B", c: 2 }, { a: "B", b: "dest", c: 2 }], sensors: [], start: "base", end: "dest", vehicle: "Fire & Rescue", nowMs: NOW, policy: { unmonitoredPenalty: 5 } });
  assert.ok(result.route.warnings.includes("ROUTE_CONTAINS_UNMONITORED_ROAD"));
});

test("route is recalculated when a monitored segment changes status", () => {
  const greenRoute = findRoute({ nodes, edges: twoPaths, sensors: [fresh("sA", "green")], start: "base", end: "dest", vehicle: "Ambulance", nowMs: NOW });
  const afterChange = findRoute({ nodes, edges: twoPaths, sensors: [fresh("sA", "red", 20)], start: "base", end: "dest", vehicle: "Ambulance", nowMs: NOW });
  assert.deepEqual(greenRoute.route.nodes, ["base", "A", "dest"]);
  assert.deepEqual(afterChange.route.nodes, ["base", "B", "dest"]);
});

test("missing sensor record for a monitored edge is UNKNOWN, not GREEN", () => {
  const result = findRoute({ nodes, edges: [{ a: "base", b: "A", c: 1, s: "missing" }, { a: "A", b: "dest", c: 1 }], sensors: [], start: "base", end: "dest", vehicle: "Ambulance", nowMs: NOW });
  assert.equal(result.route, null);
  assert.ok(result.blocked.unknown > 0);
});
