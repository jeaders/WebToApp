"""Quick static checks for the AquaRoute PWA starter. Run: python tests_static.py"""
from pathlib import Path
import json, re, subprocess, tempfile
ROOT = Path(__file__).parent / "app"
html = (ROOT / "index.html").read_text()
js = re.search(r"<script>(.*?)</script>", html, re.S).group(1)
with tempfile.NamedTemporaryFile("w", suffix=".js") as f:
    f.write(js); f.flush()
    subprocess.run(["node", "--check", f.name], check=True)
manifest = json.loads((ROOT / "manifest.webmanifest").read_text())
assert manifest["display"] == "standalone"
for icon in manifest["icons"]:
    assert (ROOT / icon["src"]).is_file()
assert (ROOT / "service-worker.js").is_file()
for token in ("AquaRouteRouting.findRoute", "orange:{approved:false", "localStorage", "serviceWorker.register", "id=\"uc\""):
    assert token in html, token
assert "./routing.js" in (ROOT / "service-worker.js").read_text()
print("PASS: app JS syntax, PWA manifest/icons, cached route engine, local sensor cache, UNKNOWN KPI, fail-closed routing integration")
