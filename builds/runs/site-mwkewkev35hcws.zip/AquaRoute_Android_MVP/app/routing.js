/*
 * AquaRoute risk-aware route engine.
 * This module is deterministic and has no network, GPS, or municipal integration.
 * All thresholds and road data passed to it must be approved by the local authority.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.AquaRouteRouting = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const VALID_STATES = new Set(["green", "orange", "red", "unknown"]);
  const DEFAULT_FRESHNESS_MS = 90_000; // Prototype-only default; not a field setting.
  const DEFAULT_FUTURE_SKEW_MS = 30_000; // Prototype-only clock-skew guard.

  function effectiveState(sensor, nowMs, freshnessMs = DEFAULT_FRESHNESS_MS, futureSkewMs = DEFAULT_FUTURE_SKEW_MS) {
    if (!sensor || !VALID_STATES.has(sensor.state)) return "unknown";
    if (sensor.state === "unknown") return "unknown";

    const timestamp = Date.parse(sensor.updatedAt);
    if (!Number.isFinite(timestamp) || !Number.isFinite(nowMs)) return "unknown";
    if (timestamp > nowMs + futureSkewMs || nowMs - timestamp > freshnessMs) return "unknown";

    // A classified reading must carry a finite, non-negative measured depth.
    // Missing/invalid depth is never silently treated as a safe status.
    if (!Number.isFinite(sensor.depth) || sensor.depth < 0) return "unknown";
    return sensor.state;
  }

  function orangeAllowed(sensor, vehicle, policy) {
    const orange = policy && policy.orange;
    if (!orange || orange.approved !== true) return false;
    const limits = orange.maxApprovedWaterDepthCmByVehicle;
    const maxDepth = limits && limits[vehicle];
    return Number.isFinite(maxDepth) && maxDepth >= 0 &&
      Number.isFinite(sensor.depth) && sensor.depth >= 0 && sensor.depth <= maxDepth;
  }

  function findRoute({
    nodes,
    edges,
    sensors,
    start,
    end,
    vehicle,
    nowMs = Date.now(),
    policy = {},
    freshnessMs = DEFAULT_FRESHNESS_MS,
    futureSkewMs = DEFAULT_FUTURE_SKEW_MS
  }) {
    const nodeSet = new Set(nodes || []);
    if (!nodeSet.has(start) || !nodeSet.has(end)) {
      return { route: null, reason: "START_OR_DESTINATION_NOT_IN_NETWORK", blocked: {} };
    }
    if (start === end) return { route: { p: [], nodes: [start], cost: 0, warnings: [] }, reason: null, blocked: {} };

    const sensorById = new Map((sensors || []).map(sensor => [sensor.id, sensor]));
    const distances = new Map([...nodeSet].map(node => [node, Infinity]));
    const previous = new Map();
    const unvisited = new Set(nodeSet);
    const blocked = { red: 0, unknown: 0, orange_unapproved: 0, orange_clearance: 0, invalid_edge: 0 };
    const warnings = new Set();
    distances.set(start, 0);

    const unmonitoredPenalty = Number.isFinite(policy.unmonitoredPenalty) && policy.unmonitoredPenalty >= 0
      ? policy.unmonitoredPenalty : 0;
    const orangePenalty = Number.isFinite(policy.orangePenalty) && policy.orangePenalty >= 0
      ? policy.orangePenalty : 0;

    while (unvisited.size) {
      let current = null;
      let best = Infinity;
      for (const node of unvisited) {
        const distance = distances.get(node);
        if (distance < best) { best = distance; current = node; }
      }
      if (current === null || best === Infinity) break;
      unvisited.delete(current);
      if (current === end) break;

      for (const edge of edges || []) {
        let next = null;
        if (edge.a === current) next = edge.b;
        else if (edge.b === current) next = edge.a;
        if (next === null || !unvisited.has(next)) continue;

        if (!Number.isFinite(edge.c) || edge.c < 0 || !nodeSet.has(edge.a) || !nodeSet.has(edge.b)) {
          blocked.invalid_edge++;
          continue;
        }

        let extraCost = 0;
        const sensorId = edge.sensorId || edge.s || null;
        if (sensorId) {
          const sensor = sensorById.get(sensorId);
          const state = effectiveState(sensor, nowMs, freshnessMs, futureSkewMs);
          if (state === "red") { blocked.red++; continue; }
          if (state === "unknown") { blocked.unknown++; continue; }
          if (state === "orange") {
            if (!policy.orange || policy.orange.approved !== true) {
              blocked.orange_unapproved++;
              continue;
            }
            if (!orangeAllowed(sensor, vehicle, policy)) {
              blocked.orange_clearance++;
              continue;
            }
            extraCost += orangePenalty;
            warnings.add("ORANGE_SEGMENT_INCLUDED_UNDER_APPROVED_VEHICLE_RULE");
          }
        } else {
          extraCost += unmonitoredPenalty;
          warnings.add("ROUTE_CONTAINS_UNMONITORED_ROAD");
        }

        const candidate = best + edge.c + extraCost;
        if (candidate < distances.get(next)) {
          distances.set(next, candidate);
          previous.set(next, { node: current, edge });
        }
      }
    }

    if (!Number.isFinite(distances.get(end))) {
      return { route: null, reason: "NO_ROUTE_WITH_CURRENT_RISK_POLICY", blocked };
    }

    const pathEdges = [];
    const pathNodes = [end];
    let cursor = end;
    while (cursor !== start) {
      const step = previous.get(cursor);
      if (!step) return { route: null, reason: "BROKEN_ROUTE_PREDECESSOR_CHAIN", blocked };
      pathEdges.unshift(step.edge);
      cursor = step.node;
      pathNodes.unshift(cursor);
    }

    return {
      route: { p: pathEdges, nodes: pathNodes, cost: distances.get(end), warnings: [...warnings] },
      reason: null,
      blocked
    };
  }

  return {
    VALID_STATES,
    DEFAULT_FRESHNESS_MS,
    DEFAULT_FUTURE_SKEW_MS,
    effectiveState,
    findRoute
  };
});
