# AquaRoute sensor-ingestion API — prototype

This is a standard-library-only Python/SQLite reference backend. It is not deployed and has not been connected to ESP32 devices, MQTT, Nagpur road systems, GPS, or emergency-service networks.

## Run locally

```sh
cd backend
AQUAROUTE_DEVICE_TOKENS='{"esp32-demo-01":"replace-with-a-long-secret"}' python3 server.py
```

The database is created at `backend/aquaroute.sqlite3` (override with `AQUAROUTE_DB`). Bind to localhost during development. Do not expose this prototype to the internet: production requires TLS termination, secret rotation, rate limiting, audit logging, hardened device provisioning and operational monitoring.

## Provision demo metadata (manual, not field data)

Use SQLite to add surveyed/approved records. Example only:

```sql
INSERT INTO road_segments(id,name) VALUES ('ROAD-DEMO-01','DEMO ONLY — replace after survey');
INSERT INTO devices(id,road_segment_id) VALUES ('esp32-demo-01','ROAD-DEMO-01');
-- Do not insert a policy until the road authority has approved its thresholds.
-- INSERT INTO threshold_policies(road_segment_id,green_max_cm,orange_max_cm,approved,approved_by,approved_at)
-- VALUES ('ROAD-DEMO-01',..., ...,1,'approving-authority','ISO-8601 timestamp');
```

## API contract

- `GET /healthz` — service health.
- `GET /v1/roads` — registered road segments.
- `GET /v1/status` — latest reading per enabled device; readings older than 300 seconds become `UNKNOWN`. This 300-second value is a prototype guard and requires local approval/configuration before field use.
- `POST /v1/devices/{device_id}/readings` — authenticated JSON ingestion.

Headers: `Authorization: Bearer <device-secret>`, `Content-Type: application/json`.

Body:

```json
{"message_id":"device-unique-sequence-or-uuid","depth_cm":12.5,"observed_at":"2026-11-17T08:00:00Z"}
```

`message_id` is idempotent per device. Timestamps must be ISO-8601 with timezone. Depth must be numeric and 0–1000 cm (input sanity bound, not a water-risk threshold). The API uses only the latest approved road-specific threshold policy: at or below green maximum => GREEN; above green and at or below orange maximum => ORANGE; above orange maximum => RED. With no approved policy the reading is stored as `UNKNOWN`, never GREEN.

## MQTT path (not implemented)

Proposed bridge: ESP32 publishes QoS 1 to `aquaroute/v1/devices/{device_id}/readings`; broker ACL restricts each device to its own topic; a backend subscriber verifies device identity, validates the same schema and forwards to `Store.ingest`. Use TLS, persistent sessions, bounded retained-message policy, replay/idempotency handling, reconnect backoff and dead-letter/audit handling. Do not enable until broker, credentials, topic ACLs and partner security review are complete.
