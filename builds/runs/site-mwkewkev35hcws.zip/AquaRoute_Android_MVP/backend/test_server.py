import json, os, tempfile, unittest
from datetime import datetime, timezone, timedelta
from server import Store, classify, parse_time

class BackendTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.NamedTemporaryFile(delete=False); self.tmp.close()
        self.store=Store(self.tmp.name)
        db=self.store.db
        db.execute("INSERT INTO road_segments(id,name) VALUES('R1','TEST ONLY')")
        db.execute("INSERT INTO devices(id,road_segment_id) VALUES('D1','R1')")
        db.commit()
    def tearDown(self):
        self.store.db.close(); os.unlink(self.tmp.name)
    def test_no_policy_fails_closed(self):
        self.assertEqual(classify(0,None),'UNKNOWN')
        result=self.store.ingest('D1',{'message_id':'m1','depth_cm':0,'observed_at':datetime.now(timezone.utc).isoformat()})
        self.assertEqual(result['state'],'UNKNOWN')
    def test_approved_threshold_classification(self):
        self.store.db.execute("INSERT INTO threshold_policies(road_segment_id,green_max_cm,orange_max_cm,approved) VALUES('R1',5,15,1)")
        self.store.db.commit()
        for mid,depth,want in [('g',5,'GREEN'),('o',10,'ORANGE'),('r',16,'RED')]:
            got=self.store.ingest('D1',{'message_id':mid,'depth_cm':depth,'observed_at':datetime.now(timezone.utc).isoformat()})
            self.assertEqual(got['state'],want)
    def test_duplicate_is_idempotent(self):
        p={'message_id':'same','depth_cm':1,'observed_at':datetime.now(timezone.utc).isoformat()}
        a=self.store.ingest('D1',p); b=self.store.ingest('D1',p)
        self.assertFalse(a['duplicate']); self.assertTrue(b['duplicate']); self.assertEqual(a['reading_id'],b['reading_id'])
    def test_invalid_depth_and_timezone_rejected(self):
        for depth in [-1,1001,True,'5']:
            with self.assertRaises(ValueError): self.store.ingest('D1',{'message_id':str(depth),'depth_cm':depth,'observed_at':datetime.now(timezone.utc).isoformat()})
        with self.assertRaises(ValueError): parse_time('2026-11-17T08:00:00')
    def test_future_timestamp_rejected(self):
        future=(datetime.now(timezone.utc)+timedelta(minutes=5)).isoformat()
        with self.assertRaises(ValueError): self.store.ingest('D1',{'message_id':'future','depth_cm':2,'observed_at':future})
    def test_unknown_device_rejected(self):
        with self.assertRaises(PermissionError): self.store.ingest('NOT-REGISTERED',{'message_id':'x','depth_cm':2,'observed_at':datetime.now(timezone.utc).isoformat()})

if __name__=='__main__': unittest.main(verbosity=2)
