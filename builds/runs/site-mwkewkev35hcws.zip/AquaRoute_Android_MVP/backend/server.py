#!/usr/bin/env python3
"""AquaRoute v1 sensor-ingestion API (stdlib-only reference implementation).

Not connected to physical sensors or deployed infrastructure. Device credentials
are supplied as AQUAROUTE_DEVICE_TOKENS='{"device-id":"secret"}'.
"""
from __future__ import annotations
import json, os, sqlite3, threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

DB_PATH = os.environ.get("AQUAROUTE_DB", str(Path(__file__).with_name("aquaroute.sqlite3")))
MAX_BODY = 16_384
FUTURE_SKEW_SECONDS = 30

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS road_segments (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, geometry_json TEXT,
 active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1))
);
CREATE TABLE IF NOT EXISTS devices (
 id TEXT PRIMARY KEY, road_segment_id TEXT NOT NULL REFERENCES road_segments(id),
 enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)), last_seen_at TEXT
);
CREATE TABLE IF NOT EXISTS threshold_policies (
 id INTEGER PRIMARY KEY AUTOINCREMENT, road_segment_id TEXT REFERENCES road_segments(id),
 green_max_cm REAL NOT NULL CHECK(green_max_cm >= 0), orange_max_cm REAL NOT NULL CHECK(orange_max_cm > green_max_cm),
 approved INTEGER NOT NULL DEFAULT 0 CHECK(approved IN (0,1)), approved_by TEXT, approved_at TEXT
);
CREATE TABLE IF NOT EXISTS readings (
 id INTEGER PRIMARY KEY AUTOINCREMENT, device_id TEXT NOT NULL REFERENCES devices(id),
 message_id TEXT NOT NULL, depth_cm REAL NOT NULL CHECK(depth_cm >= 0), observed_at TEXT NOT NULL,
 received_at TEXT NOT NULL, state TEXT NOT NULL CHECK(state IN ('GREEN','ORANGE','RED','UNKNOWN')),
 UNIQUE(device_id, message_id)
);
CREATE INDEX IF NOT EXISTS readings_road_time ON readings(device_id, observed_at DESC);
CREATE TABLE IF NOT EXISTS vehicles (
 id TEXT PRIMARY KEY, label TEXT NOT NULL, vehicle_type TEXT NOT NULL, clearance_policy_json TEXT
);
CREATE TABLE IF NOT EXISTS incidents (
 id TEXT PRIMARY KEY, vehicle_id TEXT REFERENCES vehicles(id), road_segment_id TEXT REFERENCES road_segments(id),
 status TEXT NOT NULL, details_json TEXT, created_at TEXT NOT NULL
);
"""

def parse_time(value: str) -> datetime:
    if not isinstance(value, str) or not value:
        raise ValueError("observed_at must be an ISO-8601 timestamp")
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError("observed_at must be an ISO-8601 timestamp") from exc
    if dt.tzinfo is None:
        raise ValueError("observed_at must include a timezone")
    return dt.astimezone(timezone.utc)

def classify(depth_cm: float, policy: dict | None) -> str:
    # No approved road-specific policy => fail closed.
    if not policy or not policy["approved"]:
        return "UNKNOWN"
    if depth_cm <= policy["green_max_cm"]:
        return "GREEN"
    if depth_cm <= policy["orange_max_cm"]:
        return "ORANGE"
    return "RED"

class Store:
    def __init__(self, path=DB_PATH):
        self.path = path
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)
        self.db.commit()

    def policy_for(self, road_id):
        row = self.db.execute("SELECT green_max_cm, orange_max_cm, approved FROM threshold_policies WHERE road_segment_id=? ORDER BY id DESC LIMIT 1", (road_id,)).fetchone()
        return dict(row) if row else None

    def ingest(self, device_id, payload):
        required = {"message_id", "depth_cm", "observed_at"}
        if not isinstance(payload, dict) or not required.issubset(payload):
            raise ValueError("required fields: message_id, depth_cm, observed_at")
        message_id = payload["message_id"]
        if not isinstance(message_id, str) or not 1 <= len(message_id) <= 128:
            raise ValueError("message_id must be 1-128 characters")
        depth = payload["depth_cm"]
        if isinstance(depth, bool) or not isinstance(depth, (int, float)) or depth < 0 or depth > 1000:
            raise ValueError("depth_cm must be a number from 0 to 1000")
        observed = parse_time(payload["observed_at"])
        now = datetime.now(timezone.utc)
        if (observed - now).total_seconds() > FUTURE_SKEW_SECONDS:
            raise ValueError("observed_at is too far in the future")
        with self.lock:
            device = self.db.execute("SELECT road_segment_id, enabled FROM devices WHERE id=?", (device_id,)).fetchone()
            if not device or not device["enabled"]:
                raise PermissionError("unknown or disabled device")
            road_id = device["road_segment_id"]
            policy = self.policy_for(road_id)
            state = classify(float(depth), policy)
            received = now.isoformat()
            try:
                cur = self.db.execute("INSERT INTO readings(device_id,message_id,depth_cm,observed_at,received_at,state) VALUES(?,?,?,?,?,?)",
                    (device_id, message_id, float(depth), observed.isoformat(), received, state))
            except sqlite3.IntegrityError:
                existing = self.db.execute("SELECT id,state FROM readings WHERE device_id=? AND message_id=?", (device_id,message_id)).fetchone()
                if existing:
                    return {"reading_id": existing["id"], "state": existing["state"], "duplicate": True}
                raise
            self.db.execute("UPDATE devices SET last_seen_at=? WHERE id=?", (received, device_id))
            self.db.commit()
            return {"reading_id": cur.lastrowid, "road_segment_id": road_id, "state": state, "duplicate": False, "received_at": received}

    def statuses(self):
        rows = self.db.execute("""SELECT r.id AS reading_id, d.id AS device_id, d.road_segment_id,
          r.depth_cm, r.observed_at, r.received_at, r.state
          FROM devices d LEFT JOIN readings r ON r.id=(SELECT id FROM readings WHERE device_id=d.id ORDER BY observed_at DESC,id DESC LIMIT 1)
          WHERE d.enabled=1 ORDER BY d.road_segment_id,d.id""").fetchall()
        now = datetime.now(timezone.utc)
        out=[]
        for row in rows:
            item=dict(row)
            if not item["reading_id"]:
                item["state"]="UNKNOWN"
            else:
                age=(now-parse_time(item["observed_at"])).total_seconds()
                if age < -FUTURE_SKEW_SECONDS or age > 300: item["state"]="UNKNOWN"
            out.append(item)
        return out

STORE = Store()
TOKENS = json.loads(os.environ.get("AQUAROUTE_DEVICE_TOKENS", "{}"))

class Handler(BaseHTTPRequestHandler):
    server_version = "AquaRouteAPI/0.1"
    def send_json(self, code, obj):
        data=json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(data))); self.send_header("Cache-Control","no-store")
        self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        path=urlparse(self.path).path
        if path == "/healthz": return self.send_json(200,{"ok":True,"service":"aquaroute-ingestion","mode":"prototype"})
        if path == "/v1/status": return self.send_json(200,{"items":STORE.statuses()})
        if path == "/v1/roads":
            rows=STORE.db.execute("SELECT id,name,active FROM road_segments ORDER BY id").fetchall()
            return self.send_json(200,{"items":[dict(r) for r in rows]})
        return self.send_json(404,{"error":"not_found"})
    def do_POST(self):
        path=urlparse(self.path).path
        if not path.startswith("/v1/devices/") or not path.endswith("/readings"):
            return self.send_json(404,{"error":"not_found"})
        device_id=path.split("/")[3]
        auth=self.headers.get("Authorization","")
        token=auth[7:] if auth.startswith("Bearer ") else ""
        expected=TOKENS.get(device_id)
        if not expected or not token or not __import__('hmac').compare_digest(token, expected):
            return self.send_json(401,{"error":"unauthorized"})
        try:
            length=int(self.headers.get("Content-Length","0"))
            if length <= 0 or length > MAX_BODY: raise ValueError("body size must be 1-16384 bytes")
            payload=json.loads(self.rfile.read(length))
            result=STORE.ingest(device_id,payload)
            return self.send_json(200 if result.get("duplicate") else 201,result)
        except PermissionError as exc: return self.send_json(403,{"error":str(exc)})
        except (ValueError, json.JSONDecodeError) as exc: return self.send_json(400,{"error":str(exc)})
    def log_message(self, *_): pass

def main():
    host=os.environ.get("AQUAROUTE_HOST","127.0.0.1")
    port=int(os.environ.get("AQUAROUTE_PORT","8080"))
    print(f"AquaRoute prototype API listening on http://{host}:{port}")
    ThreadingHTTPServer((host,port),Handler).serve_forever()
if __name__ == "__main__": main()
