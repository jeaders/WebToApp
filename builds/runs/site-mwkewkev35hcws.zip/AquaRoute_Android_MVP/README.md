# AquaRoute Android MVP — installable PWA increment

This increment continues the existing no-central-database prototype. It adds an Android-installable, offline-capable app shell and stricter sensor freshness handling while retaining the dispatcher/driver demo and local route calculation.

## What changed in this increment

- Added a web app manifest and service worker so Android Chrome can install the app to the home screen and reopen the cached app shell offline.
- Added local sensor snapshot storage on the device.
- Added per-reading update timestamps and visible reading age.
- Added a 90-second **demo-only** freshness timeout. A reading older than this becomes `UNKNOWN`; stale/unknown roads are excluded from route calculation.
- Added route invalidation when a reading changes or becomes stale, including a final snapshot check before dispatcher approval.
- Extracted routing into a deterministic, independently tested `app/routing.js` module.
- Added fail-closed validation: missing/invalid depth, invalid timestamps, future timestamps outside the clock-skew allowance, and stale readings become `UNKNOWN`.
- RED and UNKNOWN monitored segments are excluded. ORANGE is now excluded unless an explicitly approved, vehicle-specific maximum water-depth rule is supplied; no real Nagpur values are configured.
- Unmonitored edges are labelled in route warnings instead of being presented as sensor-cleared.
- Added an UNKNOWN KPI and cached the routing module for offline app-shell use.
- Kept the existing two-role dispatcher/driver flow and local road-graph routing.

## Open on Android

1. Put the `app` folder on an HTTPS static host (or run it from a local development server on the same network). A secure origin is required for service-worker installation; opening the HTML as a local file will not install the offline app shell.
2. Open the hosted app URL in Chrome on Android.
3. Open Chrome's menu and choose **Install app** or **Add to Home screen** (the wording varies by Chrome version).
4. Launch AquaRoute from the home screen. The app shell can reopen offline after its first successful load; live sensor messages and cross-phone communication still require connectivity.

## Current status and limits

- This is an installable Android web app (PWA), **not yet a signed native APK**.
- Sensor readings remain simulated. There is no connected ESP32 hardware, MQTT broker, GPS, or live Nagpur road map in this increment.
- The driver and dispatcher roles still share one device in this demo. Separate phones need authenticated MQTT-over-WebSocket or another secure message relay, plus message acknowledgements and reconnect handling.
- The sample road graph is schematic, not Nagpur road geometry.
- The 90-second stale timeout and sample depths are demonstration settings only. Field thresholds and freshness limits must be validated with municipal engineers and emergency-service operators.
- No central database or control-centre dashboard is introduced. A lightweight MQTT broker may relay messages without storing a permanent history; local app cache is device-only.

## Next engineering increment

Add a versioned sensor-ingestion API contract and a small backend with durable storage for road segments, devices, health, readings, vehicles and incidents. Then add authenticated MQTT-over-WebSocket delivery with per-device/per-user topic permissions, reconnect/backoff and separate-device dispatcher-to-driver route delivery. Finally package the web app with a native Android shell (for example, Capacitor) and verify an APK build in an Android SDK environment.

## Safety

AquaRoute is a development prototype, not a certified or operational emergency dispatch system. Never treat missing, invalid, stale, or disconnected sensor data as GREEN. Do not deploy without surveyed road mapping, calibrated thresholds, supervised field tests, and emergency-service approval.


## Routing engine checks

Run `node --test tests_routing.js` for the routing unit tests and `python tests_static.py` for the PWA integration checks. The ORANGE rule is deliberately unapproved by default. The sample road graph, sensor values, 90-second freshness window and route weights are demo-only and must not be used for dispatch.

## Partner approvals before any Nagpur pilot

See [`docs/PILOT_APPROVAL_CHECKLIST.md`](docs/PILOT_APPROVAL_CHECKLIST.md). In particular, road-specific warning thresholds, sensor freshness, vehicle-specific ORANGE clearance, road geometry, LED installation, data ownership, connectivity/security, dispatch override and no-safe-route procedures require documented approval from the relevant Nagpur road authority and emergency-service partners. No threshold or vehicle clearance is currently configured as a real-world rule.

## New backend increment — sensor ingestion API (prototype)

Added `backend/server.py`, a Python-standard-library HTTP API backed by SQLite. It stores road segments, device registrations, threshold policies, timestamped readings, vehicles and incidents. Device ingestion uses per-device bearer tokens, payload validation, timestamp checks and per-device message idempotency. Readings remain `UNKNOWN` unless an approved road-specific threshold policy exists. `GET /v1/status` exposes the latest device reading and fails stale readings closed.

See [`backend/README.md`](backend/README.md) for local setup, the v1 API contract, database provisioning and the proposed MQTT bridge. MQTT, ESP32 firmware, production authentication/TLS, Android-to-backend integration and real sensor connectivity are **not implemented**. The 300-second status freshness guard and 0–1000 cm input sanity bound are prototype engineering choices, not approved water-risk thresholds.

Run backend tests with `cd backend && python3 test_server.py`.
