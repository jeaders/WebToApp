# Backend and sensor pilot decisions requiring partner approval

This prototype adds a local HTTP ingestion API and SQLite persistence only. Before a Nagpur field pilot, the municipal road authority and participating emergency-service partners must approve:

1. Surveyed road-segment identifiers, geometry, sensor placement, mounting and maintenance ownership.
2. Sensor technology, calibration method, water-depth reference datum, redundancy and failure detection.
3. Road-specific GREEN/ORANGE/RED thresholds, timestamp freshness, clock-skew allowance and escalation policy.
4. Vehicle categories and ORANGE clearance rules; no vehicle clearance is inferred by this backend.
5. Device identity issuance, credential storage/rotation/revocation, TLS, broker ACLs, retention and audit requirements.
6. Data ownership, access roles, retention periods, incident records, privacy and sharing with control rooms.
7. Connectivity coverage, outage behaviour, manual verification, false-positive/negative response and no-safe-route procedure.
8. Dispatcher authority, override audit, driver acknowledgement, emergency-service operating procedures and public warning wording.

No threshold, road geometry, device registration, vehicle rule, route or travel time in the prototype is validated for real-world dispatch.
