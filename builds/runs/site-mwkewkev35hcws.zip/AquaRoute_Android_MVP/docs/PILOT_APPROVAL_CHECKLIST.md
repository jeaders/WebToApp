# AquaRoute — Nagpur pilot approval checklist

**Status: proposal for partner review; nothing in this checklist is approved or deployed.**

The pitch concept combines road-side water-level sensing, a local controller and visible LED indication, a central alert/dashboard path, and dispatcher-reviewed routing for emergency vehicles. The current software increment only exercises simulated readings against a schematic graph.

## 1. Road and sensor approval

- Confirm the road-owning authority and obtain written permission for each proposed sensor and LED installation.
- Survey exact road-segment geometry, low points, drainage, carriageway width, approach direction, safe mounting position and access for maintenance.
- Agree the measurement datum, sensor technology, calibration method, installation height, blind spots, redundancy and inspection interval.
- Define how a device reports power loss, obstruction, sensor fault, tampering, communication loss and clock drift.

## 2. Risk-state policy

- Approve road-specific GREEN / ORANGE / RED thresholds using field survey, vehicle trials where appropriate, engineering assessment and emergency-service operating procedures.
- Approve freshness limits, acceptable clock skew, filtering, rate-of-rise rules, hysteresis and the conditions that force UNKNOWN.
- Decide whether RED is an automatic closure advisory or a hard routing exclusion, and who can clear it after an incident.
- Keep ORANGE excluded until the authority and each participating emergency-service operator approve vehicle-specific limits and exception handling.
- Do not infer safe water depth from vehicle type names. Obtain actual fleet specifications and written operational limits for each vehicle class and configuration.

## 3. Routing and dispatch policy

- Validate the authoritative road graph, permitted turns, one-way restrictions, temporary closures, bridge/underpass limits and access constraints.
- Decide how unmonitored roads are represented. A road without a sensor must never be described as sensor-cleared.
- Approve route scoring, alternate-route handling, route expiry, automatic recalculation, dispatcher override and driver acknowledgement.
- Define the no-safe-route procedure, including who is contacted and how the crew proceeds under existing emergency-service rules.
- Preserve on-scene judgement: the app must not instruct a driver to enter floodwater or override an incident commander.

## 4. Data, connectivity and operations

- Approve the MQTT/API provider, network coverage, topic permissions, device identity, authentication, encryption, retry/backoff, message replay protection and monitoring.
- Define data ownership, access roles, retention, audit logs, incident records, vehicle/GPS handling, privacy notices and breach response.
- Set uptime targets, maintenance responsibility, spare-device strategy, calibration records, escalation contacts and monsoon-season operating hours.
- Agree LED colour meanings, visibility, electrical protection, power backup, fail-safe indication and traffic-police permissions.

## 5. Partner sign-off

Obtain documented review from the relevant Nagpur Municipal Corporation road / drainage authority, Nagpur Fire & Emergency Services, ambulance or emergency-dispatch operators, Traffic Police, road-owning agencies and the selected technical implementation partner. Identify one accountable operational owner before any live pilot.

## 6. Evidence required before field use

- Approved site survey and road-network dataset.
- Signed threshold, freshness and vehicle-clearance policy.
- Bench calibration and fault-injection results for every sensor type.
- End-to-end connectivity, stale-data, power-loss and recovery test results.
- Supervised route tests on a closed / controlled test area and documented dispatcher / driver training.
- A rollback plan and a written statement of what existing dispatch process remains authoritative.

Until these approvals and tests exist, use only simulated data and clearly labelled schematic routes. This application is not an operational emergency-routing authority.
