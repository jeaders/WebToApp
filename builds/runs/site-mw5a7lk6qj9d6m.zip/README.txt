RECLAIM WebView Builder upload

This ZIP places the web app at web/index.html, matching the Android WebView local path:
https://appassets.androidplatform.net/web/index.html

Upload this ZIP to the same APK builder and create a fresh APK. This is a troubleshooting package, not a guarantee; test the rebuilt APK.
