import React, { useState, useEffect } from 'react';
import { GamePhase, Language, Player, NightDecisions, DawnResult, GameStats, MvpScore, PlayMode } from './types/game';
import { HeaderBar } from './components/HeaderBar';
import { TitleScreen } from './components/TitleScreen';
import { ModeSelectionView } from './components/ModeSelectionView';
import { RulesModal } from './components/RulesModal';
import { SetupView } from './components/SetupView';
import { RoleRevealView } from './components/RoleRevealView';
import { NightPassAndPlaySequentialView } from './components/NightPassAndPlaySequentialView';
import { NightModeratorView } from './components/NightModeratorView';
import { DawnReportView } from './components/DawnReportView';
import { DiscussionTimerView } from './components/DiscussionTimerView';
import { VotingView } from './components/VotingView';
import { LynchResultView } from './components/LynchResultView';
import { GameOverView } from './components/GameOverView';
import { ThreeNoirTable } from './components/ThreeNoirTable';
import { NoirDawnTransitionOverlay } from './components/NoirDawnTransitionOverlay';
import { sound } from './utils/sound';
import { calculateMvp, generatePlayers, getRecommendedDeck } from './utils/roleAllocator';

export default function App() {
  const [lang, setLang] = useState<Language>('ar');
  const [isMuted, setIsMuted] = useState<boolean>(sound.getMuted());
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);

  // Play Mode: PASS_AND_PLAY (sequential phone passing to all) or MODERATOR (dedicated referee)
  const [playMode, setPlayMode] = useState<PlayMode>('PASS_AND_PLAY');

  // Core Game State
  const [phase, setPhase] = useState<GamePhase>('TITLE');
  const [dayNumber, setDayNumber] = useState<number>(1);
  const [players, setPlayers] = useState<Player[]>([]);
  const [cachedNames, setCachedNames] = useState<string[]>([]);

  // Night & Day Transition Data
  const [dawnResult, setDawnResult] = useState<DawnResult | null>(null);
  const [showDawnTransition, setShowDawnTransition] = useState<boolean>(false);
  const [voteCounts, setVoteCounts] = useState<Record<string, number>>({});
  const [lynchedPlayer, setLynchedPlayer] = useState<Player | null>(null);

  // End Game State
  const [winningTeam, setWinningTeam] = useState<'town' | 'mafia' | 'jester' | null>(null);
  const [winReason, setWinReason] = useState<string>('');
  const [mvp, setMvp] = useState<MvpScore | null>(null);

  // Cumulative Game Statistics for MVP scoring
  const [stats, setStats] = useState<GameStats>({
    doctorSaves: {},
    detectiveCatches: {},
    mafiaKills: {},
    correctVotes: {},
    vigilanteHitMafia: {},
  });

  // Sync RTL / LTR document direction with language
  useEffect(() => {
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  const handleToggleLang = () => {
    setLang((prev) => (prev === 'ar' ? 'en' : 'ar'));
  };

  const handleToggleMute = () => {
    const nextMute = sound.toggleMute();
    setIsMuted(nextMute);
  };

  // 1. Setup Complete -> Start Role Reveal
  const handlePlayersGenerated = (newPlayers: Player[]) => {
    setPlayers(newPlayers);
    setCachedNames(newPlayers.map((p) => p.name));
    setDayNumber(1);
    setWinningTeam(null);
    setWinReason('');
    setStats({
      doctorSaves: {},
      detectiveCatches: {},
      mafiaKills: {},
      correctVotes: {},
      vigilanteHitMafia: {},
    });
    setPhase('REVEAL_ROLES');
  };

  // 2. Roles Revealed -> Start First Night
  const handleRevealComplete = () => {
    setPhase('NIGHT_INTRO');
  };

  // 3. Night Decisions Received -> Resolve Night & Show Dawn Report
  const handleNightDecisions = (decisions: NightDecisions) => {
    const nextPlayers = [...players];
    const killedIds: string[] = [];
    let savedId: string | null = null;
    let vigKilledId: string | null = null;

    const nextStats = { ...stats };

    // Resolve Mafia Kill vs Doctor Save
    if (decisions.mafiaTargetId) {
      if (decisions.mafiaTargetId === decisions.doctorTargetId) {
        // Doctor successfully saved the victim!
        savedId = decisions.mafiaTargetId;
        const doc = nextPlayers.find((p) => p.role.type === 'doctor');
        if (doc) {
          nextStats.doctorSaves[doc.id] = (nextStats.doctorSaves[doc.id] || 0) + 1;
        }
      } else {
        // Victim murdered
        killedIds.push(decisions.mafiaTargetId);
        // Find alive mafia to award kill stats
        nextPlayers.filter((p) => p.role.team === 'mafia' && p.isAlive).forEach((m) => {
          nextStats.mafiaKills[m.id] = (nextStats.mafiaKills[m.id] || 0) + 1;
        });
      }
    }

    // Resolve Doctor self-heal tracking
    if (decisions.doctorTargetId) {
      const docIndex = nextPlayers.findIndex((p) => p.role.type === 'doctor');
      if (docIndex !== -1 && nextPlayers[docIndex].id === decisions.doctorTargetId) {
        nextPlayers[docIndex].hasUsedSelfHeal = true;
      }
    }

    // Resolve Detective Catch Stat
    if (decisions.detectiveResult && decisions.detectiveResult.isMafia) {
      const det = nextPlayers.find((p) => p.role.type === 'detective');
      if (det) {
        nextStats.detectiveCatches[det.id] = (nextStats.detectiveCatches[det.id] || 0) + 1;
      }
    }

    // Resolve Vigilante Shot
    if (decisions.vigilanteTargetId) {
      vigKilledId = decisions.vigilanteTargetId;
      if (!killedIds.includes(decisions.vigilanteTargetId)) {
        killedIds.push(decisions.vigilanteTargetId);
      }
      const vig = nextPlayers.find((p) => p.role.type === 'vigilante');
      const target = nextPlayers.find((p) => p.id === decisions.vigilanteTargetId);
      if (vig && target && target.role.team === 'mafia') {
        nextStats.vigilanteHitMafia[vig.id] = (nextStats.vigilanteHitMafia[vig.id] || 0) + 1;
      }
    }

    // Resolve Silencer Gag
    let silencedId: string | null = null;
    if (decisions.silencerTargetId) {
      silencedId = decisions.silencerTargetId;
      const silencer = nextPlayers.find((p) => p.role.type === 'silencer' && p.isAlive);
      if (silencer) {
        nextStats.silencerSilences = nextStats.silencerSilences || {};
        nextStats.silencerSilences[silencer.id] = (nextStats.silencerSilences[silencer.id] || 0) + 1;
      }
    }

    // Update player statuses (alive/dead and silenced for today)
    killedIds.forEach((victimId) => {
      const idx = nextPlayers.findIndex((p) => p.id === victimId);
      if (idx !== -1) {
        nextPlayers[idx].isAlive = false;
      }
    });

    nextPlayers.forEach((p) => {
      p.isSilenced = p.id === silencedId && p.isAlive;
    });

    setPlayers(nextPlayers);
    setStats(nextStats);

    const report: DawnResult = {
      killedPlayerIds: killedIds,
      savedPlayerId: savedId,
      vigilanteKilledPlayerId: vigKilledId,
      silencedPlayerId: silencedId,
      storyAr: savedId ? 'تمكن الطبيب من إنقاذ الضحية في اللحظات الأخيرة!' : 'استيقظت القرية على مأساة مرعبة.',
      storyEn: savedId ? 'The doctor intervened in the nick of time!' : 'A tragedy struck the innocent town.',
    };
    setDawnResult(report);
    setShowDawnTransition(true);

    // Check Win condition right after night kills!
    const winState = checkWinConditions(nextPlayers, null);
    if (winState.isOver) {
      setWinningTeam(winState.team);
      setWinReason(winState.reason);
      const computedMvp = calculateMvp(nextPlayers, nextStats, winState.team);
      setMvp(computedMvp);
    }

    setPhase('DAWN_REPORT');
  };

  // 4. Dawn Report -> Discussion
  const handleProceedToDiscussion = () => {
    if (winningTeam) {
      setPhase('GAME_OVER');
    } else {
      setPhase('DAY_DISCUSSION');
    }
  };

  // 5. Discussion -> Voting
  const handleProceedToVoting = () => {
    setPhase('VOTING');
  };

  // 6. Voting Complete -> Tally & Lynch Result
  const handleVotingComplete = (votes: Record<string, string>) => {
    const counts: Record<string, number> = {};
    Object.values(votes).forEach((targetId) => {
      counts[targetId] = (counts[targetId] || 0) + 1;
    });
    setVoteCounts(counts);

    // Find highest voted
    let highestCount = -1;
    let highestId: string | null = null;
    let isTie = false;

    Object.entries(counts).forEach(([id, count]) => {
      if (count > highestCount) {
        highestCount = count;
        highestId = id;
        isTie = false;
      } else if (count === highestCount) {
        isTie = true;
      }
    });

    const nextPlayers = [...players];
    let executed: Player | null = null;
    let nextStats = { ...stats };

    if (!isTie && highestId) {
      const idx = nextPlayers.findIndex((p) => p.id === highestId);
      if (idx !== -1) {
        nextPlayers[idx].isAlive = false;
        executed = nextPlayers[idx];

        // Award correct vote points to voters who voted for mafia
        if (executed.role.team === 'mafia') {
          Object.entries(votes).forEach(([voterId, targetId]) => {
            if (targetId === executed?.id) {
              nextStats.correctVotes[voterId] = (nextStats.correctVotes[voterId] || 0) + 1;
            }
          });
          setStats(nextStats);
        }
      }
    }

    setLynchedPlayer(executed);
    setPlayers(nextPlayers);

    // Check Win Condition after Lynch
    const winState = checkWinConditions(nextPlayers, executed);
    if (winState.isOver) {
      setWinningTeam(winState.team);
      setWinReason(winState.reason);
      const computedMvp = calculateMvp(nextPlayers, nextStats, winState.team);
      setMvp(computedMvp);
    }

    setPhase('LYNCH_RESULT');
  };

  // 7. Lynch Result Proceed: Next Night OR Game Over
  const handleLynchProceed = () => {
    if (winningTeam) {
      setPhase('GAME_OVER');
    } else {
      setDayNumber((d) => d + 1);
      setPhase('NIGHT_INTRO');
    }
  };

  // Check Win Conditions according to the exact rule:
  // "تنتهي اللعبه عند تساوي عدد الصالحين مع عدد المافيا وعند انتهاء جميع المافيا"
  const checkWinConditions = (
    currentPlayers: Player[],
    lastLynched: Player | null
  ): { isOver: boolean; team: 'town' | 'mafia' | 'jester' | null; reason: string } => {
    // 1. JESTER LYNCH SOLO WIN
    if (lastLynched && lastLynched.role.type === 'jester') {
      return {
        isOver: true,
        team: 'jester',
        reason:
          lang === 'ar'
            ? 'فوز الجوكر المنفرد! نجح الجوكر ببراعة في التلاعب بالجميع ودفع القرية لإعدامه بالتصويت، محققاً فوزه الفردي المطلق!'
            : 'Jester Solo Victory! The Jester skillfully manipulated the town assembly into lynching them, securing a glorious solo victory!',
      };
    }

    const alive = currentPlayers.filter((p) => p.isAlive);
    const aliveMafia = alive.filter((p) => p.role.team === 'mafia');
    const aliveTown = alive.filter((p) => p.role.team === 'town');

    // 2. TOWN VICTORY: All Mafia eradicated ("وعند انتهاء جميع المافيا")
    if (aliveMafia.length === 0) {
      return {
        isOver: true,
        team: 'town',
        reason:
          lang === 'ar'
            ? 'فوز الصالحين! انتهت اللعبة بانتهاء والقضاء على جميع أفراد المافيا بالكامل وتطهير المدينة.'
            : 'Town Victory! The game ends as all Mafia operatives were completely eliminated and the town was liberated.',
      };
    }

    // 3. MAFIA VICTORY: Town count equals or is overtaken by Mafia count ("عند تساوي عدد الصالحين مع عدد المافيا")
    if (aliveMafia.length >= aliveTown.length && aliveMafia.length > 0) {
      return {
        isOver: true,
        team: 'mafia',
        reason:
          lang === 'ar'
            ? `فوز المافيا! انتهت اللعبة لتساوي عدد الصالحين (${aliveTown.length}) مع عدد المافيا (${aliveMafia.length}) وفرض المافيا سيطرتها التامة على القرية!`
            : `Mafia Victory! The game ends as the number of Town (${aliveTown.length}) equals or is overtaken by Mafia (${aliveMafia.length})!`,
      };
    }

    return { isOver: false, team: null, reason: '' };
  };

  // Play Again with same names
  const handlePlayAgainSame = () => {
    const recommended = getRecommendedDeck(cachedNames.length);
    const newDeck = generatePlayers(cachedNames, recommended);
    handlePlayersGenerated(newDeck);
  };

  // Reset to title / setup
  const handleResetGame = () => {
    setPhase('TITLE');
    setWinningTeam(null);
  };

  const isNightPhase = phase.startsWith('NIGHT');

  return (
    <div className="relative min-h-screen w-full flex flex-col justify-between overflow-x-hidden text-[#f4eedd]">
      {/* Three.js 3D Noir Conference Table & Dynamic Lighting */}
      <ThreeNoirTable phase={phase} isNight={isNightPhase} />

      {/* Atmospheric Top Header Bar */}
      <HeaderBar
        lang={lang}
        onToggleLang={handleToggleLang}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onOpenRules={() => setIsRulesOpen(true)}
        onResetGame={handleResetGame}
        phase={phase}
        dayNumber={dayNumber}
        playMode={playMode}
      />

      {/* Rules Modal */}
      {isRulesOpen && (
        <RulesModal lang={lang} onClose={() => setIsRulesOpen(false)} />
      )}

      {/* Main View Port Routing */}
      <main className="flex-1 flex flex-col items-center justify-center w-full z-10 px-2 sm:px-4 py-4">
        {phase === 'TITLE' && (
          <TitleScreen
            lang={lang}
            onStart={() => setPhase('MODE_SELECT')}
            onOpenRules={() => setIsRulesOpen(true)}
          />
        )}

        {phase === 'MODE_SELECT' && (
          <ModeSelectionView
            lang={lang}
            onSelectMode={(selectedMode) => {
              setPlayMode(selectedMode);
              setPhase('SETUP');
            }}
            onBack={() => setPhase('TITLE')}
          />
        )}

        {phase === 'SETUP' && (
          <SetupView
            lang={lang}
            onPlayersGenerated={handlePlayersGenerated}
            onCancel={() => setPhase('MODE_SELECT')}
          />
        )}

        {phase === 'REVEAL_ROLES' && (
          <RoleRevealView
            lang={lang}
            players={players}
            onRevealComplete={handleRevealComplete}
          />
        )}

        {/* NIGHT PHASE: ROUTED ACCORDING TO PLAY MODE */}
        {isNightPhase && (
          playMode === 'PASS_AND_PLAY' ? (
            <NightPassAndPlaySequentialView
              lang={lang}
              players={players}
              onDecisionsComplete={handleNightDecisions}
            />
          ) : (
            <NightModeratorView
              lang={lang}
              players={players}
              dayNumber={dayNumber}
              onDecisionsComplete={handleNightDecisions}
            />
          )
        )}

        {showDawnTransition && dawnResult && (
          <NoirDawnTransitionOverlay
            lang={lang}
            dawnResult={dawnResult}
            players={players}
            dayNumber={dayNumber}
            onComplete={() => setShowDawnTransition(false)}
          />
        )}

        {phase === 'DAWN_REPORT' && dawnResult && (
          <DawnReportView
            lang={lang}
            dawnResult={dawnResult}
            players={players}
            dayNumber={dayNumber}
            isGameOver={!!winningTeam}
            winningTeam={winningTeam}
            winReason={winReason}
            onProceedToDiscussion={handleProceedToDiscussion}
            onReopenNewspaper={() => setShowDawnTransition(true)}
          />
        )}

        {phase === 'DAY_DISCUSSION' && (
          <DiscussionTimerView
            lang={lang}
            players={players}
            dayNumber={dayNumber}
            onProceedToVoting={handleProceedToVoting}
          />
        )}

        {phase === 'VOTING' && (
          <VotingView
            lang={lang}
            alivePlayers={players.filter((p) => p.isAlive)}
            onVotingComplete={handleVotingComplete}
          />
        )}

        {phase === 'LYNCH_RESULT' && (
          <LynchResultView
            lang={lang}
            lynchedPlayer={lynchedPlayer}
            voteCounts={voteCounts}
            players={players}
            isGameOver={winningTeam !== null}
            winningTeam={winningTeam}
            winReason={winReason}
            onProceed={handleLynchProceed}
          />
        )}

        {phase === 'GAME_OVER' && mvp && (
          <GameOverView
            lang={lang}
            winningTeam={winningTeam}
            winReason={winReason}
            mvp={mvp}
            players={players}
            onPlayAgainSame={handlePlayAgainSame}
            onNewGame={() => setPhase('SETUP')}
          />
        )}
      </main>

      {/* World-Matched Low-Occlusion Footer Note */}
      <footer className="w-full text-center py-2 text-[11px] text-stone-300 pointer-events-none z-10">
        <span>
          {lang === 'ar'
            ? 'مافيا: ليلة الخداع · طاولة 3D تفاعلية · وضعان للعب: تمرير بالترتيب أو حَكَم راوٍ'
            : 'Mafia Noir · 3D Pass & Play · Dual Modes: Sequential Pass or Referee'}
        </span>
      </footer>
    </div>
  );
}
