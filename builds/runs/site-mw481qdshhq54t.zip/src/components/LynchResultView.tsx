import React, { useEffect, useState } from 'react';
import { Gavel, Skull, Sparkles, Trophy, ArrowRight, ArrowLeft, Moon, AlertCircle } from 'lucide-react';
import { Language, Player, Team } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { sound } from '../utils/sound';

import { DetectiveD3VoteChart, VoteDataPoint } from './DetectiveD3VoteChart';

interface LynchResultViewProps {
  lang: Language;
  lynchedPlayer: Player | null; // null if tie
  voteCounts: Record<string, number>;
  players: Player[];
  isGameOver: boolean;
  winningTeam: 'town' | 'mafia' | 'jester' | null;
  winReason: string;
  onProceed: () => void;
}

export const LynchResultView: React.FC<LynchResultViewProps> = ({
  lang,
  lynchedPlayer,
  voteCounts,
  players,
  isGameOver,
  winningTeam,
  winReason,
  onProceed,
}) => {
  const t = useTranslation(lang);
  const [isRevealed, setIsRevealed] = useState<boolean>(false);

  useEffect(() => {
    sound.playGavel();
    const timer = setTimeout(() => {
      setIsRevealed(true);
      if (lynchedPlayer?.role.team === 'mafia') {
        sound.playReveal(true);
      } else if (lynchedPlayer?.role.type === 'jester') {
        sound.playVictory();
      }
    }, 1200);
    return () => clearTimeout(timer);
  }, [lynchedPlayer]);

  // Construct data for D3 chart
  const relevantPlayers = players.filter(
    (p) => p.isAlive || (lynchedPlayer && p.id === lynchedPlayer.id)
  );
  const d3Data: VoteDataPoint[] = relevantPlayers
    .map((p) => ({
      id: p.id,
      name: p.name,
      votes: voteCounts[p.id] || 0,
    }))
    .sort((a, b) => b.votes - a.votes);

  const totalVotesCast = Object.values(voteCounts).reduce((a, b) => a + b, 0);

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 max-w-xl mx-auto w-full relative z-10 animate-fade-in">
      <div className="w-full bg-[#18151f]/95 border border-white/15 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl flex flex-col items-center text-center space-y-5">
        {/* Header Icon */}
        <div className="w-20 h-20 rounded-3xl bg-red-950/60 border border-red-700/50 flex items-center justify-center text-red-500 shadow-xl">
          <Gavel className="w-10 h-10" />
        </div>

        <div className="space-y-1">
          <h2 className="text-2xl sm:text-3xl font-black font-cinzel text-white">
            {t.votingResults}
          </h2>
          <p className="text-xs text-stone-400">
            {lang === 'ar' ? 'اجتمعت المحكمة الشعبية ونطق القضاة بالحكم' : 'The town assembly has spoken'}
          </p>
        </div>

        {/* Lynch or Tie Result */}
        {lynchedPlayer ? (
          <div className="w-full space-y-4">
            <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-3">
              <span className="text-xs text-red-400 font-bold uppercase tracking-wider block">
                {t.playerLynched}
              </span>
              <h3 className="text-3xl font-black text-white font-cinzel">
                {lynchedPlayer.name}
              </h3>

              {isRevealed ? (
                <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2 animate-fade-in">
                  <span className="text-xs text-stone-400 block">{t.revealedRoleWas}</span>
                  <div
                    className="text-xl sm:text-2xl font-black font-cinzel"
                    style={{ color: lynchedPlayer.role.accentColor }}
                  >
                    {lang === 'ar' ? lynchedPlayer.role.nameAr : lynchedPlayer.role.nameEn}
                  </div>
                  <span
                    className={`inline-block text-xs font-bold px-3 py-1 rounded-full border ${
                      lynchedPlayer.role.team === 'mafia'
                        ? 'bg-red-950/80 text-red-300 border-red-700'
                        : lynchedPlayer.role.team === 'neutral'
                        ? 'bg-amber-950/80 text-amber-300 border-amber-700'
                        : 'bg-emerald-950/80 text-emerald-300 border-emerald-700'
                    }`}
                  >
                    {lynchedPlayer.role.team === 'mafia'
                      ? t.mafiaTeam
                      : lynchedPlayer.role.team === 'neutral'
                      ? t.neutralTeam
                      : t.townTeam}
                  </span>
                </div>
              ) : (
                <div className="py-4 text-xs text-stone-400 font-mono animate-pulse">
                  {lang === 'ar' ? 'جارٍ كشف البطاقة السرية...' : 'Revealing clandestine dossier...'}
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Tie case */
          <div className="w-full p-5 rounded-2xl bg-amber-950/30 border border-amber-800/40 text-center space-y-2">
            <AlertCircle className="w-8 h-8 text-amber-400 mx-auto" />
            <h3 className="text-lg font-bold text-amber-300">{t.lynchTie}</h3>
            <p className="text-xs text-stone-300">
              {lang === 'ar'
                ? 'تساوت الأصوات بين المرشحين، لذا لم تجد القرية إجماعاً ونجا الجميع من المشنقة اليوم!'
                : 'Votes ended in a deadlock tie. No suspect reached a clear majority today!'}
            </p>
          </div>
        )}

        {/* Game Over Victory Callout after Lynch */}
        {isGameOver && (
          <div className={`w-full p-4 rounded-2xl border space-y-1.5 ${
            winningTeam === 'mafia'
              ? 'bg-red-950/70 border-red-600/70 text-red-200'
              : winningTeam === 'jester'
              ? 'bg-amber-950/70 border-amber-500/70 text-amber-200'
              : 'bg-emerald-950/70 border-emerald-600/70 text-emerald-200'
          }`}>
            <div className="flex items-center justify-center gap-2 font-black text-base">
              <Trophy className="w-5 h-5 text-amber-400" />
              <span>
                {winningTeam === 'mafia'
                  ? t.mafiaWon
                  : winningTeam === 'jester'
                  ? t.jesterWon
                  : t.townWon}
              </span>
            </div>
            <p className="text-xs text-stone-200 text-center leading-relaxed">
              {winReason}
            </p>
          </div>
        )}

        {/* D3 Forensic Horizontal Bar Chart */}
        <div className="w-full text-left">
          <DetectiveD3VoteChart
            data={d3Data}
            totalVotesCast={totalVotesCast}
            totalVoters={relevantPlayers.length}
            lang={lang}
          />
        </div>

        {/* Next Action Button */}
        <button
          onClick={() => {
            sound.playCardFlip();
            onProceed();
          }}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-700 to-amber-600 hover:from-red-600 hover:to-amber-500 text-white font-bold text-base transition-all cursor-pointer shadow-xl flex items-center justify-center gap-2"
        >
          {isGameOver ? (
            <>
              <Trophy className="w-5 h-5 text-amber-300" />
              <span>{lang === 'ar' ? 'عرض شاشة النتيجة والتصنيف' : 'View Victory & MVP Results'}</span>
            </>
          ) : (
            <>
              <Moon className="w-5 h-5 text-indigo-300" />
              <span>{lang === 'ar' ? 'حلول الليل التالي' : 'Enter Next Night Phase'}</span>
            </>
          )}
          {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
};
