import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, Award, RotateCcw, Users, Skull, CheckCircle, Crown, Sparkles, Info, ChevronDown, ChevronUp } from 'lucide-react';
import { Language, Player, MvpScore } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { sound } from '../utils/sound';

interface GameOverViewProps {
  lang: Language;
  winningTeam: 'town' | 'mafia' | 'jester' | null;
  winReason: string;
  mvp: MvpScore;
  players: Player[];
  onPlayAgainSame: () => void;
  onNewGame: () => void;
}

export const GameOverView: React.FC<GameOverViewProps> = ({
  lang,
  winningTeam,
  winReason,
  mvp,
  players,
  onPlayAgainSame,
  onNewGame,
}) => {
  const t = useTranslation(lang);
  const [showMvpRules, setShowMvpRules] = useState<boolean>(false);

  useEffect(() => {
    sound.playVictory();

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: winningTeam === 'mafia' ? ['#dc2626', '#991b1b', '#000000'] : ['#10b981', '#f59e0b', '#3b82f6'],
      });
    } catch {
      // Ignore if confetti context unavailable
    }
  }, [winningTeam]);

  const getVictoryTitle = () => {
    if (winningTeam === 'town') return t.townWon;
    if (winningTeam === 'mafia') return t.mafiaWon;
    if (winningTeam === 'jester') return t.jesterWon;
    return t.gameOver;
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-start p-4 sm:p-6 max-w-2xl mx-auto w-full relative z-10 overflow-y-auto animate-fade-in">
      {/* Victory Banner */}
      <div className="text-center mb-6 space-y-2">
        <div className="inline-flex items-center gap-2 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 mb-2 shadow-lg">
          <Trophy className="w-8 h-8" />
        </div>

        <h2 className="text-3xl sm:text-5xl font-black font-cinzel text-white">
          {getVictoryTitle()}
        </h2>

        <p className="text-xs sm:text-sm text-stone-300 max-w-md mx-auto leading-relaxed">
          {winReason}
        </p>
      </div>

      {/* MVP Award Card */}
      <div className="w-full p-5 sm:p-6 rounded-2xl bg-gradient-to-br from-amber-950/60 via-black/85 to-stone-900/60 border border-amber-500/40 backdrop-blur-xl shadow-2xl mb-4 text-center space-y-3 relative overflow-hidden">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[11px] font-bold uppercase tracking-widest">
            <Award className="w-4 h-4 text-amber-400" />
            <span>{t.mvpTitle}</span>
          </div>

          {/* Role Alignment Badge */}
          <span
            className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
              mvp.player.role.team === 'mafia'
                ? 'bg-red-950 text-red-300 border-red-700'
                : mvp.player.role.team === 'neutral'
                ? 'bg-amber-950 text-amber-300 border-amber-700'
                : 'bg-emerald-950 text-emerald-300 border-emerald-700'
            }`}
          >
            {mvp.player.role.team === 'mafia'
              ? lang === 'ar' ? '👑 مافيا ناجٍ · فوز المافيا' : '👑 Surviving Mafia'
              : mvp.player.role.team === 'neutral'
              ? lang === 'ar' ? '🃏 بطل الجوكر المنفرد' : '🃏 Jester Champion'
              : lang === 'ar' ? '🛡️ بطل الصالحين · فوز القرية' : '🛡️ Town Champion'}
          </span>
        </div>

        <div>
          <h3 className="text-2xl sm:text-4xl font-black text-white font-cinzel tracking-wide">
            {mvp.player.name}
          </h3>
          <span
            className="text-sm font-bold block mt-1"
            style={{ color: mvp.player.role.accentColor }}
          >
            {lang === 'ar' ? mvp.player.role.nameAr : mvp.player.role.nameEn}
          </span>
        </div>

        <p className="text-xs sm:text-sm text-stone-200 max-w-md mx-auto bg-black/60 p-3 rounded-xl border border-white/10 leading-relaxed">
          {lang === 'ar' ? mvp.reasonAr : mvp.reasonEn}
        </p>

        {/* Toggle MVP Rules Explainer */}
        <div className="pt-2 border-t border-white/10 text-left">
          <button
            onClick={() => {
              sound.playCardFlip();
              setShowMvpRules((prev) => !prev);
            }}
            className="flex items-center justify-between w-full text-xs text-amber-400/90 hover:text-amber-300 font-semibold cursor-pointer py-1"
          >
            <span className="flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5" />
              <span>{t.mvpRulesSectionTitle}</span>
            </span>
            {showMvpRules ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {showMvpRules && (
            <div className="mt-2.5 p-3 rounded-xl bg-black/70 border border-white/10 space-y-2 text-xs text-stone-300 leading-relaxed animate-fade-in">
              <div className="p-2 rounded-lg bg-red-950/40 border border-red-800/30">
                <span className="font-bold text-red-400 block mb-0.5">{t.mvpRulesMafiaTitle}:</span>
                <span className="text-[11px] text-stone-300">{t.mvpRulesMafiaDesc}</span>
              </div>
              <div className="p-2 rounded-lg bg-emerald-950/40 border border-emerald-800/30">
                <span className="font-bold text-emerald-400 block mb-0.5">{t.mvpRulesTownTitle}:</span>
                <span className="text-[11px] text-stone-300">{t.mvpRulesTownDesc}</span>
              </div>
              <div className="p-2 rounded-lg bg-amber-950/40 border border-amber-800/30">
                <span className="font-bold text-amber-400 block mb-0.5">{t.mvpRulesJesterTitle}:</span>
                <span className="text-[11px] text-stone-300">{t.mvpRulesJesterDesc}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Master Reveal List */}
      <div className="w-full space-y-3 mb-8">
        <div className="flex items-center justify-between text-xs text-stone-300 font-semibold px-1">
          <span>{t.masterList}</span>
          <span className="text-stone-400">{players.length} {lang === 'ar' ? 'لاعبين' : 'players'}</span>
        </div>

        <div className="space-y-2">
          {players.map((player) => (
            <div
              key={player.id}
              className="p-3 rounded-xl bg-black/60 border border-white/10 flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <span
                  className={`w-2 h-2 rounded-full ${
                    player.isAlive ? 'bg-emerald-400' : 'bg-red-500'
                  }`}
                  title={player.isAlive ? t.alive : t.dead}
                />
                <span className="font-bold text-white text-sm">{player.name}</span>
                <span className="text-xs text-stone-400">
                  ({player.isAlive ? t.alive : t.dead})
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span
                  className="text-xs font-bold"
                  style={{ color: player.role.accentColor }}
                >
                  {lang === 'ar' ? player.role.nameAr : player.role.nameEn}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                    player.role.team === 'mafia'
                      ? 'bg-red-950 text-red-300 border-red-800'
                      : player.role.team === 'neutral'
                      ? 'bg-amber-950 text-amber-300 border-amber-800'
                      : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                  }`}
                >
                  {player.role.team === 'mafia'
                    ? t.mafiaTeam
                    : player.role.team === 'neutral'
                    ? t.neutralTeam
                    : t.townTeam}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row items-center gap-3 w-full max-w-md">
        <button
          onClick={() => {
            sound.playGavel();
            onPlayAgainSame();
          }}
          className="w-full py-4 px-6 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-base transition-all cursor-pointer shadow-xl flex items-center justify-center gap-2"
        >
          <RotateCcw className="w-5 h-5" />
          <span>{t.playAgainSame}</span>
        </button>

        <button
          onClick={() => {
            sound.playCardFlip();
            onNewGame();
          }}
          className="w-full sm:w-auto py-3.5 px-6 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <Users className="w-4 h-4" />
          <span>{t.newRoster}</span>
        </button>
      </div>
    </div>
  );
};
