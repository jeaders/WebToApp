import React from 'react';
import { Sun, Heart, Skull, Newspaper, ArrowRight, ArrowLeft, Trophy, Award, VolumeX } from 'lucide-react';
import { Language, DawnResult, Player } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { sound } from '../utils/sound';

interface DawnReportViewProps {
  lang: Language;
  dawnResult: DawnResult;
  players: Player[];
  dayNumber: number;
  isGameOver?: boolean;
  winningTeam?: 'town' | 'mafia' | 'jester' | null;
  winReason?: string;
  onProceedToDiscussion: () => void;
  onReopenNewspaper?: () => void;
}

export const DawnReportView: React.FC<DawnReportViewProps> = ({
  lang,
  dawnResult,
  players,
  dayNumber,
  isGameOver = false,
  winningTeam = null,
  winReason = '',
  onProceedToDiscussion,
  onReopenNewspaper,
}) => {
  const t = useTranslation(lang);

  const killedPlayers = players.filter((p) =>
    dawnResult.killedPlayerIds.includes(p.id)
  );
  const savedPlayer = players.find((p) => p.id === dawnResult.savedPlayerId);
  const silencedPlayer = players.find((p) => p.id === dawnResult.silencedPlayerId);

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 max-w-lg mx-auto w-full relative z-10 animate-fade-in">
      <div className="w-full bg-[#171822]/95 border border-white/15 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl flex flex-col items-center text-center space-y-6">
        {/* Morning Sun Icon & Headline */}
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
            <Sun className="w-4 h-4 text-amber-400" />
            <span>{lang === 'ar' ? `صباح اليوم ${dayNumber}` : `Dawn of Day ${dayNumber}`}</span>
          </div>

          {onReopenNewspaper && (
            <button
              onClick={() => {
                sound.playCardFlip();
                onReopenNewspaper();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-stone-800/80 hover:bg-stone-700 border border-stone-600 text-stone-300 hover:text-white text-xs font-medium transition-all cursor-pointer shadow-sm"
              title={lang === 'ar' ? 'عرض جريدة الفجر العاجلة' : 'View Morning Newspaper Extra'}
            >
              <Newspaper className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'ar' ? 'جريدة الفجر ⚡' : 'Front Page ⚡'}</span>
            </button>
          )}
        </div>

        <div className="space-y-1">
          <h2 className="text-2xl sm:text-3xl font-black font-cinzel text-white">
            {t.morningBreaks}
          </h2>
          <p className="text-xs text-stone-400">
            {lang === 'ar' ? 'صحيفة وقائع المدينة تكشف أحداث الليل' : 'The town chronicle reveals nocturnal events'}
          </p>
        </div>

        {/* Newspaper Dossier Box */}
        <div className="w-full p-5 rounded-2xl bg-black/60 border border-white/10 space-y-4 text-left">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <span className="text-[11px] font-mono uppercase tracking-widest text-stone-400 flex items-center gap-1.5">
              <Newspaper className="w-4 h-4 text-amber-400" />
              {lang === 'ar' ? 'تقرير الشرطة الجنائي' : 'Police Morning Dispatch'}
            </span>
            <span className="text-[10px] text-stone-400 font-mono">
              {lang === 'ar' ? `العدد #${dayNumber}` : `Issue #${dayNumber}`}
            </span>
          </div>

          {/* Saved by Doctor */}
          {savedPlayer && (
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
                <Heart className="w-5 h-5 fill-current" />
              </div>
              <div className="text-xs sm:text-sm">
                <span className="font-bold text-emerald-300 block">
                  {lang === 'ar' ? 'تدخل بطولي للطبيب!' : 'Heroic Medical Intervention!'}
                </span>
                <span className="text-stone-300">
                  {lang === 'ar'
                    ? `تم إنقاذ [${savedPlayer.name}] من محاولة اغتيال مؤكدة بفضل الترياق السريع!`
                    : `[${savedPlayer.name}] was saved from a targeted kill thanks to swift medical care!`}
                </span>
              </div>
            </div>
          )}

          {/* Silenced by Mafia Silencer */}
          {silencedPlayer && (
            <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-800/40 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-rose-500/20 text-rose-400 shrink-0">
                <VolumeX className="w-5 h-5" />
              </div>
              <div className="text-xs sm:text-sm text-left">
                <span className="font-bold text-rose-300 block">
                  {lang === 'ar' ? 'أمر صمت إجباري من المافيا!' : 'Mafia Gag Order Enforced!'}
                </span>
                <span className="text-stone-300">
                  {lang === 'ar'
                    ? `تم تكميم فم [${silencedPlayer.name}] بالكامل وإسكاته لليوم! يُمنع عليه التحدث أو الدفاع عن نفسه طوال مرحلة النقاش.`
                    : `[${silencedPlayer.name}] was gagged and silenced by the Mafia! They are strictly forbidden from speaking today.`}
                </span>
              </div>
            </div>
          )}

          {/* Casualties */}
          {killedPlayers.length > 0 ? (
            <div className="space-y-2.5">
              <div className="p-3.5 rounded-xl bg-red-950/50 border border-red-800/50 space-y-2">
                <div className="flex items-center gap-2 text-red-400 font-bold text-sm">
                  <Skull className="w-5 h-5" />
                  <span>{lang === 'ar' ? 'ضحايا اغتيال الليل' : 'Casualties of the Night'}</span>
                </div>
                {killedPlayers.map((victim) => (
                  <div
                    key={victim.id}
                    className="flex items-center justify-between p-2 rounded-lg bg-black/40 border border-white/5"
                  >
                    <span className="font-bold text-white text-sm">{victim.name}</span>
                    <span className="text-xs text-stone-400">
                      {lang === 'ar' ? `كان دوره: ${victim.role.nameAr}` : `Role: ${victim.role.nameEn}`}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            !savedPlayer && (
              <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 text-stone-300 text-xs text-center">
                {lang === 'ar'
                  ? 'مرت الليلة بهدوء غير معتاد دون وقوع أي ضحايا في القرية.'
                  : 'An unusually peaceful night passed with no casualties reported.'}
              </div>
            )
          )}

          {/* Game Over Victory Callout at Dawn */}
          {isGameOver && (
            <div className={`p-4 rounded-xl border space-y-2 ${
              winningTeam === 'mafia'
                ? 'bg-red-950/60 border-red-600/60 text-red-200'
                : 'bg-emerald-950/60 border-emerald-600/60 text-emerald-200'
            }`}>
              <div className="flex items-center gap-2 font-black text-sm">
                <Trophy className="w-5 h-5 text-amber-400 shrink-0" />
                <span>
                  {winningTeam === 'mafia' ? t.mafiaWon : t.townWon}
                </span>
              </div>
              <p className="text-xs text-stone-300 leading-relaxed">
                {winReason}
              </p>
            </div>
          )}
        </div>

        {/* Action Button */}
        <button
          onClick={() => {
            if (isGameOver) {
              sound.playVictory();
            } else {
              sound.playClockTick();
            }
            onProceedToDiscussion();
          }}
          className={`w-full py-4 px-6 rounded-2xl font-bold text-base transition-all cursor-pointer shadow-xl flex items-center justify-center gap-2 ${
            isGameOver
              ? 'bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-black animate-pulse'
              : 'bg-amber-500 hover:bg-amber-400 text-black'
          }`}
        >
          {isGameOver ? (
            <>
              <Award className="w-5 h-5 text-black" />
              <span>{t.viewGameOverFromDawn}</span>
            </>
          ) : (
            <>
              <span>{lang === 'ar' ? 'بدء مرحلة النقاش والتحقيق' : 'Begin Daytime Discussion'}</span>
              {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            </>
          )}
        </button>
      </div>
    </div>
  );
};
