import React from 'react';
import { X, Shield, Crown, UserCheck, Search, ShieldPlus, Target, Sparkles, CheckCircle2, Award } from 'lucide-react';
import { Language } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { ROLES_POOL } from '../utils/rolesData';
import { sound } from '../utils/sound';

interface RulesModalProps {
  lang: Language;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ lang, onClose }) => {
  const t = useTranslation(lang);

  const getRoleIcon = (type: string) => {
    switch (type) {
      case 'godfather':
        return <Crown className="w-5 h-5 text-red-500" />;
      case 'mafia':
        return <Shield className="w-5 h-5 text-red-400" />;
      case 'doctor':
        return <ShieldPlus className="w-5 h-5 text-emerald-400" />;
      case 'detective':
        return <Search className="w-5 h-5 text-blue-400" />;
      case 'vigilante':
        return <Target className="w-5 h-5 text-purple-400" />;
      case 'villager':
        return <UserCheck className="w-5 h-5 text-teal-400" />;
      case 'jester':
        return <Sparkles className="w-5 h-5 text-amber-400" />;
      default:
        return <UserCheck className="w-5 h-5 text-white" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-3xl max-h-[90vh] bg-[#14151b] border border-white/15 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-[#f4eedd]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-black/40">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Shield className="w-5 h-5" />
            </div>
            <h2 className="text-lg sm:text-xl font-bold tracking-wide">
              {t.rulesTitle}
            </h2>
          </div>
          <button
            onClick={() => {
              sound.playCardFlip();
              onClose();
            }}
            className="p-2 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title={t.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm leading-relaxed">
          {/* Overview */}
          <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-2">
            <h3 className="font-bold text-base text-amber-300">
              {lang === 'ar' ? 'نظرة عامة على اللعبة' : 'Game Overview'}
            </h3>
            <p className="text-stone-300">
              {lang === 'ar'
                ? 'تعتمد لعبة المافيا على الصراع الاجتماعي، الخداع والتفكير المنطقي بين مجموعتين: فريق الصالحين الذين يسعون لكشف الخونة، وفريق المافيا الذين يغتالون الصالحين ليلاً، بالإضافة إلى أدوار محايدة استثنائية كالجوكر.'
                : 'Mafia is a party game of social deduction, deception, and psychological observation. The innocent Town aims to uncover all Mafia members via daytime debate and voting, while the Mafia eliminates citizens in the dead of night.'}
            </p>
          </div>

          {/* Teams & Win Conditions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-800/40">
              <h4 className="font-bold text-emerald-400 mb-1 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                {t.townTeam}
              </h4>
              <p className="text-xs text-stone-300">{t.townObjective}</p>
            </div>

            <div className="p-4 rounded-xl bg-red-950/30 border border-red-800/40">
              <h4 className="font-bold text-red-400 mb-1 flex items-center gap-1.5">
                <Crown className="w-4 h-4" />
                {t.mafiaTeam}
              </h4>
              <p className="text-xs text-stone-300">{t.mafiaObjective}</p>
            </div>

            <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-800/40">
              <h4 className="font-bold text-amber-400 mb-1 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                {t.neutralTeam}
              </h4>
              <p className="text-xs text-stone-300">{t.jesterObjective}</p>
            </div>
          </div>

          {/* Standard Role Cards */}
          <div>
            <h3 className="font-bold text-base text-stone-200 mb-3">
              {lang === 'ar' ? 'الأدوار الرسمية وقدراتها' : 'Official Roles & Night Powers'}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {Object.values(ROLES_POOL).map((role) => (
                <div
                  key={role.type}
                  className="p-3.5 rounded-xl bg-black/50 border border-white/10 flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-lg bg-white/5 border border-white/10">
                        {getRoleIcon(role.type)}
                      </div>
                      <span className="font-bold text-white text-sm">
                        {lang === 'ar' ? role.nameAr : role.nameEn}
                      </span>
                    </div>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                        role.team === 'mafia'
                          ? 'bg-red-900/60 text-red-300 border border-red-700/50'
                          : role.team === 'neutral'
                          ? 'bg-amber-900/60 text-amber-300 border border-amber-700/50'
                          : 'bg-emerald-900/60 text-emerald-300 border border-emerald-700/50'
                      }`}
                    >
                      {role.team === 'mafia'
                        ? lang === 'ar'
                          ? 'مافيا'
                          : 'MAFIA'
                        : role.team === 'neutral'
                        ? lang === 'ar'
                          ? 'محايد'
                          : 'NEUTRAL'
                        : lang === 'ar'
                        ? 'صالح'
                        : 'TOWN'}
                    </span>
                  </div>
                  <p className="text-xs text-stone-300/90 mb-2 leading-relaxed">
                    {lang === 'ar' ? role.descriptionAr : role.descriptionEn}
                  </p>
                  <div className="text-[11px] text-amber-400/90 font-medium pt-1.5 border-t border-white/5">
                    {lang === 'ar' ? `القدرة: ${role.abilityAr}` : `Ability: ${role.abilityEn}`}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sequential Game Flow */}
          <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3">
            <h3 className="font-bold text-base text-stone-200">
              {lang === 'ar' ? 'التسلسل المباشر للجولة (Flow)' : 'Turn Cycle Flow'}
            </h3>
            <ol className="list-decimal list-inside space-y-1.5 text-xs text-stone-300">
              <li>
                <strong className="text-white">{lang === 'ar' ? 'توزيع الأدوار بالسر:' : 'Secret Pass & Play Reveal:'}</strong>{' '}
                {lang === 'ar'
                  ? 'يتم تمرير الهاتف لكل لاعب على انفراد ليكشف بطاقته دون أن يراها أحد.'
                  : 'Pass the device to each player privately to view their clandestine role card.'}
              </li>
              <li>
                <strong className="text-white">{lang === 'ar' ? 'مرحلة الليل:' : 'Night Phase:'}</strong>{' '}
                {lang === 'ar'
                  ? 'تنام القرية؛ يستيقظ المافيا للاغتيال، الطبيب للحماية، والمحقق للفحص سراً.'
                  : 'The town sleeps. Mafia targets a victim, Doctor heals, and Detective investigates.'}
              </li>
              <li>
                <strong className="text-white">{lang === 'ar' ? 'الصباح والنقاش:' : 'Dawn & Discussion:'}</strong>{' '}
                {lang === 'ar'
                  ? 'إعلان نتيجة أحداث الليل وبدء مؤقت النقاش لتبادل الاتهامات والملاحظات.'
                  : 'The night report reveals casualties or doctor saves. Discussion timer begins.'}
              </li>
              <li>
                <strong className="text-white">{lang === 'ar' ? 'التصويت الرسمي:' : 'Secret Voting:'}</strong>{' '}
                {lang === 'ar'
                  ? 'يمر الهاتف بين اللاعبين الأحياء ليصوت كل لاعب سراً لمن يريد إعدامه.'
                  : 'The device is passed among living players to cast secret execution ballots.'}
              </li>
              <li>
                <strong className="text-white">{lang === 'ar' ? 'الإعدام ونهاية اللعبة:' : 'Execution & Win Check:'}</strong>{' '}
                {lang === 'ar'
                  ? 'إعدام صاحب أعلى أصوات وكشف بطاقته، ثم فحص شروط الفوز أو متابعة الليلة التالية.'
                  : 'The highest-voted suspect is lynched and their true identity revealed.'}
              </li>
            </ol>
          </div>

          {/* MVP Rules Section */}
          <div className="p-4 rounded-xl bg-amber-950/25 border border-amber-500/30 space-y-3">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-base">
              <Award className="w-5 h-5 text-amber-400" />
              <span>{t.mvpRulesSectionTitle}</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 text-xs">
              <div className="p-3 rounded-lg bg-red-950/40 border border-red-800/40 space-y-1">
                <span className="font-bold text-red-400 flex items-center gap-1">
                  <Crown className="w-3.5 h-3.5" />
                  {t.mvpRulesMafiaTitle}
                </span>
                <p className="text-stone-300 leading-relaxed text-[11px]">{t.mvpRulesMafiaDesc}</p>
              </div>

              <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-800/40 space-y-1">
                <span className="font-bold text-emerald-400 flex items-center gap-1">
                  <Shield className="w-3.5 h-3.5" />
                  {t.mvpRulesTownTitle}
                </span>
                <p className="text-stone-300 leading-relaxed text-[11px]">{t.mvpRulesTownDesc}</p>
              </div>

              <div className="p-3 rounded-lg bg-amber-950/40 border border-amber-800/40 space-y-1">
                <span className="font-bold text-amber-400 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  {t.mvpRulesJesterTitle}
                </span>
                <p className="text-stone-300 leading-relaxed text-[11px]">{t.mvpRulesJesterDesc}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 border-t border-white/10 bg-black/60 flex justify-end">
          <button
            onClick={() => {
              sound.playCardFlip();
              onClose();
            }}
            className="py-2 px-6 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold text-sm transition-colors cursor-pointer"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
