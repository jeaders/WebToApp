import React, { useState } from 'react';
import { Moon, EyeOff, ShieldAlert, Crosshair, ShieldPlus, Search, Target, Check, ArrowRight, ArrowLeft, UserCheck, Sparkles, Skull, Clock, VolumeX } from 'lucide-react';
import { Language, Player, NightDecisions } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { sound } from '../utils/sound';

interface NightPassAndPlaySequentialViewProps {
  lang: Language;
  players: Player[];
  onDecisionsComplete: (decisions: NightDecisions) => void;
}

export const NightPassAndPlaySequentialView: React.FC<NightPassAndPlaySequentialViewProps> = ({
  lang,
  players,
  onDecisionsComplete,
}) => {
  const t = useTranslation(lang);

  const [currentPlayerIndex, setCurrentPlayerIndex] = useState<number>(0);
  const [isPrivacyUnlocked, setIsPrivacyUnlocked] = useState<boolean>(false);

  // Cumulative night choices
  const [mafiaTargetId, setMafiaTargetId] = useState<string | null>(null);
  const [silencerTargetId, setSilencerTargetId] = useState<string | null>(null);
  const [doctorTargetId, setDoctorTargetId] = useState<string | null>(null);
  const [detectiveTargetId, setDetectiveTargetId] = useState<string | null>(null);
  const [detectiveResult, setDetectiveResult] = useState<{ targetName: string; isMafia: boolean } | null>(null);
  const [vigilanteTargetId, setVigilanteTargetId] = useState<string | null>(null);

  // Local turn choice
  const [selectedTargetId, setSelectedTargetId] = useState<string | null>(null);

  const currentPlayer = players[currentPlayerIndex];
  const nextPlayer = currentPlayerIndex < players.length - 1 ? players[currentPlayerIndex + 1] : null;

  const alivePlayers = players.filter((p) => p.isAlive);
  const fellowMafia = players.filter((p) => p.role.team === 'mafia' && p.isAlive);

  // Advance to next player in roster
  const handleProceedToNext = () => {
    sound.playCardFlip();

    // Record decision based on role
    if (currentPlayer.isAlive) {
      if (currentPlayer.role.type === 'silencer' && selectedTargetId) {
        setSilencerTargetId(selectedTargetId);
      } else if (currentPlayer.role.team === 'mafia' && selectedTargetId) {
        setMafiaTargetId(selectedTargetId);
      } else if (currentPlayer.role.type === 'doctor' && selectedTargetId) {
        setDoctorTargetId(selectedTargetId);
      } else if (currentPlayer.role.type === 'vigilante' && selectedTargetId) {
        setVigilanteTargetId(selectedTargetId);
        sound.playGunshot();
      }
    }

    if (currentPlayerIndex < players.length - 1) {
      setCurrentPlayerIndex((idx) => idx + 1);
      setIsPrivacyUnlocked(false);
      setSelectedTargetId(null);
    } else {
      // Finished all players!
      sound.playHeartbeat();
      onDecisionsComplete({
        mafiaTargetId: currentPlayer.role.team === 'mafia' && currentPlayer.role.type !== 'silencer' && selectedTargetId ? selectedTargetId : mafiaTargetId,
        doctorTargetId: currentPlayer.role.type === 'doctor' && selectedTargetId ? selectedTargetId : doctorTargetId,
        detectiveTargetId,
        detectiveResult,
        vigilanteTargetId: currentPlayer.role.type === 'vigilante' && selectedTargetId ? selectedTargetId : vigilanteTargetId,
        silencerTargetId: currentPlayer.role.type === 'silencer' && selectedTargetId ? selectedTargetId : silencerTargetId,
      });
    }
  };

  const handleInspect = (targetId: string) => {
    setDetectiveTargetId(targetId);
    const targetPlayer = players.find((p) => p.id === targetId);
    if (!targetPlayer) return;

    // Godfather appears clean to Detective!
    const isMafia = targetPlayer.role.team === 'mafia' && targetPlayer.role.type !== 'godfather';

    sound.playReveal(isMafia);
    setDetectiveResult({
      targetName: targetPlayer.name,
      isMafia,
    });
  };

  // 1. PRIVACY CURTAIN SCREEN
  if (!isPrivacyUnlocked) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-4 max-w-lg mx-auto w-full relative z-10 animate-fade-in">
        <div className="w-full bg-[#13141c]/95 border border-white/15 rounded-3xl p-8 backdrop-blur-xl shadow-2xl flex flex-col items-center text-center space-y-6">
          <div className="flex items-center gap-2 text-stone-400 text-xs font-mono">
            <Moon className="w-3.5 h-3.5 text-indigo-400" />
            <span>
              {lang === 'ar'
                ? `جولة الليل · اللاعب ${currentPlayerIndex + 1} من ${players.length}`
                : `Night Cycle · Player ${currentPlayerIndex + 1} of ${players.length}`}
            </span>
          </div>

          <div className="w-20 h-20 rounded-2xl bg-indigo-950/40 border border-indigo-700/40 flex items-center justify-center text-indigo-400 animate-pulse">
            <EyeOff className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <p className="text-xs sm:text-sm text-stone-400 uppercase tracking-wider font-semibold">
              {t.passPhoneTo}
            </p>
            <h3 className="text-3xl sm:text-4xl font-black text-white font-cinzel">
              {currentPlayer.name}
            </h3>
          </div>

          <div className="p-3 rounded-xl bg-red-950/40 border border-red-800/40 text-red-300 text-xs flex items-center gap-2 max-w-xs">
            <ShieldAlert className="w-4 h-4 shrink-0 text-red-400" />
            <span>{t.ensurePrivacy}</span>
          </div>

          <button
            onClick={() => {
              sound.playCardFlip();
              setIsPrivacyUnlocked(true);
            }}
            className="w-full py-4 px-6 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-sm sm:text-base transition-all cursor-pointer shadow-lg"
          >
            {lang === 'ar' ? `أنا ${currentPlayer.name}، فتح مهمتي` : `I am ${currentPlayer.name}, open my task`}
          </button>
        </div>
      </div>
    );
  }

  // 2. UNLOCKED SECRET PERSONAL SCREEN
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 max-w-lg mx-auto w-full relative z-10 animate-fade-in">
      <div className="w-full bg-[#151620]/95 border border-white/15 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl flex flex-col justify-between min-h-[480px]">
        {/* CASE A: DECEASED GHOST */}
        {!currentPlayer.isAlive && (
          <div className="flex-1 flex flex-col items-center justify-center space-y-4 text-center my-auto">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-stone-400">
              <Skull className="w-12 h-12" />
            </div>
            <h3 className="text-2xl font-black text-stone-300 font-cinzel">
              {t.ghostNightTitle}
            </h3>
            <p className="text-xs sm:text-sm text-stone-400 max-w-xs leading-relaxed">
              {t.ghostNightDesc}
            </p>
          </div>
        )}

        {/* CASE B: VILLAGER OR JESTER (Innocent bluffing / camouflage) */}
        {currentPlayer.isAlive && (currentPlayer.role.type === 'villager' || currentPlayer.role.type === 'jester') && (
          <div className="flex-1 flex flex-col items-center justify-center space-y-4 text-center my-auto">
            <div className="p-4 rounded-2xl bg-teal-950/40 border border-teal-700/40 text-teal-400">
              {currentPlayer.role.type === 'jester' ? <Sparkles className="w-12 h-12 text-amber-400" /> : <UserCheck className="w-12 h-12" />}
            </div>

            <div className="space-y-1">
              <span className="text-xs text-stone-400 block">{currentPlayer.name}</span>
              <h3 className="text-2xl sm:text-3xl font-black text-white font-cinzel">
                {currentPlayer.role.type === 'jester' ? t.jesterNightTitle : t.villagerNightTitle}
              </h3>
            </div>

            <p className="text-xs sm:text-sm text-stone-300 max-w-xs leading-relaxed bg-black/40 p-4 rounded-2xl border border-white/10">
              {currentPlayer.role.type === 'jester' ? t.jesterNightDesc : t.villagerNightDesc}
            </p>

            <div className="flex items-center gap-2 text-[11px] text-amber-400/90 font-mono">
              <Clock className="w-3.5 h-3.5 animate-spin" />
              <span>{t.bluffTimeText}</span>
            </div>
          </div>
        )}

        {/* CASE C-1: MAFIA / GODFATHER ASSASSINATION */}
        {currentPlayer.isAlive && currentPlayer.role.team === 'mafia' && currentPlayer.role.type !== 'silencer' && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-white/10">
              <Crosshair className="w-6 h-6 text-red-500" />
              <div>
                <h3 className="text-lg font-bold text-red-400 font-cinzel">
                  {lang === 'ar' ? `${currentPlayer.role.nameAr} - اختيار الضحية` : `${currentPlayer.role.nameEn} - Pick Victim`}
                </h3>
                <p className="text-xs text-stone-400">{t.mafiaPrompt}</p>
              </div>
            </div>

            {/* List other mafia */}
            <div className="p-2.5 rounded-lg bg-red-950/30 border border-red-800/30 text-xs text-stone-300">
              <span className="text-red-400 font-bold block mb-1">
                {lang === 'ar' ? 'رفقاؤك في المافيا:' : 'Fellow Syndicate Members:'}
              </span>
              <span>{fellowMafia.map((m) => m.name).join(' · ')}</span>
            </div>

            {/* Candidate list */}
            <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
              {alivePlayers.map((target) => {
                const isFellow = target.role.team === 'mafia';
                const isSelected = (selectedTargetId || mafiaTargetId) === target.id;

                return (
                  <button
                    key={target.id}
                    onClick={() => {
                      sound.playCardFlip();
                      setSelectedTargetId(target.id);
                    }}
                    className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-red-950 border-red-500 text-white shadow-lg'
                        : isFellow
                        ? 'bg-white/5 border-white/5 text-stone-400'
                        : 'bg-black/40 border-white/10 text-stone-200 hover:border-white/30'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm">{target.name}</span>
                      {isFellow && (
                        <span className="text-[10px] text-red-400 px-1 rounded bg-red-950/60 border border-red-800/40">
                          {lang === 'ar' ? 'مافيا' : 'Mafia'}
                        </span>
                      )}
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-red-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* CASE C-2: SILENCER (المصمّت) */}
        {currentPlayer.isAlive && currentPlayer.role.type === 'silencer' && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-white/10">
              <VolumeX className="w-6 h-6 text-rose-500" />
              <div>
                <h3 className="text-lg font-bold text-rose-400 font-cinzel">
                  {lang === 'ar' ? 'المصمّت - تكميم وإسكات لاعب' : 'The Silencer - Gag Player'}
                </h3>
                <p className="text-xs text-stone-400">{t.silencerPrompt}</p>
              </div>
            </div>

            {/* List other mafia */}
            <div className="p-2.5 rounded-lg bg-red-950/30 border border-red-800/30 text-xs text-stone-300">
              <span className="text-rose-400 font-bold block mb-1">
                {lang === 'ar' ? 'رفقاؤك في عصابة المافيا:' : 'Fellow Syndicate Members:'}
              </span>
              <span>{fellowMafia.map((m) => m.name).join(' · ')}</span>
            </div>

            {/* Candidate list to silence */}
            <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
              {alivePlayers.map((target) => {
                const isFellow = target.role.team === 'mafia';
                const isSelected = (selectedTargetId || silencerTargetId) === target.id;

                return (
                  <button
                    key={target.id}
                    onClick={() => {
                      sound.playCardFlip();
                      setSelectedTargetId(target.id);
                    }}
                    className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-rose-950 border-rose-500 text-white shadow-lg'
                        : 'bg-black/40 border-white/10 text-stone-200 hover:border-white/30'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm">{target.name}</span>
                      {isFellow && (
                        <span className="text-[10px] text-red-400 px-1 rounded bg-red-950/60 border border-red-800/40">
                          {lang === 'ar' ? 'مافيا' : 'Mafia'}
                        </span>
                      )}
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-rose-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* CASE D: DOCTOR */}
        {currentPlayer.isAlive && currentPlayer.role.type === 'doctor' && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-white/10">
              <ShieldPlus className="w-6 h-6 text-emerald-400" />
              <div>
                <h3 className="text-lg font-bold text-emerald-400 font-cinzel">
                  {lang === 'ar' ? 'الطبيب - اختيار الحماية' : 'Doctor - Protect Target'}
                </h3>
                <p className="text-xs text-stone-400">{t.doctorPrompt}</p>
              </div>
            </div>

            {currentPlayer.hasUsedSelfHeal && (
              <div className="p-2.5 rounded-lg bg-amber-950/40 border border-amber-800/40 text-xs text-amber-300">
                {t.doctorSelfUsed}
              </div>
            )}

            <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
              {alivePlayers.map((target) => {
                const isSelf = target.id === currentPlayer.id;
                const cannotSelf = isSelf && currentPlayer.hasUsedSelfHeal;
                const isSelected = (selectedTargetId || doctorTargetId) === target.id;

                return (
                  <button
                    key={target.id}
                    disabled={cannotSelf}
                    onClick={() => {
                      sound.playCardFlip();
                      setSelectedTargetId(target.id);
                    }}
                    className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      cannotSelf
                        ? 'opacity-30 cursor-not-allowed bg-black/20 border-white/5'
                        : isSelected
                        ? 'bg-emerald-950 border-emerald-500 text-white shadow-lg'
                        : 'bg-black/40 border-white/10 text-stone-200 hover:border-white/30'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm">{target.name}</span>
                      {isSelf && (
                        <span className="text-[10px] text-emerald-400 px-1 rounded bg-emerald-950/60 border border-emerald-800/40">
                          {lang === 'ar' ? 'أنت' : 'You'}
                        </span>
                      )}
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-emerald-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* CASE E: DETECTIVE */}
        {currentPlayer.isAlive && currentPlayer.role.type === 'detective' && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-white/10">
              <Search className="w-6 h-6 text-blue-400" />
              <div>
                <h3 className="text-lg font-bold text-blue-400 font-cinzel">
                  {lang === 'ar' ? 'المحقق - فحص هوية مشتبه به' : 'Detective - Inspect Suspect'}
                </h3>
                <p className="text-xs text-stone-400">{t.detectivePrompt}</p>
              </div>
            </div>

            {!detectiveResult ? (
              <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                {alivePlayers.map((target) => {
                  if (target.id === currentPlayer.id) return null;

                  return (
                    <button
                      key={target.id}
                      onClick={() => handleInspect(target.id)}
                      className="w-full p-3 rounded-xl border bg-black/40 border-white/10 text-stone-200 hover:border-blue-400/60 text-left flex items-center justify-between transition-all cursor-pointer"
                    >
                      <span className="font-semibold text-sm">{target.name}</span>
                      <Search className="w-4 h-4 text-blue-400" />
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="p-5 rounded-2xl bg-black/60 border border-white/15 text-center space-y-2 animate-fade-in">
                <span className="text-xs text-stone-400 uppercase tracking-widest block">
                  {lang === 'ar' ? 'ملف المشتبه به:' : 'Inspected Dossier:'}
                </span>
                <h4 className="text-2xl font-black text-white font-cinzel">
                  {detectiveResult.targetName}
                </h4>
                <div
                  className={`py-2.5 px-4 rounded-xl border font-black text-sm ${
                    detectiveResult.isMafia
                      ? 'bg-red-950/80 border-red-700 text-red-400'
                      : 'bg-emerald-950/80 border-emerald-700 text-emerald-400'
                  }`}
                >
                  {detectiveResult.isMafia ? t.detectiveResultMafia : t.detectiveResultClean}
                </div>
              </div>
            )}
          </div>
        )}

        {/* CASE F: VIGILANTE */}
        {currentPlayer.isAlive && currentPlayer.role.type === 'vigilante' && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-white/10">
              <Target className="w-6 h-6 text-purple-400" />
              <div>
                <h3 className="text-lg font-bold text-purple-400 font-cinzel">
                  {lang === 'ar' ? 'القناص - رصاصتك الوحيدة' : 'Vigilante - Lethal Bullet'}
                </h3>
                <p className="text-xs text-stone-400">{t.vigilantePrompt}</p>
              </div>
            </div>

            <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
              {alivePlayers.map((target) => {
                if (target.id === currentPlayer.id) return null;
                const isSelected = selectedTargetId === target.id;

                return (
                  <button
                    key={target.id}
                    onClick={() => {
                      sound.playCardFlip();
                      setSelectedTargetId(target.id);
                    }}
                    className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-purple-950 border-purple-500 text-white shadow-lg'
                        : 'bg-black/40 border-white/10 text-stone-200 hover:border-white/30'
                    }`}
                  >
                    <span className="font-semibold text-sm">{target.name}</span>
                    {isSelected && <Target className="w-4 h-4 text-purple-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* BOTTOM ACTION BUTTON: Pass to Next Player or Finish Night */}
        <div className="mt-4 pt-4 border-t border-white/10">
          <button
            onClick={handleProceedToNext}
            className="w-full py-4 px-6 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-xl transition-all cursor-pointer"
          >
            <span>
              {nextPlayer
                ? `${t.passToNextPlayer} ${nextPlayer.name}`
                : t.finishNightLoop}
            </span>
            {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
};
