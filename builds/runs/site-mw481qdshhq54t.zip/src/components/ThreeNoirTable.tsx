import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { GamePhase } from '../types/game';

interface ThreeNoirTableProps {
  phase: GamePhase;
  isNight: boolean;
}

export const ThreeNoirTable: React.FC<ThreeNoirTableProps> = ({ phase, isNight }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);

  // Lights refs for smooth transitions
  const keyLightRef = useRef<THREE.DirectionalLight | null>(null);
  const lampLightRef = useRef<THREE.PointLight | null>(null);
  const ambientLightRef = useRef<THREE.AmbientLight | null>(null);
  const spotLightRef = useRef<THREE.SpotLight | null>(null);
  const cigarEmberLightRef = useRef<THREE.PointLight | null>(null);

  // Target camera coordinates for phase choreography
  const targetCamPos = useRef<THREE.Vector3>(new THREE.Vector3(0, 5.2, 7.2));
  const targetCamLook = useRef<THREE.Vector3>(new THREE.Vector3(0, 0.6, 0));

  // Mouse interaction for subtle immersive parallax
  const mousePos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // 1. Detect software WebGL as per guidelines
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Setup Scene & Camera
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const width = container.clientWidth;
    const height = container.clientHeight;

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 5.5, 7.8);
    cameraRef.current = camera;

    // 3. Renderer with studio PBR
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    rendererRef.current = renderer;
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(renderer.domElement);

    // 4. Procedural Room Environment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 5. Fog
    const fogColor = new THREE.Color(0x090a10);
    scene.fog = new THREE.FogExp2(fogColor, 0.045);
    scene.background = fogColor;

    // 6. Lighting Rig
    const ambientLight = new THREE.AmbientLight(0x1a2130, 0.9);
    scene.add(ambientLight);
    ambientLightRef.current = ambientLight;

    // Warm Banker's Desk Lamp Light
    const lampLight = new THREE.PointLight(0xffa83b, 4.8, 12, 1.1);
    lampLight.position.set(-1.8, 2.3, -0.6);
    lampLight.castShadow = !isSoftwareGl;
    if (lampLight.castShadow) {
      lampLight.shadow.mapSize.width = 1024;
      lampLight.shadow.mapSize.height = 1024;
      lampLight.shadow.bias = -0.001;
    }
    scene.add(lampLight);
    lampLightRef.current = lampLight;

    // Directional Window Key Light with Venetian Blind Cast Shadows
    const keyLight = new THREE.DirectionalLight(0xffecc7, 2.0);
    keyLight.position.set(5, 8, 4);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 2048;
      keyLight.shadow.mapSize.height = 2048;
      keyLight.shadow.camera.near = 0.5;
      keyLight.shadow.camera.far = 25;
      keyLight.shadow.camera.left = -5;
      keyLight.shadow.camera.right = 5;
      keyLight.shadow.camera.top = 5;
      keyLight.shadow.camera.bottom = -5;
      keyLight.shadow.bias = -0.0005;
    }
    scene.add(keyLight);
    keyLightRef.current = keyLight;

    // Interrogation / Lynch Spotlight
    const spotLight = new THREE.SpotLight(0xff4422, 0, 14, Math.PI / 5.5, 0.35, 1);
    spotLight.position.set(0, 6.2, 0);
    spotLight.target.position.set(0, 0.6, 0);
    scene.add(spotLight);
    scene.add(spotLight.target);
    spotLightRef.current = spotLight;

    // Soft Cigar Ember Point Light
    const cigarEmberLight = new THREE.PointLight(0xff4500, 0.4, 2, 2);
    cigarEmberLight.position.set(-0.8, 1.25, 0.8);
    scene.add(cigarEmberLight);
    cigarEmberLightRef.current = cigarEmberLight;

    // =========================================================================
    // PROCEDURAL TEXTURE GENERATION (Zero External File / Zero 404 Dependencies)
    // =========================================================================

    // 1. Procedural Polished Mahogany Wood Texture
    const createWoodTexture = () => {
      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 512;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Base dark mahogany wash
        ctx.fillStyle = '#22110c';
        ctx.fillRect(0, 0, 512, 512);

        // Wood grain rings
        for (let i = 0; i < 512; i += 2) {
          const v = Math.sin(i * 0.05) * 12 + Math.cos(i * 0.02) * 8;
          ctx.strokeStyle = `rgba(50, 24, 16, ${0.15 + (Math.sin(i * 0.08) + 1) * 0.15})`;
          ctx.lineWidth = 2 + Math.random() * 2;
          ctx.beginPath();
          ctx.moveTo(0, i + v);
          ctx.lineTo(512, i + v);
          ctx.stroke();
        }

        // Concentric burl swirls
        const grad = ctx.createRadialGradient(256, 256, 10, 256, 256, 250);
        grad.addColorStop(0, 'rgba(42, 19, 13, 0.2)');
        grad.addColorStop(0.5, 'rgba(28, 12, 8, 0.1)');
        grad.addColorStop(1, 'rgba(15, 6, 4, 0.4)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 512, 512);
      }
      const tex = new THREE.CanvasTexture(canvas);
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      tex.colorSpace = THREE.SRGBColorSpace;
      return tex;
    };

    // 2. Procedural Pocket Watch Dial Texture
    const createWatchDialTexture = () => {
      const canvas = document.createElement('canvas');
      canvas.width = 256;
      canvas.height = 256;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#f7f2e4';
        ctx.beginPath();
        ctx.arc(128, 128, 124, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#c5a059';
        ctx.lineWidth = 6;
        ctx.stroke();

        // Numerals
        ctx.fillStyle = '#1a1412';
        ctx.font = 'bold 22px serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const numerals = ['XII', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI'];
        numerals.forEach((num, idx) => {
          const angle = (idx * Math.PI) / 6 - Math.PI / 2;
          const x = 128 + Math.cos(angle) * 94;
          const y = 128 + Math.sin(angle) * 94;
          ctx.fillText(num, x, y);
        });

        // Hands pointing to 11:45 (Noir midnight deadline)
        ctx.strokeStyle = '#1a1412';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(128, 128);
        ctx.lineTo(128 - 45, 128 - 25);
        ctx.stroke();

        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(128, 128);
        ctx.lineTo(128 - 20, 128 - 70);
        ctx.stroke();
      }
      const tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace;
      return tex;
    };

    // 3. Procedural Currency Banknote Band Texture
    const createCurrencyTexture = () => {
      const canvas = document.createElement('canvas');
      canvas.width = 256;
      canvas.height = 128;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#1e382b'; // Banknote green
        ctx.fillRect(0, 0, 256, 128);

        ctx.strokeStyle = '#85bb65';
        ctx.lineWidth = 6;
        ctx.strokeRect(6, 6, 244, 116);

        // Center oval portrait frame
        ctx.fillStyle = '#15291f';
        ctx.beginPath();
        ctx.ellipse(128, 64, 45, 55, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Paper Money Band across center
        ctx.fillStyle = '#f4eedd';
        ctx.fillRect(90, 0, 76, 128);
        ctx.fillStyle = '#8b0000';
        ctx.font = 'bold 16px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('$10,000', 128, 68);
      }
      const tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace;
      return tex;
    };

    const woodTex = createWoodTexture();
    const watchTex = createWatchDialTexture();
    const cashTex = createCurrencyTexture();

    // =========================================================================
    // MATERIAL DEFINITIONS
    // =========================================================================
    const mahoganyMat = new THREE.MeshStandardMaterial({
      map: woodTex,
      color: 0x2e1710,
      roughness: 0.28,
      metalness: 0.12,
    });

    const antiqueBrassMat = new THREE.MeshStandardMaterial({
      color: 0xd4a359,
      roughness: 0.25,
      metalness: 0.88,
    });

    const polishedGoldMat = new THREE.MeshStandardMaterial({
      color: 0xf5b041,
      roughness: 0.18,
      metalness: 0.95,
    });

    const bluedSteelMat = new THREE.MeshStandardMaterial({
      color: 0x222634,
      roughness: 0.32,
      metalness: 0.85,
    });

    const greenLeatherMat = new THREE.MeshStandardMaterial({
      color: 0x142b20, // Inlaid dark green leather desk blotter
      roughness: 0.75,
      metalness: 0.05,
    });

    const amberGlassMat = new THREE.MeshPhysicalMaterial({
      color: 0xb45309,
      roughness: 0.1,
      metalness: 0.15,
      transparent: true,
      opacity: 0.85,
    });

    const crystalGlassMat = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      roughness: 0.05,
      metalness: 0.1,
      transparent: true,
      opacity: 0.45,
    });

    // =========================================================================
    // BUILD 3D SCENE & NOIR PROPS
    // =========================================================================
    const worldGroup = new THREE.Group();
    scene.add(worldGroup);

    // A. Room Floor (Dark oak parquet)
    const floorGeo = new THREE.PlaneGeometry(35, 35);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x0f1115,
      roughness: 0.8,
      metalness: 0.1,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.05;
    floor.receiveShadow = true;
    worldGroup.add(floor);

    // Venetian Blinds Window Gobo (Casts real diagonal blind shadows across table)
    const blindsGroup = new THREE.Group();
    blindsGroup.position.set(4.5, 6.5, 3.5);
    blindsGroup.rotation.y = -Math.PI / 4;
    for (let b = 0; b < 16; b++) {
      const slatGeo = new THREE.BoxGeometry(3.5, 0.03, 0.14);
      const slatMat = new THREE.MeshBasicMaterial({ color: 0x000000 });
      const slat = new THREE.Mesh(slatGeo, slatMat);
      slat.position.set(0, (b * 0.22) - 1.6, 0);
      slat.rotation.x = Math.PI / 6;
      slat.castShadow = true;
      blindsGroup.add(slat);
    }
    worldGroup.add(blindsGroup);

    // B. MASTER CONFERENCE TABLE (Composite 8 parts)
    const tableGroup = new THREE.Group();

    // 1. Heavy Beveled Tabletop
    const tableTopGeo = new THREE.CylinderGeometry(3.8, 3.8, 0.18, 64);
    const tableTop = new THREE.Mesh(tableTopGeo, mahoganyMat);
    tableTop.position.y = 1.0;
    tableTop.castShadow = true;
    tableTop.receiveShadow = true;
    tableGroup.add(tableTop);

    // 2. Beveled Lower Edge Apron
    const apronGeo = new THREE.CylinderGeometry(3.6, 3.75, 0.14, 64);
    const apron = new THREE.Mesh(apronGeo, mahoganyMat);
    apron.position.y = 0.85;
    apron.castShadow = true;
    tableGroup.add(apron);

    // 3. Antique Brass Outer Rim Trim
    const rimGeo = new THREE.TorusGeometry(3.81, 0.04, 16, 64);
    const rim = new THREE.Mesh(rimGeo, antiqueBrassMat);
    rim.rotation.x = Math.PI / 2;
    rim.position.y = 1.0;
    tableGroup.add(rim);

    // 4. Inlaid Green Leather Desk Blotter Center Insert
    const blotterGeo = new THREE.CylinderGeometry(2.5, 2.5, 0.015, 64);
    const blotter = new THREE.Mesh(blotterGeo, greenLeatherMat);
    blotter.position.y = 1.095;
    blotter.receiveShadow = true;
    tableGroup.add(blotter);

    // 5. Inlaid Gold Stitched Ring on Blotter
    const stitchRingGeo = new THREE.TorusGeometry(2.45, 0.015, 12, 64);
    const stitchRing = new THREE.Mesh(stitchRingGeo, polishedGoldMat);
    stitchRing.rotation.x = Math.PI / 2;
    stitchRing.position.y = 1.1;
    tableGroup.add(stitchRing);

    // 6. Center Fluted Pedestal Column
    const pedestalGeo = new THREE.CylinderGeometry(0.45, 0.7, 0.9, 32);
    const pedestal = new THREE.Mesh(pedestalGeo, mahoganyMat);
    pedestal.position.y = 0.45;
    pedestal.castShadow = true;
    tableGroup.add(pedestal);

    // 7. Base Foot Stand
    const baseGeo = new THREE.CylinderGeometry(1.8, 2.0, 0.12, 32);
    const base = new THREE.Mesh(baseGeo, mahoganyMat);
    base.position.y = 0.06;
    base.receiveShadow = true;
    tableGroup.add(base);

    // 8. 4 Brass Claw Feet
    for (let c = 0; c < 4; c++) {
      const angle = (c * Math.PI) / 2;
      const clawGeo = new THREE.BoxGeometry(0.3, 0.14, 0.45);
      const claw = new THREE.Mesh(clawGeo, antiqueBrassMat);
      claw.position.set(Math.cos(angle) * 1.9, 0.06, Math.sin(angle) * 1.9);
      claw.rotation.y = -angle;
      claw.castShadow = true;
      tableGroup.add(claw);
    }

    worldGroup.add(tableGroup);

    // C. VINTAGE BANKER'S DESK LAMP (Composite 6 parts)
    const lampGroup = new THREE.Group();
    lampGroup.position.set(-1.8, 1.1, -0.6);

    // Stepped Brass Base
    const lampBaseGeo = new THREE.CylinderGeometry(0.32, 0.36, 0.08, 24);
    const lampBase = new THREE.Mesh(lampBaseGeo, antiqueBrassMat);
    lampBase.castShadow = true;
    lampGroup.add(lampBase);

    // Lamp Vertical Stem
    const stemGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.75, 16);
    const stem = new THREE.Mesh(stemGeo, antiqueBrassMat);
    stem.position.y = 0.42;
    lampGroup.add(stem);

    // Gooseneck Curved Top Arm
    const gooseGeo = new THREE.CylinderGeometry(0.035, 0.035, 0.45, 16);
    const goose = new THREE.Mesh(gooseGeo, antiqueBrassMat);
    goose.position.set(0.16, 0.85, 0);
    goose.rotation.z = -Math.PI / 4;
    lampGroup.add(goose);

    // Classic Emerald Green Glass Banker Hood Shade
    const shadeGeo = new THREE.CylinderGeometry(0.18, 0.32, 0.52, 24, 1, false, 0, Math.PI);
    const emeraldGlassMat = new THREE.MeshStandardMaterial({
      color: 0x0f4229,
      roughness: 0.2,
      metalness: 0.3,
      side: THREE.DoubleSide,
    });
    const shade = new THREE.Mesh(shadeGeo, emeraldGlassMat);
    shade.position.set(0.35, 0.95, 0);
    shade.rotation.x = Math.PI / 2;
    shade.rotation.z = -Math.PI / 2.5;
    shade.castShadow = true;
    lampGroup.add(shade);

    // Glowing Filament Bulb inside shade
    const bulbGeo = new THREE.SphereGeometry(0.09, 16, 16);
    const bulbMat = new THREE.MeshBasicMaterial({ color: 0xffe6a3 });
    const bulb = new THREE.Mesh(bulbGeo, bulbMat);
    bulb.position.set(0.35, 0.95, 0);
    lampGroup.add(bulb);

    // Brass Pull-Chain Switch with bead
    const chainGeo = new THREE.CylinderGeometry(0.008, 0.008, 0.35, 8);
    const chain = new THREE.Mesh(chainGeo, polishedGoldMat);
    chain.position.set(0.32, 0.75, 0.1);
    lampGroup.add(chain);

    const beadGeo = new THREE.SphereGeometry(0.025, 8, 8);
    const bead = new THREE.Mesh(beadGeo, polishedGoldMat);
    bead.position.set(0.32, 0.56, 0.1);
    lampGroup.add(bead);

    worldGroup.add(lampGroup);

    // D. CRYSTAL WHISKEY GLASS & AMBER BOURBON (Composite 3 parts)
    const glassGroup = new THREE.Group();
    glassGroup.position.set(-1.4, 1.1, 0.9);

    // Faceted Lowball Glass Tumbler
    const tumblerGeo = new THREE.CylinderGeometry(0.22, 0.18, 0.42, 12, 1, true);
    const tumbler = new THREE.Mesh(tumblerGeo, crystalGlassMat);
    tumbler.position.y = 0.21;
    tumbler.castShadow = true;
    glassGroup.add(tumbler);

    // Thick Crystal Base
    const glassBaseGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.08, 12);
    const glassBase = new THREE.Mesh(glassBaseGeo, crystalGlassMat);
    glassBase.position.y = 0.04;
    glassGroup.add(glassBase);

    // Amber Whiskey Liquid inside
    const whiskeyGeo = new THREE.CylinderGeometry(0.19, 0.17, 0.22, 12);
    const whiskey = new THREE.Mesh(whiskeyGeo, amberGlassMat);
    whiskey.position.y = 0.15;
    glassGroup.add(whiskey);

    // Two Crystal Ice Cubes
    const iceMat = new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.1, transparent: true, opacity: 0.6 });
    const ice1 = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.1), iceMat);
    ice1.position.set(0.04, 0.2, 0.02);
    ice1.rotation.set(0.3, 0.4, 0.1);
    glassGroup.add(ice1);

    const ice2 = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.09, 0.09), iceMat);
    ice2.position.set(-0.04, 0.22, -0.03);
    ice2.rotation.set(-0.2, 0.5, 0.3);
    glassGroup.add(ice2);

    worldGroup.add(glassGroup);

    // E. CRYSTAL ASHTRAY & SMOKING HAVANA CIGAR (Composite 4 parts)
    const ashtrayGroup = new THREE.Group();
    ashtrayGroup.position.set(-0.7, 1.1, 1.3);

    // Glass Ashtray
    const ashtrayGeo = new THREE.CylinderGeometry(0.34, 0.3, 0.1, 16);
    const ashtray = new THREE.Mesh(ashtrayGeo, crystalGlassMat);
    ashtray.position.y = 0.05;
    ashtray.castShadow = true;
    ashtrayGroup.add(ashtray);

    // Havana Cigar
    const cigarMat = new THREE.MeshStandardMaterial({ color: 0x4a2e1b, roughness: 0.8 });
    const cigarGeo = new THREE.CylinderGeometry(0.03, 0.032, 0.45, 12);
    const cigar = new THREE.Mesh(cigarGeo, cigarMat);
    cigar.rotation.x = Math.PI / 2;
    cigar.rotation.z = Math.PI / 5;
    cigar.position.set(0.05, 0.08, 0);
    cigar.castShadow = true;
    ashtrayGroup.add(cigar);

    // Gold Cigar Band Ring
    const bandGeo = new THREE.CylinderGeometry(0.033, 0.033, 0.05, 12);
    const band = new THREE.Mesh(bandGeo, polishedGoldMat);
    band.rotation.x = Math.PI / 2;
    band.rotation.z = Math.PI / 5;
    band.position.set(0.12, 0.08, 0.1);
    ashtrayGroup.add(band);

    // Glowing Orange Ember Tip
    const emberGeo = new THREE.CylinderGeometry(0.028, 0.028, 0.02, 12);
    const emberMat = new THREE.MeshBasicMaterial({ color: 0xff3b00 });
    const ember = new THREE.Mesh(emberGeo, emberMat);
    ember.rotation.x = Math.PI / 2;
    ember.rotation.z = Math.PI / 5;
    ember.position.set(-0.06, 0.08, -0.15);
    ashtrayGroup.add(ember);

    worldGroup.add(ashtrayGroup);

    // F. STACKS OF BANKNOTES / MAFIA CASH BRIBE (Composite 3 stacks)
    const cashGroup = new THREE.Group();
    cashGroup.position.set(1.5, 1.1, 0.8);
    cashGroup.rotation.y = -Math.PI / 5;

    const stackGeo = new THREE.BoxGeometry(0.8, 0.12, 0.42);
    const cashMat = new THREE.MeshStandardMaterial({ map: cashTex, roughness: 0.6 });

    const stack1 = new THREE.Mesh(stackGeo, cashMat);
    stack1.position.y = 0.06;
    stack1.castShadow = true;
    cashGroup.add(stack1);

    const stack2 = new THREE.Mesh(stackGeo, cashMat);
    stack2.position.set(0.05, 0.18, 0.02);
    stack2.rotation.y = 0.15;
    stack2.castShadow = true;
    cashGroup.add(stack2);

    const stack3 = new THREE.Mesh(stackGeo, cashMat);
    stack3.position.set(-0.35, 0.06, 0.35);
    stack3.rotation.y = -0.35;
    stack3.castShadow = true;
    cashGroup.add(stack3);

    worldGroup.add(cashGroup);

    // G. CONFIDENTIAL CRIME DOSSIER & POLICE EVIDENCE FILES (Composite 5 parts)
    const dossierGroup = new THREE.Group();
    dossierGroup.position.set(0.4, 1.1, 0.2);
    dossierGroup.rotation.y = -Math.PI / 10;

    // Manila Folder Base
    const folderGeo = new THREE.BoxGeometry(1.2, 0.025, 1.5);
    const folderMat = new THREE.MeshStandardMaterial({ color: 0xd9b382, roughness: 0.7 });
    const folder = new THREE.Mesh(folderGeo, folderMat);
    folder.position.y = 0.012;
    folder.castShadow = true;
    folder.receiveShadow = true;
    dossierGroup.add(folder);

    // Red Confidential Stamp Ribbon
    const stampGeo = new THREE.BoxGeometry(0.5, 0.03, 0.14);
    const stampMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.4 });
    const stamp = new THREE.Mesh(stampGeo, stampMat);
    stamp.position.set(0.1, 0.015, 0.3);
    dossierGroup.add(stamp);

    // Crime Scene Polaroid Photo clipped to folder
    const polaroidGeo = new THREE.BoxGeometry(0.45, 0.03, 0.55);
    const photoMat = new THREE.MeshStandardMaterial({ color: 0xf4eedd, roughness: 0.5 });
    const polaroid = new THREE.Mesh(polaroidGeo, photoMat);
    polaroid.position.set(-0.25, 0.028, -0.2);
    polaroid.rotation.y = 0.25;
    dossierGroup.add(polaroid);

    // Dark photo snapshot image
    const photoInnerGeo = new THREE.BoxGeometry(0.38, 0.032, 0.38);
    const photoInnerMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.3 });
    const photoInner = new THREE.Mesh(photoInnerGeo, photoInnerMat);
    photoInner.position.set(-0.25, 0.03, -0.23);
    photoInner.rotation.y = 0.25;
    dossierGroup.add(photoInner);

    // Gold Fountain Pen
    const penGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.65, 12);
    const penMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.2, metalness: 0.5 });
    const pen = new THREE.Mesh(penGeo, penMat);
    pen.rotation.z = Math.PI / 2;
    pen.rotation.y = 0.4;
    pen.position.set(0.4, 0.03, -0.1);
    pen.castShadow = true;
    dossierGroup.add(pen);

    const nibGeo = new THREE.ConeGeometry(0.02, 0.08, 12);
    const nib = new THREE.Mesh(nibGeo, polishedGoldMat);
    nib.rotation.z = -Math.PI / 2;
    nib.rotation.y = 0.4;
    nib.position.set(0.72, 0.03, 0.02);
    dossierGroup.add(nib);

    worldGroup.add(dossierGroup);

    // H. ANTIQUE GOLD POCKET WATCH WITH DIAL & CHAIN (Composite 4 parts)
    const watchGroup = new THREE.Group();
    watchGroup.position.set(0.8, 1.1, 1.25);
    watchGroup.rotation.y = 0.3;

    // Gold Casing
    const watchCaseGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.04, 24);
    const watchCase = new THREE.Mesh(watchCaseGeo, polishedGoldMat);
    watchCase.position.y = 0.02;
    watchCase.castShadow = true;
    watchGroup.add(watchCase);

    // Dial Face
    const dialGeo = new THREE.CylinderGeometry(0.155, 0.155, 0.042, 24);
    const dialMat = new THREE.MeshStandardMaterial({ map: watchTex, roughness: 0.3 });
    const dial = new THREE.Mesh(dialGeo, dialMat);
    dial.position.y = 0.022;
    watchGroup.add(dial);

    // Glass Crystal Dome
    const glassDomeGeo = new THREE.SphereGeometry(0.16, 16, 8, 0, Math.PI * 2, 0, Math.PI / 3);
    const glassDome = new THREE.Mesh(glassDomeGeo, crystalGlassMat);
    glassDome.position.y = 0.015;
    watchGroup.add(glassDome);

    // Top Winding Crown & Loop
    const crownGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.06, 12);
    const crown = new THREE.Mesh(crownGeo, polishedGoldMat);
    crown.rotation.x = Math.PI / 2;
    crown.position.set(0, 0.02, -0.21);
    watchGroup.add(crown);

    worldGroup.add(watchGroup);

    // I. UPGRADED REVOLVER & BRASS BULLETS (Composite 6 parts)
    const revolverGroup = new THREE.Group();
    revolverGroup.position.set(1.4, 1.1, -0.8);
    revolverGroup.rotation.y = -Math.PI / 3.2;

    // Barrel
    const barrelGeo = new THREE.CylinderGeometry(0.045, 0.045, 0.72, 16);
    const barrel = new THREE.Mesh(barrelGeo, bluedSteelMat);
    barrel.rotation.z = Math.PI / 2;
    barrel.position.set(0.35, 0.06, 0);
    barrel.castShadow = true;
    revolverGroup.add(barrel);

    // Fluted Cylinder
    const cylinderGeo = new THREE.CylinderGeometry(0.095, 0.095, 0.24, 18);
    const cylinder = new THREE.Mesh(cylinderGeo, bluedSteelMat);
    cylinder.rotation.z = Math.PI / 2;
    cylinder.position.set(0, 0.06, 0);
    cylinder.castShadow = true;
    revolverGroup.add(cylinder);

    // Hammer & Frame
    const frameGeo = new THREE.BoxGeometry(0.2, 0.14, 0.08);
    const frame = new THREE.Mesh(frameGeo, bluedSteelMat);
    frame.position.set(-0.12, 0.06, 0);
    frame.castShadow = true;
    revolverGroup.add(frame);

    // Checkered Walnut Grip
    const gripGeo = new THREE.BoxGeometry(0.13, 0.38, 0.08);
    const gripMat = new THREE.MeshStandardMaterial({ color: 0x3d2314, roughness: 0.5 });
    const grip = new THREE.Mesh(gripGeo, gripMat);
    grip.position.set(-0.24, -0.08, 0);
    grip.rotation.z = Math.PI / 5.5;
    grip.castShadow = true;
    revolverGroup.add(grip);

    // 3 Brass Cartridges standing and lying
    const bulletGeo = new THREE.CylinderGeometry(0.025, 0.025, 0.14, 12);
    const bullet1 = new THREE.Mesh(bulletGeo, antiqueBrassMat);
    bullet1.position.set(0.1, 0.07, 0.2);
    bullet1.castShadow = true;
    revolverGroup.add(bullet1);

    const bullet2 = new THREE.Mesh(bulletGeo, antiqueBrassMat);
    bullet2.position.set(0.2, 0.07, 0.25);
    bullet2.castShadow = true;
    revolverGroup.add(bullet2);

    const bullet3 = new THREE.Mesh(bulletGeo, antiqueBrassMat);
    bullet3.rotation.x = Math.PI / 2;
    bullet3.rotation.z = 0.5;
    bullet3.position.set(0.28, 0.025, 0.16);
    bullet3.castShadow = true;
    revolverGroup.add(bullet3);

    worldGroup.add(revolverGroup);

    // J. JUDGE'S GAVEL & SOUNDING BLOCK (Composite 4 parts)
    const gavelGroup = new THREE.Group();
    gavelGroup.position.set(-0.6, 1.1, 0.2);
    gavelGroup.rotation.y = Math.PI / 3.8;

    // Turned Gavel Head
    const headGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.48, 20);
    const head = new THREE.Mesh(headGeo, mahoganyMat);
    head.rotation.z = Math.PI / 2;
    head.position.y = 0.14;
    head.castShadow = true;
    gavelGroup.add(head);

    // Inlaid Brass Ring on Gavel Head
    const gavelRingGeo = new THREE.TorusGeometry(0.122, 0.015, 12, 24);
    const gavelRing = new THREE.Mesh(gavelRingGeo, antiqueBrassMat);
    gavelRing.rotation.y = Math.PI / 2;
    gavelRing.position.y = 0.14;
    gavelGroup.add(gavelRing);

    // Turned Handle
    const handleGeo = new THREE.CylinderGeometry(0.032, 0.045, 0.95, 16);
    const handle = new THREE.Mesh(handleGeo, mahoganyMat);
    handle.rotation.x = Math.PI / 2;
    handle.position.set(0, 0.14, 0.42);
    handle.castShadow = true;
    gavelGroup.add(handle);

    // Beveled Hexagonal Sounding Block
    const blockGeo = new THREE.CylinderGeometry(0.38, 0.42, 0.09, 6);
    const block = new THREE.Mesh(blockGeo, mahoganyMat);
    block.position.y = 0.045;
    block.castShadow = true;
    block.receiveShadow = true;
    gavelGroup.add(block);

    worldGroup.add(gavelGroup);

    // K. RETRO BAKELITE ROTARY DESK TELEPHONE (Composite 5 parts)
    const phoneGroup = new THREE.Group();
    phoneGroup.position.set(-1.8, 1.1, 1.5);
    phoneGroup.rotation.y = Math.PI / 4;

    const bakeliteMat = new THREE.MeshStandardMaterial({ color: 0x14161a, roughness: 0.18, metalness: 0.4 });

    // Phone Pyramidal Base
    const phoneBaseGeo = new THREE.CylinderGeometry(0.28, 0.42, 0.25, 4);
    const phoneBase = new THREE.Mesh(phoneBaseGeo, bakeliteMat);
    phoneBase.position.y = 0.125;
    phoneBase.rotation.y = Math.PI / 4;
    phoneBase.castShadow = true;
    phoneGroup.add(phoneBase);

    // Chrome Rotary Dial Face
    const dialFaceGeo = new THREE.CylinderGeometry(0.14, 0.14, 0.02, 20);
    const dialFace = new THREE.Mesh(dialFaceGeo, antiqueBrassMat);
    dialFace.position.set(0, 0.21, 0.18);
    dialFace.rotation.x = Math.PI / 3.5;
    phoneGroup.add(dialFace);

    // Chrome Cradle Prongs
    const cradleGeo = new THREE.BoxGeometry(0.32, 0.08, 0.08);
    const cradle = new THREE.Mesh(cradleGeo, antiqueBrassMat);
    cradle.position.set(0, 0.28, -0.05);
    phoneGroup.add(cradle);

    // Handset
    const handsetHandleGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.65, 12);
    const handsetHandle = new THREE.Mesh(handsetHandleGeo, bakeliteMat);
    handsetHandle.rotation.z = Math.PI / 2;
    handsetHandle.position.set(0, 0.35, -0.05);
    handsetHandle.castShadow = true;
    phoneGroup.add(handsetHandle);

    const earPieceGeo = new THREE.ConeGeometry(0.11, 0.12, 16);
    const ear1 = new THREE.Mesh(earPieceGeo, bakeliteMat);
    ear1.position.set(-0.32, 0.32, -0.05);
    ear1.rotation.z = Math.PI / 2;
    phoneGroup.add(ear1);

    const ear2 = new THREE.Mesh(earPieceGeo, bakeliteMat);
    ear2.position.set(0.32, 0.32, -0.05);
    ear2.rotation.z = -Math.PI / 2;
    phoneGroup.add(ear2);

    worldGroup.add(phoneGroup);

    // L. DOCTOR'S MEDICINE VIALS & AMBER SERUM (Composite 3 parts)
    const doctorGroup = new THREE.Group();
    doctorGroup.position.set(-1.0, 1.1, -1.3);

    const bottleGeo = new THREE.CylinderGeometry(0.13, 0.16, 0.45, 18);
    const bottle = new THREE.Mesh(bottleGeo, amberGlassMat);
    bottle.position.y = 0.225;
    bottle.castShadow = true;
    doctorGroup.add(bottle);

    // Cork Stopper
    const corkMat = new THREE.MeshStandardMaterial({ color: 0x8a6240, roughness: 0.9 });
    const corkGeo = new THREE.CylinderGeometry(0.08, 0.065, 0.1, 16);
    const cork = new THREE.Mesh(corkGeo, corkMat);
    cork.position.y = 0.48;
    doctorGroup.add(cork);

    // Glass Syringe lying beside vial
    const syringeGeo = new THREE.CylinderGeometry(0.035, 0.035, 0.45, 12);
    const syringe = new THREE.Mesh(syringeGeo, crystalGlassMat);
    syringe.rotation.x = Math.PI / 2;
    syringe.rotation.z = 0.4;
    syringe.position.set(0.24, 0.035, 0.1);
    syringe.castShadow = true;
    doctorGroup.add(syringe);

    worldGroup.add(doctorGroup);

    // =========================================================================
    // MOUSE PARALLAX & RESIZE LISTENERS
    // =========================================================================
    const handleMouseMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth) * 2 - 1;
      const y = -(e.clientY / window.innerHeight) * 2 + 1;
      mousePos.current = { x: x * 0.4, y: y * 0.2 };
    };
    window.addEventListener('mousemove', handleMouseMove);

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // =========================================================================
    // RENDER ANIMATION LOOP
    // =========================================================================
    let animationFrameId: number;
    const clock = new THREE.Clock();

    const currentCamPos = camera.position.clone();
    const currentCamLook = new THREE.Vector3(0, 0.6, 0);

    const tick = () => {
      const delta = Math.min(clock.getDelta(), 0.05);
      const elapsed = clock.getElapsedTime();

      // Atmospheric camera sway + mouse parallax damping
      const swayX = Math.sin(elapsed * 0.3) * 0.2 + mousePos.current.x;
      const swayY = Math.cos(elapsed * 0.25) * 0.1 + mousePos.current.y;

      const damp = 1 - Math.exp(-3.5 * delta);
      currentCamPos.lerp(
        new THREE.Vector3(
          targetCamPos.current.x + swayX,
          targetCamPos.current.y + swayY,
          targetCamPos.current.z
        ),
        damp
      );
      camera.position.copy(currentCamPos);

      currentCamLook.lerp(targetCamLook.current, damp);
      camera.lookAt(currentCamLook);

      // Lamp flicker in night mode
      if (lampLightRef.current) {
        if (isNight) {
          lampLightRef.current.intensity = 4.8 + Math.sin(elapsed * 7) * 0.25 + (Math.random() - 0.5) * 0.15;
        } else {
          lampLightRef.current.intensity = 2.2;
        }
      }

      // Cigar ember pulse
      if (cigarEmberLightRef.current) {
        cigarEmberLightRef.current.intensity = 0.35 + Math.sin(elapsed * 3) * 0.2 + Math.random() * 0.1;
      }

      renderer.render(scene, camera);
      animationFrameId = requestAnimationFrame(tick);
    };

    tick();

    // Cleanup
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      woodTex.dispose();
      watchTex.dispose();
      cashTex.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Dynamic Lighting & Camera Choreography based on Game Phase & Day/Night
  useEffect(() => {
    if (!sceneRef.current || !cameraRef.current) return;

    if (isNight) {
      // Night mode: Dim, moody midnight fog, prominent warm banker lamp
      if (sceneRef.current.fog) {
        (sceneRef.current.fog as THREE.FogExp2).color.setHex(0x060814);
      }
      sceneRef.current.background = new THREE.Color(0x060814);

      if (ambientLightRef.current) {
        ambientLightRef.current.color.setHex(0x0a1020);
        ambientLightRef.current.intensity = 0.45;
      }
      if (keyLightRef.current) {
        keyLightRef.current.color.setHex(0x384c75);
        keyLightRef.current.intensity = 0.35; // Cool midnight moonlight
      }
      if (spotLightRef.current) {
        spotLightRef.current.intensity = 0;
      }

      // Camera: close-up dramatic angle on table dossier and gun
      targetCamPos.current.set(0.2, 4.3, 5.8);
      targetCamLook.current.set(0, 1.1, 0.2);
    } else if (phase === 'LYNCH_RESULT' || phase === 'VOTING') {
      // Lynch / Voting interrogation spotlight!
      if (sceneRef.current.fog) {
        (sceneRef.current.fog as THREE.FogExp2).color.setHex(0x120a0a);
      }
      sceneRef.current.background = new THREE.Color(0x120a0a);

      if (ambientLightRef.current) {
        ambientLightRef.current.color.setHex(0x221515);
        ambientLightRef.current.intensity = 0.55;
      }
      if (keyLightRef.current) {
        keyLightRef.current.color.setHex(0xaa3333);
        keyLightRef.current.intensity = 0.9;
      }
      if (spotLightRef.current) {
        spotLightRef.current.intensity = 5.2; // Dramatic red center spotlight on gavel
      }

      // Camera focuses right on the center gavel & evidence
      targetCamPos.current.set(-0.5, 3.8, 4.4);
      targetCamLook.current.set(-0.2, 1.1, 0.4);
    } else if (phase === 'GAME_OVER') {
      // Triumphant wide view
      if (sceneRef.current.fog) {
        (sceneRef.current.fog as THREE.FogExp2).color.setHex(0x15121c);
      }
      sceneRef.current.background = new THREE.Color(0x15121c);

      if (ambientLightRef.current) ambientLightRef.current.intensity = 1.1;
      if (keyLightRef.current) keyLightRef.current.intensity = 2.4;
      if (spotLightRef.current) spotLightRef.current.intensity = 0;

      targetCamPos.current.set(0, 5.8, 8.2);
      targetCamLook.current.set(0, 0.6, 0);
    } else {
      // Daytime (Discussion / Dawn / Setup): warm morning sunlight streaming through blinds
      if (sceneRef.current.fog) {
        (sceneRef.current.fog as THREE.FogExp2).color.setHex(0x171311);
      }
      sceneRef.current.background = new THREE.Color(0x171311);

      if (ambientLightRef.current) {
        ambientLightRef.current.color.setHex(0x403028);
        ambientLightRef.current.intensity = 1.15;
      }
      if (keyLightRef.current) {
        keyLightRef.current.color.setHex(0xffecc7);
        keyLightRef.current.intensity = 2.4; // Bright morning sun
      }
      if (spotLightRef.current) {
        spotLightRef.current.intensity = 0;
      }

      targetCamPos.current.set(0, 5.0, 7.0);
      targetCamLook.current.set(0, 0.6, 0);
    }
  }, [phase, isNight]);

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 w-full h-full pointer-events-none -z-10 overflow-hidden"
      aria-hidden="true"
    />
  );
};
