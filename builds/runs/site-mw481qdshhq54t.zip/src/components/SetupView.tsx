import React, { useState, useEffect } from 'react';
import { Users, Shield, Plus, Minus, Check, AlertTriangle, ArrowRight, ArrowLeft, Sparkles, Layers } from 'lucide-react';
import { Language, Player } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { getRecommendedDeck, generatePlayers, RoleDeckConfig } from '../utils/roleAllocator';
import { ROLES_POOL } from '../utils/rolesData';
import { Interactive3DRoleCard } from './Interactive3DRoleCard';
import { sound } from '../utils/sound';

interface SetupViewProps {
  lang: Language;
  onPlayersGenerated: (players: Player[]) => void;
  onCancel: () => void;
}

export const SetupView: React.FC<SetupViewProps> = ({
  lang,
  onPlayersGenerated,
  onCancel,
}) => {
  const t = useTranslation(lang);

  const [playerCount, setPlayerCount] = useState<number>(6);
  const [playerNames, setPlayerNames] = useState<string[]>([
    'خالد',
    'سارة',
    'عمر',
    'نورة',
    'فهد',
    'ريم',
  ]);

  const [isCustomDeck, setIsCustomDeck] = useState<boolean>(false);
  const [deckConfig, setDeckConfig] = useState<RoleDeckConfig>(getRecommendedDeck(6));

  // Sync playerNames and deckConfig when playerCount changes
  useEffect(() => {
    setPlayerNames((prev) => {
      const next = [...prev];
      if (next.length < playerCount) {
        for (let i = next.length; i < playerCount; i++) {
          next.push(lang === 'ar' ? `لاعب ${i + 1}` : `Player ${i + 1}`);
        }
      } else if (next.length > playerCount) {
        next.splice(playerCount);
      }
      return next;
    });

    if (!isCustomDeck) {
      setDeckConfig(getRecommendedDeck(playerCount));
    }
  }, [playerCount, isCustomDeck, lang]);

  const handleNameChange = (index: number, val: string) => {
    const updated = [...playerNames];
    updated[index] = val;
    setPlayerNames(updated);
  };

  const handleCustomRoleChange = (roleKey: keyof RoleDeckConfig, delta: number) => {
    const next = { ...deckConfig };
    const currentVal = next[roleKey];
    const newVal = Math.max(0, currentVal + delta);
    next[roleKey] = newVal;

    // Recalculate remaining villagers
    const specialTotal =
      next.godfatherCount +
      next.mafiaCount +
      next.silencerCount +
      next.doctorCount +
      next.detectiveCount +
      next.vigilanteCount +
      next.jesterCount;

    if (specialTotal > playerCount) return; // Prevent exceeding player count
    next.villagerCount = Math.max(0, playerCount - specialTotal);

    setDeckConfig(next);
  };

  const totalMafia = deckConfig.godfatherCount + deckConfig.mafiaCount + deckConfig.silencerCount;
  const totalTown = deckConfig.doctorCount + deckConfig.detectiveCount + deckConfig.vigilanteCount + deckConfig.villagerCount;
  const totalSpecial = totalMafia + totalTown + deckConfig.jesterCount;

  const specialCount =
    deckConfig.godfatherCount +
    deckConfig.mafiaCount +
    deckConfig.silencerCount +
    deckConfig.doctorCount +
    deckConfig.detectiveCount +
    deckConfig.vigilanteCount +
    deckConfig.jesterCount;
  const canAddMoreSpecial = specialCount < playerCount;

  const isInvalid = totalMafia === 0 || totalMafia >= totalTown || totalSpecial !== playerCount;

  const handleStartGame = () => {
    sound.playGavel();
    const players = generatePlayers(playerNames, deckConfig);
    onPlayersGenerated(players);
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-start p-4 sm:p-6 max-w-5xl lg:max-w-6xl mx-auto w-full relative z-10 overflow-y-auto">
      {/* Title */}
      <div className="text-center mb-6 space-y-1">
        <h2 className="text-2xl sm:text-3xl font-black font-cinzel text-white">
          {lang === 'ar' ? 'إعداد جلسة اللعب وتوزيع الأدوار' : 'Session Setup & Roster'}
        </h2>
        <p className="text-xs sm:text-sm text-stone-400">
          {lang === 'ar'
            ? 'حدد عدد المشاركين، أدخل الأسماء، واختر توزيعة الأدوار المناسبة لمجموعتكم'
            : 'Configure player count, participant names, and role distribution.'}
        </p>
      </div>

      <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Left Column: Player Count & Names */}
        <div className="space-y-5 p-5 rounded-2xl bg-black/60 border border-white/10 backdrop-blur-md">
          {/* Count Stepper */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-400" />
                {t.playersCount}
              </label>
              <span className="font-mono-num text-lg font-bold text-amber-400">
                {playerCount}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  sound.playCardFlip();
                  setPlayerCount((c) => Math.max(4, c - 1));
                }}
                disabled={playerCount <= 4}
                className="w-10 h-10 rounded-lg bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center text-white cursor-pointer font-bold"
              >
                <Minus className="w-4 h-4" />
              </button>

              <input
                type="range"
                min={4}
                max={16}
                value={playerCount}
                onChange={(e) => {
                  sound.playCardFlip();
                  setPlayerCount(Number(e.target.value));
                }}
                className="flex-1 accent-amber-500 cursor-pointer h-2 bg-white/10 rounded-lg"
              />

              <button
                onClick={() => {
                  sound.playCardFlip();
                  setPlayerCount((c) => Math.min(16, c + 1));
                }}
                disabled={playerCount >= 16}
                className="w-10 h-10 rounded-lg bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center text-white cursor-pointer font-bold"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Player Names Input List */}
          <div>
            <label className="block text-xs font-semibold text-stone-300 uppercase tracking-wider mb-2">
              {t.playerNames} ({playerNames.length})
            </label>
            <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
              {playerNames.map((name, index) => (
                <div key={index} className="flex items-center gap-2">
                  <span className="w-6 text-xs font-mono text-stone-400 text-center">
                    {index + 1}
                  </span>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => handleNameChange(index, e.target.value)}
                    placeholder={`${t.playerPlaceholder} ${index + 1}`}
                    maxLength={18}
                    className="flex-1 px-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-white text-sm focus:border-amber-400 focus:outline-none transition-colors"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Roles Distribution & Balance */}
        <div className="space-y-5 p-5 rounded-2xl bg-black/60 border border-white/10 backdrop-blur-md flex flex-col justify-between">
          <div>
            {/* Mode Toggle: Preset vs Custom */}
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-white/10">
              <span className="text-sm font-bold text-white flex items-center gap-2">
                <Shield className="w-4 h-4 text-red-400" />
                {t.rolesDistribution}
              </span>

              <div className="flex items-center gap-1 p-1 bg-white/5 rounded-lg border border-white/10 text-xs">
                <button
                  onClick={() => {
                    sound.playCardFlip();
                    setIsCustomDeck(false);
                    setDeckConfig(getRecommendedDeck(playerCount));
                  }}
                  className={`px-2.5 py-1 rounded-md font-semibold transition-colors cursor-pointer ${
                    !isCustomDeck ? 'bg-amber-500 text-black shadow-sm' : 'text-stone-300 hover:text-white'
                  }`}
                >
                  {t.balancedGame}
                </button>
                <button
                  onClick={() => {
                    sound.playCardFlip();
                    setIsCustomDeck(true);
                  }}
                  className={`px-2.5 py-1 rounded-md font-semibold transition-colors cursor-pointer ${
                    isCustomDeck ? 'bg-amber-500 text-black shadow-sm' : 'text-stone-300 hover:text-white'
                  }`}
                >
                  {t.customGame}
                </button>
              </div>
            </div>

            {/* Interactive 3D Role Cards Grid */}
            <div className="space-y-2 mb-3">
              <div className="flex items-center justify-between text-xs text-amber-400 font-semibold px-1">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  {lang === 'ar' ? 'بطاقات الأدوار التفاعلية 3D' : 'Interactive 3D Role Cards'}
                </span>
                <span className="text-[11px] text-stone-400 font-mono">
                  {lang === 'ar' ? 'حرّك للإمالة · اقلب للملف 🔄' : 'Hover to tilt · Flip for dossier 🔄'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 max-h-[460px] overflow-y-auto p-1.5 rounded-2xl bg-black/40 border border-white/5">
                {/* 1. Godfather */}
                <Interactive3DRoleCard
                  role={ROLES_POOL.godfather}
                  count={deckConfig.godfatherCount}
                  lang={lang}
                  isCustomDeck={isCustomDeck}
                  onIncrement={() => handleCustomRoleChange('godfatherCount', 1)}
                  onDecrement={() => handleCustomRoleChange('godfatherCount', -1)}
                  canIncrement={canAddMoreSpecial}
                />

                {/* 2. Silencer (المصمّت) */}
                <Interactive3DRoleCard
                  role={ROLES_POOL.silencer}
                  count={deckConfig.silencerCount}
                  lang={lang}
                  isCustomDeck={isCustomDeck}
                  onIncrement={() => handleCustomRoleChange('silencerCount', 1)}
                  onDecrement={() => handleCustomRoleChange('silencerCount', -1)}
                  canIncrement={canAddMoreSpecial}
                />

                {/* 3. Mafia Members */}
                <Interactive3DRoleCard
                  role={ROLES_POOL.mafia}
                  count={deckConfig.mafiaCount}
                  lang={lang}
                  isCustomDeck={isCustomDeck}
                  onIncrement={() => handleCustomRoleChange('mafiaCount', 1)}
                  onDecrement={() => handleCustomRoleChange('mafiaCount', -1)}
                  canIncrement={canAddMoreSpecial}
                />

                {/* 4. Doctor */}
                <Interactive3DRoleCard
                  role={ROLES_POOL.doctor}
                  count={deckConfig.doctorCount}
                  lang={lang}
                  isCustomDeck={isCustomDeck}
                  onIncrement={() => handleCustomRoleChange('doctorCount', 1)}
                  onDecrement={() => handleCustomRoleChange('doctorCount', -1)}
                  canIncrement={canAddMoreSpecial}
                />

                {/* 5. Detective */}
                <Interactive3DRoleCard
                  role={ROLES_POOL.detective}
                  count={deckConfig.detectiveCount}
                  lang={lang}
                  isCustomDeck={isCustomDeck}
                  onIncrement={() => handleCustomRoleChange('detectiveCount', 1)}
                  onDecrement={() => handleCustomRoleChange('detectiveCount', -1)}
                  canIncrement={canAddMoreSpecial}
                />

                {/* 6. Vigilante */}
                <Interactive3DRoleCard
                  role={ROLES_POOL.vigilante}
                  count={deckConfig.vigilanteCount}
                  lang={lang}
                  isCustomDeck={isCustomDeck}
                  onIncrement={() => handleCustomRoleChange('vigilanteCount', 1)}
                  onDecrement={() => handleCustomRoleChange('vigilanteCount', -1)}
                  canIncrement={canAddMoreSpecial}
                />

                {/* 7. Jester */}
                <Interactive3DRoleCard
                  role={ROLES_POOL.jester}
                  count={deckConfig.jesterCount}
                  lang={lang}
                  isCustomDeck={isCustomDeck}
                  onIncrement={() => handleCustomRoleChange('jesterCount', 1)}
                  onDecrement={() => handleCustomRoleChange('jesterCount', -1)}
                  canIncrement={canAddMoreSpecial}
                />

                {/* 8. Villager (Citizen) */}
                <Interactive3DRoleCard
                  role={ROLES_POOL.villager}
                  count={deckConfig.villagerCount}
                  lang={lang}
                  isCustomDeck={isCustomDeck}
                  onIncrement={() => {}}
                  onDecrement={() => {}}
                  canIncrement={false}
                />
              </div>
            </div>

            {/* Validation warning if unbalanced */}
            {isInvalid && (
              <div className="mt-3 p-2.5 rounded-lg bg-red-950/60 border border-red-800/60 flex items-center gap-2 text-xs text-red-300">
                <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
                <span>
                  {totalMafia === 0
                    ? lang === 'ar'
                      ? 'يجب وجود عضو مافيا واحد على الأقل!'
                      : 'Must have at least 1 Mafia member!'
                    : totalMafia >= totalTown
                    ? lang === 'ar'
                      ? 'عدد المافيا كبير جداً مقارنة بالصالحين!'
                      : 'Mafia count is too high compared to Town!'
                    : lang === 'ar'
                    ? 'مجموع الأدوار لا يطابق عدد اللاعبين!'
                    : 'Total roles do not match player count!'}
                </span>
              </div>
            )}
          </div>

          {/* Bottom Action Buttons */}
          <div className="flex items-center gap-3 pt-4 border-t border-white/10">
            <button
              onClick={() => {
                sound.playCardFlip();
                onCancel();
              }}
              className="py-3 px-5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              {t.back}
            </button>

            <button
              onClick={handleStartGame}
              disabled={isInvalid}
              className="flex-1 py-3 px-6 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer"
            >
              <span>{lang === 'ar' ? 'توزيع الأدوار بالسر' : 'Begin Secret Role Reveal'}</span>
              {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
