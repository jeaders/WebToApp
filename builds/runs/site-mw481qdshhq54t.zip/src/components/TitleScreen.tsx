import React, { useEffect } from 'react';
import { Play, BookOpen, ShieldAlert, Users, Award } from 'lucide-react';
import { Language } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { sound } from '../utils/sound';

interface TitleScreenProps {
  lang: Language;
  onStart: () => void;
  onOpenRules: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  lang,
  onStart,
  onOpenRules,
}) => {
  const t = useTranslation(lang);

  // Keyboard shortcut: Space or Enter to start
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        sound.playGavel();
        onStart();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onStart]);

  return (
    <div className="flex-1 flex flex-col items-center justify-between px-4 py-8 sm:py-12 max-w-4xl mx-auto w-full text-center relative z-10">
      {/* Top spacer to balance negative space */}
      <div className="h-4 sm:h-10" />

      {/* Hero Title Lockup */}
      <div className="space-y-4 max-w-2xl animate-fade-in">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-red-950/40 border border-red-800/40 text-red-400 text-xs sm:text-sm font-semibold tracking-wider mb-2">
          <ShieldAlert className="w-4 h-4 text-red-500" />
          <span>{lang === 'ar' ? 'جلسة لعب جماعي واقعية (Pass & Play)' : 'Local Party Social Deduction'}</span>
        </div>

        <h1 className="font-cinzel text-4xl sm:text-6xl md:text-7xl font-black tracking-tight text-[#f4eedd] drop-shadow-2xl">
          {lang === 'ar' ? (
            <span className="font-cairo font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-amber-200 to-red-400">
              مافيا: ليلة الخداع
            </span>
          ) : (
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-600 via-stone-200 to-red-500">
              MAFIA NOIR
            </span>
          )}
        </h1>

        <p className="text-sm sm:text-lg text-stone-300/90 max-w-xl mx-auto font-medium leading-relaxed">
          {t.appTagline}
        </p>

        <p className="text-xs sm:text-sm text-stone-400 max-w-md mx-auto">
          {lang === 'ar'
            ? 'سلم الهاتف بين أصدقائك، استكشف أدواركم السرية في الظلام، واكتشف الخونة نهاراً بالتصويت.'
            : 'Pass the device among friends, discover your clandestine night roles, and cross-examine suspects by daylight.'}
        </p>
      </div>

      {/* Feature Highlights Pills */}
      <div className="grid grid-cols-3 gap-2 sm:gap-4 max-w-lg w-full my-6 text-stone-300">
        <div className="p-3 rounded-xl bg-black/60 border border-white/10 flex flex-col items-center">
          <Users className="w-5 h-5 text-amber-400 mb-1" />
          <span className="text-xs font-semibold">{lang === 'ar' ? '4 - 16 لاعباً' : '4 - 16 Players'}</span>
          <span className="text-[10px] text-stone-400">{lang === 'ar' ? 'هاتف واحد' : '1 Device'}</span>
        </div>
        <div className="p-3 rounded-xl bg-black/60 border border-white/10 flex flex-col items-center">
          <ShieldAlert className="w-5 h-5 text-red-400 mb-1" />
          <span className="text-xs font-semibold">{lang === 'ar' ? '7 أدوار تكتيكية' : '7 Unique Roles'}</span>
          <span className="text-[10px] text-stone-400">{lang === 'ar' ? 'مافيا وطبيب ومحقق' : 'Doctor & Cop'}</span>
        </div>
        <div className="p-3 rounded-xl bg-black/60 border border-white/10 flex flex-col items-center">
          <Award className="w-5 h-5 text-emerald-400 mb-1" />
          <span className="text-xs font-semibold">{lang === 'ar' ? 'تقييم MVP' : 'MVP Scoring'}</span>
          <span className="text-[10px] text-stone-400">{lang === 'ar' ? 'أفضل لاعب' : 'Top Performer'}</span>
        </div>
      </div>

      {/* Action CTA Buttons */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3 w-full max-w-md">
        <button
          onClick={() => {
            sound.playGavel();
            onStart();
          }}
          className="w-full py-4 px-8 rounded-xl bg-gradient-to-r from-red-700 via-red-600 to-amber-700 hover:from-red-600 hover:to-amber-600 text-white font-bold text-base sm:text-lg shadow-xl shadow-red-950/60 border border-red-500/40 flex items-center justify-center gap-3 transition-all transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
        >
          <Play className="w-5 h-5 fill-current" />
          <span>{t.startGame}</span>
        </button>

        <button
          onClick={() => {
            sound.playCardFlip();
            onOpenRules();
          }}
          className="w-full sm:w-auto py-3.5 px-6 rounded-xl bg-black/60 hover:bg-white/10 border border-white/15 text-stone-200 hover:text-white font-semibold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <BookOpen className="w-4 h-4 text-amber-400" />
          <span>{t.howToPlay}</span>
        </button>
      </div>

      {/* Control Hint Footer */}
      <div className="mt-6 text-[11px] text-stone-400 tracking-wider">
        <span>{lang === 'ar' ? 'اضغط Enter أو المس للبدء · صوت Web Audio مدمج' : 'Press Space / Enter to Begin · Procedural Web Audio Synth'}</span>
      </div>
    </div>
  );
};
