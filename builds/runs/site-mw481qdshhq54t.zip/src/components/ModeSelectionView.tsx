import React from 'react';
import { Smartphone, Crown, Users, BookOpen, ArrowRight, ArrowLeft } from 'lucide-react';
import { Language, PlayMode } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { sound } from '../utils/sound';

interface ModeSelectionViewProps {
  lang: Language;
  onSelectMode: (mode: PlayMode) => void;
  onBack: () => void;
}

export const ModeSelectionView: React.FC<ModeSelectionViewProps> = ({
  lang,
  onSelectMode,
  onBack,
}) => {
  const t = useTranslation(lang);

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 max-w-3xl mx-auto w-full relative z-10 animate-fade-in">
      {/* Title */}
      <div className="text-center mb-8 space-y-2">
        <h2 className="text-3xl sm:text-4xl font-black font-cinzel text-white">
          {t.choosePlayMode}
        </h2>
        <p className="text-xs sm:text-sm text-stone-300 max-w-md mx-auto">
          {t.choosePlayModeDesc}
        </p>
      </div>

      {/* Two Mode Choice Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 w-full mb-8">
        {/* Card 1: Sequential Pass & Play (بدون حكم - تمرير بالترتيب) */}
        <button
          onClick={() => {
            sound.playGavel();
            onSelectMode('PASS_AND_PLAY');
          }}
          className="p-6 rounded-3xl bg-black/70 hover:bg-black/90 border border-amber-500/30 hover:border-amber-400 backdrop-blur-xl shadow-2xl flex flex-col justify-between text-left transition-all group cursor-pointer transform hover:-translate-y-1 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl group-hover:bg-amber-500/10 transition-colors pointer-events-none" />

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                <Smartphone className="w-7 h-7" />
              </div>
              <span className="text-[11px] font-bold px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                {t.modePassPlayBadge}
              </span>
            </div>

            <div>
              <h3 className="text-xl sm:text-2xl font-black text-white font-cinzel group-hover:text-amber-300 transition-colors mb-2">
                {t.modePassPlayTitle}
              </h3>
              <p className="text-xs sm:text-sm text-stone-300/90 leading-relaxed">
                {t.modePassPlayDesc}
              </p>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-amber-400 text-xs font-bold">
            <span>{lang === 'ar' ? 'اختيار هذا الوضع والمتابعة' : 'Select this mode & continue'}</span>
            {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
          </div>
        </button>

        {/* Card 2: Moderator / Narrator Mode (مع طرف حكم) */}
        <button
          onClick={() => {
            sound.playGavel();
            onSelectMode('MODERATOR');
          }}
          className="p-6 rounded-3xl bg-black/70 hover:bg-black/90 border border-red-500/30 hover:border-red-400 backdrop-blur-xl shadow-2xl flex flex-col justify-between text-left transition-all group cursor-pointer transform hover:-translate-y-1 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/5 rounded-full blur-2xl group-hover:bg-red-500/10 transition-colors pointer-events-none" />

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="w-14 h-14 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400 group-hover:scale-110 transition-transform">
                <Crown className="w-7 h-7" />
              </div>
              <span className="text-[11px] font-bold px-3 py-1 rounded-full bg-red-950/80 text-red-300 border border-red-700/60">
                {t.modeModeratorBadge}
              </span>
            </div>

            <div>
              <h3 className="text-xl sm:text-2xl font-black text-white font-cinzel group-hover:text-red-300 transition-colors mb-2">
                {t.modeModeratorTitle}
              </h3>
              <p className="text-xs sm:text-sm text-stone-300/90 leading-relaxed">
                {t.modeModeratorDesc}
              </p>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-red-400 text-xs font-bold">
            <span>{lang === 'ar' ? 'اختيار هذا الوضع والمتابعة' : 'Select this mode & continue'}</span>
            {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
          </div>
        </button>
      </div>

      {/* Back button */}
      <button
        onClick={() => {
          sound.playCardFlip();
          onBack();
        }}
        className="py-2.5 px-6 rounded-xl bg-white/10 hover:bg-white/20 text-stone-300 hover:text-white text-xs font-semibold transition-colors cursor-pointer"
      >
        {t.back}
      </button>
    </div>
  );
};
