import React, { useState, useEffect } from 'react';
import { Timer, Play, Pause, Plus, ShieldAlert, ArrowRight, ArrowLeft, MessageSquare, AlertTriangle, Vote, Clock, RefreshCw } from 'lucide-react';
import { Language, Player } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { sound } from '../utils/sound';

interface DiscussionTimerViewProps {
  lang: Language;
  players: Player[];
  dayNumber: number;
  onProceedToVoting: () => void;
}

export const DiscussionTimerView: React.FC<DiscussionTimerViewProps> = ({
  lang,
  players,
  dayNumber,
  onProceedToVoting,
}) => {
  const t = useTranslation(lang);

  const [timeLeft, setTimeLeft] = useState<number>(90); // 90 seconds debate by default
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [suspectIds, setSuspectIds] = useState<string[]>([]);
  const [isTimeUpModalOpen, setIsTimeUpModalOpen] = useState<boolean>(false);

  const alivePlayers = players.filter((p) => p.isAlive);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isRunning && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            // Timer expired!
            setIsRunning(false);
            setIsTimeUpModalOpen(true);
            sound.playGavel();
            return 0;
          }
          if (prev <= 11) {
            sound.playClockTick(true);
          } else if (prev % 15 === 0) {
            sound.playClockTick(false);
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isRunning, timeLeft]);

  const toggleSuspect = (playerId: string) => {
    sound.playCardFlip();
    setSuspectIds((prev) =>
      prev.includes(playerId) ? prev.filter((id) => id !== playerId) : [...prev, playerId]
    );
  };

  const handleExtendTime = (extraSeconds: number) => {
    sound.playCardFlip();
    setTimeLeft((prev) => prev + extraSeconds);
    setIsRunning(true);
    setIsTimeUpModalOpen(false);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-start p-4 sm:p-6 max-w-2xl mx-auto w-full relative z-10 overflow-y-auto">
      {/* Title */}
      <div className="text-center mb-4 space-y-1">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
          <MessageSquare className="w-4 h-4" />
          <span>{lang === 'ar' ? `نقاش اليوم ${dayNumber}` : `Day ${dayNumber} Debates`}</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black font-cinzel text-white">
          {t.discussionPhase}
        </h2>
        <p className="text-xs sm:text-sm text-stone-400 max-w-md mx-auto">
          {t.discussionDesc}
        </p>
      </div>

      {/* Timer HUD Display */}
      <div className="w-full p-6 rounded-3xl bg-black/70 border border-white/15 backdrop-blur-xl shadow-2xl flex flex-col items-center mb-6 relative overflow-hidden">
        {/* Subtle red alert ambient glow when 0 */}
        {timeLeft === 0 && (
          <div className="absolute inset-0 bg-red-950/30 pointer-events-none animate-pulse" />
        )}

        <div className="flex items-center gap-3 mb-2 text-stone-400 text-xs uppercase tracking-widest font-semibold">
          <Timer className="w-4 h-4 text-amber-400" />
          <span>{t.timeRemaining}</span>
        </div>

        <div
          className={`font-mono-num text-5xl sm:text-6xl font-black tracking-wider transition-colors my-2 ${
            timeLeft === 0
              ? 'text-red-500 animate-pulse'
              : timeLeft <= 15
              ? 'text-red-400 animate-pulse'
              : 'text-white'
          }`}
        >
          {formatTime(timeLeft)}
        </div>

        {/* Timer Controls */}
        <div className="flex items-center gap-2 mt-3 z-10">
          {timeLeft > 0 ? (
            <button
              onClick={() => {
                sound.playCardFlip();
                setIsRunning(!isRunning);
              }}
              className="py-2 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isRunning ? t.pauseTimer : t.resumeTimer}</span>
            </button>
          ) : (
            <button
              onClick={() => setIsTimeUpModalOpen(true)}
              className="py-2 px-4 rounded-xl bg-red-900/60 hover:bg-red-800/80 border border-red-500/50 text-red-200 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-lg animate-pulse"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
              <span>{lang === 'ar' ? 'خيارات انتهاء الوقت' : 'Time Up Decisions'}</span>
            </button>
          )}

          <button
            onClick={() => handleExtendTime(30)}
            className="py-2 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-amber-400 font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{t.addTime}</span>
          </button>
        </div>
      </div>

      {/* Living Players Accusation Grid */}
      <div className="w-full space-y-3 mb-6">
        <div className="flex items-center justify-between text-xs text-stone-300 font-semibold px-1">
          <span>{lang === 'ar' ? 'لوحة المشتبه بهم (انقر لتحديد من تشك به):' : 'Accusation Board (tap to flag suspects):'}</span>
          <span className="text-stone-400">
            {alivePlayers.length} {lang === 'ar' ? 'أحياء' : 'alive'}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {alivePlayers.map((player) => {
            const isSuspected = suspectIds.includes(player.id);

            return (
              <button
                key={player.id}
                onClick={() => toggleSuspect(player.id)}
                className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                  isSuspected
                    ? 'bg-red-950/80 border-red-500 text-white shadow-lg ring-1 ring-red-500'
                    : 'bg-black/50 border-white/10 text-stone-300 hover:border-white/30'
                }`}
              >
                <span className="font-semibold text-sm truncate">{player.name}</span>
                {isSuspected && <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom Main Proceed Button */}
      <button
        onClick={() => {
          sound.playGavel();
          onProceedToVoting();
        }}
        className="w-full py-4 px-8 rounded-2xl bg-gradient-to-r from-red-700 to-amber-600 hover:from-red-600 hover:to-amber-500 text-white font-bold text-base shadow-xl flex items-center justify-center gap-2 cursor-pointer transition-all"
      >
        <span>{t.startVoting}</span>
        {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
      </button>

      {/* ========================================================================= */}
      {/* TIME'S UP DECISION MODAL: Vote vs Extend Discussion                      */}
      {/* ========================================================================= */}
      {isTimeUpModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-lg bg-[#161722]/95 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl flex flex-col items-center text-center space-y-6">
            {/* Header Icon */}
            <div className="w-20 h-20 rounded-3xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-xl animate-pulse">
              <Clock className="w-10 h-10" />
            </div>

            {/* Title & Prompt */}
            <div className="space-y-2">
              <span className="text-xs font-mono font-bold uppercase tracking-widest text-red-400 bg-red-950/60 px-3 py-1 rounded-full border border-red-800/40">
                {lang === 'ar' ? 'انتهت المهلة الزمنية' : 'Timer Expired'}
              </span>
              <h3 className="text-2xl sm:text-3xl font-black font-cinzel text-white">
                {t.discussionTimeUpTitle}
              </h3>
              <p className="text-xs sm:text-sm text-stone-300 max-w-sm mx-auto leading-relaxed">
                {t.discussionTimeUpPrompt}
              </p>
            </div>

            {/* Decision Branches */}
            <div className="w-full space-y-3 pt-2">
              {/* Branch 1: Proceed to Voting */}
              <button
                onClick={() => {
                  sound.playGavel();
                  setIsTimeUpModalOpen(false);
                  onProceedToVoting();
                }}
                className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-700 via-red-600 to-amber-700 hover:from-red-600 hover:to-amber-600 text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-xl border border-red-500/40 cursor-pointer transition-all transform hover:-translate-y-0.5"
              >
                <Vote className="w-5 h-5 text-amber-300" />
                <span>{t.proceedToVotingNow}</span>
                {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
              </button>

              {/* Branch 2: Extension Options */}
              <div className="pt-2 border-t border-white/10 space-y-2">
                <span className="text-xs font-semibold text-stone-400 block mb-1">
                  {lang === 'ar' ? 'أو تمديد وقت النقاش لمزيد من التحقيق:' : 'Or extend debate time for further inquiries:'}
                </span>

                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => handleExtendTime(30)}
                    className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-stone-200 hover:text-white font-bold text-xs flex flex-col items-center justify-center gap-1 transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 text-amber-400" />
                    <span>+30s</span>
                  </button>

                  <button
                    onClick={() => handleExtendTime(60)}
                    className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-stone-200 hover:text-white font-bold text-xs flex flex-col items-center justify-center gap-1 transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 text-amber-400" />
                    <span>+60s</span>
                  </button>

                  <button
                    onClick={() => handleExtendTime(120)}
                    className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-stone-200 hover:text-white font-bold text-xs flex flex-col items-center justify-center gap-1 transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 text-amber-400" />
                    <span>+120s</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
