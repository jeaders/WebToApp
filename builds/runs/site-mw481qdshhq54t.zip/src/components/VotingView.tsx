import React, { useState } from 'react';
import { Vote, EyeOff, ShieldAlert, CheckCircle, ArrowRight, ArrowLeft, BarChart3, ListFilter } from 'lucide-react';
import { Language, Player } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { sound } from '../utils/sound';
import { DetectiveD3VoteChart, VoteDataPoint } from './DetectiveD3VoteChart';

interface VotingViewProps {
  lang: Language;
  alivePlayers: Player[];
  onVotingComplete: (votesMap: Record<string, string>) => void;
}

export const VotingView: React.FC<VotingViewProps> = ({
  lang,
  alivePlayers,
  onVotingComplete,
}) => {
  const t = useTranslation(lang);

  const [currentVoterIndex, setCurrentVoterIndex] = useState<number>(0);
  const [isPrivacyUnlocked, setIsPrivacyUnlocked] = useState<boolean>(false);
  const [selectedTargetId, setSelectedTargetId] = useState<string | null>(null);
  const [votesMap, setVotesMap] = useState<Record<string, string>>({});
  const [viewMode, setViewMode] = useState<'BALLOT' | 'D3_CHART'>('BALLOT');

  const currentVoter = alivePlayers[currentVoterIndex];

  // Calculate real-time vote distribution data for D3 chart
  const getRealTimeVoteData = (): VoteDataPoint[] => {
    const tally: Record<string, number> = {};
    alivePlayers.forEach((p) => {
      tally[p.id] = 0;
    });

    Object.values(votesMap).forEach((targetId) => {
      if (tally[targetId] !== undefined) {
        tally[targetId] += 1;
      }
    });

    // If current voter has made a tentative selection, reflect in chart
    if (selectedTargetId && tally[selectedTargetId] !== undefined) {
      tally[selectedTargetId] += 1;
    }

    return alivePlayers.map((p) => ({
      id: p.id,
      name: p.name,
      votes: tally[p.id] || 0,
    }));
  };

  const chartData = getRealTimeVoteData();
  const totalVotesCast = Object.keys(votesMap).length + (selectedTargetId ? 1 : 0);

  const handleConfirmVote = () => {
    if (!selectedTargetId) return;

    sound.playCardFlip();
    const updatedVotes = {
      ...votesMap,
      [currentVoter.id]: selectedTargetId,
    };
    setVotesMap(updatedVotes);

    if (currentVoterIndex < alivePlayers.length - 1) {
      // Advance to next voter
      setCurrentVoterIndex((i) => i + 1);
      setSelectedTargetId(null);
      setIsPrivacyUnlocked(false);
      setViewMode('BALLOT');
    } else {
      // All votes cast!
      sound.playGavel();
      onVotingComplete(updatedVotes);
    }
  };

  // Privacy Curtain before each voter
  if (!isPrivacyUnlocked) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-4 max-w-lg mx-auto w-full relative z-10 animate-fade-in">
        <div className="w-full bg-[#151620]/95 border border-white/15 rounded-3xl p-8 backdrop-blur-xl shadow-2xl flex flex-col items-center text-center space-y-6">
          <div className="text-xs font-mono text-stone-400">
            {lang === 'ar' ? `المصوّت ${currentVoterIndex + 1} من ${alivePlayers.length}` : `Voter ${currentVoterIndex + 1} of ${alivePlayers.length}`}
          </div>

          <div className="w-20 h-20 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 animate-pulse">
            <EyeOff className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <p className="text-xs sm:text-sm text-stone-400 uppercase tracking-wider font-semibold">
              {t.passPhoneTo}
            </p>
            <h3 className="text-3xl sm:text-4xl font-black text-white font-cinzel">
              {currentVoter.name}
            </h3>
          </div>

          <div className="p-3 rounded-xl bg-red-950/40 border border-red-800/40 text-red-300 text-xs flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 shrink-0 text-red-400" />
            <span>{t.ensurePrivacy}</span>
          </div>

          <button
            onClick={() => {
              sound.playCardFlip();
              setIsPrivacyUnlocked(true);
            }}
            className="w-full py-3.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-sm transition-all cursor-pointer shadow-lg"
          >
            {lang === 'ar' ? 'أنا المصوّت، أدلِ بصوتي' : 'I am ready, cast my ballot'}
          </button>
        </div>
      </div>
    );
  }

  // Voting Booth Screen with D3 Real-Time Chart Integration
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 max-w-xl mx-auto w-full relative z-10 animate-fade-in">
      <div className="w-full bg-[#161722]/95 border border-white/15 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl flex flex-col justify-between min-h-[520px]">
        {/* Header & Tabs */}
        <div className="space-y-3 pb-3 border-b border-white/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold">
              <Vote className="w-4 h-4" />
              <span>{t.votingPhase}</span>
            </div>
            <span className="text-xs font-mono text-stone-400">
              {currentVoterIndex + 1} / {alivePlayers.length}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs text-stone-300 font-semibold">{t.voterTurn}</span>
              <span className="text-base font-bold text-white">{currentVoter.name}</span>
            </div>

            {/* View Mode Switcher: Ballot List vs D3 Chart */}
            <div className="flex items-center gap-1 p-1 bg-black/40 rounded-lg border border-white/10 text-xs">
              <button
                onClick={() => {
                  sound.playCardFlip();
                  setViewMode('BALLOT');
                }}
                className={`px-2.5 py-1 rounded-md font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                  viewMode === 'BALLOT' ? 'bg-amber-500 text-black shadow-sm' : 'text-stone-300 hover:text-white'
                }`}
                title={lang === 'ar' ? 'قائمة المرشحين' : 'Ballot list'}
              >
                <ListFilter className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{lang === 'ar' ? 'الاقتراع' : 'Ballot'}</span>
              </button>

              <button
                onClick={() => {
                  sound.playCardFlip();
                  setViewMode('D3_CHART');
                }}
                className={`px-2.5 py-1 rounded-md font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                  viewMode === 'D3_CHART' ? 'bg-red-600 text-white shadow-sm' : 'text-stone-300 hover:text-white'
                }`}
                title={lang === 'ar' ? 'مخطط D3 الجنائي' : 'D3 Forensic Chart'}
              >
                <BarChart3 className="w-3.5 h-3.5 text-amber-300" />
                <span>{lang === 'ar' ? 'مخطط D3' : 'D3 Chart'}</span>
              </button>
            </div>
          </div>

          <p className="text-xs text-stone-400">
            {viewMode === 'BALLOT'
              ? t.selectSuspect
              : lang === 'ar'
              ? 'توزيع الأصوات المباشر (تحليل D3 الجنائي):'
              : 'Real-time D3 Forensic Vote Distribution:'}
          </p>
        </div>

        {/* VIEW MODE 1: CANDIDATES BALLOT SELECTION */}
        {viewMode === 'BALLOT' ? (
          <div className="space-y-2 max-h-60 overflow-y-auto pr-1 my-3">
            {alivePlayers.map((candidate) => {
              if (candidate.id === currentVoter.id) return null; // Cannot vote for oneself

              const isSelected = selectedTargetId === candidate.id;

              return (
                <button
                  key={candidate.id}
                  onClick={() => {
                    sound.playCardFlip();
                    setSelectedTargetId(candidate.id);
                  }}
                  className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-red-950 border-red-500 text-white shadow-lg ring-1 ring-red-500'
                      : 'bg-black/40 border-white/10 text-stone-200 hover:border-white/30'
                  }`}
                >
                  <span className="font-semibold text-sm">{candidate.name}</span>
                  {isSelected && <CheckCircle className="w-5 h-5 text-red-500" />}
                </button>
              );
            })}
          </div>
        ) : (
          /* VIEW MODE 2: D3 REAL-TIME HORIZONTAL BAR CHART */
          <div className="my-2 animate-fade-in">
            <DetectiveD3VoteChart
              data={chartData}
              totalVotesCast={totalVotesCast}
              totalVoters={alivePlayers.length}
              lang={lang}
            />
          </div>
        )}

        {/* Selected suspect reminder when in D3 view */}
        {viewMode === 'D3_CHART' && (
          <div className="p-2 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between text-xs mb-3">
            <span className="text-stone-300">
              {lang === 'ar' ? 'صوتك الحالي موجه إلى:' : 'Your current vote target:'}
            </span>
            <span className="font-bold text-amber-400">
              {selectedTargetId
                ? alivePlayers.find((p) => p.id === selectedTargetId)?.name
                : lang === 'ar'
                ? 'لم تختر مرشحاً بعد'
                : 'None selected yet'}
            </span>
          </div>
        )}

        {/* Submit Vote Button */}
        <button
          onClick={handleConfirmVote}
          disabled={!selectedTargetId}
          className={`w-full py-4 px-6 rounded-2xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xl ${
            selectedTargetId
              ? 'bg-red-600 hover:bg-red-500 text-white'
              : 'bg-white/10 text-white/30 cursor-not-allowed'
          }`}
        >
          <span>
            {currentVoterIndex < alivePlayers.length - 1
              ? t.submitVoteNext
              : t.finishVoting}
          </span>
          {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
};
