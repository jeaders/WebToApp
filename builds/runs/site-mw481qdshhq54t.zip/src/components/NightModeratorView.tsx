import React, { useState } from 'react';
import { Crown, Moon, Crosshair, ShieldPlus, Search, Target, Check, ArrowRight, ArrowLeft, Sun, Volume2 } from 'lucide-react';
import { Language, Player, NightDecisions } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { sound } from '../utils/sound';

interface NightModeratorViewProps {
  lang: Language;
  players: Player[];
  dayNumber: number;
  onDecisionsComplete: (decisions: NightDecisions) => void;
}

export const NightModeratorView: React.FC<NightModeratorViewProps> = ({
  lang,
  players,
  dayNumber,
  onDecisionsComplete,
}) => {
  const t = useTranslation(lang);

  const [step, setStep] = useState<'SLEEP' | 'MAFIA' | 'DOCTOR' | 'DETECTIVE' | 'VIGILANTE'>('SLEEP');

  const [mafiaTargetId, setMafiaTargetId] = useState<string | null>(null);
  const [doctorTargetId, setDoctorTargetId] = useState<string | null>(null);
  const [detectiveTargetId, setDetectiveTargetId] = useState<string | null>(null);
  const [detectiveResult, setDetectiveResult] = useState<{ targetName: string; isMafia: boolean } | null>(null);
  const [vigilanteTargetId, setVigilanteTargetId] = useState<string | null>(null);

  const alivePlayers = players.filter((p) => p.isAlive);
  const aliveMafia = alivePlayers.filter((p) => p.role.team === 'mafia');
  const aliveDoctor = alivePlayers.find((p) => p.role.type === 'doctor');
  const aliveDetective = alivePlayers.find((p) => p.role.type === 'detective');
  const aliveVigilante = alivePlayers.find((p) => p.role.type === 'vigilante');

  const handleInspect = (targetId: string) => {
    setDetectiveTargetId(targetId);
    const target = players.find((p) => p.id === targetId);
    if (!target) return;
    const isMafia = target.role.team === 'mafia' && target.role.type !== 'godfather';
    sound.playReveal(isMafia);
    setDetectiveResult({ targetName: target.name, isMafia });
  };

  const handleFinish = () => {
    sound.playGavel();
    onDecisionsComplete({
      mafiaTargetId,
      doctorTargetId,
      detectiveTargetId,
      detectiveResult,
      vigilanteTargetId,
    });
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 max-w-xl mx-auto w-full relative z-10 animate-fade-in">
      <div className="w-full bg-[#14151e]/95 border border-red-500/30 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl flex flex-col justify-between min-h-[500px]">
        {/* Moderator Badge Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-red-950/80 border border-red-700/60 text-red-400">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white font-cinzel">
                {t.moderatorScriptTitle}
              </h2>
              <span className="text-[11px] text-stone-400">
                {lang === 'ar' ? `إدارة الليلة ${dayNumber}` : `Night ${dayNumber} Management`}
              </span>
            </div>
          </div>

          <div className="text-xs font-mono px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-amber-400">
            {step === 'SLEEP'
              ? '1/5'
              : step === 'MAFIA'
              ? '2/5'
              : step === 'DOCTOR'
              ? '3/5'
              : step === 'DETECTIVE'
              ? '4/5'
              : '5/5'}
          </div>
        </div>

        {/* STEP 1: VILLAGE SLEEP */}
        {step === 'SLEEP' && (
          <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6 my-auto">
            <div className="w-20 h-20 rounded-3xl bg-indigo-950/40 border border-indigo-700/40 flex items-center justify-center text-indigo-400">
              <Moon className="w-10 h-10" />
            </div>

            <div className="p-4 rounded-2xl bg-black/60 border border-white/10 max-w-sm space-y-2">
              <div className="flex items-center justify-center gap-1.5 text-amber-400 text-xs font-bold uppercase">
                <Volume2 className="w-4 h-4" />
                <span>{lang === 'ar' ? 'ما تقوله للغرفة بصوتك:' : 'Read aloud to the room:'}</span>
              </div>
              <p className="text-sm sm:text-base text-white font-medium leading-relaxed">
                {t.moderatorStepVillageSleep}
              </p>
            </div>

            <button
              onClick={() => {
                sound.playHeartbeat();
                setStep('MAFIA');
              }}
              className="w-full py-4 px-6 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm sm:text-base transition-all shadow-xl flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{lang === 'ar' ? 'الجميع أغمض عينيه · استدعاء المافيا' : 'Everyone closed eyes · Call Mafia'}</span>
              {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            </button>
          </div>
        )}

        {/* STEP 2: MAFIA WAKE */}
        {step === 'MAFIA' && (
          <div className="space-y-4">
            <div className="p-3.5 rounded-xl bg-red-950/40 border border-red-800/40 space-y-1">
              <span className="text-xs text-amber-400 font-bold block flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5" />
                {lang === 'ar' ? 'اقرأ للغرفة:' : 'Announce to room:'}
              </span>
              <p className="text-xs sm:text-sm text-white font-medium">
                {t.moderatorStepMafia}
              </p>
            </div>

            <div className="text-xs text-stone-300">
              <span className="text-red-400 font-bold">
                {lang === 'ar' ? 'أعضاء المافيا الأحياء: ' : 'Living Mafia: '}
              </span>
              <span>{aliveMafia.map((m) => m.name).join(' · ')}</span>
            </div>

            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {alivePlayers.map((player) => {
                const isSelected = mafiaTargetId === player.id;
                return (
                  <button
                    key={player.id}
                    onClick={() => {
                      sound.playCardFlip();
                      setMafiaTargetId(player.id);
                    }}
                    className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-red-950 border-red-500 text-white font-bold'
                        : 'bg-black/40 border-white/10 text-stone-200 hover:border-white/20'
                    }`}
                  >
                    <span>{player.name}</span>
                    {isSelected && <Check className="w-4 h-4 text-red-400" />}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => {
                sound.playCardFlip();
                if (aliveDoctor) setStep('DOCTOR');
                else if (aliveDetective) setStep('DETECTIVE');
                else if (aliveVigilante) setStep('VIGILANTE');
                else handleFinish();
              }}
              disabled={!mafiaTargetId}
              className="w-full py-3.5 px-6 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-30 text-white font-bold text-sm cursor-pointer shadow-lg mt-2"
            >
              {lang === 'ar' ? 'تأكيد ضحية المافيا والمتابعة' : 'Confirm Mafia victim & continue'}
            </button>
          </div>
        )}

        {/* STEP 3: DOCTOR WAKE */}
        {step === 'DOCTOR' && aliveDoctor && (
          <div className="space-y-4">
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40 space-y-1">
              <span className="text-xs text-amber-400 font-bold block flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5" />
                {lang === 'ar' ? 'اقرأ للغرفة:' : 'Announce to room:'}
              </span>
              <p className="text-xs sm:text-sm text-white font-medium">
                {t.moderatorStepDoctor}
              </p>
            </div>

            <div className="text-xs text-stone-300">
              <span className="text-emerald-400 font-bold">
                {lang === 'ar' ? 'الطبيب: ' : 'Doctor: '}
              </span>
              <span>{aliveDoctor.name}</span>
            </div>

            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {alivePlayers.map((player) => {
                const isSelected = doctorTargetId === player.id;
                return (
                  <button
                    key={player.id}
                    onClick={() => {
                      sound.playCardFlip();
                      setDoctorTargetId(player.id);
                    }}
                    className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-950 border-emerald-500 text-white font-bold'
                        : 'bg-black/40 border-white/10 text-stone-200 hover:border-white/20'
                    }`}
                  >
                    <span>{player.name}</span>
                    {isSelected && <Check className="w-4 h-4 text-emerald-400" />}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => {
                sound.playCardFlip();
                if (aliveDetective) setStep('DETECTIVE');
                else if (aliveVigilante) setStep('VIGILANTE');
                else handleFinish();
              }}
              disabled={!doctorTargetId}
              className="w-full py-3.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-30 text-white font-bold text-sm cursor-pointer shadow-lg mt-2"
            >
              {lang === 'ar' ? 'تأكيد حماية الطبيب والمتابعة' : 'Confirm Doctor protect & continue'}
            </button>
          </div>
        )}

        {/* STEP 4: DETECTIVE WAKE */}
        {step === 'DETECTIVE' && aliveDetective && (
          <div className="space-y-4">
            <div className="p-3.5 rounded-xl bg-blue-950/40 border border-blue-800/40 space-y-1">
              <span className="text-xs text-amber-400 font-bold block flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5" />
                {lang === 'ar' ? 'اقرأ للغرفة:' : 'Announce to room:'}
              </span>
              <p className="text-xs sm:text-sm text-white font-medium">
                {t.moderatorStepDetective}
              </p>
            </div>

            <div className="text-xs text-stone-300">
              <span className="text-blue-400 font-bold">
                {lang === 'ar' ? 'المحقق: ' : 'Detective: '}
              </span>
              <span>{aliveDetective.name}</span>
            </div>

            {!detectiveResult ? (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {alivePlayers.map((player) => {
                  if (player.id === aliveDetective.id) return null;
                  return (
                    <button
                      key={player.id}
                      onClick={() => handleInspect(player.id)}
                      className="w-full p-2.5 rounded-xl border bg-black/40 border-white/10 text-stone-200 hover:border-blue-400/60 text-left flex items-center justify-between cursor-pointer"
                    >
                      <span>{player.name}</span>
                      <Search className="w-4 h-4 text-blue-400" />
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-black/70 border border-white/15 text-center space-y-2">
                <span className="text-xs text-stone-400 block">
                  {lang === 'ar' ? 'النتيجة (أشر للمحقق بإبهام لأعلى إن كان صالحاً أو لأسفل إن كان مافيا):' : 'Secret signal (thumbs up clean / thumbs down mafia):'}
                </span>
                <h4 className="text-xl font-bold text-white">{detectiveResult.targetName}</h4>
                <div
                  className={`py-2 px-3 rounded-lg font-bold text-sm ${
                    detectiveResult.isMafia
                      ? 'bg-red-950 text-red-400 border border-red-700'
                      : 'bg-emerald-950 text-emerald-400 border border-emerald-700'
                  }`}
                >
                  {detectiveResult.isMafia ? t.detectiveResultMafia : t.detectiveResultClean}
                </div>
              </div>
            )}

            {detectiveResult && (
              <button
                onClick={() => {
                  sound.playCardFlip();
                  if (aliveVigilante) setStep('VIGILANTE');
                  else handleFinish();
                }}
                className="w-full py-3.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm cursor-pointer shadow-lg mt-2"
              >
                {lang === 'ar' ? 'أرسلت الإشارة للمحقق · متابعة' : 'Signaled Detective · Continue'}
              </button>
            )}
          </div>
        )}

        {/* STEP 5: VIGILANTE */}
        {step === 'VIGILANTE' && aliveVigilante && (
          <div className="space-y-4">
            <div className="p-3.5 rounded-xl bg-purple-950/40 border border-purple-800/40 space-y-1">
              <span className="text-xs text-amber-400 font-bold block flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5" />
                {lang === 'ar' ? 'اقرأ للغرفة:' : 'Announce to room:'}
              </span>
              <p className="text-xs sm:text-sm text-white font-medium">
                {t.moderatorStepVigilante}
              </p>
            </div>

            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {alivePlayers.map((player) => {
                if (player.id === aliveVigilante.id) return null;
                const isSelected = vigilanteTargetId === player.id;
                return (
                  <button
                    key={player.id}
                    onClick={() => {
                      sound.playCardFlip();
                      setVigilanteTargetId(player.id);
                    }}
                    className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-purple-950 border-purple-500 text-white font-bold'
                        : 'bg-black/40 border-white/10 text-stone-200 hover:border-white/20'
                    }`}
                  >
                    <span>{player.name}</span>
                    {isSelected && <Target className="w-4 h-4 text-purple-400" />}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center gap-2 mt-2">
              <button
                onClick={() => {
                  setVigilanteTargetId(null);
                  handleFinish();
                }}
                className="w-1/2 py-3 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs cursor-pointer"
              >
                {lang === 'ar' ? 'لم يطلق رصاصته' : 'No shot fired'}
              </button>
              <button
                onClick={() => {
                  sound.playGunshot();
                  handleFinish();
                }}
                disabled={!vigilanteTargetId}
                className="w-1/2 py-3 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-30 text-white font-bold text-xs cursor-pointer shadow-lg"
              >
                {lang === 'ar' ? 'تأكيد إطلاق النار' : 'Confirm shot'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
