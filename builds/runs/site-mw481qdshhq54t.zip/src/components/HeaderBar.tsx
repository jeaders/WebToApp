import React from 'react';
import { Volume2, VolumeX, Globe, BookOpen, RotateCcw } from 'lucide-react';
import { Language, GamePhase, PlayMode } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { sound } from '../utils/sound';

interface HeaderBarProps {
  lang: Language;
  onToggleLang: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenRules: () => void;
  onResetGame: () => void;
  phase: GamePhase;
  dayNumber: number;
  playMode?: PlayMode;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  lang,
  onToggleLang,
  isMuted,
  onToggleMute,
  onOpenRules,
  onResetGame,
  phase,
  dayNumber,
  playMode = 'PASS_AND_PLAY',
}) => {
  const t = useTranslation(lang);

  const getPhaseBadge = () => {
    if (phase === 'TITLE' || phase === 'MODE_SELECT' || phase === 'GAME_OVER') return null;
    const isNightPhase = phase.startsWith('NIGHT');
    return (
      <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-black/60 border border-white/10 text-xs tracking-wider">
        <span
          className={`inline-block w-2 h-2 rounded-full ${
            isNightPhase ? 'bg-indigo-400 animate-pulse' : 'bg-amber-400'
          }`}
        />
        <span className="font-semibold text-white/90">
          {lang === 'ar' ? `اليوم ${dayNumber}` : `Day ${dayNumber}`}
        </span>
        <span className="text-white/40">·</span>
        <span className="text-white/70">
          {playMode === 'PASS_AND_PLAY'
            ? lang === 'ar'
              ? 'تمرير بالترتيب'
              : 'Pass & Play'
            : lang === 'ar'
            ? 'وضع الحَكَم'
            : 'Moderator'}
        </span>
      </div>
    );
  };

  return (
    <header className="relative z-20 flex items-center justify-between w-full px-4 py-3 sm:px-6 bg-gradient-to-b from-black/80 via-black/40 to-transparent pointer-events-auto">
      {/* Brand lockup */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => {
            sound.playGavel();
            onResetGame();
          }}
          className="flex items-center gap-2 text-left group focus:outline-none"
          title={t.home}
        >
          <div className="w-8 h-8 rounded-lg bg-red-950/80 border border-red-700/60 flex items-center justify-center text-red-500 font-cinzel font-bold text-sm shadow-md group-hover:border-red-500 transition-colors">
            M
          </div>
          <div>
            <h1 className="font-cinzel text-sm sm:text-base font-bold tracking-widest text-[#f4eedd] group-hover:text-red-400 transition-colors">
              {lang === 'ar' ? 'مافيا: ليلة الخداع' : 'MAFIA NOIR'}
            </h1>
          </div>
        </button>

        {getPhaseBadge()}
      </div>

      {/* Control buttons dock */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Rules button */}
        <button
          onClick={() => {
            sound.playCardFlip();
            onOpenRules();
          }}
          className="p-2 sm:px-3 sm:py-1.5 rounded-lg bg-black/50 hover:bg-white/10 border border-white/10 hover:border-white/25 text-white/80 hover:text-white transition-all flex items-center gap-1.5 text-xs font-medium cursor-pointer"
          title={t.howToPlay}
        >
          <BookOpen className="w-4 h-4 text-amber-400" />
          <span className="hidden sm:inline">{t.howToPlay}</span>
        </button>

        {/* Audio mute toggle */}
        <button
          onClick={onToggleMute}
          className={`p-2 rounded-lg border transition-all cursor-pointer ${
            isMuted
              ? 'bg-red-950/40 border-red-800/40 text-red-400 hover:bg-red-900/40'
              : 'bg-black/50 border-white/10 text-white/80 hover:bg-white/10 hover:text-white'
          }`}
          title={isMuted ? t.soundOff : t.soundOn}
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
        </button>

        {/* Language switch */}
        <button
          onClick={() => {
            sound.playCardFlip();
            onToggleLang();
          }}
          className="px-2.5 py-1.5 rounded-lg bg-black/50 hover:bg-white/10 border border-white/10 hover:border-white/25 text-white/90 hover:text-white transition-all flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
          title={t.switchLang}
        >
          <Globe className="w-3.5 h-3.5 text-blue-400" />
          <span>{t.switchLang}</span>
        </button>

        {/* Restart / Reset game if active */}
        {phase !== 'TITLE' && (
          <button
            onClick={() => {
              if (window.confirm(lang === 'ar' ? 'هل أنت متأكد من إعادة ضبط اللعبة والعودة للرئيسية؟' : 'Are you sure you want to quit to the title screen?')) {
                onResetGame();
              }
            }}
            className="p-2 rounded-lg bg-black/50 hover:bg-red-950/50 border border-white/10 hover:border-red-800/60 text-white/60 hover:text-red-400 transition-all cursor-pointer"
            title={t.reset}
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        )}
      </div>
    </header>
  );
};
