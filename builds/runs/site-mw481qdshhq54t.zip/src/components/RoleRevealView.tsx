import React, { useState } from 'react';
import { Shield, Eye, EyeOff, ShieldAlert, ArrowRight, ArrowLeft, Crown, ShieldPlus, Search, Target, UserCheck, Sparkles } from 'lucide-react';
import { Language, Player } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { sound } from '../utils/sound';

interface RoleRevealViewProps {
  lang: Language;
  players: Player[];
  onRevealComplete: () => void;
}

export const RoleRevealView: React.FC<RoleRevealViewProps> = ({
  lang,
  players,
  onRevealComplete,
}) => {
  const t = useTranslation(lang);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isRevealed, setIsRevealed] = useState<boolean>(false);

  const currentPlayer = players[currentIndex];

  const getRoleIcon = (type: string) => {
    switch (type) {
      case 'godfather':
        return <Crown className="w-12 h-12 text-red-500" />;
      case 'mafia':
        return <ShieldAlert className="w-12 h-12 text-red-400" />;
      case 'doctor':
        return <ShieldPlus className="w-12 h-12 text-emerald-400" />;
      case 'detective':
        return <Search className="w-12 h-12 text-blue-400" />;
      case 'vigilante':
        return <Target className="w-12 h-12 text-purple-400" />;
      case 'villager':
        return <UserCheck className="w-12 h-12 text-teal-400" />;
      case 'jester':
        return <Sparkles className="w-12 h-12 text-amber-400" />;
      default:
        return <UserCheck className="w-12 h-12 text-white" />;
    }
  };

  const handleNextStep = () => {
    if (!isRevealed) {
      // Reveal current role
      sound.playCardFlip();
      setIsRevealed(true);
    } else {
      // Hide card and advance to next player
      sound.playCardFlip();
      setIsRevealed(false);
      if (currentIndex < players.length - 1) {
        setCurrentIndex((i) => i + 1);
      } else {
        // All players revealed! Start first night
        sound.playHeartbeat();
        onRevealComplete();
      }
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 max-w-lg mx-auto w-full relative z-10">
      {/* Progress Counter */}
      <div className="text-center mb-4">
        <span className="text-xs sm:text-sm font-bold text-stone-400 tracking-wider">
          {t.playerNumber} {currentIndex + 1} {t.of} {players.length}
        </span>
        <div className="w-48 h-1 bg-white/10 rounded-full mt-2 mx-auto overflow-hidden">
          <div
            className="h-full bg-amber-500 transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / players.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Main Privacy Card */}
      <div className="w-full bg-[#16171f]/90 border border-white/15 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl flex flex-col items-center text-center transition-all min-h-[420px] justify-between">
        {!isRevealed ? (
          /* Privacy Curtain Screen */
          <div className="flex-1 flex flex-col items-center justify-center space-y-6 my-auto">
            <div className="w-20 h-20 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 animate-pulse">
              <EyeOff className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <p className="text-xs sm:text-sm text-stone-400 uppercase tracking-wider font-semibold">
                {t.passPhoneTo}
              </p>
              <h2 className="text-3xl sm:text-4xl font-black text-white font-cinzel">
                {currentPlayer.name}
              </h2>
            </div>

            <div className="p-3 rounded-xl bg-red-950/40 border border-red-800/40 text-red-300 text-xs sm:text-sm flex items-center gap-2 max-w-xs">
              <ShieldAlert className="w-4 h-4 shrink-0 text-red-400" />
              <span>{t.ensurePrivacy}</span>
            </div>
          </div>
        ) : (
          /* Secret Role Card Revealed */
          <div className="flex-1 flex flex-col items-center justify-center space-y-4 my-auto w-full animate-fade-in">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 shadow-inner">
              {getRoleIcon(currentPlayer.role.type)}
            </div>

            <div>
              <span className="text-xs text-stone-400 block mb-1">
                {currentPlayer.name}
              </span>
              <h2
                className="text-2xl sm:text-3xl font-black font-cinzel tracking-wide"
                style={{ color: currentPlayer.role.accentColor }}
              >
                {lang === 'ar' ? currentPlayer.role.nameAr : currentPlayer.role.nameEn}
              </h2>
            </div>

            {/* Faction Badge */}
            <span
              className={`text-xs font-bold px-3 py-1 rounded-full border ${
                currentPlayer.role.team === 'mafia'
                  ? 'bg-red-950/80 text-red-300 border-red-700/60'
                  : currentPlayer.role.team === 'neutral'
                  ? 'bg-amber-950/80 text-amber-300 border-amber-700/60'
                  : 'bg-emerald-950/80 text-emerald-300 border-emerald-700/60'
              }`}
            >
              {currentPlayer.role.team === 'mafia'
                ? t.mafiaTeam
                : currentPlayer.role.team === 'neutral'
                ? t.neutralTeam
                : t.townTeam}
            </span>

            {/* Description & Ability */}
            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed max-w-xs bg-black/40 p-3 rounded-xl border border-white/5">
              {lang === 'ar' ? currentPlayer.role.descriptionAr : currentPlayer.role.descriptionEn}
            </p>

            <div className="text-xs text-amber-400/90 font-medium">
              {lang === 'ar'
                ? `القدرة الليلية: ${currentPlayer.role.abilityAr}`
                : `Night Ability: ${currentPlayer.role.abilityEn}`}
            </div>
          </div>
        )}

        {/* Action Toggle Button */}
        <button
          onClick={handleNextStep}
          className={`w-full py-4 px-6 rounded-2xl font-bold text-base transition-all flex items-center justify-center gap-2 shadow-xl cursor-pointer mt-4 ${
            !isRevealed
              ? 'bg-amber-500 hover:bg-amber-400 text-black'
              : 'bg-stone-800 hover:bg-stone-700 text-white border border-white/20'
          }`}
        >
          {!isRevealed ? (
            <>
              <Eye className="w-5 h-5" />
              <span>{t.revealSecretRole}</span>
            </>
          ) : (
            <>
              <EyeOff className="w-5 h-5" />
              <span>
                {currentIndex < players.length - 1
                  ? t.hideAndPass
                  : lang === 'ar'
                  ? 'إخفاء وبدء الليلة الأولى'
                  : 'Hide & Begin Night 1'}
              </span>
              {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            </>
          )}
        </button>
      </div>
    </div>
  );
};
