import React, { useState, useEffect } from 'react';
import { Newspaper, ArrowRight, ArrowLeft, FastForward, Sun, AlertTriangle } from 'lucide-react';
import { Language, DawnResult, Player } from '../types/game';
import { sound } from '../utils/sound';

interface NoirDawnTransitionOverlayProps {
  lang: Language;
  dawnResult: DawnResult;
  players: Player[];
  dayNumber: number;
  onComplete: () => void;
}

export const NoirDawnTransitionOverlay: React.FC<NoirDawnTransitionOverlayProps> = ({
  lang,
  dawnResult,
  players,
  dayNumber,
  onComplete,
}) => {
  const [animationStage, setAnimationStage] = useState<'BLINDS' | 'SLAM' | 'READABLE'>('BLINDS');

  const killedPlayers = players.filter((p) => dawnResult.killedPlayerIds.includes(p.id));
  const savedPlayer = players.find((p) => p.id === dawnResult.savedPlayerId);

  useEffect(() => {
    // 1. Stage 1: Blinds opening & darkness
    const t1 = setTimeout(() => {
      sound.playNewspaperReveal();
      setAnimationStage('SLAM');
    }, 450);

    // 2. Stage 2: Newspaper settles
    const t2 = setTimeout(() => {
      setAnimationStage('READABLE');
    }, 1100);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  // Determine main newspaper headline
  const getHeadline = () => {
    if (killedPlayers.length > 0) {
      const names = killedPlayers.map((k) => k.name).join(' و ');
      const namesEn = killedPlayers.map((k) => k.name).join(' & ');
      return {
        kickerAr: 'طبعة خاصة عاجلة · جريمة منتصف الليل',
        kickerEn: 'SPECIAL EXTRA EDITION · MIDNIGHT CRIME',
        titleAr: `اغتيال في جنح الظلام: مقتل [${names}] في شوارع القرية!`,
        titleEn: `MURDER IN THE SHADOWS: [${namesEn}] STRUCK DOWN!`,
        leadAr: `استيقظ سكان القرية عند أول خيوط الفجر على نبأ مفزع بعد العثور على جثة في الأزقة المظلمة. تشير أصابع الاتهام إلى مؤامرة دبرتها يد المافيا في الخفاء.`,
        leadEn: `Citizens were awakened at the first crack of dawn by chilling news as another body was discovered in the rain-slicked alleyways. Authorities suspect underworld syndicate activity.`,
      };
    } else if (savedPlayer) {
      return {
        kickerAr: 'معجزة الفجر · إنقاذ بطولي',
        kickerEn: 'MIRACLE AT DAWN · HEROIC INTERVENTION',
        titleAr: `ترياق الحياة! الطبيب ينقذ [${savedPlayer.name}] من قبضة المافيا!`,
        titleEn: `DEATH DEFIED! DOCTOR SAVES [${savedPlayer.name}] FROM ASSASSINS!`,
        leadAr: `في تدخل طبي جريء وبطولي، نجح ترياق الطبيب السريع في إحباط محاولة اغتيال مؤكدة دبرت في الظلام، ليفيق الجميع سالمين مع تباشير الصباح.`,
        leadEn: `In a daring stroke of emergency medicine, the town physician administered a life-saving antidote, completely thwarting an underworld assassination contract.`,
      };
    } else {
      return {
        kickerAr: 'تقرير الصباح · هدوء استثنائي',
        kickerEn: 'MORNING BULLETIN · UNEASY CALM',
        titleAr: 'هدوء حذر في القرية: لا ضحايا سقطوا في عتمة الليل!',
        titleEn: 'UNEASY SILENCE: THE CITY SURVIVES THE NIGHT UNSCATHED!',
        leadAr: `انقشعت غيوم الليل البهيم دون تسجيل أي ضحية بين الأهالي، إلا أن التوتر ما زال يسود الأجواء وسط ترقب لما ستسفر عنه جلسة النقاش والمحاكمة النهارية.`,
        leadEn: `The midnight fog lifted without a single casualty reported. Yet an uneasy tension grips the streets as citizens prepare for the upcoming town council debate.`,
      };
    }
  };

  const headline = getHeadline();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-hidden select-none">
      {/* 1. Deep Film-Noir Heavy Vignette & Venetian Blinds Shadow Overlay */}
      <div
        className={`absolute inset-0 bg-black/85 transition-opacity duration-700 pointer-events-none ${
          animationStage === 'BLINDS' ? 'opacity-100' : 'opacity-90'
        }`}
        style={{
          backgroundImage: `
            radial-gradient(circle at 50% 50%, rgba(245, 175, 65, 0.08) 0%, rgba(0, 0, 0, 0.95) 85%),
            repeating-linear-gradient(0deg, transparent 0px, transparent 18px, rgba(0, 0, 0, 0.6) 19px, rgba(0, 0, 0, 0.6) 24px)
          `,
        }}
      />

      {/* 2. Skip Button Top Right */}
      <button
        onClick={() => {
          sound.playCardFlip();
          onComplete();
        }}
        className="absolute top-5 right-5 z-50 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 border border-white/15 text-stone-300 hover:text-white text-xs font-semibold backdrop-blur-md transition-all cursor-pointer"
      >
        <span>{lang === 'ar' ? 'تخطي' : 'Skip'}</span>
        <FastForward className="w-3.5 h-3.5" />
      </button>

      {/* 3. The 1930s Film-Noir Extra Spinning Newspaper */}
      <div
        className={`relative w-full max-w-xl transition-all duration-700 ease-out transform ${
          animationStage === 'BLINDS'
            ? 'scale-15 rotate-[-720deg] opacity-0'
            : animationStage === 'SLAM'
            ? 'scale-105 rotate-[-2deg] opacity-100 shadow-[0_35px_80px_rgba(0,0,0,0.95)]'
            : 'scale-100 rotate-[-0.5deg] opacity-100 shadow-[0_25px_60px_rgba(0,0,0,0.9)]'
        }`}
      >
        {/* Newspaper Paper Sheet */}
        <div className="relative bg-[#f4eedd] text-[#1b1715] p-5 sm:p-7 rounded-lg border-2 border-[#3d322b] shadow-2xl overflow-hidden font-serif">
          {/* Aged paper subtle texture lines */}
          <div
            className="absolute inset-0 pointer-events-none opacity-20 mix-blend-multiply"
            style={{
              backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(0,0,0,0.04) 4px)',
            }}
          />

          {/* Red Rubber Ink Stamp (Tilted on corner) */}
          <div className="absolute top-4 right-4 sm:top-5 sm:right-6 pointer-events-none transform rotate-[14deg] border-2 border-red-700/80 px-2.5 py-0.5 rounded text-[11px] font-mono font-black text-red-700/90 tracking-widest uppercase">
            {lang === 'ar' ? 'طبعة عاجلة ⚡' : 'SPECIAL EXTRA ⚡'}
          </div>

          {/* Newspaper Masthead */}
          <div className="text-center pb-2.5 mb-3 border-b-2 border-[#1b1715]">
            <div className="flex items-center justify-between text-[10px] font-mono uppercase tracking-widest text-stone-600 border-b border-stone-400/60 pb-1 mb-1.5">
              <span>{lang === 'ar' ? 'الصحيفة اليومية المستقلة' : 'The Independent Daily'}</span>
              <span>{lang === 'ar' ? `العدد #${dayNumber} · طبعة الفجر` : `Vol. XXXIV · Day ${dayNumber} Dawn`}</span>
              <span>{lang === 'ar' ? 'سعر النسخة: 5 قروش' : 'Price: Two Cents'}</span>
            </div>

            <h1 className="font-cinzel text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-[#1b1715]">
              {lang === 'ar' ? 'وقائع المدينة' : 'THE NOIR CHRONICLE'}
            </h1>
            <p className="text-[11px] tracking-widest uppercase font-mono text-stone-600 mt-0.5">
              {lang === 'ar' ? 'عين الحقيقة الساهرة على أسرار الليل' : 'Voice of the Village · Truth in Shadows'}
            </p>
          </div>

          {/* Kicker / Lead Headline */}
          <div className="space-y-2 mb-4">
            <span className="inline-block text-[11px] sm:text-xs font-mono font-bold tracking-wider uppercase text-red-800 bg-red-100/60 px-2 py-0.5 rounded">
              {lang === 'ar' ? headline.kickerAr : headline.kickerEn}
            </span>

            <h2 className="text-xl sm:text-2xl md:text-3xl font-black leading-tight text-[#110e0c] font-cinzel">
              {lang === 'ar' ? headline.titleAr : headline.titleEn}
            </h2>
          </div>

          {/* Double Rule Divider */}
          <div className="border-t-2 border-b border-[#1b1715] py-0.5 my-3" />

          {/* Two-Column Editorial Story */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs leading-relaxed text-[#2a2420]">
            <div className="sm:col-span-2">
              <p className="font-medium text-xs sm:text-sm first-letter:text-2xl first-letter:font-bold first-letter:float-left first-letter:mr-1">
                {lang === 'ar' ? headline.leadAr : headline.leadEn}
              </p>
            </div>

            {/* Side Column Alert Box */}
            <div className="p-2.5 rounded bg-[#e8e0cc] border border-[#cfc4ac] space-y-1 text-[11px]">
              <span className="font-bold text-stone-800 flex items-center gap-1 font-mono uppercase">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-700" />
                {lang === 'ar' ? 'بيان الشرطة:' : 'Police Alert:'}
              </span>
              <p className="text-stone-700 leading-snug">
                {lang === 'ar'
                  ? 'يُهيب العمدة بجميع الأهالي التجمع في الساحة المركزية للمناظرة والإدلاء بأصواتهم.'
                  : 'Town magistrates urge all citizens to convene at the town square for deliberation.'}
              </p>
            </div>
          </div>

          {/* Action / Continue CTA */}
          <div className="mt-5 pt-3 border-t-2 border-[#1b1715] flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-[11px] text-stone-600 font-mono">
              <Sun className="w-3.5 h-3.5 text-amber-600" />
              <span>{lang === 'ar' ? 'أشرقت الشمس على الساحة' : 'The dawn sun shines above'}</span>
            </div>

            <button
              onClick={() => {
                sound.playGavel();
                onComplete();
              }}
              className="py-2.5 px-5 rounded-lg bg-[#1b1715] hover:bg-[#3d322b] text-[#f4eedd] font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg transition-all cursor-pointer transform hover:scale-105"
            >
              <span>{lang === 'ar' ? 'قراءة التفاصيل والتقرير الكامل' : 'Examine Police Dispatch'}</span>
              {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
