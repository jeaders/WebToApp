import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { Language } from '../types/game';

export interface VoteDataPoint {
  id: string;
  name: string;
  votes: number;
}

interface DetectiveD3VoteChartProps {
  data: VoteDataPoint[];
  totalVotesCast: number;
  totalVoters: number;
  lang: Language;
}

export const DetectiveD3VoteChart: React.FC<DetectiveD3VoteChartProps> = ({
  data,
  totalVotesCast,
  totalVoters,
  lang,
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return;

    const containerWidth = containerRef.current.clientWidth || 360;
    const barHeight = 32;
    const margin = {
      top: 15,
      right: lang === 'ar' ? 80 : 50,
      bottom: 25,
      left: lang === 'ar' ? 50 : 80,
    };

    const height = data.length * (barHeight + 10) + margin.top + margin.bottom;
    const width = containerWidth;
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove(); // Clear previous render

    svg
      .attr('width', width)
      .attr('height', height)
      .attr('viewBox', `0 0 ${width} ${height}`)
      .attr('style', 'max-width: 100%; height: auto;');

    // Defs: Gradients and filters for Noir aesthetic
    const defs = svg.append('defs');

    // 1. Leader Bar Gradient (Blood Red to Amber)
    const leaderGrad = defs
      .append('linearGradient')
      .attr('id', 'noir-lead-grad')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '100%')
      .attr('y2', '0%');
    leaderGrad.append('stop').attr('offset', '0%').attr('stop-color', '#991b1b');
    leaderGrad.append('stop').attr('offset', '100%').attr('stop-color', '#dc2626');

    // 2. Normal Bar Gradient (Charcoal to Crimson)
    const normalGrad = defs
      .append('linearGradient')
      .attr('id', 'noir-normal-grad')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '100%')
      .attr('y2', '0%');
    normalGrad.append('stop').attr('offset', '0%').attr('stop-color', '#334155');
    normalGrad.append('stop').attr('offset', '100%').attr('stop-color', '#64748b');

    // 3. Subtle glow filter
    const filter = defs.append('filter').attr('id', 'noir-glow').attr('x', '-20%').attr('y', '-20%').attr('width', '140%').attr('height', '140%');
    filter.append('feGaussianBlur').attr('stdDeviation', '2').attr('result', 'blur');
    filter.append('feComposite').attr('in', 'SourceGraphic').attr('in2', 'blur').attr('operator', 'over');

    const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);

    // Max votes calculation
    const maxVotes = Math.max(1, d3.max(data, (d) => d.votes) || 1, Math.min(totalVoters, 4));

    // Scales
    const xScale = d3.scaleLinear().domain([0, maxVotes]).range([0, innerWidth]);

    const yScale = d3
      .scaleBand<string>()
      .domain(data.map((d) => d.id))
      .range([0, innerHeight])
      .padding(0.25);

    // Dashed Grid Lines
    const xTicks = xScale.ticks(Math.min(maxVotes, 6));
    g.append('g')
      .attr('class', 'grid')
      .selectAll('line')
      .data(xTicks)
      .enter()
      .append('line')
      .attr('x1', (d) => xScale(d))
      .attr('x2', (d) => xScale(d))
      .attr('y1', 0)
      .attr('y2', innerHeight)
      .attr('stroke', 'rgba(255, 255, 255, 0.08)')
      .attr('stroke-dasharray', '2 3');

    // Background track for each candidate (so 0-vote bars show the track)
    g.selectAll('.track-bar')
      .data(data)
      .enter()
      .append('rect')
      .attr('class', 'track-bar')
      .attr('y', (d) => yScale(d.id) || 0)
      .attr('x', 0)
      .attr('height', yScale.bandwidth())
      .attr('width', innerWidth)
      .attr('rx', 4)
      .attr('fill', 'rgba(255, 255, 255, 0.03)')
      .attr('stroke', 'rgba(255, 255, 255, 0.06)');

    // Animated Real-Time Vote Bars
    const maxVal = d3.max(data, (d) => d.votes) || 0;

    g.selectAll('.vote-bar')
      .data(data)
      .enter()
      .append('rect')
      .attr('class', 'vote-bar')
      .attr('y', (d) => yScale(d.id) || 0)
      .attr('x', 0)
      .attr('height', yScale.bandwidth())
      .attr('rx', 4)
      .attr('fill', (d) => (d.votes > 0 && d.votes === maxVal ? 'url(#noir-lead-grad)' : 'url(#noir-normal-grad)'))
      .attr('stroke', (d) => (d.votes > 0 && d.votes === maxVal ? '#ef4444' : 'rgba(255, 255, 255, 0.2)'))
      .attr('stroke-width', (d) => (d.votes > 0 && d.votes === maxVal ? 1.5 : 1))
      .attr('filter', (d) => (d.votes > 0 && d.votes === maxVal ? 'url(#noir-glow)' : null))
      .attr('width', 0)
      .transition()
      .duration(500)
      .ease(d3.easeCubicOut)
      .attr('width', (d) => Math.max(0, xScale(d.votes)));

    // Candidate Name Labels
    g.selectAll('.name-label')
      .data(data)
      .enter()
      .append('text')
      .attr('class', 'name-label')
      .attr('y', (d) => (yScale(d.id) || 0) + yScale.bandwidth() / 2 + 4)
      .attr('x', -8)
      .attr('text-anchor', 'end')
      .attr('fill', (d) => (d.votes > 0 && d.votes === maxVal ? '#fca5a5' : '#cbd5e1'))
      .attr('font-size', '11px')
      .attr('font-weight', (d) => (d.votes > 0 && d.votes === maxVal ? 'bold' : 'normal'))
      .attr('font-family', 'Cairo, Inter, sans-serif')
      .text((d) => (d.name.length > 9 ? d.name.slice(0, 8) + '…' : d.name));

    // Value Labels on the right of bars
    g.selectAll('.val-label')
      .data(data)
      .enter()
      .append('text')
      .attr('class', 'val-label')
      .attr('y', (d) => (yScale(d.id) || 0) + yScale.bandwidth() / 2 + 4)
      .attr('x', (d) => xScale(d.votes) + 8)
      .attr('text-anchor', 'start')
      .attr('fill', (d) => (d.votes > 0 && d.votes === maxVal ? '#f87171' : '#94a3b8'))
      .attr('font-size', '11px')
      .attr('font-weight', 'bold')
      .attr('font-family', 'JetBrains Mono, monospace')
      .text((d) => `${d.votes} ${lang === 'ar' ? 'صوت' : 'v'}`)
      .style('opacity', 0)
      .transition()
      .duration(500)
      .delay(150)
      .style('opacity', 1);

    // Bottom X-Axis ticks
    const xAxis = g
      .append('g')
      .attr('transform', `translate(0, ${innerHeight})`)
      .call(
        d3
          .axisBottom(xScale)
          .ticks(Math.min(maxVotes, 5))
          .tickFormat(d3.format('d'))
          .tickSize(4)
      );

    xAxis.select('.domain').attr('stroke', 'rgba(255, 255, 255, 0.15)');
    xAxis.selectAll('.tick line').attr('stroke', 'rgba(255, 255, 255, 0.2)');
    xAxis
      .selectAll('.tick text')
      .attr('fill', '#94a3b8')
      .attr('font-size', '9px')
      .attr('font-family', 'JetBrains Mono, monospace');
  }, [data, totalVotesCast, totalVoters, lang]);

  return (
    <div
      ref={containerRef}
      className="w-full p-4 rounded-2xl bg-black/80 border border-white/10 backdrop-blur-md shadow-xl my-3"
    >
      {/* Chart Top Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-2 mb-2 text-xs">
        <div className="flex items-center gap-1.5 font-bold font-cinzel text-white">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span>{lang === 'ar' ? 'لوحة التحليل الجنائي لتوزيع الأصوات (D3)' : 'Forensic Vote Distribution Analytics (D3)'}</span>
        </div>
        <span className="text-[10px] font-mono text-stone-400">
          {lang === 'ar'
            ? `${totalVotesCast} من ${totalVoters} أصوات مسجلة`
            : `${totalVotesCast} of ${totalVoters} ballots recorded`}
        </span>
      </div>

      {/* SVG Canvas */}
      <div className="overflow-x-auto flex justify-center">
        <svg ref={svgRef} className="overflow-visible" />
      </div>

      <div className="flex items-center justify-between text-[10px] text-stone-400 mt-2 pt-1.5 border-t border-white/5 font-mono">
        <span>{lang === 'ar' ? 'المؤشر الأحمر: أعلى مشتبه به' : 'Red Indicator: Current Prime Suspect'}</span>
        <span>{lang === 'ar' ? 'تحديث فوري مع كل صوت' : 'Real-time D3 update'}</span>
      </div>
    </div>
  );
};
