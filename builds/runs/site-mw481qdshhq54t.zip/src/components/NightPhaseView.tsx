import React, { useState } from 'react';
import { Moon, EyeOff, ShieldAlert, Crosshair, ShieldPlus, Search, Target, Check, ArrowRight, ArrowLeft } from 'lucide-react';
import { Language, Player, GamePhase, NightDecisions } from '../types/game';
import { useTranslation } from '../utils/i18n';
import { sound } from '../utils/sound';

interface NightPhaseViewProps {
  lang: Language;
  phase: GamePhase;
  players: Player[];
  onDecisionsComplete: (decisions: NightDecisions) => void;
}

export const NightPhaseView: React.FC<NightPhaseViewProps> = ({
  lang,
  phase,
  players,
  onDecisionsComplete,
}) => {
  const t = useTranslation(lang);

  // Sub-stages within night phase
  const [subStage, setSubStage] = useState<'INTRO' | 'MAFIA' | 'DOCTOR' | 'DETECTIVE' | 'VIGILANTE'>('INTRO');
  const [isPrivacyUnlocked, setIsPrivacyUnlocked] = useState<boolean>(false);

  // Night action choices state
  const [mafiaTargetId, setMafiaTargetId] = useState<string | null>(null);
  const [doctorTargetId, setDoctorTargetId] = useState<string | null>(null);
  const [detectiveTargetId, setDetectiveTargetId] = useState<string | null>(null);
  const [detectiveRevealed, setDetectiveRevealed] = useState<{ targetName: string; isMafia: boolean } | null>(null);
  const [vigilanteTargetId, setVigilanteTargetId] = useState<string | null>(null);

  // Alive players
  const alivePlayers = players.filter((p) => p.isAlive);
  const aliveMafia = alivePlayers.filter((p) => p.role.team === 'mafia');
  const aliveDoctor = alivePlayers.find((p) => p.role.type === 'doctor');
  const aliveDetective = alivePlayers.find((p) => p.role.type === 'detective');
  const aliveVigilante = alivePlayers.find((p) => p.role.type === 'vigilante');

  // Move from INTRO -> MAFIA
  const handleStartNightMoves = () => {
    sound.playHeartbeat();
    setIsPrivacyUnlocked(false);
    setSubStage('MAFIA');
  };

  // Submit Mafia choice and advance
  const handleConfirmMafia = () => {
    if (!mafiaTargetId) return;
    sound.playCardFlip();
    setIsPrivacyUnlocked(false);

    if (aliveDoctor) {
      setSubStage('DOCTOR');
    } else if (aliveDetective) {
      setSubStage('DETECTIVE');
    } else if (aliveVigilante) {
      setSubStage('VIGILANTE');
    } else {
      finishNight();
    }
  };

  // Submit Doctor choice and advance
  const handleConfirmDoctor = () => {
    sound.playCardFlip();
    setIsPrivacyUnlocked(false);

    if (aliveDetective) {
      setSubStage('DETECTIVE');
    } else if (aliveVigilante) {
      setSubStage('VIGILANTE');
    } else {
      finishNight();
    }
  };

  // Perform Detective Inspection
  const handleInspect = (targetId: string) => {
    setDetectiveTargetId(targetId);
    const targetPlayer = players.find((p) => p.id === targetId);
    if (!targetPlayer) return;

    // Rule: Godfather appears innocent/clean to the Detective!
    const isMafia = targetPlayer.role.team === 'mafia' && targetPlayer.role.type !== 'godfather';

    sound.playReveal(isMafia);
    setDetectiveRevealed({
      targetName: targetPlayer.name,
      isMafia,
    });
  };

  // Submit Detective choice and advance
  const handleConfirmDetective = () => {
    sound.playCardFlip();
    setIsPrivacyUnlocked(false);

    if (aliveVigilante) {
      setSubStage('VIGILANTE');
    } else {
      finishNight();
    }
  };

  // Submit Vigilante choice (or skip) and conclude night
  const handleConfirmVigilante = (shoot: boolean) => {
    if (shoot && vigilanteTargetId) {
      sound.playGunshot();
    } else {
      sound.playCardFlip();
    }
    finishNight();
  };

  const finishNight = () => {
    onDecisionsComplete({
      mafiaTargetId,
      doctorTargetId,
      detectiveTargetId,
      detectiveResult: detectiveRevealed,
      vigilanteTargetId,
    });
  };

  // 1. INTRO: Village Asleep Screen
  if (subStage === 'INTRO') {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-4 max-w-lg mx-auto w-full relative z-10 text-center animate-fade-in">
        <div className="w-24 h-24 rounded-3xl bg-indigo-950/60 border border-indigo-700/50 flex items-center justify-center text-indigo-400 mb-6 shadow-2xl animate-pulse">
          <Moon className="w-12 h-12" />
        </div>

        <h2 className="text-3xl sm:text-4xl font-black font-cinzel text-white mb-3">
          {t.nightFalls}
        </h2>
        <p className="text-sm sm:text-base text-stone-300 max-w-sm mb-8">
          {t.villageAsleep}
        </p>

        <button
          onClick={handleStartNightMoves}
          className="w-full py-4 px-8 rounded-2xl bg-gradient-to-r from-red-800 to-indigo-900 hover:from-red-700 hover:to-indigo-800 text-white font-bold text-base shadow-xl border border-white/20 flex items-center justify-center gap-2 cursor-pointer transition-all"
        >
          <span>{lang === 'ar' ? 'بدء تحركات الليل السرية' : 'Begin Secret Night Moves'}</span>
          {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
        </button>
      </div>
    );
  }

  // 2. PRIVACY CURTAIN SCREEN FOR SUB-STAGES
  if (!isPrivacyUnlocked) {
    let title = '';
    let subtitle = '';
    let icon = <EyeOff className="w-10 h-10 text-amber-400" />;

    if (subStage === 'MAFIA') {
      title = lang === 'ar' ? 'مرر الهاتف إلى أفراد المافيا' : 'Pass phone to the Mafia';
      subtitle = lang === 'ar' ? 'على أفراد المافيا التجمع بصمت حول الشاشة' : 'Mafia members must view quietly together';
      icon = <Crosshair className="w-10 h-10 text-red-500" />;
    } else if (subStage === 'DOCTOR') {
      title = lang === 'ar' ? `مرر الهاتف إلى الطبيب (${aliveDoctor?.name})` : `Pass phone to Doctor (${aliveDoctor?.name})`;
      subtitle = lang === 'ar' ? 'تأكد من عدم نظر أي شخص آخر للشاشة' : 'Ensure nobody else is looking';
      icon = <ShieldPlus className="w-10 h-10 text-emerald-400" />;
    } else if (subStage === 'DETECTIVE') {
      title = lang === 'ar' ? `مرر الهاتف إلى المحقق (${aliveDetective?.name})` : `Pass phone to Detective (${aliveDetective?.name})`;
      subtitle = lang === 'ar' ? 'جلسة فحص أمنية وسرية للغاية' : 'Top-secret dossier investigation';
      icon = <Search className="w-10 h-10 text-blue-400" />;
    } else if (subStage === 'VIGILANTE') {
      title = lang === 'ar' ? `مرر الهاتف إلى القناص (${aliveVigilante?.name})` : `Pass phone to Vigilante (${aliveVigilante?.name})`;
      subtitle = lang === 'ar' ? 'رصاصتك الفضية بانتظار قرارك' : 'Your silver bullet awaits decision';
      icon = <Target className="w-10 h-10 text-purple-400" />;
    }

    return (
      <div className="flex-1 flex flex-col items-center justify-center p-4 max-w-lg mx-auto w-full relative z-10 animate-fade-in">
        <div className="w-full bg-[#13141c]/90 border border-white/15 rounded-3xl p-8 backdrop-blur-xl shadow-2xl flex flex-col items-center text-center space-y-6">
          <div className="w-20 h-20 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
            {icon}
          </div>

          <div className="space-y-2">
            <h3 className="text-2xl sm:text-3xl font-black text-white font-cinzel">
              {title}
            </h3>
            <p className="text-xs sm:text-sm text-stone-400">{subtitle}</p>
          </div>

          <div className="p-3 rounded-xl bg-red-950/40 border border-red-800/40 text-red-300 text-xs flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 shrink-0 text-red-400" />
            <span>{t.ensurePrivacy}</span>
          </div>

          <button
            onClick={() => {
              sound.playCardFlip();
              setIsPrivacyUnlocked(true);
            }}
            className="w-full py-3.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-sm transition-all cursor-pointer shadow-lg"
          >
            {lang === 'ar' ? 'أنا صاحب الدور، افتح الشاشة' : 'I am ready, reveal actions'}
          </button>
        </div>
      </div>
    );
  }

  // 3. UNLOCKED SCREENS FOR CURRENT NIGHT ACTION
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 max-w-lg mx-auto w-full relative z-10 animate-fade-in">
      <div className="w-full bg-[#151620]/95 border border-white/15 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl flex flex-col justify-between min-h-[460px]">
        {/* SUBSTAGE: MAFIA */}
        {subStage === 'MAFIA' && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-white/10">
              <Crosshair className="w-6 h-6 text-red-500" />
              <div>
                <h3 className="text-lg font-bold text-red-400 font-cinzel">
                  {lang === 'ar' ? 'جلسة اغتيال المافيا' : 'Mafia Assassination'}
                </h3>
                <p className="text-xs text-stone-400">{t.mafiaPrompt}</p>
              </div>
            </div>

            {/* List fellow mafia */}
            <div className="p-2.5 rounded-lg bg-red-950/30 border border-red-800/30 text-xs text-stone-300">
              <span className="text-red-400 font-bold block mb-1">
                {lang === 'ar' ? 'أعضاء المافيا الحاضرون:' : 'Active Mafia Members:'}
              </span>
              <span>{aliveMafia.map((m) => `${m.name} (${m.role.type === 'godfather' ? (lang === 'ar' ? 'الزعيم' : 'Godfather') : (lang === 'ar' ? 'عضو' : 'Member')})`).join(' · ')}</span>
            </div>

            {/* Target Selection: All alive players */}
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {alivePlayers.map((player) => {
                const isFellowMafia = player.role.team === 'mafia';
                const isSelected = mafiaTargetId === player.id;

                return (
                  <button
                    key={player.id}
                    onClick={() => {
                      sound.playCardFlip();
                      setMafiaTargetId(player.id);
                    }}
                    className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-red-950 border-red-500 text-white shadow-lg'
                        : isFellowMafia
                        ? 'bg-white/5 border-white/5 text-stone-400 hover:border-red-900/40'
                        : 'bg-black/40 border-white/10 text-stone-200 hover:border-white/30'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm">{player.name}</span>
                      {isFellowMafia && (
                        <span className="text-[10px] text-red-400 font-bold px-1.5 py-0.5 rounded bg-red-950/60 border border-red-800/40">
                          {lang === 'ar' ? 'مافيا' : 'Mafia'}
                        </span>
                      )}
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-red-400" />}
                  </button>
                );
              })}
            </div>

            <button
              onClick={handleConfirmMafia}
              disabled={!mafiaTargetId}
              className="w-full py-3.5 px-6 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-sm transition-all cursor-pointer shadow-lg mt-4"
            >
              {lang === 'ar' ? 'تأكيد اختيار الضحية' : 'Confirm Kill Target'}
            </button>
          </div>
        )}

        {/* SUBSTAGE: DOCTOR */}
        {subStage === 'DOCTOR' && aliveDoctor && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-white/10">
              <ShieldPlus className="w-6 h-6 text-emerald-400" />
              <div>
                <h3 className="text-lg font-bold text-emerald-400 font-cinzel">
                  {lang === 'ar' ? 'غرفة عمليات الطبيب' : 'Doctor Protection'}
                </h3>
                <p className="text-xs text-stone-400">{t.doctorPrompt}</p>
              </div>
            </div>

            {aliveDoctor.hasUsedSelfHeal && (
              <div className="p-2.5 rounded-lg bg-amber-950/40 border border-amber-800/40 text-xs text-amber-300">
                {t.doctorSelfUsed}
              </div>
            )}

            {/* Target Selection: All alive players */}
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {alivePlayers.map((player) => {
                const isDoctor = player.id === aliveDoctor.id;
                const cannotHealSelf = isDoctor && aliveDoctor.hasUsedSelfHeal;
                const isSelected = doctorTargetId === player.id;

                return (
                  <button
                    key={player.id}
                    disabled={cannotHealSelf}
                    onClick={() => {
                      sound.playCardFlip();
                      setDoctorTargetId(player.id);
                    }}
                    className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      cannotHealSelf
                        ? 'opacity-30 cursor-not-allowed bg-black/20 border-white/5'
                        : isSelected
                        ? 'bg-emerald-950 border-emerald-500 text-white shadow-lg'
                        : 'bg-black/40 border-white/10 text-stone-200 hover:border-white/30'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm">{player.name}</span>
                      {isDoctor && (
                        <span className="text-[10px] text-emerald-400 font-bold px-1.5 py-0.5 rounded bg-emerald-950/60 border border-emerald-800/40">
                          {lang === 'ar' ? 'أنت (الطبيب)' : 'You (Doctor)'}
                        </span>
                      )}
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-emerald-400" />}
                  </button>
                );
              })}
            </div>

            <button
              onClick={handleConfirmDoctor}
              disabled={!doctorTargetId}
              className="w-full py-3.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-sm transition-all cursor-pointer shadow-lg mt-4"
            >
              {lang === 'ar' ? 'تأكيد الحماية بالترياق' : 'Confirm Antidote Protection'}
            </button>
          </div>
        )}

        {/* SUBSTAGE: DETECTIVE */}
        {subStage === 'DETECTIVE' && aliveDetective && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-white/10">
              <Search className="w-6 h-6 text-blue-400" />
              <div>
                <h3 className="text-lg font-bold text-blue-400 font-cinzel">
                  {lang === 'ar' ? 'مكتب التحقيقات السري' : 'Detective Inspection'}
                </h3>
                <p className="text-xs text-stone-400">{t.detectivePrompt}</p>
              </div>
            </div>

            {!detectiveRevealed ? (
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {alivePlayers.map((player) => {
                  const isDetective = player.id === aliveDetective.id;
                  if (isDetective) return null; // Can't inspect self

                  return (
                    <button
                      key={player.id}
                      onClick={() => handleInspect(player.id)}
                      className="w-full p-3 rounded-xl border bg-black/40 border-white/10 text-stone-200 hover:border-blue-400/60 text-left flex items-center justify-between transition-all cursor-pointer"
                    >
                      <span className="font-semibold text-sm">{player.name}</span>
                      <Search className="w-4 h-4 text-blue-400" />
                    </button>
                  );
                })}
              </div>
            ) : (
              /* Confidential Inspection Dossier Stamp Result */
              <div className="p-6 rounded-2xl bg-black/60 border border-white/15 text-center space-y-3 animate-fade-in">
                <span className="text-xs text-stone-400 uppercase tracking-widest block">
                  {lang === 'ar' ? 'نتيجة الفحص الجنائي' : 'Forensic Investigation Result'}
                </span>
                <h4 className="text-2xl font-black text-white font-cinzel">
                  {detectiveRevealed.targetName}
                </h4>
                <div
                  className={`py-3 px-4 rounded-xl border font-black text-base ${
                    detectiveRevealed.isMafia
                      ? 'bg-red-950/80 border-red-700 text-red-400'
                      : 'bg-emerald-950/80 border-emerald-700 text-emerald-400'
                  }`}
                >
                  {detectiveRevealed.isMafia ? t.detectiveResultMafia : t.detectiveResultClean}
                </div>
                <p className="text-[11px] text-stone-400">
                  {lang === 'ar'
                    ? '(ملاحظة: زعيم المافيا يملك حصانة خاصة ويظهر كبريء دائماً)'
                    : '(Note: The Godfather possesses special immunity and always appears clean)'}
                </p>
              </div>
            )}

            {detectiveRevealed && (
              <button
                onClick={handleConfirmDetective}
                className="w-full py-3.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm transition-all cursor-pointer shadow-lg mt-4"
              >
                {lang === 'ar' ? 'إخفاء الملف وتمرير الهاتف' : 'Conceal Dossier & Continue'}
              </button>
            )}
          </div>
        )}

        {/* SUBSTAGE: VIGILANTE */}
        {subStage === 'VIGILANTE' && aliveVigilante && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-white/10">
              <Target className="w-6 h-6 text-purple-400" />
              <div>
                <h3 className="text-lg font-bold text-purple-400 font-cinzel">
                  {lang === 'ar' ? 'رصاصة القناص الفضية' : 'Vigilante Bullet'}
                </h3>
                <p className="text-xs text-stone-400">{t.vigilantePrompt}</p>
              </div>
            </div>

            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {alivePlayers.map((player) => {
                if (player.id === aliveVigilante.id) return null; // Can't shoot self
                const isSelected = vigilanteTargetId === player.id;

                return (
                  <button
                    key={player.id}
                    onClick={() => {
                      sound.playCardFlip();
                      setVigilanteTargetId(player.id);
                    }}
                    className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-purple-950 border-purple-500 text-white shadow-lg'
                        : 'bg-black/40 border-white/10 text-stone-200 hover:border-white/30'
                    }`}
                  >
                    <span className="font-semibold text-sm">{player.name}</span>
                    {isSelected && <Target className="w-4 h-4 text-purple-400" />}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center gap-3 mt-4">
              <button
                onClick={() => handleConfirmVigilante(false)}
                className="w-1/2 py-3 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs cursor-pointer"
              >
                {t.vigilanteSkip}
              </button>

              <button
                onClick={() => handleConfirmVigilante(true)}
                disabled={!vigilanteTargetId}
                className="w-1/2 py-3 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-30 disabled:cursor-not-allowed text-white font-bold text-xs cursor-pointer shadow-lg"
              >
                {t.vigilanteShoot}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
