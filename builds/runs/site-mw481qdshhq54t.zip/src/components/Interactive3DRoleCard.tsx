import React, { useState, useRef } from 'react';
import { 
  Crown, 
  VolumeX, 
  Shield, 
  ShieldPlus, 
  Search, 
  Target, 
  UserCheck, 
  Sparkles, 
  RotateCw, 
  Plus, 
  Minus, 
  Check, 
  Info 
} from 'lucide-react';
import { RoleInfo, Language } from '../types/game';
import { sound } from '../utils/sound';

interface Interactive3DRoleCardProps {
  role: RoleInfo;
  count: number;
  lang: Language;
  isCustomDeck: boolean;
  onIncrement?: () => void;
  onDecrement?: () => void;
  canIncrement?: boolean;
}

export const Interactive3DRoleCard: React.FC<Interactive3DRoleCardProps> = ({
  role,
  count,
  lang,
  isCustomDeck,
  onIncrement,
  onDecrement,
  canIncrement = true,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotateX, setRotateX] = useState<number>(0);
  const [rotateY, setRotateY] = useState<number>(0);
  const [glare, setGlare] = useState<{ x: number; y: number; opacity: number }>({ x: 50, y: 50, opacity: 0 });
  const [isFlipped, setIsFlipped] = useState<boolean>(false);

  const getRoleIcon = () => {
    switch (role.type) {
      case 'godfather':
        return <Crown className="w-6 h-6 text-red-500" />;
      case 'silencer':
        return <VolumeX className="w-6 h-6 text-rose-400" />;
      case 'mafia':
        return <Shield className="w-6 h-6 text-red-400" />;
      case 'doctor':
        return <ShieldPlus className="w-6 h-6 text-emerald-400" />;
      case 'detective':
        return <Search className="w-6 h-6 text-blue-400" />;
      case 'vigilante':
        return <Target className="w-6 h-6 text-purple-400" />;
      case 'jester':
        return <Sparkles className="w-6 h-6 text-amber-400" />;
      case 'villager':
      default:
        return <UserCheck className="w-6 h-6 text-teal-400" />;
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    // Calculate rotation limits (-15 to +15 deg)
    const rotX = -((y - centerY) / centerY) * 12;
    const rotY = ((x - centerX) / centerX) * 12;

    setRotateX(rotX);
    setRotateY(rotY);
    setGlare({
      x: (x / rect.width) * 100,
      y: (y / rect.height) * 100,
      opacity: 0.45,
    });
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setGlare((prev) => ({ ...prev, opacity: 0 }));
  };

  const toggleFlip = (e: React.MouseEvent) => {
    e.stopPropagation();
    sound.playCardFlip();
    setIsFlipped((prev) => !prev);
  };

  const getTeamLabel = () => {
    if (role.team === 'mafia') return lang === 'ar' ? 'عصابة المافيا' : 'Mafia Syndicate';
    if (role.team === 'neutral') return lang === 'ar' ? 'فريق محايد' : 'Neutral';
    return lang === 'ar' ? 'فريق الصالحين' : 'Town Citizen';
  };

  const getTeamBadgeColor = () => {
    if (role.team === 'mafia') return 'bg-red-950/80 border-red-700/60 text-red-300';
    if (role.team === 'neutral') return 'bg-amber-950/80 border-amber-700/60 text-amber-300';
    return 'bg-emerald-950/80 border-emerald-700/60 text-emerald-300';
  };

  const isActive = count > 0;

  return (
    <div
      className="relative w-full h-[220px] select-none perspective-[1000px] group cursor-pointer"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      <div
        ref={cardRef}
        style={{
          transform: `rotateX(${rotateX}deg) rotateY(${rotateY + (isFlipped ? 180 : 0)}deg) ${
            isActive ? 'scale3d(1.02, 1.02, 1.02)' : 'scale3d(0.98, 0.98, 0.98)'
          }`,
          transformStyle: 'preserve-3d',
          transition: 'transform 0.15s ease-out, box-shadow 0.25s ease',
        }}
        className={`w-full h-full rounded-2xl relative transition-shadow duration-300 ${
          isActive
            ? 'shadow-[0_12px_30px_rgba(0,0,0,0.8),0_0_20px_rgba(217,119,6,0.2)] border-2'
            : 'shadow-[0_4px_16px_rgba(0,0,0,0.5)] border opacity-75 hover:opacity-100'
        }`}
      >
        {/* ========================================================================= */}
        {/* FRONT FACE OF 3D CARD                                                    */}
        {/* ========================================================================= */}
        <div
          style={{
            backfaceVisibility: 'hidden',
            borderColor: isActive ? role.accentColor : 'rgba(255,255,255,0.12)',
            background: isActive
              ? `linear-gradient(145deg, rgba(20,20,30,0.96) 0%, rgba(12,12,18,0.98) 100%)`
              : 'rgba(15,15,22,0.9)',
          }}
          className="absolute inset-0 rounded-2xl p-3.5 flex flex-col justify-between overflow-hidden border backdrop-blur-xl"
        >
          {/* Dynamic Interactive Specular Lighting Sheen */}
          <div
            style={{
              background: `radial-gradient(circle at ${glare.x}% ${glare.y}%, rgba(255,255,255,0.2) 0%, transparent 65%)`,
              opacity: glare.opacity,
              pointerEvents: 'none',
            }}
            className="absolute inset-0 transition-opacity duration-150 rounded-2xl z-20"
          />

          {/* Top Bar: Team Pill + Flip Button + Active Count Badge */}
          <div
            style={{ transform: 'translateZ(20px)' }}
            className="flex items-center justify-between z-10"
          >
            <div className="flex items-center gap-1.5">
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getTeamBadgeColor()}`}>
                {getTeamLabel()}
              </span>

              {/* Flip Button for 3D Dossier */}
              <button
                type="button"
                onClick={toggleFlip}
                title={lang === 'ar' ? 'اقلب البطاقة لقراءة الملف السري' : 'Flip card to read secret dossier'}
                className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-stone-300 hover:text-white transition-colors cursor-pointer"
              >
                <RotateCw className="w-3 h-3" />
              </button>
            </div>

            {/* Stepper Count Badge */}
            <div className="flex items-center gap-1">
              {isCustomDeck ? (
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="flex items-center gap-1 bg-black/60 p-0.5 rounded-lg border border-white/15"
                >
                  <button
                    type="button"
                    onClick={() => {
                      sound.playCardFlip();
                      onDecrement?.();
                    }}
                    disabled={count <= 0}
                    className="w-5 h-5 rounded flex items-center justify-center bg-white/10 hover:bg-white/25 disabled:opacity-20 disabled:hover:bg-white/10 text-white font-bold text-xs cursor-pointer transition-colors"
                  >
                    <Minus className="w-3 h-3" />
                  </button>

                  <span
                    className="font-mono-num font-bold text-xs w-5 text-center"
                    style={{ color: isActive ? role.accentColor : '#9ca3af' }}
                  >
                    {count}
                  </span>

                  <button
                    type="button"
                    onClick={() => {
                      sound.playCardFlip();
                      onIncrement?.();
                    }}
                    disabled={!canIncrement}
                    className="w-5 h-5 rounded flex items-center justify-center bg-white/10 hover:bg-white/25 disabled:opacity-20 disabled:hover:bg-white/10 text-white font-bold text-xs cursor-pointer transition-colors"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
              ) : (
                <span
                  className="font-mono-num font-bold text-xs px-2 py-0.5 rounded-full bg-black/70 border border-white/20"
                  style={{ color: isActive ? role.accentColor : '#6b7280' }}
                >
                  {count} {lang === 'ar' ? 'بطاقات' : 'cards'}
                </span>
              )}
            </div>
          </div>

          {/* Middle 3D Layer: Role Icon, Name, and Ability */}
          <div
            style={{ transform: 'translateZ(30px)' }}
            className="flex items-center gap-3 my-1 z-10"
          >
            <div
              style={{
                borderColor: `${role.accentColor}55`,
                backgroundColor: `${role.accentColor}18`,
              }}
              className="w-12 h-12 rounded-xl border flex items-center justify-center shrink-0 shadow-inner group-hover:scale-105 transition-transform"
            >
              {getRoleIcon()}
            </div>

            <div className="flex-1 min-w-0">
              <h3 className="font-cinzel font-bold text-sm sm:text-base text-white truncate">
                {lang === 'ar' ? role.nameAr : role.nameEn}
              </h3>
              <p className="text-[11px] text-stone-300/90 line-clamp-2 leading-relaxed">
                {lang === 'ar' ? role.descriptionAr : role.descriptionEn}
              </p>
            </div>
          </div>

          {/* Bottom 3D Footprint: Ability highlights */}
          <div
            style={{ transform: 'translateZ(18px)' }}
            className="pt-2 border-t border-white/10 flex items-center justify-between text-[10px] z-10"
          >
            <span
              className="font-medium truncate max-w-[85%]"
              style={{ color: role.accentColor }}
            >
              {lang === 'ar' ? `⚡ ${role.abilityAr}` : `⚡ ${role.abilityEn}`}
            </span>

            <span className="text-stone-400 text-[10px] underline cursor-pointer hover:text-white" onClick={toggleFlip}>
              {lang === 'ar' ? 'الملف' : 'Info'}
            </span>
          </div>

          {/* Holographic Watermark Badge */}
          <div
            style={{ transform: 'translateZ(5px)' }}
            className="absolute -bottom-6 -right-6 w-24 h-24 rounded-full opacity-5 pointer-events-none"
            style={{ backgroundColor: role.accentColor }}
          />
        </div>

        {/* ========================================================================= */}
        {/* BACK FACE OF 3D CARD: Confidential Secret Dossier                         */}
        {/* ========================================================================= */}
        <div
          style={{
            backfaceVisibility: 'hidden',
            transform: 'rotateY(180deg)',
            borderColor: role.accentColor,
            background: 'linear-gradient(145deg, #101016 0%, #07070a 100%)',
          }}
          className="absolute inset-0 rounded-2xl p-4 flex flex-col justify-between border-2 shadow-2xl backdrop-blur-2xl text-left"
        >
          {/* Back Header */}
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <span className="text-[11px] font-mono tracking-widest uppercase text-amber-400 flex items-center gap-1.5 font-bold">
              <Info className="w-3.5 h-3.5" />
              {lang === 'ar' ? 'الملف التكتيكي السري' : 'Confidential Dossier'}
            </span>
            <button
              type="button"
              onClick={toggleFlip}
              className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-stone-300 hover:text-white transition-colors cursor-pointer"
            >
              <RotateCw className="w-3 h-3" />
            </button>
          </div>

          {/* Dossier Tactical Lore & Strategy */}
          <div className="space-y-2 text-xs text-stone-300 my-auto">
            <div className="font-bold text-white text-sm">
              {lang === 'ar' ? role.nameAr : role.nameEn}
            </div>

            <p className="text-[11px] leading-relaxed text-stone-300 bg-black/50 p-2.5 rounded-xl border border-white/5">
              {lang === 'ar' ? role.descriptionAr : role.descriptionEn}
            </p>

            <div className="text-[11px] text-amber-300/90 font-medium">
              {lang === 'ar' ? `المهمة: ${role.abilityAr}` : `Mission: ${role.abilityEn}`}
            </div>
          </div>

          {/* Return Hint */}
          <div className="text-center pt-2 border-t border-white/10">
            <button
              type="button"
              onClick={toggleFlip}
              className="text-[10px] text-stone-400 hover:text-white uppercase tracking-wider font-semibold"
            >
              {lang === 'ar' ? '↶ انقر للعودة إلى واجهة البطاقة' : '↶ Click to flip back'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
