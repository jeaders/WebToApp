import { Player, RoleInfo, RoleType, GameStats, MvpScore } from '../types/game';
import { ROLES_POOL } from './rolesData';

export interface RoleDeckConfig {
  godfatherCount: number;
  mafiaCount: number;
  silencerCount: number;
  doctorCount: number;
  detectiveCount: number;
  vigilanteCount: number;
  jesterCount: number;
  villagerCount: number;
}

export const getRecommendedDeck = (totalPlayers: number): RoleDeckConfig => {
  // Balanced default based on classic Mafia standards
  let mafiaTotal = Math.max(1, Math.floor(totalPlayers / 3.5));
  if (totalPlayers >= 7 && mafiaTotal < 2) mafiaTotal = 2;
  if (totalPlayers >= 11 && mafiaTotal < 3) mafiaTotal = 3;
  if (totalPlayers >= 15 && mafiaTotal < 4) mafiaTotal = 4;

  const hasGodfather = mafiaTotal >= 1 ? 1 : 0;
  // If mafia has at least 2 members (totalPlayers >= 7), include 1 Silencer
  const hasSilencer = mafiaTotal >= 2 ? 1 : 0;
  const regularMafia = Math.max(0, mafiaTotal - hasGodfather - hasSilencer);
  const hasDoctor = totalPlayers >= 5 ? 1 : 0;
  const hasDetective = totalPlayers >= 5 ? 1 : 0;
  const hasVigilante = totalPlayers >= 9 ? 1 : 0;
  const hasJester = totalPlayers >= 7 ? 1 : 0;

  const specialCount = hasGodfather + regularMafia + hasSilencer + hasDoctor + hasDetective + hasVigilante + hasJester;
  const villagers = Math.max(0, totalPlayers - specialCount);

  return {
    godfatherCount: hasGodfather,
    mafiaCount: regularMafia,
    silencerCount: hasSilencer,
    doctorCount: hasDoctor,
    detectiveCount: hasDetective,
    vigilanteCount: hasVigilante,
    jesterCount: hasJester,
    villagerCount: villagers,
  };
};

export const generatePlayers = (
  playerNames: string[],
  config: RoleDeckConfig
): Player[] => {
  const deck: RoleInfo[] = [];

  for (let i = 0; i < config.godfatherCount; i++) deck.push(ROLES_POOL.godfather);
  for (let i = 0; i < config.mafiaCount; i++) deck.push(ROLES_POOL.mafia);
  for (let i = 0; i < config.silencerCount; i++) deck.push(ROLES_POOL.silencer);
  for (let i = 0; i < config.doctorCount; i++) deck.push(ROLES_POOL.doctor);
  for (let i = 0; i < config.detectiveCount; i++) deck.push(ROLES_POOL.detective);
  for (let i = 0; i < config.vigilanteCount; i++) deck.push(ROLES_POOL.vigilante);
  for (let i = 0; i < config.jesterCount; i++) deck.push(ROLES_POOL.jester);
  for (let i = 0; i < config.villagerCount; i++) deck.push(ROLES_POOL.villager);

  // If mismatch with players length, pad or slice
  while (deck.length < playerNames.length) {
    deck.push(ROLES_POOL.villager);
  }
  if (deck.length > playerNames.length) {
    deck.length = playerNames.length;
  }

  // Fisher-Yates shuffle
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }

  return playerNames.map((name, index) => ({
    id: `player_${index}_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    name: name.trim().length > 0 ? name.trim() : `لاعب ${index + 1}`,
    role: deck[index],
    isAlive: true,
    votesReceived: 0,
    isProtected: false,
    isTargetedByMafia: false,
    isTargetedByVigilante: false,
    hasUsedSelfHeal: false,
  }));
};

export const calculateMvp = (
  players: Player[],
  stats: GameStats,
  winningTeam: 'town' | 'mafia' | 'jester' | null
): MvpScore => {
  // 1. JESTER SOLO VICTORY
  if (winningTeam === 'jester') {
    const jester = players.find((p) => p.role.type === 'jester') || players[0];
    return {
      player: jester,
      score: 100,
      reasonAr: 'عرّاب الفوضى والتلاعب! نجح في استفزاز القرية ودفعهم ببراعة لإعدامه بالتصويت محققاً فوزه الفردي الأسطوري!',
      reasonEn: 'Master of Chaos! Manipulated the entire town assembly into executing them by daytime ballot, achieving an extraordinary solo victory!',
    };
  }

  // 2. MAFIA VICTORY OR SURVIVING MAFIA RULE
  // "when one of the mafia is alive the game make the mafia MVP"
  if (winningTeam === 'mafia') {
    const aliveMafia = players.filter((p) => p.role.team === 'mafia' && p.isAlive);
    const candidateMafia = aliveMafia.length > 0
      ? aliveMafia
      : players.filter((p) => p.role.team === 'mafia');

    let bestMafia = candidateMafia[0] || players[0];
    let maxMafiaScore = -1;

    candidateMafia.forEach((m) => {
      let score = 50; // High base score for winning
      if (m.isAlive) score += 30; // Survival bonus
      if (m.role.type === 'godfather') score += 20; // Syndicate Kingpin bonus
      const kills = stats.mafiaKills[m.id] || 0;
      score += kills * 10;
      const votes = stats.correctVotes[m.id] || 0;
      score += votes * 5;
      const silences = stats.silencerSilences?.[m.id] || 0;
      score += silences * 8;

      if (score > maxMafiaScore) {
        maxMafiaScore = score;
        bestMafia = m;
      }
    });

    const isGodfather = bestMafia.role.type === 'godfather';
    const isSilencer = bestMafia.role.type === 'silencer';
    const isAlive = bestMafia.isAlive;

    return {
      player: bestMafia,
      score: Math.max(80, maxMafiaScore),
      reasonAr: isGodfather
        ? 'زعيم المافيا ومهندس الخديعة! قاد العصابة من الظل، وتخفى بحصانته أمام تحقيقات المحقق وبقي حياً حتى سقطت القرية بالكامل!'
        : isSilencer
        ? 'المصمّت الاستراتيجي! كمّم أفواه قادة القرية وشل قدرتهم على الدفاع والنقاش نهاراً، مؤمناً نصر المافيا الكاسح!'
        : isAlive
        ? 'بقي حياً وراوغ جميع المحققين وأصوات القرية حتى اللحظة الأخيرة، محققاً النصر الحاسم للمافيا!'
        : 'قاد هجمات ليلية استراتيجية شلت حركة القرية وفتحت الطريق لنصر المافيا المؤزر!',
      reasonEn: isGodfather
        ? 'Syndicate Boss & Mastermind! Directed the nightly assassinations, eluded all investigations, and survived to claim total supremacy!'
        : isSilencer
        ? 'The Tactical Silencer! Muffled key town voices and paralyzed daytime cross-examinations, cementing syndicate control!'
        : isAlive
        ? 'Eluded all detective checks and town ballots, surviving until the end to clinch ultimate victory for the Mafia!'
        : 'Led devastating night attacks that crippled the village and secured triumph for the Syndicate!',
    };
  }

  // 3. TOWN VICTORY: All Mafia eliminated / caught by village
  // "the game end when all of mafia dead or cached by village"
  const townPlayers = players.filter((p) => p.role.team === 'town');
  const candidateTown = townPlayers.length > 0 ? townPlayers : players;

  let bestTown = candidateTown[0];
  let maxTownScore = -999;
  let reasonAr = 'تصويت حاسم وقيادة ذكية ساهمت في تطهير المدينة والقضاء على المافيا بالكامل.';
  let reasonEn = 'Decisive voting and astute deduction helped purge the entire syndicate from town.';

  candidateTown.forEach((p) => {
    let score = 10;
    const saves = stats.doctorSaves[p.id] || 0;
    const catches = stats.detectiveCatches[p.id] || 0;
    const vigHits = stats.vigilanteHitMafia[p.id] || 0;
    const votes = stats.correctVotes[p.id] || 0;

    score += catches * 35; // Identifying mafia is huge
    score += saves * 35; // Saving innocent lives from night kill
    score += vigHits * 40; // Lethal execution of a mafia
    score += votes * 15; // Voting on lynched mafia
    if (p.isAlive) score += 15; // Survived until town victory

    if (score > maxTownScore) {
      maxTownScore = score;
      bestTown = p;

      if (p.role.type === 'detective' && catches > 0) {
        reasonAr = `المحقق الأسطوري! كشف ملفات ${catches} من أفراد المافيا في الظلام وقاد القرية لإدانتهم وإعدامهم بالتصويت!`;
        reasonEn = `Legendary Detective! Unmasked ${catches} Mafia conspirator(s) in the dark and guided the town to decisive execution!`;
      } else if (p.role.type === 'doctor' && saves > 0) {
        reasonAr = `طبيب القرية المنقذ! أحبط محاولات اغتيال المافيا ${saves} مرة بجرعات الترياق الحاسمة وحافظ على أرواح الأبرياء!`;
        reasonEn = `Savior Doctor! Thwarted ${saves} assassination attempt(s) with timely antidotes, keeping town numbers intact!`;
      } else if (p.role.type === 'vigilante' && vigHits > 0) {
        reasonAr = `القناص الحاسم! أطلق رصاصته الفضية بدقة استثنائية وأسقط عنصراً خطيراً من أفراد المافيا!`;
        reasonEn = `Decisive Vigilante! Fired a lethal precision shot that eliminated a high-threat Mafia operative!`;
      } else if (votes > 0) {
        reasonAr = `المواطن القيادي! تميز بقوة المنطق في مناظرات النهار وأدلى بأصوات حاسمة لإعدام الخونة وتطهير المدينة!`;
        reasonEn = `Town Leader! Used sharp deduction during cross-examinations and cast decisive ballots to lynch the Mafia conspirators!`;
      } else if (p.isAlive) {
        reasonAr = `صامد حتى النهاية! نجا من محاولات المكر والغدر وساهم في صمود القرية حتى الانتصار النهائي.`;
        reasonEn = `Steadfast survivor! Endured nocturnal danger and anchored town resolve until ultimate victory.`;
      }
    }
  });

  return {
    player: bestTown,
    score: Math.max(30, maxTownScore),
    reasonAr,
    reasonEn,
  };
};
