export type Team = 'town' | 'mafia' | 'neutral';

export type RoleType = 
  | 'villager'
  | 'doctor'
  | 'detective'
  | 'vigilante'
  | 'mafia'
  | 'godfather'
  | 'silencer'
  | 'jester';

export interface RoleInfo {
  type: RoleType;
  team: Team;
  nameAr: string;
  nameEn: string;
  descriptionAr: string;
  descriptionEn: string;
  abilityAr: string;
  abilityEn: string;
  icon: string;
  accentColor: string;
}

export interface Player {
  id: string;
  name: string;
  role: RoleInfo;
  isAlive: boolean;
  votesReceived: number;
  isProtected: boolean;
  isTargetedByMafia: boolean;
  isTargetedByVigilante: boolean;
  isSilenced?: boolean;
  hasUsedSelfHeal?: boolean;
}

export type PlayMode = 'MODERATOR' | 'PASS_AND_PLAY';

export type GamePhase =
  | 'TITLE'
  | 'MODE_SELECT'
  | 'RULES'
  | 'SETUP'
  | 'REVEAL_ROLES'
  | 'NIGHT_INTRO'
  | 'NIGHT_MAFIA'
  | 'NIGHT_SILENCER'
  | 'NIGHT_DOCTOR'
  | 'NIGHT_DETECTIVE'
  | 'NIGHT_VIGILANTE'
  | 'DAWN_REPORT'
  | 'DAY_DISCUSSION'
  | 'VOTING'
  | 'LYNCH_RESULT'
  | 'GAME_OVER';

export interface NightDecisions {
  mafiaTargetId: string | null;
  doctorTargetId: string | null;
  detectiveTargetId: string | null;
  detectiveResult: { targetName: string; isMafia: boolean } | null;
  vigilanteTargetId: string | null;
  silencerTargetId?: string | null;
}

export interface DawnResult {
  killedPlayerIds: string[];
  savedPlayerId: string | null;
  vigilanteKilledPlayerId: string | null;
  silencedPlayerId?: string | null;
  storyAr: string;
  storyEn: string;
}

export interface GameStats {
  doctorSaves: Record<string, number>; // playerId -> count
  detectiveCatches: Record<string, number>; // playerId -> count
  mafiaKills: Record<string, number>; // playerId -> count
  correctVotes: Record<string, number>; // playerId -> count
  vigilanteHitMafia: Record<string, number>; // playerId -> count
  silencerSilences?: Record<string, number>; // playerId -> count
}

export interface MvpScore {
  player: Player;
  score: number;
  reasonAr: string;
  reasonEn: string;
}

export type Language = 'ar' | 'en';
