# وثيقة التصميم البرمجي والتكتيكي للعبة المافيا (Mafia Game Blueprint - Flutter)

هذه الوثيقة تمثل التوثيق الهندسي الشامل والكامل لبناء تطبيق لعبة المافيا (Pass & Play) باستخدام إطار العمل **Flutter**، مطابقة تماماً للقواعد الأصلية والدقيقة للعبة الواقعية دون أي افتراضات خارج نطاق اللعبة القياسي.

---

## 1. الشرح العام وقواعد اللعبة (Game Overview & Rules)

تعتمد لعبة المافيا على الصراع الاجتماعي، الخداع، والتفكير المنطقي بين مجموعتين:
1. **فريق الصالحين (القرية / المواطنون):** لا يعرفون هوية بعضهم البعض، وهدفهم كشف كل أفراد المافيا والقضاء عليهم بالتصويت.
2. **فريق المافيا:** يعرفون أعضاء فريقهم، وهدفهم التخلص من الصالحين بالتتابع ليلاً والتضليل نهاراً حتى يتساوى عددهم مع عدد الصالحين.
3. **الأدوار المحايدة (اختياري مثل الجوكر):** تملك أهدافاً فردية خاصة.

---

## 2. نظام وتوزيع الأدوار (Roles & Deck System)

يتم ضبط الإعدادات قبل بدء اللعب بتحديد **عدد اللاعبين الإجمالي** وإدخال **أسماء اللاعبين (اختياري/إجباري)**، واختيار **توزيعة أعداد الصالحين والمافيا**. توزيع الأدوار يكون **عشوائياً بالكامل (Randomized)** عند بدء الجلسة.

### القائمة المعيارية للأدوار:

| اسم الدور | الفريق | الفئة | القدرة الليلية / الميزة |
| :--- | :--- | :--- | :--- |
| **المواطن (Villager)** | الصالحين | عادي | ليس لديه قدرة ليلية، قوته تتجلى في النقاش والتصويت نهاراً. |
| **الطبيب (Doctor)** | الصالحين | خاص | يستيقظ ليلاً ليحمي شخصاً واحداً من الاغتيال (يمكنه حماية نفسه مرة واحدة). |
| **المحقق (Detective / Cop)** | الصالحين | خاص | يستيقظ ليلاً ليفحص هويت شخص واحد (يكشف التطبيق له: مافيا أم صالح). |
| **القناص (Vigilante)** | الصالحين | خاص | يملك رصاصة واحدة في اللعبة لاستخدامها ليلاً ضد من يشك به. |
| **المافيا العادي (Mafia)** | المافيا | عادي | يستيقظ ليلاً مع باقي المافيا للاعتماد بالتصويت على اغتيال شخص واحد. |
| **زعيم المافيا (Godfather)** | المافيا | خاص | صاحب القرار النهائي في الاغتيال ليلاً، وعند فحص المحقق له يظهر كـ "صالح". |
| **الجوكر / المهرج (Jester)** | محايد | خاص | هدفه الوحيد أن يتم التصويت لإعدامه نهاراً، وحينها يفوز بمفرده فوراً. |

---

## 3. التسلسل التدفيقي المباشر للتطبيق (Application Flow Sequence)

```text
[1. شاشة التعليمات والقواعد]
         │
         ▼
[2. شاشة الإعدادات واسماء اللاعبين وتحديد (عدد الصالحين / المافيا)]
         │
         ▼
[3. شاشة التنبيه وتوزيع الأدوار العشوائية (Pass & Play Loop)]
  ├── عرض: "سلم الهاتف إلى: [اسم اللاعب]"
  ├── ضغط زر "عرض دوري السري"
  ├── عرض بطاقة الدور (مافيا/طبيب/محقق/مواطن...)
  └── ضغط زر "إخفاء ومرر للهاتف للاعب التالي"
         │
         ▼
[4. مرحلة الليل (Night Phase)]
  ├── إغلاق القرية (شاشة إخفاء)
  ├── استدعاء المافيا -> اختيار الضحية
  ├── استدعاء الطبيب -> اختيار الشخص المراد حمايته
  └── استدعاء المحقق -> فحص لاعب واظهار النتيجة سرّاً
         │
         ▼
[5. مرحلة الصباح والنتائج (Dawn / Morning)]
  └── إعلان نتيجة الليل (من قُتل أو "نجا الجميع بفضل الطبيب")
         │
         ▼
[6. مرحلة النقاش والتحقيق (Discussion Phase)]
  └── مؤقت زمني للنقاش والتلاوم والاتهام
         │
         ▼
[7. مرحلة التصويت المباشر (Round-Robin Voting Phase)]
  ├── يمر الهاتف أو يعرض بالترتيب: "[اسم اللاعب الحالي] أدلِ بصوتك"
  └── يتم اختيار المشتبه به من قائمة الأحياء
         │
         ▼
[8. شاشة نتيجة التصويت والكشف (Lynch Result)]
  ├── إعلان أعلى شخص حاز على أصوات
  ├── إعدام اللاعب وكشف بطاقته (صالح / مافيا)
  └── فحص شروط النهاية (Win Condition Check)
         │
         ├── لم تنتهِ ────► العودة إلى [4. مرحلة الليل]
         └── انتهت   ────► الانتقال إلى [9. شاشة النتائج النهائية والتصنيف]
```

---

## 4. البناء الهندسي بنمط Clean Architecture (Flutter Directory Structure)

```text
lib/
├── core/
│   ├── constants/
│   │   ├── app_colors.dart
│   │   └── app_assets.dart
│   ├── theme/
│   │   └── app_theme.dart
│   └── utils/
│       └── role_allocator.dart       # خوارزمية التوزيع العشوائي للأدوار
│
├── features/
│   ├── rules/                        # شاشة الشرح والقواعد
│   ├── setup/                        # شاشة ادخال الأسماء والأعداد
│   ├── role_assignment/              # شاشة مرر الهاتف وكشف الأدوار
│   ├── game_play/
│   │   ├── domain/
│   │   │   ├── entities/
│   │   │   │   ├── player.dart       # نموذج اللاعب
│   │   │   │   └── role.dart         # نموذج البطاقة والدور
│   │   │   └── usecases/
│   │   │       ├── process_night.dart # منطق دمج قرارات الليل (قتل vs حماية)
│   │   │       └── process_votes.dart # منطق فرز الأصوات تحديد المطرود
│   │   └── presentation/
│   │       ├── bloc/
│   │       │   ├── mafia_bloc.dart
│   │       │   ├── mafia_event.dart
│   │       │   └── mafia_state.dart
│   │       └── pages/
│   │           ├── night_page.dart
│   │           ├── day_discussion_page.dart
│   │           ├── voting_page.dart
│   │           └── lynch_result_page.dart
│   └── game_over/                    # شاشة نتائج الفائزين والتصنيف والتكريم
└── main.dart
```

---

## 5. الكود المصدري البرمجي لبناء الهياكل الأساسية (Flutter Implementation)

### أ. نموذج البيانات للعب والبطاقات (`player.dart` & `role.dart`)

```dart
enum Team { town, mafia, neutral }
enum RoleType { villager, doctor, detective, godfather, mafia, jester, vigilante }

class Role {
  final String name;
  final RoleType type;
  final Team team;
  final String description;
  final String iconPath;

  const Role({
    required this.name,
    required this.type,
    required this.team,
    required this.description,
    required this.iconPath,
  });
}

class Player {
  final String id;
  final String name;
  final Role role;
  bool isAlive;
  int votesReceived;
  bool isProtected;
  bool isTargetedByMafia;

  Player({
    required this.id,
    required this.name,
    required this.role,
    this.isAlive = true,
    this.votesReceived = 0,
    this.isProtected = false,
    this.isTargetedByMafia = false,
  });

  Player copyWith({
    bool? isAlive,
    int? votesReceived,
    bool? isProtected,
    bool? isTargetedByMafia,
  }) {
    return Player(
      id: id,
      name: name,
      role: role,
      isAlive: isAlive ?? this.isAlive,
      votesReceived: votesReceived ?? this.votesReceived,
      isProtected: isProtected ?? this.isProtected,
      isTargetedByMafia: isTargetedByMafia ?? this.isTargetedByMafia,
    );
  }
}
```

---

### ب. خوارزمية التوزيع العشوائي للأدوار (`role_allocator.dart`)

```dart
import 'dart:math';
import '../features/game_play/domain/entities/player.dart';
import '../features/game_play/domain/entities/role.dart';

class RoleAllocator {
  static final List<Role> availableRolesPool = [
    const Role(
      name: 'زعيم المافيا',
      type: RoleType.godfather,
      team: Team.mafia,
      description: 'يقود المافيا ويظهر بريئاً للمحقق.',
      iconPath: 'assets/roles/godfather.png',
    ),
    const Role(
      name: 'مافيا',
      type: RoleType.mafia,
      team: Team.mafia,
      description: 'يصوت ليلاً مع أفراد المافيا للتخلص من الصالحين.',
      iconPath: 'assets/roles/mafia.png',
    ),
    const Role(
      name: 'طبيب',
      type: RoleType.doctor,
      team: Team.town,
      description: 'يحمي لاعباً واحداً كل ليلة من القتل.',
      iconPath: 'assets/roles/doctor.png',
    ),
    const Role(
      name: 'محقق',
      type: RoleType.detective,
      team: Team.town,
      description: 'يكشف هوية لاعب واحد كل ليلة.',
      iconPath: 'assets/roles/detective.png',
    ),
    const Role(
      name: 'مواطن صالح',
      type: RoleType.villager,
      team: Team.town,
      description: 'يعتمد على قوة التصويت والنقاش الكشف عن الخونة.',
      iconPath: 'assets/roles/villager.png',
    ),
    const Role(
      name: 'الجوكر',
      type: RoleType.jester,
      team: Team.neutral,
      description: 'هدفها أن يُصوّت ضدها القرية وتُعدم ليلاً ليحقق الفوز الفردي.',
      iconPath: 'assets/roles/jester.png',
    ),
  ];

  static List<Player> generatePlayers({
    required List<String> playerNames,
    required int mafiaCount,
    required int townCount,
  }) {
    List<Role> deck = [];

    // 1. إضافة أفراد المافيا
    deck.add(availableRolesPool.firstWhere((r) => r.type == RoleType.godfather));
    for (int i = 1; i < mafiaCount; i++) {
      deck.add(availableRolesPool.firstWhere((r) => r.type == RoleType.mafia));
    }

    // 2. إضافة أدوار الصالحين الخاصة
    deck.add(availableRolesPool.firstWhere((r) => r.type == RoleType.doctor));
    deck.add(availableRolesPool.firstWhere((r) => r.type == RoleType.detective));

    // 3. إكمال الباقي بالصالحين العاديين
    int remainingTown = townCount - 2;
    for (int i = 0; i < remainingTown; i++) {
      deck.add(availableRolesPool.firstWhere((r) => r.type == RoleType.villager));
    }

    // خلط الأدوار عشوائياً بشكل كامل
    deck.shuffle(Random());

    // ربط الأسماء بالأدوار
    List<Player> players = [];
    for (int i = 0; i < playerNames.length; i++) {
      players.add(
        Player(
          id: 'player_$i',
          name: playerNames[i].trim().isEmpty ? 'لاعب ${i + 1}' : playerNames[i],
          role: deck[i],
        ),
      );
    }

    return players;
  }
}
```

---

### ج. شاشة توزيع واستلام الأدوار المتتابعة (`role_reveal_page.dart`)

```dart
import 'package:flutter/material.dart';
import '../domain/entities/player.dart';

class RoleRevealPage extends StatefulWidget {
  final List<Player> players;
  final VoidCallback onRevealComplete;

  const RoleRevealPage({
    Key? key,
    required this.players,
    required this.onRevealComplete,
  }) : super(key: key);

  @override
  State<RoleRevealPage> createState() => _RoleRevealPageState();
}

class _RoleRevealPageState extends State<RoleRevealPage> {
  int currentIndex = 0;
  bool isRoleVisible = false;

  void _nextStep() {
    if (isRoleVisible) {
      // إخفاء البطاقة والتناوب للاعب التالي
      setState(() {
        isRoleVisible = false;
        if (currentIndex < widget.players.length - 1) {
          currentIndex++;
        } else {
          // الانتهاء من جميع اللاعبين والبدء بالليل الأول
          widget.onRevealComplete();
        }
      });
    } else {
      // إظهار البطاقة السرية للاعب الحالي
      setState(() {
        isRoleVisible = true;
      });
    }
  }

  @override
  Widget build(BuildContext me Context) {
    final currentPlayer = widget.players[currentIndex];

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAlignment.center,
            children: [
              Text(
                'اللاعب ${currentIndex + 1} من ${widget.players.length}',
                style: const TextStyle(color: Colors.grey, fontSize: 16),
              ),
              const SizedBox(height: 20),
              if (!isRoleVisible) ...[
                const Icon(Icons.screen_lock_portrait, size: 80, color: Colors.amber),
                const SizedBox(height: 20),
                Text(
                  'مرر الهاتف إلى:\n${currentPlayer.name}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                const Text(
                  'تأكد من أن لا أحد آخر ينظر إلى الشاشة!',
                  style: TextStyle(color: Colors.redAccent, fontSize: 14),
                ),
              ] else ...[
                Card(
                  color: const Color(0xFF1E1E1E),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        Text(
                          currentPlayer.name,
                          style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                        ),
                        const Divider(color: Colors.white24),
                        const SizedBox(height: 10),
                        Text(
                          currentPlayer.role.name,
                          style: TextStyle(
                            color: currentPlayer.role.team == Team.mafia ? Colors.red : Colors.green,
                            fontSize: 30,
                            fontWeight: FontWeight.black,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          currentPlayer.role.description,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white70, fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
              const Spacer(),
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.amber,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: _nextStep,
                  child: Text(
                    !isRoleVisible ? 'اظهار دوري السري' : 'إخفاء والتمرير للاعب التالي',
                    style: const TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
```

---

### د. نظام وتصميم مرحلة التصويت بالدور (`voting_page.dart`)

```dart
import 'package:flutter/material.dart';
import '../domain/entities/player.dart';

class VotingPage extends StatefulWidget {
  final List<Player> alivePlayers;
  final Function(Map<String, String>) onVotingComplete; // Map<VoterId, TargetPlayerId>

  const VotingPage({
    Key? key,
    required this.alivePlayers,
    required this.onVotingComplete,
  }) : super(key: key);

  @override
  State<VotingPage> createState() => _VotingPageState();
}

class _VotingPageState extends State<VotingPage> {
  int currentVoterIndex = 0;
  final Map<String, String> votesMap = {};
  String? selectedTargetId;

  void _submitVote() {
    if (selectedTargetId == null) return;

    final voter = widget.alivePlayers[currentVoterIndex];
    votesMap[voter.id] = selectedTargetId!;

    if (currentVoterIndex < widget.alivePlayers.length - 1) {
      setState(() {
        currentVoterIndex++;
        selectedTargetId = null;
      });
    } else {
      widget.onVotingComplete(votesMap);
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentVoter = widget.alivePlayers[currentVoterIndex];

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text('مرحلة التصويت الرسمي'),
        backgroundColor: Colors.black,
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.amber.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  const Icon(Icons.how_to_vote, color: Colors.amber),
                  const SizedBox(width: 10),
                  Text(
                    'دور المصوّت: ${currentVoter.name}',
                    style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 15),
            const Text(
              'اختر الشخص الذي تشك به وتريد إعدامه:',
              style: TextStyle(color: Colors.white70, fontSize: 16),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: widget.alivePlayers.length,
                itemBuilder: (context, index) {
                  final candidate = widget.alivePlayers[index];
                  // لا يمكن للاعب التصويت لنفسه
                  if (candidate.id == currentVoter.id) return const SizedBox.shrink();

                  final isSelected = selectedTargetId == candidate.id;

                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        selectedTargetId = candidate.id;
                      });
                    },
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 6),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: isSelected ? Colors.red.withOpacity(0.3) : const Color(0xFF1E1E1E),
                        border: Border.all(color: isSelected ? Colors.red : Colors.white10),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            candidate.name,
                            style: const TextStyle(color: Colors.white, fontSize: 18),
                          ),
                          if (isSelected) const Icon(Icons.check_circle, color: Colors.red),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: selectedTargetId != null ? Colors.red : Colors.grey,
                ),
                onPressed: selectedTargetId != null ? _submitVote : null,
                child: Text(
                  currentVoterIndex < widget.alivePlayers.length - 1
                      ? 'تأكيد الصوت والتمرير للتالي'
                      : 'إرسال وإنهاء التصويت',
                  style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
```

---

## 6. منطق كشف النتائج وحساب الفوز والتصنيف النهائي (`game_engine.dart`)

```dart
import '../domain/entities/player.dart';
import '../domain/entities/role.dart';

class GameResult {
  final bool isGameOver;
  final Team? winningTeam;
  final String reason;

  GameResult({required this.isGameOver, this.winningTeam, required this.reason});
}

class GameEngine {
  // فرز نتائج التصويت النهائيوكشف البطاقة
  static Player getLynchTarget(List<Player> alivePlayers, Map<String, String> votesMap) {
    Map<String, int> voteCounts = {};

    for (var targetId in votesMap.values) {
      voteCounts[targetId] = (voteCounts[targetId] ?? 0) + 1;
    }

    String? highestVotedPlayerId;
    int maxVotes = -1;

    voteCounts.forEach((playerId, count) {
      if (count > maxVotes) {
        maxVotes = count;
        highestVotedPlayerId = playerId;
      }
    });

    return alivePlayers.firstWhere((p) => p.id == highestVotedPlayerId);
  }

  // فحص شروط انتهاء اللعبة
  static GameResult checkWinConditions(List<Player> allPlayers) {
    final alivePlayers = allPlayers.where((p) => p.isAlive).toList();
    final aliveMafia = alivePlayers.where((p) => p.role.team == Team.mafia).toList();
    final aliveTown = alivePlayers.where((p) => p.role.team == Team.town).toList();

    // 1. فوز الصالحين: انتهاء المافيا بالكامل
    if (aliveMafia.isEmpty) {
      return GameResult(
        isGameOver: true,
        winningTeam: Team.town,
        reason: 'نجح الصالحون في تطهير المدينة من جميع أفراد المافيا!',
      );
    }

    // 2. فوز المافيا: تساؤي أو تفوق المافيا في العدد
    if (aliveMafia.length >= aliveTown.length) {
      return GameResult(
        isGameOver: true,
        winningTeam: Team.mafia,
        reason: 'سيطرت المافيا على القرية بعد أن تساوى عددهم مع الصالحين!',
      );
    }

    return GameResult(isGameOver: false, reason: 'اللعبة مستمرة');
  }

  // حساب الشخصية المميزة والأكثر تأثيراً في اللعبة
  static String calculateMVP(List<Player> allPlayers, Map<String, int> successfulActions) {
    // بناءً على من قام بأفضل حمايات (الطبيب) أو أدق فحوصات (المحقق) أو أكثر تصويت دقيق
    Player? mvpPlayer;
    int maxScore = -1;

    for (var player in allPlayers) {
      int score = successfulActions[player.id] ?? 0;
      if (score > maxScore) {
        maxScore = score;
        mvpPlayer = player;
      }
    }

    return mvpPlayer != null
        ? '${mvpPlayer.name} (${mvpPlayer.role.name})'
        : 'جميع اللاعبين قدموا أداءً ممتازاً!';
  }
}
```

---

## 7. دليل شاشة النتائج والتصنيف النهائي (Game Over & Summary UI Design)

عند تحقق شرط نهاية اللعبة، يتم عرض شاشة ختامية تشمل التالي:
1. **شعار وسطر الفوز:** (مثل: "فوز الصالحين 🏆" أو "فوز المافيا 🔪").
2. **وسام أفضل لاعب (MVP):** إبراز الشخص المميز في الجولة الذي حسم النتيجة بقراراته.
3. **قائمة الأدوار الكاملة (The Master Reveal List):** عرض كشف حساب لجميع اللاعبين (الأحياء والأموات) وأدوارهم التي لعبوها في الخفاء.
4. **زر إعادة اللعب بنفس الأسماء (Replay):** يعيد خلط البطاقات عشوائياً بدون الحاجة لإعادة كتابة الأسماء.