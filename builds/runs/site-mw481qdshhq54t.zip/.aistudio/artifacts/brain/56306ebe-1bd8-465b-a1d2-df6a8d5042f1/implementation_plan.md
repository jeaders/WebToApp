# Mafia Noir: Pass & Play Social Deduction Game (مافيا: ليلة الخداع)

An interactive, atmospheric Pass & Play Mafia party game featuring a dramatic 3D noir conference table with dynamic day-to-night lighting transitions, procedural case file props, bilingual Arabic/English support, and high-stakes social deduction mechanics conforming strictly to the official Mafia documentation.

---

> [!IMPORTANT]
> **User Review & Confirmed Design Decisions**
> 
> - **Confirmed 3D Atmosphere**: Atmospheric 1930s Noir 3D round table in Three.js with dynamic day-to-night lighting, vintage desk lamp, procedural dossier folders, antique revolver, doctor's syringe/vial, and gavel props.
> - **Confirmed Language Interface**: Arabic primary (with native RTL layout, Cairo/Amiri typography, authentic terminology) paired with an instant English toggle in the top control bar.
> - **Game Flow Compliance**: Full adherence to the attached `mafia_game_documentation_b0aad2de.md` specification—Setup & Custom Roster -> Secret Role Reveal -> Night Actions (Mafia kill, Doctor protect, Detective inspect, Vigilante bullet) -> Dawn Reveal -> Timed Discussion -> Round-Robin Secret Lynch Voting -> Win Conditions Check -> Master Reveal & MVP Ceremony.

---

## 1. Overview & Core Concept

**Mafia Noir** translates the classic living-room social deduction party game into an engaging digital pass-and-play experience on a single shared device (phone, tablet, or laptop screen passed between friends).

- **Core Gameplay**: 4 to 16 players take turns receiving secret roles. By night, evil conspirators assassinate citizens while specialists secretly heal and investigate. By day, the town gathers around the table to debate, cross-examine, and vote to lynch suspected criminals.
- **The Twist & Polish**: Rather than static text cards, the game is staged inside an evocative, cinematic 3D safehouse. When night falls, the 3D scene dims into deep moonlit shadows and warm desk lamp amber; when morning breaks, sunlight cuts through Venetian blinds to illuminate the survivor dossiers.
- **Special Roles**:
  - **Town (الصالحين)**: Villager (المواطن), Doctor (الطبيب - protects 1 target, self-heal once), Detective (المحقق - inspects 1 target; Godfather appears innocent), Vigilante (القناص - 1 bullet per game).
  - **Mafia (المافيا)**: Regular Mafia (مافيا), Godfather (زعيم المافيا - priority killer, immune to detective inspection).
  - **Neutral (محايد)**: Jester (الجوكر - wins solo if lynched by vote).

---

## 2. User Experience & Visual Design

### Key User Flows

```
┌─────────────────┐      ┌─────────────────┐      ┌─────────────────────────┐
│  Title Screen   │ ───► │  Roster Setup   │ ───► │ Pass & Play Card Reveal │
│ 3D Noir Table   │      │ Players & Roles │      │ "Hand phone to [Name]"  │
└─────────────────┘      └─────────────────┘      └─────────────────────────┘
                                                               │
                                                               ▼
┌─────────────────┐      ┌─────────────────┐      ┌─────────────────────────┐
│ Lynch & Reveal  │ ◄─── │ Secret Voting   │ ◄─── │ Dawn & Discussion Timer │
│ Win Check / MVP │      │ Pass & Vote     │      │ Night report + speech   │
└─────────────────┘      └─────────────────┘      └─────────────────────────┘
        │                                                      ▲
        ▼                                                      │
┌─────────────────┐                                            │
│   Next Night    │ ───────────────────────────────────────────┘
│   Phase Cycle   │
└─────────────────┘
```

1. **Title Screen (شاشة البداية)**:
   - Full-bleed 3D camera pan over an illuminated mahogany table with a vintage lamp, detective notebook, pocket watch, and cards. Bespoke Arabic/English title lockup, "Start Game" CTA, and rules modal.
2. **Setup & Roles Customizer (إعداد اللاعبين)**:
   - Quick presets (6, 8, 10, 12 players) or custom roster entry. Real-time balance calculator showing Town vs Mafia ratios, and toggles for special roles (Godfather, Doctor, Detective, Vigilante, Jester).
3. **Pass & Play Secret Reveal Loop (توزيع الأدوار بالسر)**:
   - "Pass phone to [Player Name]" privacy curtain -> Press & hold or tap "Reveal My Role" -> Beautiful flip-card animation with role title, faction emblem, and action abilities -> "Cover & Pass to Next Player".
4. **Night Phase (مرحلة الليل)**:
   - 3D table dims into midnight ambient fog with soft spotlighting.
   - Screen requests each waking role secretly or moderator-led:
     - *Mafia*: Pick victim from alive townspeople.
     - *Doctor*: Pick a player to protect from murder.
     - *Detective*: Choose one player to investigate (results revealed as "Clean" or "Mafia").
     - *Vigilante*: Optional shot (once per game).
5. **Dawn Phase & Discussion (مرحلة الصباح والنقاش)**:
   - Morning sunray lighting transition. Newspaper headline reporting the night's victim or dramatic headline: "Everyone survived! The Doctor saved a life."
   - Discussion timer (e.g. 90s/120s with pause, +30s, and chime sound effects). Player accusations note-pad.
6. **Round-Robin Voting (مرحلة التصويت الرسمي)**:
   - Secret voting booth (pass phone to each living player in turn to cast their ballot privately, eliminating peer-pressure) OR open show-of-hands vote tally.
7. **Execution & Win Resolution (الإعدام ونهاية اللعبة)**:
   - Cinematic gavel strike / dossier stamp. Highest voted player eliminated with role card reveal (unless Jester, which triggers instant Jester victory!).
   - Win condition evaluation: Mafia eradicated = Town Victory; Mafia >= Town = Mafia Victory.
8. **Game Over & MVP Summary (شاشة النتائج والتصنيف)**:
   - Grand victory banner, Master Reveal list showing all secret roles, and algorithmically calculated MVP (most clutch doctor save, detective discoveries, or decisive voting). Replay button preserving player names!

### Visual Identity & Theme
- **Aesthetic Direction**: 1930s Film Noir meets modern confidential intelligence dossier.
- **Color Palette**: Deep obsidian (`#0A0A0C`), warm cigar-box mahogany (`#1A1412`), aged parchment cream (`#F4EEDD`), crimson mafia red (`#DC2626`), emerald town green (`#10B981`), amber lamplight (`#F59E0B`).
- **Typography**: Arabic rendered with crisp Cairo/Amiri serif styling; English in elegant Playfair Display / Inter pairing.
- **Audio Feedback**: Procedural Web Audio synth (clock ticking, gavel impact, dramatic reveal drone, heartbeat during night phase, cheerful victory fanfare) with global mute switch.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Zero-Dependency Procedural 3D Noir Scene**
  - *Approach*: Built with Three.js r160+ using procedural geometry (`LatheGeometry` for table lamp and drinking glasses, beveled `BoxGeometry` for vintage books and case dossiers, `ExtrudeGeometry` for revolver silhouette and gavel) and `CanvasTexture` bump maps.
  - *Why*: Eliminates 404 errors, zero external model lag, instant loading, and runs buttery smooth on desktop and mobile.
- **Decision 2: Pass & Play Privacy Safeguards**
  - *Approach*: Double-curtain screen ("Are you [Name]?" with clear confirmation before showing private information) and immediate auto-hiding when passing.
  - *Why*: Prevents peeking in local party environments.
- **Decision 3: Dual Mode (Direct Player Pass-and-Play vs Moderator Narrator Mode)**
  - *Approach*: The app can act as the automated pass-and-play machine (passing phone each night/vote) OR as an interactive Narrator companion for a human game master.
- **Decision 4: Bilingual RTL/LTR Architecture**
  - *Approach*: Dedicated localization dictionary supporting instant switching between Arabic (`dir="rtl"`) and English (`dir="ltr"`).

---

## 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────┐
│                      React Application                      │
│                                                             │
│  ┌─────────────────────────┐   ┌─────────────────────────┐  │
│  │   Language / I18n       │   │    Web Audio Synth      │  │
│  │  (Arabic / English)     │   │  (Gavel, Ticks, Stems)  │  │
│  └───────────┬─────────────┘   └────────────┬────────────┘  │
│              │                              │               │
│  ┌───────────▼──────────────────────────────▼────────────┐  │
│  │                   Mafia Game Engine                   │  │
│  │  - Player Roster & Role Allocator                     │  │
│  │  - Night Actions Resolver (Kills vs Doctor Saves)     │  │
│  │  - Vote Tally & Lynch Logic                           │  │
│  │  - Win Condition Evaluator & MVP Scoring System       │  │
│  └───────────┬──────────────────────────────┬────────────┘  │
│              │                              │               │
│  ┌───────────▼─────────────┐   ┌────────────▼────────────┐  │
│  │    2D Pass & Play UI    │   │  Three.js 3D Viewport   │  │
│  │ - Setup & Customizer    │   │ - Mahogany Round Table  │  │
│  │ - Role Reveal Flippers  │   │ - Ambient Noir Desk Lamp│  │
│  │ - Night Action Prompts  │   │ - Day/Night Transitions │  │
│  │ - Discussion & Voting   │   │ - Procedural Props      │  │
│  └─────────────────────────┘   └─────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### Core State Models

- `Role`: `{ id, nameAr, nameEn, team: 'town'|'mafia'|'neutral', descriptionAr, descriptionEn, icon, ability }`
- `Player`: `{ id, name, role, isAlive, votesReceived, isProtected, isTargeted, investigationRevealed }`
- `GameState`:
  - `phase`: `'TITLE' | 'RULES' | 'SETUP' | 'REVEAL_ROLES' | 'NIGHT_MAFIA' | 'NIGHT_DOCTOR' | 'NIGHT_DETECTIVE' | 'NIGHT_VIGILANTE' | 'DAWN_REPORT' | 'DAY_DISCUSSION' | 'VOTING' | 'LYNCH_RESULT' | 'GAME_OVER'`
  - `dayNumber`: integer
  - `actionLog`: night targets, saves, investigations, and vote tallies
  - `mvpData`: action points tracker for saves, catches, and clutch votes

---

## 5. Verification & Testing Plan

1. **Compilation & Linting**: Verify clean TypeScript types, no missing exports, and co-execute `compile_applet` and `lint_applet`.
2. **Game Logic Validation**:
   - Test Mafia kill blocked when Doctor protects the same player.
   - Test Detective inspection correctly reporting Godfather as "Town/Clean".
   - Test Jester instant solo win upon being lynched during Day voting.
   - Test Town win when last Mafia is eliminated.
   - Test Mafia win when Mafia count >= Town count.
3. **Pass & Play Flow**:
   - Verify seamless progression through all player reveals with privacy covers.
   - Verify secret round-robin ballot voting and tie-breaker mechanics.
4. **Three.js Performance & Responsiveness**:
   - Validate smooth 60fps rendering, day-to-night lighting transitions, resize handling, and mobile layout.
