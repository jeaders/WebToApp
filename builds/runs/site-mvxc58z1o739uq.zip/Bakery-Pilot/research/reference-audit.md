# Bakery Pilot — Reference Audit & Product Contract

**Source URL:** https://replit.com/@winsbig365/Bakery-Pilot?s=app
**Audit date:** 2026-10-25 (resumed 2026-10-27)
**Disposition:** New build from concept, not a verified reproduction of the Replit project.

## Product summary

| Field | Finding | Evidence | Confidence | Rebuild consequence |
|---|---|---|---|---|
| Product promise | The supplied Replit page displays “Page not found”; no product promise was observable. Bakery Pilot is being created as a bakery operations control center based on its name and the user's instruction to create a new app from the concept. | Replit URL above returned Replit 404 page. | Observed 404; product framing inferred | Treat the app as a new concept. Do not claim continuity with, or fidelity to, the inaccessible Replit build. |
| Intended audience | Independent bakery owners and managers. | Inferred from “Bakery Pilot” and approved build scope. | Inferred | Prioritize quick daily decisions, clear production status, low-friction data entry, and a responsive floor-friendly view. |
| Primary user job | Turn customer demand, recipes, stock, and available production into a feasible daily bake plan, then track execution. | Approved Bakery Pilot scope saved for this project. | Inferred from approved scope | Make demand-to-bake planning the primary workflow, with the daily operations view as the landing surface. |
| Core differentiator | Connect open orders to recipe requirements, inventory constraints, batch counts, and progress in one operational loop. | Approved Bakery Pilot scope saved for this project. | Inferred/product design | Model the linked workflow; avoid disconnected placeholder dashboard tiles. |
| Primary CTA | Not observable on the reference. For the new app, prioritize “Build today’s plan” and the next missing setup action. | Reference 404; new product decision. | Unverified / designed | Dashboard should provide contextual next actions and useful empty states. |
| Access model | Reference access model unknown. New app uses authenticated owner workspaces with data scoped to the signed-in owner. | Reference 404; approved scope requests Manus OAuth and owner-level isolation. | Inferred for new app | Use Manus OAuth and ensure every business query/mutation is owner-scoped server-side. |

## Navigation map

| Route | Public/private | Purpose | Entry points | Exit / next action | Evidence |
|---|---|---|---|---|---|
| Replit reference URL | Unavailable | Could not inspect the actual product. | User-supplied URL | Request was clarified to create a new app from the concept. | Observed 404 on 2026-10-25. |
| `/` | Private after authentication | Daily operations dashboard and primary bake-plan workflow. | OAuth return / app navigation | Open orders, recipes, inventory, production, reports. | Inferred new-build route. |
| `/orders` | Private | Manage customer demand and fulfillment status. | Dashboard, navigation | Plan production or update fulfillment. | Inferred from approved scope. |
| `/recipes` | Private | Manage yields, ingredients, costs, and suggested prices. | Navigation, plan editor | Update stock requirements and margin insights. | Inferred from approved scope. |
| `/inventory` | Private | Review on-hand stock, reorder thresholds, and stock movements. | Dashboard, navigation, shortages | Receive stock or adjust waste/usage. | Inferred from approved scope. |
| `/production` | Private | Build daily plans and track recipe batches and actual yield. | Dashboard, orders, navigation | Record progress and ingredient consumption. | Inferred from approved scope. |
| `/reports` | Private | Date-based summaries of sales, output, usage, waste, costs, margin, and stock risks. | Navigation | Return to dashboard / change date range. | Inferred from approved scope. |
| `/settings` | Private | Edit bakery name, currency, timezone, and daily batch capacity. | Navigation / dashboard settings action | Return to planning and reporting. | Added in the new concept build. |

## Core workflow

| Step | User action | Input/state | System response | Result/state | Failure or empty state | Implementation requirement |
|---|---|---|---|---|---|---|
| 1 | Sign in and enter the bakery workspace. | Manus OAuth identity; owner workspace may have no data yet. | Resolve authenticated owner; load only that owner's records. | Private daily operations view. | Logged-out state, OAuth failure, loading, or empty-workspace onboarding. | Use supplied OAuth/session helpers; protect writes and isolate all business rows by owner ID. |
| 2 | Create recipes and ingredients; enter stock and reorder thresholds. | Recipe yield, ingredient quantities/units, prices, inventory quantity, threshold. | Validate values; compute batch/unit cost, gross margin, and suggested selling price; persist records. | Recipe book and inventory with auditable stock movements. | No recipes/stock; invalid quantities; server or persistence failure with retry. | Store actual user input; server-side validation and calculations; preserve unit consistency. |
| 3 | Record customer orders and requested items, quantities, and due dates. | Order line items; fulfillment status. | Persist order; derive open demand by recipe and date. | Order queue and demand signal. | No orders; invalid date/quantity; order references a missing recipe. | CRUD with owner scoping; explicit status transitions; retain useful order history. |
| 4 | Generate and refine a bake plan for a selected date. | Open orders, recipe yields, inventory, planned capacity/batches. | Aggregate required quantities, recommend recipe batch counts, surface ingredient shortages, allow edits. | Feasible daily production plan linked to orders and ingredient needs. | No demand; missing recipe links; insufficient inventory; incomplete setup. | Deterministic, explainable calculations using current persisted records—not hardcoded recommendations. |
| 5 | Track batches through production and fulfillment. | Planned quantity/date/time, status, actual yield, consumed/wasted ingredients. | Update batch progress and stock movements; refresh dashboard and cost summaries. | Current execution state and auditable ingredient use. | Invalid transition, stale stock, or persistence failure; let user retry safely. | Persist state changes and movements atomically where possible; make state transitions explicit. |
| 6 | Review operating summaries. | Selected date/range and persisted bakery data. | Aggregate order volume, output, usage/waste, inventory risks, revenue, costs, and margin. | Actionable summaries derived from actual records. | No data for range; partial/failed data loads with clear retry. | No fake metrics; label currency/unit sources and date boundaries. |

## Data model

| Object | Fields observed or required | Owner | Lifecycle | Persistence requirement |
|---|---|---|---|---|
| User/account | Manus OAuth `openId`, name, email, timestamps. | Authenticated Manus identity | OAuth upsert, sign-in | Use supplied users table; no fabricated Preview identity. |
| Bakery profile | Name, timezone, locale/currency, capacity preferences where supported. | User | Setup/edit | Persist as owner-scoped settings. |
| Ingredient | Name, unit, current quantity, reorder point, unit cost, active state. | User | Create/edit/archive | Durable; quantities changed through auditable stock movements. |
| Recipe | Name, yield, ingredient links and required quantities, selling price, target margin. | User | Create/edit/archive | Durable; cost rollups derive from current ingredient prices. |
| Customer order | Customer label/contact where entered, due date, status, line items, notes. | User | Create/edit/status transitions | Durable; status history or updated timestamp retained. |
| Production plan/batch | Date/time, recipe, target quantity, recommended batch count, status, actual yield. | User | Generate/refine/start/complete | Durable; records link to demand and stock movements. |
| Stock movement | Ingredient, quantity delta, type (purchase/adjustment/waste/production), reference, note, timestamp. | User | Append-only | Durable audit trail; no direct unexplained stock mutation. |
| Report aggregates | Derived from saved orders, batches, recipes, and movements. | User | On demand | Compute from real data; do not persist fake fixture summaries. |

## Design direction

No visual direction was provided by the user or verifiable on the reference. Candidate styles considered: warm neo-artisan operations desk (0.06), restrained Swiss editorial ledger (0.04), and stark production-console minimalism (0.02). **Selected: warm neo-artisan operations desk.** Probabilities are exploratory design preferences, not user preferences.

| Category | Decision |
|---|---|
| Background / surface | Warm flour/cream canvas with clean white cards for dense operational information. |
| Accent / signal color | Ownable toasted-clay / terracotta for primary actions; sage for ready/complete; amber and berry for stock risk and blockers. |
| Foreground / muted text | Deep espresso ink, with warm gray secondary text and clear contrast. |
| Typography | Fraunces for editorial page titles and DM Sans for compact, highly legible controls and data. |
| Headline scale | Calm, compact headings; use a short operational sentence rather than oversized marketing copy. |
| Body scale / rhythm | 14–16 px operational text, generous line height, clear hierarchy between label, value, and explanation. |
| Layout paradigm | Persistent narrow left rail on desktop; date-aware command surface and task panels; mobile collapses navigation and prioritizes the plan and next action. Avoid a wall of identical KPI cards. |
| Signature elements | Small oven-heat/progress markers for batch state; paper-like warm surfaces with fine ruled separators; a terracotta “next action” treatment. |
| Interaction | Fast, direct task completion; preserve filters and date selection; visible validation; keyboard focus; avoid decorative motion in repeated workflows. |
| Animation | Short ease-out feedback only for occasional panels/toasts; reduced-motion support; no looping or attention-stealing animation. |
| Mobile behavior | Stack operational sections, keep primary actions reachable, use horizontally scrollable date/filters only when needed, prevent dense tables from clipping. |
| Brand essence | “The steady hand behind a better bake day.” For independent bakery teams; practical, warm, exact. Personality: grounded, capable, calm. |
| Brand voice | Headings say what needs doing (“Today’s bake plan”); microcopy explains the next step plainly (“Add recipes to turn open orders into batch quantities.”). |
| Mark | A minimal oven/loaf mark paired with the Bakery Pilot wordmark; keep dashboard icon small and legible. |

## Research comparison

No competitor comparison was performed. The source app was inaccessible, and the requested deliverable is a new concept build, not a market study. No category or competitor claims are asserted here.

## Rebuild contract

- **Core user job:** Convert orders, recipes, inventory, and production capacity into a feasible daily bake plan and track it through completion.
- **Minimum happy path:** Sign in → add ingredients and recipes → create an order → generate/refine the date's production plan → track batches and stock movements → review actual operating summaries.
- **Real input:** Authenticated owner-entered products, recipes, ingredient quantities/costs, inventory movements, orders, batch plans, production status/yield, and report date range.
- **Real output:** Database-backed daily demand and bake plan, explainable shortage/batch recommendations, recipe/order cost and margin rollups, and date-based operating summaries.
- **Persistent state:** Owner-isolated MySQL-compatible records through Drizzle/tRPC and Manus OAuth; do not use shared demo records or local-only state as the source of truth.
- **Supporting routes:** `/`, `/orders`, `/recipes`, `/inventory`, `/production`, `/reports`, `/404`, plus authentication entry/return handled by the supplied platform flow.
- **Faithful elements:** The name and bakery-operations concept only; nothing about the original Replit UI or workflow could be verified.
- **Intentional improvements:** A linked order-to-plan-to-production workflow; clear shortage and cost signals; auditable stock usage; mobile-first production status; owner data isolation; robust explicit empty/loading/error/success states.
- **Unverified or blocked assumptions:** Replit app is not publicly accessible at the supplied URL; original routes, data, brand, functionality, users, integrations, pricing, and design are unknown. The new app must be described as an independent concept build.
