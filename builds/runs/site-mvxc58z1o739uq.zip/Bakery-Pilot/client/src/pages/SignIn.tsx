import { ArrowRight, ShieldCheck, Wheat } from "lucide-react";
import { useState } from "react";
import { startLogin } from "@/const";

export default function SignIn() {
  const [error, setError] = useState("");
  const beginLogin = () => {
    setError("");
    try {
      startLogin();
    } catch {
      setError("Secure sign-in isn’t available right now. Refresh this page and try again.");
    }
  };
  return <main className="signin-page">
    <section className="signin-panel" aria-labelledby="signin-title">
      <div className="signin-brand"><span className="brand-mark large"><Wheat size={24} aria-hidden="true" /></span><div><strong>Bakery Pilot</strong><small>THE DAILY BAKE, IN HAND</small></div></div>
      <div className="signin-copy"><p className="eyebrow">YOUR BAKERY, IN RHYTHM</p><h1 id="signin-title">Make every bake day feel a little more in hand.</h1><p>Bring orders, recipes, ingredients, and production into one calm place. Start with what you have; build your workflow as you go.</p></div>
      <button className="button button-primary signin-button" type="button" onClick={beginLogin}>Continue with Manus <ArrowRight size={17} aria-hidden="true" /></button>
      {error && <p className="signin-error" role="alert">{error}</p>}
      <p className="signin-security"><ShieldCheck size={16} aria-hidden="true" /> Your bakery records are private to your signed-in account.</p>
    </section>
    <aside className="signin-aside" aria-label="Bakery Pilot product overview">
      <div className="aside-grain" aria-hidden="true" />
      <div className="oven-card">
        <div className="oven-topline"><span>BAKE DAY / 01</span><span className="oven-live"><i /> READY WHEN YOU ARE</span></div>
        <div className="oven-art" aria-hidden="true"><div className="oven-arch"><div className="oven-loaf" /><div className="oven-score score-one" /><div className="oven-score score-two" /><div className="oven-glow" /></div><div className="oven-base" /></div>
        <div className="oven-caption"><span>From first order<br />to final tray.</span><strong>One steady rhythm.</strong></div>
      </div>
      <div className="aside-footnote"><span>ORDERS → RECIPES → INVENTORY → PRODUCTION</span><span>BUILT FOR THE PEOPLE BEHIND THE COUNTER</span></div>
    </aside>
  </main>;
}
