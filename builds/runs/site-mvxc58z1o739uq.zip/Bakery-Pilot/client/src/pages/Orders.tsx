import { useMemo, useState, type FormEvent } from "react";
import { ClipboardList, Plus, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { formatCurrency, formatDate, formatQuantity, todayISO } from "@/lib/format";
import { EmptyState, ErrorState, LoadingState, PageHeading, StatusPill } from "@/components/Ui";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Link } from "wouter";

const statusOptions: Record<string, string[]> = {
  new: ["confirmed", "cancelled"],
  confirmed: ["in_production", "ready", "cancelled"],
  in_production: ["ready", "cancelled"],
  ready: ["completed", "in_production"],
  completed: [],
  cancelled: [],
};
type Line = { recipeId: string; quantity: string };

export default function Orders() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | undefined>();
  const [customerName, setCustomerName] = useState("");
  const [dueDate, setDueDate] = useState(todayISO());
  const [notes, setNotes] = useState("");
  const [lines, setLines] = useState<Line[]>([{ recipeId: "", quantity: "1" }]);
  const [formError, setFormError] = useState("");
  const orders = trpc.bakery.orders.list.useQuery({});
  const recipes = trpc.bakery.recipes.list.useQuery();
  const settings = trpc.bakery.settings.get.useQuery();
  const utils = trpc.useUtils();

  const save = trpc.bakery.orders.save.useMutation({
    onSuccess: async () => {
      toast.success(editingId ? "Order updated." : "Order added to the queue.");
      setOpen(false);
      resetForm();
      await Promise.all([
        utils.bakery.orders.list.invalidate(),
        utils.bakery.dashboard.snapshot.invalidate(),
        utils.bakery.production.preview.invalidate(),
        utils.bakery.reports.summary.invalidate(),
      ]);
    },
    onError: error => { setFormError(error.message); toast.error(error.message); },
  });
  const updateStatus = trpc.bakery.orders.updateStatus.useMutation({
    onSuccess: async () => {
      toast.success("Order status updated.");
      await Promise.all([
        utils.bakery.orders.list.invalidate(),
        utils.bakery.dashboard.snapshot.invalidate(),
        utils.bakery.production.preview.invalidate(),
        utils.bakery.reports.summary.invalidate(),
      ]);
    },
    onError: error => toast.error(error.message),
  });

  function resetForm() {
    setEditingId(undefined);
    setCustomerName("");
    setDueDate(todayISO(settings.data?.timezone ?? "UTC"));
    setNotes("");
    setLines([{ recipeId: "", quantity: "1" }]);
    setFormError("");
  }

  function openNew() {
    resetForm();
    setOpen(true);
  }

  function openEdit(order: NonNullable<typeof orders.data>[number]) {
    setEditingId(order.id);
    setCustomerName(order.customerName);
    setDueDate(order.dueDate);
    setNotes(order.notes ?? "");
    setLines(order.items.map(item => ({ recipeId: String(item.recipeId), quantity: String(item.quantity) })));
    setFormError("");
    setOpen(true);
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFormError("");
    const parsedLines = lines
      .filter(line => line.recipeId && Number(line.quantity) > 0)
      .map(line => ({ recipeId: Number(line.recipeId), quantity: Number(line.quantity) }));
    if (parsedLines.length === 0) {
      setFormError("Add at least one recipe and quantity.");
      return;
    }
    save.mutate({ id: editingId, customerName, dueDate, notes: notes || undefined, items: parsedLines });
  }

  const visibleOrders = useMemo(() => (orders.data ?? []).filter(order => {
    const statusMatches = statusFilter === "all" || order.status === statusFilter;
    const searchMatches = !search.trim() || `${order.customerName} ${order.notes ?? ""}`.toLowerCase().includes(search.trim().toLowerCase());
    return statusMatches && searchMatches;
  }), [orders.data, search, statusFilter]);
  const currency = settings.data?.currency ?? "USD";
  const activeRecipes = recipes.data ?? [];
  const editingOrder = orders.data?.find(order => order.id === editingId);
  const productionStarted = editingOrder ? ["in_production", "ready"].includes(editingOrder.status) : false;

  return <div className="page-shell">
    <PageHeading
      eyebrow="CUSTOMER DEMAND"
      title="Orders, without the loose ends."
      description="Capture what’s due, see order value and recipe costs, then turn open demand into a production plan."
      action={<button className="button button-primary" type="button" disabled={settings.isLoading} onClick={openNew}><Plus size={16} />New order</button>}
    />

    <div className="order-toolbar">
      <div className="search-wrap"><Search size={15} aria-hidden="true" /><input aria-label="Search orders" className="field-control search-control" placeholder="Search customer or note" value={search} onChange={event => setSearch(event.target.value)} /></div>
      <label className="sr-only" htmlFor="order-status-filter">Filter orders by status</label>
      <select id="order-status-filter" className="field-control filter-select" value={statusFilter} onChange={event => setStatusFilter(event.target.value)}>
        <option value="all">All statuses</option><option value="new">New</option><option value="confirmed">Confirmed</option><option value="in_production">In production</option><option value="ready">Ready</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option>
      </select>
      <span className="toolbar-count">{visibleOrders.length} order{visibleOrders.length === 1 ? "" : "s"}</span>
    </div>

    {orders.isLoading
      ? <LoadingState label="Loading orders…" />
      : orders.error
        ? <ErrorState message={orders.error.message} onRetry={() => void orders.refetch()} />
        : visibleOrders.length === 0
          ? <section className="panel"><EmptyState icon={ClipboardList} title={orders.data?.length ? "No orders match these filters." : "The order queue is clear."} description={orders.data?.length ? "Try another status or search term." : "Add a customer order to begin building your demand picture. Orders are saved to your private bakery workspace."} action={<button className="button button-secondary" type="button" onClick={openNew}><Plus size={15} />Add an order</button>} /></section>
          : <section className="panel"><div className="data-table-wrap"><table className="data-table">
            <thead><tr><th>Customer / items</th><th>Due date</th><th>Status</th><th>Order value</th><th>Est. gross profit</th><th><span className="sr-only">Actions</span></th></tr></thead>
            <tbody>{visibleOrders.map(order => <tr key={order.id}>
              <td><div className="primary-cell">{order.customerName}</div><div className="secondary-cell">{order.items.map(item => `${formatQuantity(item.quantity)} × ${item.recipeName}`).join(" · ")}</div></td>
              <td>{formatDate(order.dueDate, { month: "short", day: "numeric", year: "numeric" })}</td>
              <td><div className="status-cell"><StatusPill status={order.status} />{statusOptions[order.status]?.length > 0 && <>
                <label className="sr-only" htmlFor={`status-${order.id}`}>Move {order.customerName} order to another status</label>
                <select id={`status-${order.id}`} className="status-select" value="" disabled={updateStatus.isPending} onChange={event => { if (event.target.value) updateStatus.mutate({ id: order.id, status: event.target.value as "new" | "confirmed" | "in_production" | "ready" | "completed" | "cancelled" }); }}>
                  <option value="">Move to…</option>{statusOptions[order.status].map(status => <option key={status} value={status}>{status.replaceAll("_", " ")}</option>)}
                </select>
              </>}</div></td>
              <td className="money-cell">{formatCurrency(order.total, currency)}</td>
              <td className="money-cell">{formatCurrency(order.grossProfit, currency)}<div className="secondary-cell">{order.margin.toFixed(0)}% margin</div></td>
              <td><div className="table-actions">{!["completed", "cancelled"].includes(order.status) && <button className="button button-secondary button-sm" type="button" onClick={() => openEdit(order)}>Edit</button>}</div></td>
            </tr>)}</tbody>
          </table></div></section>}

    <div className="orders-footer-note"><span>Prices and recipe costs are snapshotted when an order is saved.</span><Link href="/production" className="inline-link">Use demand in a bake plan <span aria-hidden="true">→</span></Link></div>

    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="dialog-content order-dialog">
        <DialogHeader className="dialog-heading">
          <DialogTitle>{editingId ? "Edit order" : "Add an order"}</DialogTitle>
          <DialogDescription>{productionStarted ? "Production has started. The due date and recipe quantities are locked; only the customer label and notes may be changed." : "Keep the due date and recipe quantities clear; this demand will feed the production planner."}</DialogDescription>
        </DialogHeader>
        {activeRecipes.length === 0 && <div className="callout"><ClipboardList size={17} /><div><strong>A recipe is needed first.</strong><p>Add at least one active recipe before saving an order. <Link className="inline-link" href="/recipes">Open recipes →</Link></p></div></div>}
        <form onSubmit={submit}>
          <div className="form-grid">
            <label className="field-wrap"><span className="field-label">Customer / order label</span><input className="field-control" autoFocus maxLength={140} required placeholder="e.g. Nora’s Saturday pickup" value={customerName} onChange={event => setCustomerName(event.target.value)} /></label>
            <label className="field-wrap"><span className="field-label">Due date</span><input className="field-control" type="date" required value={dueDate} disabled={productionStarted} onChange={event => setDueDate(event.target.value)} /></label>
            <div className="wide line-items-field">
              <div className="line-items-heading"><span className="field-label">Order items</span><button className="button button-secondary button-sm" type="button" onClick={() => setLines(current => [...current, { recipeId: "", quantity: "1" }])} disabled={productionStarted || !activeRecipes.length}><Plus size={13} />Add line</button></div>
              {lines.map((line, index) => <div className="order-line" key={index}>
                <label className="sr-only" htmlFor={`order-recipe-${index}`}>Recipe for item {index + 1}</label>
                <select id={`order-recipe-${index}`} className="field-control" value={line.recipeId} disabled={productionStarted} onChange={event => setLines(current => current.map((row, rowIndex) => rowIndex === index ? { ...row, recipeId: event.target.value } : row))} required>
                  <option value="">Choose a recipe</option>{activeRecipes.map(recipe => <option key={recipe.id} value={recipe.id}>{recipe.name} · {formatCurrency(recipe.sellingPrice, currency)} / {recipe.yieldUnit.replace(/s$/, "")}</option>)}
                </select>
                <label className="sr-only" htmlFor={`order-quantity-${index}`}>Quantity for item {index + 1}</label>
                <input id={`order-quantity-${index}`} className="field-control quantity-input" type="number" min="0.001" step="0.001" required value={line.quantity} disabled={productionStarted} onChange={event => setLines(current => current.map((row, rowIndex) => rowIndex === index ? { ...row, quantity: event.target.value } : row))} />
                {lines.length > 1 && <button className="icon-button remove-line" type="button" disabled={productionStarted} onClick={() => setLines(current => current.filter((_, rowIndex) => rowIndex !== index))} aria-label={`Remove item ${index + 1}`}><Trash2 size={15} /></button>}
              </div>)}
            </div>
            <label className="field-wrap wide"><span className="field-label">Notes <small>optional</small></span><textarea className="field-control" maxLength={2000} placeholder="Pickup time, packaging, or a detail to remember" value={notes} onChange={event => setNotes(event.target.value)} /></label>
          </div>
          {formError && <p className="dialog-error" role="alert">{formError}</p>}
          <div className="form-actions"><button className="button button-secondary" type="button" onClick={() => setOpen(false)}>Cancel</button><button className="button button-primary" type="submit" disabled={save.isPending || activeRecipes.length === 0}>{save.isPending ? "Saving…" : editingId ? "Save changes" : "Save order"}</button></div>
        </form>
      </DialogContent>
    </Dialog>
  </div>;
}
