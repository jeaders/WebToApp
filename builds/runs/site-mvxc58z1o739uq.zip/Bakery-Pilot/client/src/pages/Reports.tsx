import { useEffect, useState } from "react";
import { AlertTriangle, BarChart3, CalendarDays, ChartColumn, CircleDollarSign, CookingPot, Package, ShoppingBag } from "lucide-react";
import { EmptyState, ErrorState, LoadingState, PageHeading, SectionTitle } from "@/components/Ui";
import { trpc } from "@/lib/trpc";
import { dateOffset, formatCurrency, formatDate, formatQuantity, todayISO } from "@/lib/format";

export default function Reports() {
  const [to, setTo] = useState("");
  const [from, setFrom] = useState("");
  const dateRangeValid = from.length === 10 && to.length === 10 && from <= to;
  const report = trpc.bakery.reports.summary.useQuery({ from, to }, { enabled: dateRangeValid });
  const settings = trpc.bakery.settings.get.useQuery();
  useEffect(() => {
    if (settings.data?.timezone && !from && !to) {
      const today = todayISO(settings.data.timezone);
      setTo(today);
      setFrom(dateOffset(-29, today));
    }
  }, [settings.data?.timezone, from, to]);
  const currency = settings.data?.currency ?? "USD";
  const usage = report.data?.usageByIngredient ?? [];
  const waste = report.data?.wasteByIngredient ?? [];
  const maxUsage = Math.max(1, ...usage.map(item => item.quantity));
  const maxWaste = Math.max(1, ...waste.map(item => item.quantity));
  const hasData = Boolean(report.data && (
    report.data.orderCount ||
    report.data.plannedBatchCount ||
    usage.length ||
    waste.length ||
    report.data.lowStock.length
  ));

  return (
    <div className="page-shell">
      <PageHeading
        eyebrow="OPERATING PICTURE"
        title="See how the work is moving."
        description="Read completed orders alongside planned bake days and bakery-local ingredient movements; each measure keeps its date basis visible."
        action={
          <div className="report-date-range">
            <label className="date-chip">
              <CalendarDays size={15} aria-hidden="true" />
              <span className="sr-only">Report start date</span>
              <input aria-label="Report start date" type="date" value={from} max={to || undefined} onChange={event => setFrom(event.target.value)} />
            </label>
            <span aria-hidden="true">to</span>
            <label className="date-chip">
              <CalendarDays size={15} aria-hidden="true" />
              <span className="sr-only">Report end date</span>
              <input aria-label="Report end date" type="date" value={to} min={from || undefined} onChange={event => setTo(event.target.value)} />
            </label>
          </div>
        }
      />

      {settings.error ? (
        <ErrorState message={settings.error.message} onRetry={() => void settings.refetch()} />
      ) : settings.isLoading || !from || !to ? (
        <LoadingState label="Setting the date range to your bakery calendar…" />
      ) : !dateRangeValid ? (
        <div className="callout error" role="alert">
          <AlertTriangle size={17} aria-hidden="true" />
          <div><strong>Choose a valid date range.</strong><p>Enter both dates, with the end date on or after the start date.</p></div>
        </div>
      ) : report.isLoading ? (
        <LoadingState label="Summarizing recorded bakery activity…" />
      ) : report.error ? (
        <ErrorState message={report.error.message} onRetry={() => void report.refetch()} />
      ) : !report.data || !hasData ? (
        <section className="panel">
          <EmptyState
            icon={BarChart3}
            title="Your report will grow with the work."
            description="Completed orders, production batches, and stock movements will appear here when they’re recorded. No placeholder sales or sample figures are shown."
          />
        </section>
      ) : (
        <>
          <div className="report-range-note">
            <span className="report-period-dot" aria-hidden="true" />
            Bakery-local range: <strong>{formatDate(from, { month: "short", day: "numeric", year: "numeric" })}</strong> to <strong>{formatDate(to, { month: "short", day: "numeric", year: "numeric" })}</strong>. Orders use due date; batches use planned date; stock flows use movement time.
          </div>

          <div className="metric-grid report-metrics">
            <article className="metric-card">
              <div className="metric-label"><span className="metric-icon"><CircleDollarSign size={15} /></span>Completed order value</div>
              <div className="metric-value">{formatCurrency(report.data.completedSales, currency)}</div>
              <div className="metric-note">{report.data.completedOrderCount} completed order{report.data.completedOrderCount === 1 ? "" : "s"} due in range</div>
            </article>
            <article className="metric-card">
              <div className="metric-label"><span className="metric-icon sage"><ChartColumn size={15} /></span>Gross profit</div>
              <div className="metric-value">{formatCurrency(report.data.grossProfit, currency)}</div>
              <div className="metric-note">{report.data.grossMargin.toFixed(0)}% margin on completed orders</div>
            </article>
            <article className="metric-card">
              <div className="metric-label"><span className="metric-icon amber"><CookingPot size={15} /></span>Actual output</div>
              <div className="metric-value">{formatQuantity(report.data.actualOutput)}</div>
              <div className="metric-note">Across {report.data.completedBatchCount} completed batch{report.data.completedBatchCount === 1 ? "" : "es"}</div>
            </article>
            <article className="metric-card">
              <div className="metric-label"><span className="metric-icon berry"><Package size={15} /></span>Recorded waste</div>
              <div className="metric-value">{formatQuantity(report.data.wasteQuantity)}</div>
              <div className="metric-note">Ingredient quantities explicitly recorded as waste</div>
            </article>
          </div>

          <div className="report-secondary-metrics">
            <div><span>OPEN ORDER VALUE</span><strong>{formatCurrency(report.data.committedSales, currency)}</strong><small>{report.data.openOrderCount} open order{report.data.openOrderCount === 1 ? "" : "s"} due in range; estimated, not completed sales</small></div>
            <div><span>ORDER VOLUME</span><strong>{report.data.orderCount}</strong><small>All non-cancelled orders in range</small></div>
            <div><span>PLANNED BATCHES</span><strong>{report.data.plannedBatchCount}</strong><small>{report.data.completedBatchCount} completed</small></div>
            <div><span>RECIPE COSTS</span><strong>{formatCurrency(report.data.completedCosts, currency)}</strong><small>Saved cost snapshot on completed orders</small></div>
          </div>

          <div className="two-column report-grid">
            <section className="panel panel-pad">
              <SectionTitle title="Ingredient flow" aside={<span className="section-subtitle">Recorded movements</span>} />
              <div className="usage-groups">
                <div className="usage-group">
                  <h4>Production use</h4>
                  {usage.length ? (
                    <ol className="usage-chart" aria-label="Production ingredient use by quantity">
                      {usage.slice(0, 8).map(item => (
                        <li className="usage-row" key={item.ingredientId}>
                          <div className="usage-label"><strong>{item.name}</strong><span>{formatQuantity(item.quantity)} {item.unit}</span></div>
                          <div className="usage-track"><span style={{ width: `${Math.max(3, item.quantity / maxUsage * 100)}%` }} /></div>
                        </li>
                      ))}
                    </ol>
                  ) : <p className="empty-inline">No production use recorded in this period.</p>}
                </div>
                <div className="usage-group waste-group">
                  <h4>Waste logged</h4>
                  {waste.length ? (
                    <ol className="usage-chart" aria-label="Ingredient waste by quantity">
                      {waste.slice(0, 8).map(item => (
                        <li className="usage-row" key={item.ingredientId}>
                          <div className="usage-label"><strong>{item.name}</strong><span>{formatQuantity(item.quantity)} {item.unit}</span></div>
                          <div className="usage-track"><span style={{ width: `${Math.max(3, item.quantity / maxWaste * 100)}%` }} /></div>
                        </li>
                      ))}
                    </ol>
                  ) : <p className="empty-inline">No ingredient waste recorded in this period.</p>}
                </div>
              </div>
            </section>

            <section className="panel panel-pad">
              <SectionTitle title="Watch list" aside={<span className="section-subtitle">Current stock position</span>} />
              {report.data.lowStock.length ? (
                <div className="report-risk-list">
                  {report.data.lowStock.slice(0, 6).map(item => (
                    <div className="report-risk-row" key={item.id}>
                      <span className="risk-indicator"><AlertTriangle size={14} aria-hidden="true" /></span>
                      <span><strong>{item.name}</strong><small>Reorder point {formatQuantity(item.reorderPoint)} {item.unit}</small></span>
                      <em>{formatQuantity(item.currentStock)} {item.unit}</em>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="stock-clear"><span className="stock-clear-mark" aria-hidden="true">✓</span><div><strong>No current reorder flags</strong><p>All tracked ingredients are above their reorder points.</p></div></div>
              )}
            </section>
          </div>

          <p className="report-method-note"><ShoppingBag size={14} aria-hidden="true" />Completed order value, gross profit, and saved recipe cost include completed orders whose due date is in this range. Batch counts and actual output are grouped by the batch’s planned date. Ingredient use and waste are grouped by movement timestamp in the bakery timezone. Open order value is estimated due-date value, not completed sales; waste reflects explicit movements, not recipe estimates.</p>
        </>
      )}
    </div>
  );
}
