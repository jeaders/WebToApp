import { useEffect, useMemo, useState, type FormEvent } from "react";
import { AlertTriangle, ArrowRight, CalendarDays, Check, ChefHat, CookingPot, Plus, Save, Wheat } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, ErrorState, LoadingState, PageHeading, StatusPill } from "@/components/Ui";
import { trpc } from "@/lib/trpc";
import { formatCurrency, formatDate, formatQuantity, todayISO } from "@/lib/format";
import { buildPlanRecommendations, type DemandInput, type RecipePlanningInput } from "@shared/bakeryLogic";

type DraftLine = {
  key: string;
  batchId?: number;
  recipeId: number;
  recipeName: string;
  demandQuantity: number;
  yieldQuantity: number;
  yieldUnit: string;
  batchCount: number;
  plannedTime: string;
  status?: string;
  supplemental?: boolean;
  uncoveredDemand?: number;
};

const nextBatch: Record<string, string> = { planned: "mixing", mixing: "baking", baking: "ready" };
const draftKey = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2)}`;

export default function Production() {
  const [date, setDate] = useState("");
  const [draft, setDraft] = useState<DraftLine[] | null>(null);
  const [planNotes, setPlanNotes] = useState("");
  const [addRecipeId, setAddRecipeId] = useState("");
  const [completing, setCompleting] = useState<(DraftLine & { batchId: number }) | null>(null);
  const [actualYield, setActualYield] = useState("");
  const [completeError, setCompleteError] = useState("");
  const settingsQuery = trpc.bakery.settings.get.useQuery();
  useEffect(() => {
    if (!date && settingsQuery.data?.timezone) setDate(todayISO(settingsQuery.data.timezone));
  }, [date, settingsQuery.data?.timezone]);
  const preview = trpc.bakery.production.preview.useQuery({ date }, { enabled: Boolean(date) });
  const recipes = trpc.bakery.recipes.list.useQuery();
  const ingredients = trpc.bakery.ingredients.list.useQuery();
  const utils = trpc.useUtils();
  const currency = settingsQuery.data?.currency ?? "USD";

  useEffect(() => {
    const data = preview.data;
    if (!data) return;

    const activeBatches = data.batches.filter(batch => batch.status !== "cancelled");
    const batchesByRecipe = new Map<number, typeof activeBatches>();
    for (const batch of activeBatches) {
      const group = batchesByRecipe.get(batch.recipeId) ?? [];
      group.push(batch);
      batchesByRecipe.set(batch.recipeId, group);
    }
    const demandByRecipe = new Map(data.recommendations.lines.map(line => [line.recipeId, line]));
    const gapByPlannedBatch = new Map<number, number>();
    const supplementalLines: DraftLine[] = [];

    for (const recommendation of data.recommendations.lines) {
      const group = batchesByRecipe.get(recommendation.recipeId) ?? [];
      const committedOutput = group.reduce((sum, batch) => {
        if (batch.status === "completed") return sum + Number(batch.actualYield ?? 0);
        return sum + Number(batch.targetQuantity);
      }, 0);
      const uncoveredDemand = Math.max(0, recommendation.demandQuantity - committedOutput);
      if (uncoveredDemand <= 0.0005) continue;

      const editableBatch = group.find(batch => batch.status === "planned");
      if (editableBatch) {
        gapByPlannedBatch.set(editableBatch.id, uncoveredDemand);
        continue;
      }

      supplementalLines.push({
        key: draftKey(`demand-${recommendation.recipeId}`),
        recipeId: recommendation.recipeId,
        recipeName: recommendation.recipeName,
        demandQuantity: group.length ? uncoveredDemand : recommendation.demandQuantity,
        yieldQuantity: recommendation.yieldQuantity,
        yieldUnit: recommendation.yieldUnit,
        batchCount: Math.max(1, Math.ceil(uncoveredDemand / recommendation.yieldQuantity)),
        plannedTime: "",
        supplemental: group.length > 0,
      });
    }

    if (data.plan) {
      const savedLines: DraftLine[] = activeBatches.map(batch => {
        const recommendation = demandByRecipe.get(batch.recipeId);
        return {
          key: `saved-${batch.id}`,
          batchId: batch.id,
          recipeId: batch.recipeId,
          recipeName: batch.recipeName,
          demandQuantity: recommendation?.demandQuantity ?? Number(batch.demandQuantity),
          yieldQuantity: Number(batch.targetQuantity) / Math.max(batch.batchCount, 1),
          yieldUnit: batch.yieldUnit,
          batchCount: batch.batchCount,
          plannedTime: batch.plannedTime ?? "",
          status: batch.status,
          uncoveredDemand: gapByPlannedBatch.get(batch.id),
        };
      });
      setDraft([...savedLines, ...supplementalLines]);
      setPlanNotes(data.plan.notes ?? "");
    } else {
      setDraft(data.recommendations.lines.map(line => ({
        key: `recommendation-${line.recipeId}`,
        recipeId: line.recipeId,
        recipeName: line.recipeName,
        demandQuantity: line.demandQuantity,
        yieldQuantity: line.yieldQuantity,
        yieldUnit: line.yieldUnit,
        batchCount: line.recommendedBatches,
        plannedTime: "",
      })));
      setPlanNotes("");
    }
  }, [preview.data]);

  const refresh = async () => Promise.all([
    utils.bakery.production.preview.invalidate(),
    utils.bakery.production.batches.invalidate(),
    utils.bakery.dashboard.snapshot.invalidate(),
    utils.bakery.ingredients.list.invalidate(),
    utils.bakery.ingredients.movements.invalidate(),
    utils.bakery.reports.summary.invalidate(),
  ]);
  const savePlan = trpc.bakery.production.savePlan.useMutation({
    onSuccess: async () => { toast.success("Production plan saved."); await refresh(); },
    onError: error => toast.error(error.message),
  });
  const updateBatch = trpc.bakery.production.updateBatch.useMutation({
    onSuccess: async () => {
      toast.success("Batch progress saved and inventory updated.");
      setCompleting(null);
      setCompleteError("");
      await refresh();
    },
    onError: error => { setCompleteError(error.message); toast.error(error.message); },
  });

  const recipeInputs = useMemo<RecipePlanningInput[]>(() => (recipes.data ?? []).map(recipe => ({
    id: recipe.id,
    name: recipe.name,
    yieldQuantity: Number(recipe.yieldQuantity),
    yieldUnit: recipe.yieldUnit,
    ingredients: recipe.ingredients.filter(part => !part.isArchived).map(part => ({
      ingredientId: part.ingredientId,
      ingredientName: part.ingredientName,
      unit: part.unit,
      quantityPerBatch: part.quantityPerBatch,
      currentStock: part.currentStock,
      unitCost: part.unitCost,
    })),
  })), [recipes.data]);

  const lines = draft ?? [];
  const capacity = preview.data?.settings.dailyBatchCapacity ?? 24;
  const countForStock = lines.filter(line => line.status !== "completed" && line.status !== "cancelled" && line.batchCount > 0);
  const completedBatchCount = lines.filter(line => line.status === "completed").reduce((sum, line) => sum + line.batchCount, 0);
  const adjustedPlanBase = buildPlanRecommendations(
    countForStock.map(line => ({ recipeId: line.recipeId, quantity: line.batchCount * line.yieldQuantity })),
    recipeInputs,
    capacity,
  );
  const adjustedTotalBatches = adjustedPlanBase.totalBatches + completedBatchCount;
  const adjustedPlan = {
    ...adjustedPlanBase,
    totalBatches: adjustedTotalBatches,
    capacityExceeded: adjustedTotalBatches > adjustedPlanBase.dailyBatchCapacity,
  };
  const totalRecipeCost = lines
    .filter(line => line.status !== "completed" && line.status !== "cancelled")
    .reduce((sum, line) => sum + (recipes.data?.find(recipe => recipe.id === line.recipeId)?.batchCost ?? 0) * line.batchCount, 0);
  const savedBatches = preview.data?.batches ?? [];
  const initialDemandExists = Boolean(preview.data?.recommendations.lines.length);
  const editableLines = lines.filter(line => !line.status || line.status === "planned");
  const savingAllowed = editableLines.length > 0;
  const manuallyAvailable = recipeInputs;

  function changeLine(key: string, patch: Partial<DraftLine>) {
    setDraft(current => (current ?? []).map(line => line.key === key ? { ...line, ...patch } : line));
  }

  function addRecipe() {
    const recipe = recipeInputs.find(item => item.id === Number(addRecipeId));
    if (!recipe) return;
    setDraft(current => [...(current ?? []), {
      key: draftKey(`manual-${recipe.id}`),
      recipeId: recipe.id,
      recipeName: recipe.name,
      demandQuantity: 0,
      yieldQuantity: recipe.yieldQuantity,
      yieldUnit: recipe.yieldUnit,
      batchCount: 1,
      plannedTime: "",
    }]);
    setAddRecipeId("");
  }

  function submitPlan(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const items = editableLines.map(line => ({
      batchId: line.batchId,
      recipeId: line.recipeId,
      demandQuantity: Math.max(0, line.demandQuantity),
      batchCount: Math.max(1, line.batchCount),
      plannedTime: line.plannedTime || undefined,
    }));
    if (items.length === 0) return;
    savePlan.mutate({ date, notes: planNotes || undefined, items });
  }

  function progressBatch(batch: NonNullable<typeof preview.data>["batches"][number], status: string) {
    const line = {
      key: `saved-${batch.id}`,
      batchId: batch.id,
      recipeId: batch.recipeId,
      recipeName: batch.recipeName,
      demandQuantity: Number(batch.demandQuantity),
      yieldQuantity: Number(batch.targetQuantity) / Math.max(batch.batchCount, 1),
      yieldUnit: batch.yieldUnit,
      batchCount: batch.batchCount,
      plannedTime: batch.plannedTime ?? "",
      status: batch.status,
    };
    if (status === "completed") {
      setCompleting(line);
      setActualYield(String(batch.targetQuantity));
      setCompleteError("");
      return;
    }
    updateBatch.mutate({ id: batch.id, status: status as "planned" | "mixing" | "baking" | "ready" | "completed" | "cancelled" });
  }

  function completeSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!completing) return;
    updateBatch.mutate({ id: completing.batchId, status: "completed", actualYield: Number(actualYield) });
  }

  return <div className="page-shell">
    <PageHeading
      eyebrow="DEMAND → DOUGH → DONE"
      title="Make the day add up."
      description="Translate open orders into recipe batches, catch ingredient constraints, and track what actually came out of the oven."
      action={<label className="date-chip"><CalendarDays size={15} aria-hidden="true" /><span className="sr-only">Plan production for date</span><input aria-label="Plan production for date" type="date" value={date} onChange={event => setDate(event.target.value)} /></label>}
    />
    {settingsQuery.error
      ? <ErrorState message={settingsQuery.error.message} onRetry={() => void settingsQuery.refetch()} />
      : settingsQuery.isLoading || !date || preview.isLoading || recipes.isLoading || ingredients.isLoading
      ? <LoadingState label="Working out the day’s production picture…" />
      : preview.error
        ? <ErrorState message={preview.error.message} onRetry={() => void preview.refetch()} />
        : recipes.error
          ? <ErrorState message={recipes.error.message} onRetry={() => void recipes.refetch()} />
          : ingredients.error
            ? <ErrorState message={ingredients.error.message} onRetry={() => void ingredients.refetch()} />
            : !preview.data
              ? <LoadingState />
              : recipeInputs.length === 0
                ? <section className="panel"><EmptyState icon={ChefHat} title="The planner needs a recipe to work from." description="Add recipes with ingredient quantities and yield. Then customer orders can become a real batch and stock plan." action={<Link className="button button-primary" href="/recipes">Build a recipe <ArrowRight size={15} /></Link>} /></section>
                : <>
                  {preview.data.recipeCount === 0 && <div className="callout"><Wheat size={17} /><div><strong>Add a recipe before planning.</strong><p>The planner uses saved yields and ingredient quantities to calculate batches and stock needs.</p></div></div>}
                  <div className="production-summary-strip">
                    <div><span>PLANNING DATE</span><strong>{formatDate(date, { weekday: "long", month: "long", day: "numeric" })}</strong></div>
                    <div><span>OPEN DEMAND</span><strong>{formatQuantity(preview.data.recommendations.lines.reduce((sum, line) => sum + line.demandQuantity, 0))} items</strong></div>
                    <div><span>PLANNED BATCHES</span><strong>{adjustedPlan.totalBatches} <small>/ {adjustedPlan.dailyBatchCapacity} capacity</small></strong></div>
                    <div><span>EST. INGREDIENT COST</span><strong>{formatCurrency(totalRecipeCost, currency)}</strong></div>
                  </div>

                  <div className="production-layout">
                    <section className="panel plan-panel">
                      <div className="panel-pad">
                        <div className="section-title">
                          <div>
                            <h3>{preview.data.plan ? "Saved production plan" : initialDemandExists ? "Recommended from open orders" : "Build a manual production plan"}</h3>
                            <p className="section-subtitle">{initialDemandExists ? "Demand includes open orders due on or before this date. New demand is reconciled with saved batches." : "No open demand is due by this date. Add a recipe if you still want to plan a batch."}</p>
                          </div>
                          {preview.data.plan && <StatusPill status={preview.data.plan.status} />}
                        </div>
                        {adjustedPlan.capacityExceeded && <div className="callout"><AlertTriangle size={17} /><div><strong>Planned batches exceed your daily capacity.</strong><p>This is a planning signal, not a hard stop. Review the line counts or update capacity in bakery settings.</p></div></div>}
                        {adjustedPlan.shortages.length > 0 && <div className="callout error"><AlertTriangle size={17} /><div><strong>{adjustedPlan.shortages.length} ingredient shortage{adjustedPlan.shortages.length === 1 ? "" : "s"} in this plan.</strong><p>{adjustedPlan.shortages.slice(0, 4).map(item => `${item.ingredientName}: short ${formatQuantity(item.shortfall)} ${item.unit}`).join(" · ")}{adjustedPlan.shortages.length > 4 ? " · More in the shortage list" : ""}</p></div></div>}
                        {lines.some(line => (line.uncoveredDemand ?? 0) > 0.0005) && <div className="callout"><AlertTriangle size={17} /><div><strong>Current order demand is higher than a saved, unstarted batch.</strong><p>Increase that editable batch count and save the plan. Started or completed batches remain locked; any remaining demand is added as a supplemental batch.</p></div></div>}

                        {recipeInputs.length > 0 && <div className="manual-add-row">
                          <label className="sr-only" htmlFor="add-plan-recipe">Add a supplemental recipe batch</label>
                          <select id="add-plan-recipe" className="field-control" value={addRecipeId} onChange={event => setAddRecipeId(event.target.value)}>
                            <option value="">Add a supplemental batch</option>
                            {manuallyAvailable.map(recipe => <option key={recipe.id} value={recipe.id}>{recipe.name} · {formatQuantity(recipe.yieldQuantity)} {recipe.yieldUnit}</option>)}
                          </select>
                          <button className="button button-secondary" type="button" onClick={addRecipe} disabled={!addRecipeId}><Plus size={14} />Add batch</button>
                        </div>}

                        {lines.length === 0
                          ? <EmptyState icon={CookingPot} title={initialDemandExists ? "Demand needs an active recipe." : "Nothing planned yet."} description={initialDemandExists ? "One or more orders reference recipes that are no longer available. Check the recipe book before planning." : "Choose a recipe above to plan production without open orders."} />
                          : <form onSubmit={submitPlan}>
                            <div className="data-table-wrap"><table className="data-table plan-table">
                              <thead><tr><th>Recipe</th><th>Demand</th><th>Batch count</th><th>Planned output</th><th>Time</th></tr></thead>
                              <tbody>{lines.map(line => {
                                const locked = Boolean(line.status && line.status !== "planned");
                                return <tr key={line.key}>
                                  <td>
                                    <div className="primary-cell">{line.recipeName}{line.supplemental && <span className="supplemental-tag">Supplemental</span>}</div>
                                    <div className="secondary-cell">Yield {formatQuantity(line.yieldQuantity)} {line.yieldUnit} / batch</div>
                                    {line.supplemental && <div className="secondary-cell">Additional demand: {formatQuantity(line.demandQuantity)} {line.yieldUnit}</div>}
                                    {(line.uncoveredDemand ?? 0) > 0.0005 && <div className="secondary-cell">{formatQuantity(line.uncoveredDemand)} {line.yieldUnit} not yet covered</div>}
                                  </td>
                                  <td>{formatQuantity(line.demandQuantity)} {line.yieldUnit}</td>
                                  <td><label className="sr-only" htmlFor={`batch-count-${line.key}`}>Batch count for {line.recipeName}</label><input id={`batch-count-${line.key}`} className="field-control batch-count-control" type="number" min="1" max="500" step="1" value={line.batchCount} disabled={locked} onChange={event => changeLine(line.key, { batchCount: Number(event.target.value) })} /></td>
                                  <td>{formatQuantity(line.batchCount * line.yieldQuantity)} {line.yieldUnit}</td>
                                  <td><label className="sr-only" htmlFor={`batch-time-${line.key}`}>Planned time for {line.recipeName}</label><input id={`batch-time-${line.key}`} className="field-control time-control" type="time" value={line.plannedTime} disabled={locked} onChange={event => changeLine(line.key, { plannedTime: event.target.value })} /></td>
                                </tr>;
                              })}</tbody>
                            </table></div>
                            <label className="field-wrap plan-notes"><span className="field-label">Plan note <small>optional</small></span><input className="field-control" maxLength={2000} placeholder="What should the team know?" value={planNotes} onChange={event => setPlanNotes(event.target.value)} /></label>
                            <div className="plan-footer">
                              <span>{adjustedPlan.shortages.length ? "Shortages are warnings; batches can be saved, but cannot be completed until stock is sufficient." : "Saved batches remain locked after production starts; supplemental batches can cover later demand."}</span>
                              <button type="submit" className="button button-primary" disabled={savePlan.isPending || !savingAllowed}><Save size={15} />{savePlan.isPending ? "Saving…" : preview.data.plan ? "Update plan" : "Save production plan"}</button>
                            </div>
                          </form>}
                      </div>
                    </section>

                    <aside className="stack production-side">
                      <section className="panel panel-pad">
                        <div className="section-title"><h3>Ingredient check</h3><Link href="/inventory" className="inline-link">Inventory <ArrowRight size={14} /></Link></div>
                        {adjustedPlan.shortages.length
                          ? <div className="shortage-list">{adjustedPlan.shortages.map(item => <div className="shortage-row" key={item.ingredientId}><span className="shortage-mark"><AlertTriangle size={15} /></span><span><strong>{item.ingredientName}</strong><small>Need {formatQuantity(item.needed)} {item.unit}; have {formatQuantity(item.available)} {item.unit}</small></span><em>−{formatQuantity(item.shortfall)} {item.unit}</em></div>)}</div>
                          : <div className="stock-clear"><span className="stock-clear-mark">✓</span><div><strong>{lines.length ? "No shortages in this plan" : "Add batches to check stock"}</strong><p>{lines.length ? "Current ingredient quantities cover the selected batch counts." : "Stock needs are calculated from recipe quantities."}</p></div></div>}
                      </section>
                      <section className="production-tip"><span className="tip-icon"><Check size={16} /></span><div><strong>Production stays auditable.</strong><p>Started batches and order quantities are locked. New demand can be planned in a supplemental batch without changing work already underway.</p></div></section>
                    </aside>
                  </div>

                  <section className="panel panel-pad batches-panel">
                    <div className="section-title"><div><h3>Batch progress</h3><p className="section-subtitle">Move each batch forward as work happens. Stock is consumed once, when actual yield is recorded.</p></div></div>
                    {savedBatches.length === 0
                      ? <EmptyState icon={CookingPot} title="Batches appear here after you save a plan." description="Once the plan is saved, start mixing, mark the bake ready, then record actual yield to complete the batch." />
                      : <div className="batch-progress-list">{savedBatches.map(batch => <div className="batch-progress-row" key={batch.id}>
                        <span className="batch-stamp"><CookingPot size={16} /></span>
                        <div className="batch-progress-main"><div className="batch-title-line"><strong>{batch.recipeName}</strong><StatusPill status={batch.status} /></div><small>{batch.batchCount} batch{batch.batchCount === 1 ? "" : "es"} · target {formatQuantity(batch.targetQuantity)} {batch.yieldUnit}{batch.plannedTime ? ` · ${batch.plannedTime}` : ""}{batch.actualYield ? ` · actual ${formatQuantity(batch.actualYield)} ${batch.yieldUnit}` : ""}</small></div>
                        <div className="batch-progress-actions">
                          {nextBatch[batch.status] && <button className="button button-secondary button-sm" type="button" disabled={updateBatch.isPending} onClick={() => progressBatch(batch, nextBatch[batch.status])}>{batch.status === "planned" ? "Start mixing" : batch.status === "mixing" ? "Move to bake" : "Mark ready"}<ArrowRight size={13} /></button>}
                          {batch.status === "ready" && <button className="button button-primary button-sm" type="button" disabled={updateBatch.isPending} onClick={() => progressBatch(batch, "completed")}>Complete batch</button>}
                          {!(["completed", "cancelled"].includes(batch.status)) && <button className="text-action" type="button" disabled={updateBatch.isPending} onClick={() => updateBatch.mutate({ id: batch.id, status: "cancelled" })}>Cancel</button>}
                        </div>
                      </div>)}</div>}
                  </section>
                </>}

    <Dialog open={Boolean(completing)} onOpenChange={open => { if (!open) { setCompleting(null); setCompleteError(""); } }}>
      <DialogContent className="dialog-content">
        <DialogHeader className="dialog-heading"><DialogTitle>Complete the batch</DialogTitle><DialogDescription>{completing ? `${completing.recipeName} · planned for ${formatQuantity(completing.batchCount * completing.yieldQuantity)} ${completing.yieldUnit}. Ingredient usage will be posted from the recipe.` : "Record the actual yield."}</DialogDescription></DialogHeader>
        <form onSubmit={completeSubmit}>
          <label className="field-wrap"><span className="field-label">Actual yield ({completing?.yieldUnit ?? "units"})</span><input autoFocus className="field-control" type="number" min="0.001" step="0.001" required value={actualYield} onChange={event => setActualYield(event.target.value)} /></label>
          {completeError && <p className="dialog-error" role="alert">{completeError}</p>}
          <div className="callout good"><Wheat size={16} /><div><strong>Stock changes happen once.</strong><p>Completing a batch records ingredient quantities required for its batch count and writes a linked movement entry.</p></div></div>
          <div className="form-actions"><button className="button button-secondary" type="button" onClick={() => setCompleting(null)}>Cancel</button><button className="button button-primary" type="submit" disabled={updateBatch.isPending}>{updateBatch.isPending ? "Saving…" : "Record actual yield"}</button></div>
        </form>
      </DialogContent>
    </Dialog>
  </div>;
}
