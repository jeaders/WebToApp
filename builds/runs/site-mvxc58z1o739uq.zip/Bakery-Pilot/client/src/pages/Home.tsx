import { AlertTriangle, ArrowRight, CalendarDays, ClipboardList, CookingPot, Package, Plus, ShoppingBag, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { formatCurrency, formatDate, formatQuantity, todayISO } from "@/lib/format";
import { EmptyState, ErrorState, LoadingState, PageHeading, SectionTitle, StatusPill } from "@/components/Ui";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";

export default function Home() {
  const [date, setDate] = useState("");
  const settings = trpc.bakery.settings.get.useQuery();
  useEffect(() => {
    if (!date && settings.data?.timezone) setDate(todayISO(settings.data.timezone));
  }, [date, settings.data?.timezone]);
  const snapshot = trpc.bakery.dashboard.snapshot.useQuery({ date }, { enabled: Boolean(date) });
  if (settings.error) return <ErrorState message={settings.error.message} onRetry={() => void settings.refetch()} />;
  if (settings.isLoading || snapshot.isLoading || !date) return <LoadingState label="Gathering today’s bakery picture…" />;
  if (snapshot.error || !snapshot.data) return <ErrorState message={snapshot.error?.message ?? "Your operations summary is unavailable."} onRetry={() => void snapshot.refetch()} />;
  const data = snapshot.data;
  const currency = data.settings.currency;
  const hasSetup = data.totalRecipes > 0 || data.totalIngredients > 0;

  return <div className="page-shell">
    <PageHeading eyebrow="THE BAKE DAY, AT A GLANCE" title={date === todayISO(data.settings.timezone) ? "Good morning. Let’s get ahead." : `Bake plan · ${formatDate(date, { month: "long", day: "numeric" })}`} description="A clear read on what’s due, what’s in the oven, and what needs your attention next." action={<div className="dashboard-actions"><label className="date-chip"><CalendarDays size={15} aria-hidden="true" /><span className="sr-only">View operations for date</span><input aria-label="View operations for date" type="date" value={date} onChange={event => setDate(event.target.value)} /></label><Link className="button button-primary" href="/orders"><Plus size={16} aria-hidden="true" />New order</Link></div>} />

    {!hasSetup && <section className="onboarding-banner" aria-labelledby="onboarding-title">
      <div className="onboarding-icon"><Sparkles size={19} aria-hidden="true" /></div>
      <div className="onboarding-copy"><p className="eyebrow">YOUR WORKSPACE IS READY</p><h3 id="onboarding-title">Start with the ingredients you bake with.</h3><p>Add a few ingredients and recipes first. Then open orders can become batch counts and a real stock check.</p></div>
      <div className="onboarding-steps"><Link href="/inventory"><span>01</span>Add ingredients<ArrowRight size={14} /></Link><Link href="/recipes"><span>02</span>Build recipes<ArrowRight size={14} /></Link><Link href="/orders"><span>03</span>Capture demand<ArrowRight size={14} /></Link></div>
    </section>}

    <div className="metric-grid">
      <article className="metric-card"><div className="metric-label"><span className="metric-icon"><ShoppingBag size={15} /></span>Open orders due</div><div className="metric-value">{data.orderCount}</div><div className="metric-note">Due by {formatDate(date, { month: "short", day: "numeric" })} · {formatQuantity(data.dueUnits)} items</div></article>
      <article className="metric-card"><div className="metric-label"><span className="metric-icon sage"><CookingPot size={15} /></span>Planned output</div><div className="metric-value">{formatQuantity(data.plannedUnits)}</div><div className="metric-note">{data.activeBatches.length} active batch{data.activeBatches.length === 1 ? "" : "es"} · {formatQuantity(data.completedUnits)} completed</div></article>
      <article className="metric-card"><div className="metric-label"><span className="metric-icon amber"><Package size={15} /></span>Stock to watch</div><div className="metric-value">{data.lowStock.length}</div><div className="metric-note">Ingredient{data.lowStock.length === 1 ? "" : "s"} at or below reorder point</div></article>
      <article className="metric-card"><div className="metric-label"><span className="metric-icon berry"><ClipboardList size={15} /></span>Order value</div><div className="metric-value">{formatCurrency(data.committedValue, currency)}</div><div className="metric-note">Open orders · {data.committedMargin.toFixed(0)}% estimated gross margin</div></article>
    </div>

    <div className="dashboard-grid">
      <section className="panel panel-pad">
        <SectionTitle title="Today’s production" aside={<Link className="inline-link" href="/production">Open plan <ArrowRight size={14} /></Link>} />
        {data.plan ? <>
          <div className="plan-status-row"><span className="plan-date-label"><CalendarDays size={15} />{formatDate(date, { weekday: "long", month: "long", day: "numeric" })}</span><StatusPill status={data.plan.status} /></div>
          {data.activeBatches.length || data.completedUnits > 0 ? <div className="batch-list compact-list">
            {[...data.activeBatches, ...[]].slice(0, 4).map(batch => <div className="batch-row" key={batch.id}><span className="batch-stamp"><CookingPot size={15} /></span><span className="batch-main"><strong>{batch.recipeName}</strong><small>{batch.batchCount} batch{batch.batchCount === 1 ? "" : "es"} · target {formatQuantity(batch.targetQuantity)} {batch.yieldUnit}</small></span><StatusPill status={batch.status} /></div>)}
            {data.completedUnits > 0 && <p className="completed-note">{formatQuantity(data.completedUnits)} units recorded as completed.</p>}
          </div> : <EmptyState icon={CookingPot} title="The plan is saved, but no batches are underway." description="Open production to review the recipe quantities and move batches into the day’s work." action={<Link className="button button-secondary" href="/production">Review plan <ArrowRight size={15} /></Link>} />}
        </> : <EmptyState icon={CookingPot} title="No bake plan saved for this date." description={data.orderCount ? "Turn due orders into recipe batch counts, check ingredient shortages, and save a plan." : "A saved plan will gather the day’s batches and progress in one place."} action={<Link className="button button-secondary" href="/production">Build the plan <ArrowRight size={15} /></Link>} />}
      </section>

      <section className="panel panel-pad">
        <SectionTitle title="Ingredients to watch" aside={<Link className="inline-link" href="/inventory">Inventory <ArrowRight size={14} /></Link>} />
        {data.lowStock.length ? <div className="risk-list">{data.lowStock.slice(0, 5).map(ingredient => <div className="risk-row" key={ingredient.id}><span className="risk-indicator"><AlertTriangle size={15} /></span><span className="risk-main"><strong>{ingredient.name}</strong><small>Reorder at {formatQuantity(ingredient.reorderPoint)} {ingredient.unit}</small></span><span className="risk-quantity">{formatQuantity(ingredient.currentStock)} <small>{ingredient.unit}</small></span></div>)}</div> : <div className="stock-clear"><span className="stock-clear-mark">✓</span><div><strong>No low-stock flags</strong><p>Ingredient levels are above their reorder points.</p></div></div>}
      </section>

      <section className="panel panel-pad dashboard-orders">
        <SectionTitle title="Orders needing a hand" aside={<Link className="inline-link" href="/orders">All orders <ArrowRight size={14} /></Link>} />
        {data.orders.length ? <div className="order-preview-list">{data.orders.map(order => <Link href="/orders" className="order-preview" key={order.id}><span className="order-avatar">{order.customerName.trim().slice(0, 1).toUpperCase()}</span><span className="order-preview-copy"><strong>{order.customerName}</strong><small>{formatDate(order.dueDate, { month: "short", day: "numeric" })} · {order.items.length} line{order.items.length === 1 ? "" : "s"}</small></span><span className="order-preview-total">{formatCurrency(order.total, currency)}</span><StatusPill status={order.status} /></Link>)}</div> : <EmptyState icon={ClipboardList} title="No open orders in view." description="Add an order when a customer confirms a bake. It will be counted in the planning view." action={<Link className="button button-secondary" href="/orders"><Plus size={15} />Add an order</Link>} />}
      </section>

      <section className="daily-note-card">
        <div className="daily-note-kicker"><span className="note-star">✳</span> A SMALL THING THAT HELPS</div>
        <p>Batch counts round up to the full recipe yield. Check the shortage list before saving so the plan matches what’s actually on your shelves.</p>
        <Link href="/production" className="note-link">See how today adds up <ArrowRight size={14} /></Link>
      </section>
    </div>
  </div>;
}
