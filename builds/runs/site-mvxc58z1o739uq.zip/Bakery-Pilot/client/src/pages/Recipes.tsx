import { useMemo, useState, type FormEvent } from "react";
import { BookOpen, ChefHat, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, ErrorState, LoadingState, PageHeading } from "@/components/Ui";
import { trpc } from "@/lib/trpc";
import { formatCurrency, formatQuantity } from "@/lib/format";
import { Link } from "wouter";

type RecipeLine = { ingredientId: string; quantityPerBatch: string };
const blankRecipe = { name: "", category: "Bread", yieldQuantity: "12", yieldUnit: "pcs", sellingPrice: "0", targetMargin: "65", notes: "" };

export default function Recipes() {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | undefined>();
  const [form, setForm] = useState(blankRecipe);
  const [lines, setLines] = useState<RecipeLine[]>([{ ingredientId: "", quantityPerBatch: "1" }]);
  const [formError, setFormError] = useState("");
  const recipeQuery = trpc.bakery.recipes.list.useQuery();
  const ingredientQuery = trpc.bakery.ingredients.list.useQuery();
  const settings = trpc.bakery.settings.get.useQuery();
  const utils = trpc.useUtils();
  const activeIngredients = ingredientQuery.data ?? [];
  const currency = settings.data?.currency ?? "USD";
  const ingredientMap = useMemo(() => new Map(activeIngredients.map(item => [item.id, item])), [activeIngredients]);
  const estimatedCost = lines.reduce((sum, line) => sum + Number(ingredientMap.get(Number(line.ingredientId))?.unitCost ?? 0) * Number(line.quantityPerBatch || 0), 0);
  const yieldQuantity = Number(form.yieldQuantity || 0);
  const unitCost = yieldQuantity > 0 ? estimatedCost / yieldQuantity : 0;
  const targetMargin = Math.max(0, Math.min(Number(form.targetMargin || 0) / 100, .9));
  const suggestedPrice = targetMargin < 1 ? unitCost / (1 - targetMargin) : 0;

  const save = trpc.bakery.recipes.save.useMutation({
    onSuccess: async () => { toast.success(editingId ? "Recipe updated." : "Recipe added to the book."); setOpen(false); await Promise.all([utils.bakery.recipes.list.invalidate(), utils.bakery.dashboard.snapshot.invalidate(), utils.bakery.production.preview.invalidate()]); },
    onError: error => { setFormError(error.message); toast.error(error.message); },
  });
  const archive = trpc.bakery.recipes.archive.useMutation({
    onSuccess: async () => { toast.success("Recipe archived. It remains in historical orders and production records."); await Promise.all([utils.bakery.recipes.list.invalidate(), utils.bakery.dashboard.snapshot.invalidate()]); },
    onError: error => toast.error(error.message),
  });

  function startNew() { setEditingId(undefined); setForm(blankRecipe); setLines([{ ingredientId: "", quantityPerBatch: "1" }]); setFormError(""); setOpen(true); }
  function startEdit(recipe: NonNullable<typeof recipeQuery.data>[number]) {
    setEditingId(recipe.id);
    setForm({ name: recipe.name, category: recipe.category, yieldQuantity: String(recipe.yieldQuantity), yieldUnit: recipe.yieldUnit, sellingPrice: String(recipe.sellingPrice), targetMargin: String(Number(recipe.targetMargin) * 100), notes: recipe.notes ?? "" });
    setLines(recipe.ingredients.filter(item => !item.isArchived).map(item => ({ ingredientId: String(item.ingredientId), quantityPerBatch: String(item.quantityPerBatch) })));
    setFormError(""); setOpen(true);
  }
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setFormError("");
    const recipeIngredients = lines.filter(line => line.ingredientId && Number(line.quantityPerBatch) > 0).map(line => ({ ingredientId: Number(line.ingredientId), quantityPerBatch: Number(line.quantityPerBatch) }));
    if (!recipeIngredients.length) { setFormError("Add at least one ingredient and quantity."); return; }
    save.mutate({ id: editingId, name: form.name, category: form.category, yieldQuantity: Number(form.yieldQuantity), yieldUnit: form.yieldUnit, sellingPrice: Number(form.sellingPrice), targetMargin: targetMargin, notes: form.notes || undefined, ingredients: recipeIngredients });
  }

  return <div className="page-shell">
    <PageHeading eyebrow="RECIPES & YIELD" title="Keep the recipe book honest." description="Set a reliable yield, record what goes into each batch, and let current ingredient prices show you the real cost." action={<button type="button" className="button button-primary" onClick={startNew}><Plus size={16} />New recipe</button>} />
    {ingredientQuery.isLoading || recipeQuery.isLoading ? <LoadingState label="Opening your recipe book…" /> : ingredientQuery.error ? <ErrorState message={ingredientQuery.error.message} onRetry={() => void ingredientQuery.refetch()} /> : recipeQuery.error ? <ErrorState message={recipeQuery.error.message} onRetry={() => void recipeQuery.refetch()} /> : activeIngredients.length === 0 ? <section className="panel"><EmptyState icon={ChefHat} title="Add ingredients before writing recipes." description="Recipes use your current ingredient prices to calculate batch and per-item costs. Start with the inventory you already track." action={<Link className="button button-primary" href="/inventory"><Plus size={15} />Add ingredients</Link>} /></section> : (recipeQuery.data ?? []).length === 0 ? <section className="panel"><EmptyState icon={BookOpen} title="Your recipe book is ready for a first entry." description="Build one repeatable recipe with a clear yield. Bakery Pilot will use it to cost orders and turn demand into batch counts." action={<button className="button button-primary" type="button" onClick={startNew}><Plus size={15} />Add a recipe</button>} /></section> : <div className="recipe-grid">{recipeQuery.data!.map(recipe => <article className="panel recipe-card" key={recipe.id}>
      <div className="recipe-card-top"><span className="recipe-category">{recipe.category}</span><button className="button button-quiet button-sm" type="button" onClick={() => startEdit(recipe)}>Edit</button></div>
      <h3>{recipe.name}</h3><p className="recipe-yield">Yield <strong>{formatQuantity(recipe.yieldQuantity)} {recipe.yieldUnit}</strong> per batch</p>
      <div className="recipe-ingredient-summary">{recipe.ingredients.filter(item => !item.isArchived).map(item => <span key={item.ingredientId}>{formatQuantity(item.quantityPerBatch)} {item.unit} {item.ingredientName}</span>)}</div>
      <div className="recipe-cost-grid"><div><small>Batch cost</small><strong>{formatCurrency(recipe.batchCost, currency)}</strong></div><div><small>Cost / {recipe.yieldUnit.replace(/s$/, "")}</small><strong>{formatCurrency(recipe.unitCost, currency)}</strong></div><div><small>Current margin</small><strong className={recipe.margin < Number(recipe.targetMargin) * 100 ? "margin-low" : "margin-good"}>{recipe.margin.toFixed(0)}%</strong></div></div>
      <div className="recipe-card-bottom"><span>Suggested price <strong>{formatCurrency(recipe.suggestedPrice, currency)}</strong></span><button className="text-action" type="button" onClick={() => { if (window.confirm(`Archive ${recipe.name}? Historical orders and batches will be preserved.`)) archive.mutate({ id: recipe.id }); }}>Archive</button></div>
    </article>)}</div>}

    <Dialog open={open} onOpenChange={setOpen}><DialogContent className="dialog-content recipe-dialog"><DialogHeader className="dialog-heading"><DialogTitle>{editingId ? "Edit recipe" : "Create a recipe"}</DialogTitle><DialogDescription>Use ingredient units as tracked in inventory. Batch cost updates from the current ingredient prices.</DialogDescription></DialogHeader>
      <form onSubmit={submit}>
        <div className="form-grid"><label className="field-wrap"><span className="field-label">Recipe name</span><input className="field-control" autoFocus required maxLength={140} placeholder="Country sourdough" value={form.name} onChange={event => setForm(current => ({ ...current, name: event.target.value }))} /></label>
          <label className="field-wrap"><span className="field-label">Category</span><select className="field-control" value={form.category} onChange={event => setForm(current => ({ ...current, category: event.target.value }))}><option>Bread</option><option>Pastry</option><option>Cake</option><option>Cookie</option><option>Sandwich</option><option>Other</option></select></label>
          <label className="field-wrap"><span className="field-label">Batch yield</span><input className="field-control" type="number" min="0.001" step="0.001" required value={form.yieldQuantity} onChange={event => setForm(current => ({ ...current, yieldQuantity: event.target.value }))} /></label>
          <label className="field-wrap"><span className="field-label">Yield unit</span><select className="field-control" value={form.yieldUnit} onChange={event => setForm(current => ({ ...current, yieldUnit: event.target.value }))}><option value="pcs">Pieces</option><option value="loaves">Loaves</option><option value="kg">Kilograms</option><option value="trays">Trays</option></select><span className="field-hint">After production history exists, this unit stays fixed so recorded yields keep their meaning.</span></label>
          <div className="wide line-items-field"><div className="line-items-heading"><span className="field-label">Ingredients per batch</span><button type="button" className="button button-secondary button-sm" onClick={() => setLines(current => [...current, { ingredientId: "", quantityPerBatch: "1" }])}><Plus size={13} />Add ingredient</button></div>
            {lines.map((line, index) => <div className="recipe-line" key={index}><label className="sr-only" htmlFor={`ingredient-${index}`}>Ingredient {index + 1}</label><select id={`ingredient-${index}`} className="field-control" value={line.ingredientId} onChange={event => setLines(current => current.map((row, rowIndex) => rowIndex === index ? { ...row, ingredientId: event.target.value } : row))} required><option value="">Choose ingredient</option>{activeIngredients.map(ingredient => <option key={ingredient.id} value={ingredient.id}>{ingredient.name} · {ingredient.unit}</option>)}</select><label className="sr-only" htmlFor={`ingredient-qty-${index}`}>Quantity per batch for ingredient {index + 1}</label><input id={`ingredient-qty-${index}`} className="field-control quantity-input" type="number" min="0.001" step="0.001" required value={line.quantityPerBatch} onChange={event => setLines(current => current.map((row, rowIndex) => rowIndex === index ? { ...row, quantityPerBatch: event.target.value } : row))} />{lines.length > 1 && <button type="button" className="icon-button remove-line" aria-label={`Remove ingredient ${index + 1}`} onClick={() => setLines(current => current.filter((_, rowIndex) => rowIndex !== index))}><Trash2 size={15} /></button>}</div>)}
          </div>
          <label className="field-wrap"><span className="field-label">Selling price per item</span><input className="field-control" type="number" min="0" step="0.01" required value={form.sellingPrice} onChange={event => setForm(current => ({ ...current, sellingPrice: event.target.value }))} /></label>
          <label className="field-wrap"><span className="field-label">Target gross margin</span><input className="field-control" type="number" min="0" max="90" step="1" required value={form.targetMargin} onChange={event => setForm(current => ({ ...current, targetMargin: event.target.value }))} /><span className="field-hint">Suggested per-item price: {formatCurrency(suggestedPrice, currency)} · Estimated current margin: {((Number(form.sellingPrice || 0) - unitCost) / Math.max(Number(form.sellingPrice || 0), .0001) * 100).toFixed(0)}%</span></label>
          <label className="field-wrap wide"><span className="field-label">Notes <small>optional</small></span><textarea className="field-control" maxLength={2000} placeholder="Process notes, fermentation, or finishing" value={form.notes} onChange={event => setForm(current => ({ ...current, notes: event.target.value }))} /></label>
        </div>
        {formError && <p className="dialog-error" role="alert">{formError}</p>}
        <div className="cost-preview"><span>Estimated batch cost</span><strong>{formatCurrency(estimatedCost, currency)}</strong><span>{formatCurrency(unitCost, currency)} / item</span></div>
        <div className="form-actions"><button type="button" className="button button-secondary" onClick={() => setOpen(false)}>Cancel</button><button type="submit" className="button button-primary" disabled={save.isPending || activeIngredients.length === 0}>{save.isPending ? "Saving…" : editingId ? "Save recipe" : "Add recipe"}</button></div>
      </form>
    </DialogContent></Dialog>
  </div>;
}
