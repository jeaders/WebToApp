import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import AppShell from "@/components/AppShell";
import { LoadingState } from "@/components/Ui";
import { useAuth } from "@/_core/hooks/useAuth";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { Route, Switch } from "wouter";

const Dashboard = lazy(() => import("@/pages/Home"));
const Orders = lazy(() => import("@/pages/Orders"));
const Recipes = lazy(() => import("@/pages/Recipes"));
const Inventory = lazy(() => import("@/pages/Inventory"));
const Production = lazy(() => import("@/pages/Production"));
const Reports = lazy(() => import("@/pages/Reports"));
const Settings = lazy(() => import("@/pages/Settings"));
const SignIn = lazy(() => import("@/pages/SignIn"));
const NotFound = lazy(() => import("@/pages/NotFound"));

function Workspace() {
  const { loading, user, logout } = useAuth();

  if (loading) {
    return (
      <main className="auth-loading" role="status" aria-live="polite">
        <span className="brand-mark"><span className="oven-loading-dot" /></span>
        <p>Opening your bakery workspace…</p>
      </main>
    );
  }

  if (!user) {
    return <Suspense fallback={<LoadingState label="Opening secure sign in…" />}><SignIn /></Suspense>;
  }

  return (
    <AppShell user={user} onLogout={logout}>
      <Suspense fallback={<LoadingState label="Opening this workspace…" />}>
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/orders" component={Orders} />
          <Route path="/recipes" component={Recipes} />
          <Route path="/inventory" component={Inventory} />
          <Route path="/production" component={Production} />
          <Route path="/reports" component={Reports} />
          <Route path="/settings" component={Settings} />
          <Route path="/404" component={NotFound} />
          <Route component={NotFound} />
        </Switch>
      </Suspense>
    </AppShell>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster position="top-right" richColors />
          <Workspace />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
