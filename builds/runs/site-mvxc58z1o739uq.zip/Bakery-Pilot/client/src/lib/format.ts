export function todayISO(timeZone = "UTC", now = new Date()) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    calendar: "iso8601",
    numberingSystem: "latn",
  }).formatToParts(now);
  const value = (type: "year" | "month" | "day") => parts.find(part => part.type === type)?.value ?? "";
  return `${value("year")}-${value("month")}-${value("day")}`;
}

export function formatDate(value: string | Date, options: Intl.DateTimeFormatOptions = { weekday: "short", month: "short", day: "numeric" }) {
  const date = value instanceof Date ? value : new Date(`${value.slice(0, 10)}T12:00:00`);
  return new Intl.DateTimeFormat("en", options).format(date);
}

export function formatCurrency(value: number | string | null | undefined, currency = "USD", options?: Intl.NumberFormatOptions) {
  const amount = Number(value ?? 0);
  return new Intl.NumberFormat(undefined, { style: "currency", currency: /^[A-Z]{3}$/.test(currency) ? currency : "USD", maximumFractionDigits: 2, ...options }).format(Number.isFinite(amount) ? amount : 0);
}

export function formatQuantity(value: number | string | null | undefined, maximumFractionDigits = 2) {
  const amount = Number(value ?? 0);
  return new Intl.NumberFormat(undefined, { maximumFractionDigits }).format(Number.isFinite(amount) ? amount : 0);
}

export function dateOffset(days: number, from = todayISO()) {
  const [year, month, day] = from.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, day + days)).toISOString().slice(0, 10);
}
