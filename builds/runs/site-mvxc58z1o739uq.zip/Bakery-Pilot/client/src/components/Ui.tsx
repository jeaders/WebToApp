import { AlertTriangle, ArrowRight, CircleCheck, LoaderCircle, PackageOpen, type LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

export function PageHeading({ eyebrow, title, description, action }: {
  eyebrow?: string;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return <div className="page-heading">
    <div>{eyebrow && <p className="eyebrow">{eyebrow}</p>}<h2>{title}</h2>{description && <p className="page-description">{description}</p>}</div>
    {action && <div className="page-heading-action">{action}</div>}
  </div>;
}

export function LoadingState({ label = "Loading your bakery workspace" }: { label?: string }) {
  return <div className="state-panel" role="status" aria-live="polite"><LoaderCircle className="spin" size={21} aria-hidden="true" /><span>{label}</span></div>;
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return <div className="error-panel" role="alert"><AlertTriangle size={20} aria-hidden="true" /><div><strong>We couldn’t load this view.</strong><p>{message}</p></div>{onRetry && <Button type="button" variant="outline" onClick={onRetry}>Try again</Button>}</div>;
}

export function EmptyState({ icon: Icon = PackageOpen, title, description, action }: {
  icon?: LucideIcon;
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  return <div className="empty-state"><span className="empty-icon"><Icon size={22} aria-hidden="true" /></span><h3>{title}</h3><p>{description}</p>{action && <div className="empty-action">{action}</div>}</div>;
}

const statusLabels: Record<string, string> = {
  new: "New", confirmed: "Confirmed", in_production: "In production", ready: "Ready", completed: "Completed", cancelled: "Cancelled",
  planned: "Planned", mixing: "Mixing", baking: "Baking", active: "Active", draft: "Draft",
};
export function StatusPill({ status }: { status: string }) {
  const tone = status === "completed" || status === "ready" ? "good" : status === "cancelled" ? "muted" : status === "in_production" || status === "mixing" || status === "baking" ? "warm" : "neutral";
  return <span className={`status-pill ${tone}`}><span className="status-indicator" aria-hidden="true" />{statusLabels[status] ?? status.replaceAll("_", " ")}</span>;
}

export function SectionTitle({ title, aside }: { title: string; aside?: React.ReactNode }) {
  return <div className="section-title"><h3>{title}</h3>{aside}</div>;
}

export function Field({ label, hint, error, children }: { label: string; hint?: string; error?: string; children: React.ReactNode }) {
  const id = `field-${label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
  return <div className="field-wrap"><label className="field-label" htmlFor={id}>{label}</label>{hint && <p className="field-hint">{hint}</p>}{children}{error && <p className="field-error" role="alert">{error}</p>}</div>;
}

export function FieldControl({ id, ...props }: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input id={id} className="field-control" {...props} />;
}

export function FieldSelect({ id, ...props }: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select id={id} className="field-control" {...props} />;
}

export function FormMessage({ children, tone = "success" }: { children: React.ReactNode; tone?: "success" | "error" }) {
  const Icon = tone === "success" ? CircleCheck : AlertTriangle;
  return <div className={`form-message ${tone}`} role={tone === "error" ? "alert" : "status"}><Icon size={17} aria-hidden="true" />{children}</div>;
}

export function InlineLink({ href, children }: { href: string; children: React.ReactNode }) {
  return <a className="inline-link" href={href}>{children}<ArrowRight size={15} aria-hidden="true" /></a>;
}
