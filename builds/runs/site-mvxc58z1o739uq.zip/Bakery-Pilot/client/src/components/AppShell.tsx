import { BookOpen, ChartColumn, ClipboardList, CookingPot, LayoutDashboard, LogOut, Package, Settings2, Wheat } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";

type AppUser = { name?: string | null; email?: string | null };
type Props = { user: AppUser; onLogout: () => Promise<void>; children: React.ReactNode };

const navigation = [
  { href: "/", label: "Today", icon: LayoutDashboard },
  { href: "/orders", label: "Orders", icon: ClipboardList },
  { href: "/recipes", label: "Recipes", icon: BookOpen },
  { href: "/inventory", label: "Inventory", icon: Package },
  { href: "/production", label: "Production", icon: CookingPot },
  { href: "/reports", label: "Reports", icon: ChartColumn },
];
const titles: Record<string, string> = {
  "/": "Today’s operations",
  "/orders": "Orders",
  "/recipes": "Recipe book",
  "/inventory": "Ingredient inventory",
  "/production": "Production plan",
  "/reports": "Operating summaries",
  "/settings": "Bakery settings",
};

export default function AppShell({ user, onLogout, children }: Props) {
  const [location] = useLocation();
  const initials = (user.name || user.email || "B").trim().slice(0, 1).toUpperCase();
  const title = titles[location] ?? "Bakery Pilot";
  const signOut = async () => {
    try {
      await onLogout();
      toast.success("Signed out safely.");
    } catch {
      toast.error("Sign-out could not finish. Please try again.");
    }
  };

  return (
    <div className="app-frame">
      <a href="#main-content" className="skip-link">Skip to main content</a>
      <aside className="desktop-sidebar" aria-label="Bakery Pilot workspace">
        <Link href="/" className="brand-lockup" aria-label="Bakery Pilot — today’s operations">
          <span className="brand-mark" aria-hidden="true"><Wheat size={19} strokeWidth={2.2} /></span>
          <span className="brand-copy"><strong>Bakery Pilot</strong><small>THE DAILY BAKE, IN HAND</small></span>
        </Link>
        <div className="sidebar-caption">WORKSPACE</div>
        <nav className="side-nav" aria-label="Main navigation">
          {navigation.map(item => {
            const Icon = item.icon;
            const active = location === item.href;
            return (
              <Link key={item.href} href={item.href} className={`nav-link${active ? " is-active" : ""}`} aria-current={active ? "page" : undefined}>
                <Icon size={18} strokeWidth={active ? 2.2 : 1.8} aria-hidden="true" />
                <span>{item.label}</span>
                {item.href === "/orders" && <span className="nav-dot" aria-hidden="true" />}
              </Link>
            );
          })}
        </nav>
        <div className="sidebar-bottom">
          <Link href="/settings" className={`nav-link${location === "/settings" ? " is-active" : ""}`} aria-current={location === "/settings" ? "page" : undefined}>
            <Settings2 size={18} aria-hidden="true" /><span>Bakery settings</span>
          </Link>
          <div className="profile-card">
            <span className="avatar" aria-hidden="true">{initials}</span>
            <span className="profile-copy"><strong>{user.name || "Bakery owner"}</strong><small>{user.email || "Signed in"}</small></span>
            <button className="icon-button profile-logout" type="button" onClick={() => void signOut()} aria-label="Sign out" title="Sign out"><LogOut size={16} /></button>
          </div>
        </div>
      </aside>

      <div className="app-main-column">
        <header className="topbar">
          <div className="mobile-brand">
            <span className="brand-mark" aria-hidden="true"><Wheat size={18} /></span>
            <strong>Bakery Pilot</strong>
          </div>
          <div className="topbar-heading"><span className="crumb">BAKERY PILOT</span><h1>{title}</h1></div>
          <div className="topbar-actions">
            <span className="workspace-status"><span className="status-dot" /> Private workspace</span>
            <Link href="/settings" className="topbar-settings" aria-label="Bakery settings"><Settings2 size={18} /></Link>
            <button className="icon-button mobile-logout" type="button" onClick={() => void signOut()} aria-label="Sign out"><LogOut size={18} /></button>
          </div>
        </header>
        <nav className="mobile-nav" aria-label="Main navigation">
          {navigation.map(item => {
            const Icon = item.icon;
            const active = location === item.href;
            return <Link key={item.href} href={item.href} className={`mobile-nav-link${active ? " is-active" : ""}`} aria-current={active ? "page" : undefined}>
              <Icon size={17} aria-hidden="true" /><span>{item.label}</span>
            </Link>;
          })}
        </nav>
        <main id="main-content" className="main-content">{children}</main>
      </div>
    </div>
  );
}
