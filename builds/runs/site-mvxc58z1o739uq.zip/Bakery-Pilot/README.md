# Bakery Pilot

A private bakery-operations workspace for independent bakery owners and managers. Bakery Pilot turns saved customer orders and recipes into a practical daily bake plan, checks ingredient availability, tracks production batches, and keeps stock movement history auditable.

The supplied Replit reference could not be inspected, so this app is an independent concept build—not a verified reproduction of that project. See [`research/reference-audit.md`](research/reference-audit.md) for the source limitation, product assumptions, route map, and design direction.

## What it does

- Capture customer orders with due dates, recipe quantities, notes, and fulfillment status.
- Maintain recipes, ingredient quantities, yields, current costs, suggested prices, and target margins.
- Track ingredient stock, reorder points, purchases, adjustments, waste, and production usage.
- Convert open demand into editable daily production plans with batch counts, time slots, capacity signals, and shortage checks.
- Track batches from planned through mixing, baking, ready, and completion; record actual yield and linked stock use.
- Review date-range operating summaries for orders, output, ingredient use and waste, revenue, costs, margin, and low stock.
- Keep business records scoped to the signed-in owner through the project's Manus OAuth session.

## Stack

React, Vite, TypeScript, Express, tRPC, Drizzle ORM, and the project's managed MySQL-compatible database. The UI uses the existing project components and a warm, responsive bakery-operations design system.

## Run and maintain

The project uses the pinned package manager and lockfile already in the repository.

```sh
pnpm install --frozen-lockfile
pnpm db:migrate
pnpm dev
```

The development server listens on `PORT` (default `3000`). The runtime must provide the project's server, managed database, and Manus OAuth configuration; never commit local `.env` files or credentials.

Useful commands:

```sh
pnpm check       # TypeScript
pnpm test        # Unit/platform tests
pnpm build       # Client and server production bundles
pnpm start       # Serve the built application
```

Migrations are committed under `drizzle/`. Development and published production share the managed database, so applying a migration changes that shared database. Review every generated migration before applying it; the checked-in migrations preserve existing business rows.

## Data and operational notes

- No sample customer, recipe, order, or inventory records are seeded; a signed-in owner starts with clear setup prompts.
- Currency is selected before entering priced records and cannot be changed after financial data exists, because historic values are not silently converted.
- Ingredient units are protected once stock, a recipe, or movement history depends on them.
- Started/completed production batches and in-production order quantities are locked to preserve the agreed demand and bill of materials. Later demand can be added as supplemental batches.
- Date-based stock movement reports use the bakery's IANA timezone, including daylight-saving boundaries.
- `client/public/manus-routes.json` declares the page routes; update it whenever page routing changes.

## Project map

- `client/src/pages/` — dashboard, orders, recipes, inventory, production, reports, and settings.
- `client/src/components/` — authenticated app shell and reusable operational UI.
- `server/bakeryRouter.ts` — validated, authenticated business procedures.
- `server/bakeryDb.ts` — owner-scoped persistence and transactions.
- `shared/bakeryLogic.ts` — deterministic costing, planning, and timezone calculations.
- `drizzle/` — schemas and additive database migrations.
- `research/reference-audit.md` and `TODO.md` — source limitation, approved product contract, and build outcomes.
