export type RecipeIngredientInput = {
  ingredientId: number;
  ingredientName: string;
  unit: string;
  quantityPerBatch: number;
  currentStock: number;
  unitCost: number;
};

export type RecipePlanningInput = {
  id: number;
  name: string;
  yieldQuantity: number;
  yieldUnit: string;
  ingredients: RecipeIngredientInput[];
};

export type DemandInput = { recipeId: number; quantity: number };

export function numeric(value: string | number | null | undefined): number {
  const parsed = typeof value === "number" ? value : Number(value ?? 0);
  return Number.isFinite(parsed) ? parsed : 0;
}

function startOfLocalDateUtc(dateISO: string, timeZone: string) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateISO);
  if (!match) throw new RangeError("Use a valid YYYY-MM-DD date.");
  const [, yearText, monthText, dayText] = match;
  const year = Number(yearText);
  const month = Number(monthText);
  const day = Number(dayText);
  const localMidnightAsUtc = Date.UTC(year, month - 1, day);
  if (new Date(localMidnightAsUtc).toISOString().slice(0, 10) !== dateISO) throw new RangeError("Use a valid calendar date.");

  const formatter = new Intl.DateTimeFormat("en-US", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  });
  let candidate = localMidnightAsUtc;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const parts = Object.fromEntries(formatter.formatToParts(new Date(candidate)).map(part => [part.type, part.value]));
    const formattedAsUtc = Date.UTC(
      Number(parts.year), Number(parts.month) - 1, Number(parts.day),
      Number(parts.hour), Number(parts.minute), Number(parts.second),
    );
    const offset = formattedAsUtc - Math.floor(candidate / 1000) * 1000;
    candidate = localMidnightAsUtc - offset;
  }
  return new Date(candidate);
}

export function localDateRangeUtc(from: string, to: string, timeZone: string) {
  if (from > to) throw new RangeError("End date must be on or after start date.");
  const nextDay = new Date(`${to}T00:00:00.000Z`);
  nextDay.setUTCDate(nextDay.getUTCDate() + 1);
  const start = startOfLocalDateUtc(from, timeZone);
  const endExclusive = startOfLocalDateUtc(nextDay.toISOString().slice(0, 10), timeZone);
  return { start, end: new Date(endExclusive.getTime() - 1) };
}

export function recipeCost(ingredients: RecipeIngredientInput[]) {
  return ingredients.reduce((total, item) => total + item.quantityPerBatch * item.unitCost, 0);
}

export function marginPercent(unitPrice: number, unitCost: number) {
  if (unitPrice <= 0) return 0;
  return ((unitPrice - unitCost) / unitPrice) * 100;
}

export function suggestedPrice(unitCost: number, targetMargin: number) {
  if (unitCost <= 0) return 0;
  const bounded = Math.min(Math.max(targetMargin, 0), 0.9);
  return unitCost / (1 - bounded);
}

export type PlanLine = {
  recipeId: number;
  recipeName: string;
  demandQuantity: number;
  yieldQuantity: number;
  yieldUnit: string;
  recommendedBatches: number;
  recommendedQuantity: number;
};

export type PlanShortage = {
  ingredientId: number;
  ingredientName: string;
  unit: string;
  needed: number;
  available: number;
  shortfall: number;
};

export function buildPlanRecommendations(
  demand: DemandInput[],
  recipes: RecipePlanningInput[],
  dailyBatchCapacity: number,
) {
  const demandByRecipe = new Map<number, number>();
  for (const item of demand) {
    if (item.quantity > 0) {
      demandByRecipe.set(item.recipeId, (demandByRecipe.get(item.recipeId) ?? 0) + item.quantity);
    }
  }

  const recipeById = new Map(recipes.map(recipe => [recipe.id, recipe]));
  const lines: PlanLine[] = [];
  const ingredientNeeds = new Map<number, PlanShortage>();

  for (const [recipeId, demandQuantity] of demandByRecipe) {
    const recipe = recipeById.get(recipeId);
    if (!recipe || recipe.yieldQuantity <= 0) continue;
    const recommendedBatches = Math.ceil(demandQuantity / recipe.yieldQuantity);
    lines.push({
      recipeId,
      recipeName: recipe.name,
      demandQuantity,
      yieldQuantity: recipe.yieldQuantity,
      yieldUnit: recipe.yieldUnit,
      recommendedBatches,
      recommendedQuantity: recommendedBatches * recipe.yieldQuantity,
    });
    for (const ingredient of recipe.ingredients) {
      const needed = recommendedBatches * ingredient.quantityPerBatch;
      const current = ingredientNeeds.get(ingredient.ingredientId);
      if (current) {
        current.needed += needed;
      } else {
        ingredientNeeds.set(ingredient.ingredientId, {
          ingredientId: ingredient.ingredientId,
          ingredientName: ingredient.ingredientName,
          unit: ingredient.unit,
          needed,
          available: ingredient.currentStock,
          shortfall: 0,
        });
      }
    }
  }

  lines.sort((a, b) => a.recipeName.localeCompare(b.recipeName));
  const shortages = [...ingredientNeeds.values()]
    .map(item => ({ ...item, shortfall: Math.max(0, item.needed - item.available) }))
    .filter(item => item.shortfall > 0.0005)
    .sort((a, b) => b.shortfall - a.shortfall);
  const totalBatches = lines.reduce((total, item) => total + item.recommendedBatches, 0);
  const safeCapacity = Math.max(0, Math.floor(dailyBatchCapacity));

  return {
    lines,
    shortages,
    totalBatches,
    dailyBatchCapacity: safeCapacity,
    capacityExceeded: totalBatches > safeCapacity,
    uncoveredDemand: demandByRecipe.size > lines.length,
  };
}
