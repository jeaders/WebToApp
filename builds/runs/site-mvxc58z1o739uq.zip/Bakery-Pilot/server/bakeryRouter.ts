import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  archiveIngredient,
  archiveRecipe,
  getDashboardSnapshot,
  getPlanPreview,
  getReport,
  getSettings,
  listBatches,
  listIngredients,
  listMovements,
  listOrders,
  listRecipes,
  moveStock,
  saveIngredient,
  saveOrder,
  savePlan,
  saveRecipe,
  updateBatch,
  updateOrderStatus,
  updateSettings,
} from "./bakeryDb";
import { protectedProcedure, router } from "./_core/trpc";

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(value => {
  const date = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}, "Enter a valid calendar date.");

const positive = (label: string, max = 1_000_000) => z.number().finite(`${label} must be a number.`).positive(`${label} must be greater than zero.`).max(max, `${label} is too large.`);
const nonnegative = (label: string, max = 1_000_000) => z.number().finite(`${label} must be a number.`).min(0, `${label} cannot be negative.`).max(max, `${label} is too large.`);

const orderStatus = z.enum(["new", "confirmed", "in_production", "ready", "completed", "cancelled"]);
const batchStatus = z.enum(["planned", "mixing", "baking", "ready", "completed", "cancelled"]);

export const bakeryRouter = router({
  settings: router({
    get: protectedProcedure.query(({ ctx }) => getSettings(ctx.user.id)),
    update: protectedProcedure.input(z.object({
      bakeryName: z.string().trim().min(1).max(140),
      currency: z.string().regex(/^[A-Za-z]{3}$/).transform(value => value.toUpperCase()),
      timezone: z.string().min(1).max(64).refine(value => {
        try { new Intl.DateTimeFormat("en", { timeZone: value }); return true; } catch { return false; }
      }, "Choose a valid time zone."),
      dailyBatchCapacity: z.number().int().min(1).max(5000),
    })).mutation(({ ctx, input }) => updateSettings(ctx.user.id, input)),
  }),

  dashboard: router({
    snapshot: protectedProcedure.input(z.object({ date: isoDate })).query(({ ctx, input }) => getDashboardSnapshot(ctx.user.id, input.date)),
  }),

  ingredients: router({
    list: protectedProcedure.query(({ ctx }) => listIngredients(ctx.user.id)),
    movements: protectedProcedure.input(z.object({ limit: z.number().int().min(1).max(100).default(40) }).optional())
      .query(({ ctx, input }) => listMovements(ctx.user.id, input?.limit ?? 40)),
    save: protectedProcedure.input(z.object({
      id: z.number().int().positive().optional(),
      name: z.string().trim().min(1).max(140),
      unit: z.string().trim().min(1).max(16),
      openingStock: nonnegative("Opening stock").optional(),
      reorderPoint: nonnegative("Reorder point"),
      unitCost: nonnegative("Unit cost", 1_000_000),
    })).mutation(({ ctx, input }) => saveIngredient(ctx.user.id, input)),
    archive: protectedProcedure.input(z.object({ id: z.number().int().positive() }))
      .mutation(({ ctx, input }) => archiveIngredient(ctx.user.id, input.id)),
    moveStock: protectedProcedure.input(z.object({
      ingredientId: z.number().int().positive(),
      movementType: z.enum(["purchase", "adjustment", "waste"]),
      quantity: z.number().finite().refine(value => value !== 0, "Quantity cannot be zero.").max(1_000_000).min(-1_000_000),
      note: z.string().trim().max(500).optional(),
      updatedUnitCost: nonnegative("Updated unit cost", 1_000_000).optional(),
    }).superRefine((value, context) => {
      if (value.movementType !== "adjustment" && value.quantity <= 0) {
        context.addIssue({ code: "custom", path: ["quantity"], message: "Enter a positive quantity for purchases and waste." });
      }
    })).mutation(({ ctx, input }) => moveStock(ctx.user.id, input)),
  }),

  recipes: router({
    list: protectedProcedure.query(({ ctx }) => listRecipes(ctx.user.id)),
    save: protectedProcedure.input(z.object({
      id: z.number().int().positive().optional(),
      name: z.string().trim().min(1).max(140),
      category: z.string().trim().min(1).max(48),
      yieldQuantity: positive("Yield"),
      yieldUnit: z.string().trim().min(1).max(16),
      sellingPrice: nonnegative("Selling price", 1_000_000),
      targetMargin: z.number().finite().min(0).max(0.9),
      notes: z.string().trim().max(2000).optional(),
      ingredients: z.array(z.object({ ingredientId: z.number().int().positive(), quantityPerBatch: positive("Ingredient quantity") })).min(1).max(50),
    })).mutation(({ ctx, input }) => saveRecipe(ctx.user.id, input)),
    archive: protectedProcedure.input(z.object({ id: z.number().int().positive() }))
      .mutation(({ ctx, input }) => archiveRecipe(ctx.user.id, input.id)),
  }),

  orders: router({
    list: protectedProcedure.input(z.object({
      from: isoDate.optional(),
      to: isoDate.optional(),
      status: orderStatus.optional(),
    }).optional()).query(({ ctx, input }) => listOrders(ctx.user.id, input ?? {})),
    save: protectedProcedure.input(z.object({
      id: z.number().int().positive().optional(),
      customerName: z.string().trim().min(1).max(140),
      dueDate: isoDate,
      notes: z.string().trim().max(2000).optional(),
      items: z.array(z.object({ recipeId: z.number().int().positive(), quantity: positive("Order quantity") })).min(1).max(50),
    })).mutation(({ ctx, input }) => saveOrder(ctx.user.id, input)),
    updateStatus: protectedProcedure.input(z.object({ id: z.number().int().positive(), status: orderStatus }))
      .mutation(({ ctx, input }) => updateOrderStatus(ctx.user.id, input.id, input.status)),
  }),

  production: router({
    preview: protectedProcedure.input(z.object({ date: isoDate })).query(({ ctx, input }) => getPlanPreview(ctx.user.id, input.date)),
    batches: protectedProcedure.input(z.object({ date: isoDate.optional() }).optional())
      .query(({ ctx, input }) => listBatches(ctx.user.id, input?.date)),
    savePlan: protectedProcedure.input(z.object({
      date: isoDate,
      notes: z.string().trim().max(2000).optional(),
      items: z.array(z.object({
        batchId: z.number().int().positive().optional(),
        recipeId: z.number().int().positive(),
        demandQuantity: nonnegative("Demand quantity"),
        batchCount: z.number().int().min(1).max(500),
        plannedTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/).optional(),
      })).min(1).max(50).superRefine((items, context) => {
        const savedBatchIds = items.flatMap(item => item.batchId === undefined ? [] : [item.batchId]);
        if (new Set(savedBatchIds).size !== savedBatchIds.length) {
          context.addIssue({ code: "custom", message: "A saved batch can appear only once in a plan update." });
        }
      }),
    })).mutation(({ ctx, input }) => savePlan(ctx.user.id, input)),
    updateBatch: protectedProcedure.input(z.object({
      id: z.number().int().positive(),
      status: batchStatus,
      actualYield: positive("Actual yield").optional(),
      notes: z.string().trim().max(2000).optional(),
    }).superRefine((value, context) => {
      if (value.status === "completed" && value.actualYield === undefined) {
        context.addIssue({ code: "custom", path: ["actualYield"], message: "Enter actual yield to complete a batch." });
      }
    })).mutation(({ ctx, input }) => updateBatch(ctx.user.id, input)),
  }),

  reports: router({
    summary: protectedProcedure.input(z.object({ from: isoDate, to: isoDate }).refine(value => value.from <= value.to, {
      path: ["to"], message: "End date must be on or after the start date.",
    })).query(({ ctx, input }) => getReport(ctx.user.id, input.from, input.to)),
  }),
});
