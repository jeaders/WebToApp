import { TRPCError } from "@trpc/server";
import { and, asc, desc, eq, gte, inArray, isNull, lte } from "drizzle-orm";
import {
  bakerySettings,
  ingredients,
  orderItems,
  orders,
  productionBatches,
  productionPlans,
  recipeIngredients,
  recipes,
  stockMovements,
} from "../drizzle/schema";
import { buildPlanRecommendations, localDateRangeUtc, marginPercent, numeric, recipeCost, suggestedPrice } from "../shared/bakeryLogic";
import { getDb } from "./db";

export type BakeryDb = NonNullable<Awaited<ReturnType<typeof getDb>>>;

async function requireDb(): Promise<BakeryDb> {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Bakery storage is temporarily unavailable. Try again shortly." });
  return db;
}

function missing(message: string): never {
  throw new TRPCError({ code: "NOT_FOUND", message });
}

function number(value: string | number | null | undefined) {
  return numeric(value);
}

export async function getSettings(ownerId: number) {
  const db = await requireDb();
  await db.insert(bakerySettings).values({ ownerId }).onDuplicateKeyUpdate({ set: { ownerId } });
  const [settings] = await db.select().from(bakerySettings).where(eq(bakerySettings.ownerId, ownerId)).limit(1);
  if (!settings) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Bakery settings could not be loaded." });
  return settings;
}

export async function updateSettings(ownerId: number, input: { bakeryName: string; currency: string; timezone: string; dailyBatchCapacity: number }) {
  const db = await requireDb();
  await getSettings(ownerId);
  await db.transaction(async tx => {
    const [current] = await tx.select().from(bakerySettings).where(eq(bakerySettings.ownerId, ownerId)).limit(1).for("update");
    if (!current) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Bakery settings could not be loaded." });
    if (input.currency !== current.currency) {
      const [pricedIngredient] = await tx.select({ id: ingredients.id }).from(ingredients).where(eq(ingredients.ownerId, ownerId)).limit(1);
      const [pricedRecipe] = await tx.select({ id: recipes.id }).from(recipes).where(eq(recipes.ownerId, ownerId)).limit(1);
      const [recordedOrder] = await tx.select({ id: orders.id }).from(orders).where(eq(orders.ownerId, ownerId)).limit(1);
      if (pricedIngredient || pricedRecipe || recordedOrder) {
        throw new TRPCError({ code: "CONFLICT", message: "Currency cannot be changed after ingredients, recipes, or orders have been recorded because saved amounts are not converted." });
      }
    }
    await tx.update(bakerySettings).set(input).where(and(eq(bakerySettings.id, current.id), eq(bakerySettings.ownerId, ownerId)));
  });
  return getSettings(ownerId);
}

export async function listIngredients(ownerId: number, includeArchived = false) {
  const db = await requireDb();
  return db.select().from(ingredients)
    .where(and(eq(ingredients.ownerId, ownerId), includeArchived ? undefined : eq(ingredients.isArchived, false)))
    .orderBy(asc(ingredients.name));
}

export async function saveIngredient(ownerId: number, input: {
  id?: number;
  name: string;
  unit: string;
  openingStock?: number;
  reorderPoint: number;
  unitCost: number;
}) {
  const db = await requireDb();
  await getSettings(ownerId);
  if (input.id) {
    return db.transaction(async tx => {
      await tx.select({ id: bakerySettings.id }).from(bakerySettings).where(eq(bakerySettings.ownerId, ownerId)).limit(1).for("update");
      const [existing] = await tx.select().from(ingredients)
        .where(and(eq(ingredients.id, input.id!), eq(ingredients.ownerId, ownerId), eq(ingredients.isArchived, false))).limit(1).for("update");
      if (!existing) missing("Ingredient not found.");
      if (input.unit !== existing.unit) {
        const [recipeUse] = await tx.select({ id: recipeIngredients.id }).from(recipeIngredients)
          .where(and(eq(recipeIngredients.ownerId, ownerId), eq(recipeIngredients.ingredientId, existing.id))).limit(1);
        const [movement] = await tx.select({ id: stockMovements.id }).from(stockMovements)
          .where(and(eq(stockMovements.ownerId, ownerId), eq(stockMovements.ingredientId, existing.id))).limit(1);
        if (number(existing.currentStock) !== 0 || number(existing.reorderPoint) !== 0 || recipeUse || movement) {
          throw new TRPCError({ code: "CONFLICT", message: "This ingredient’s unit is in use by stock, a recipe, or movement history. Its unit cannot be changed without converting those records." });
        }
      }
      await tx.update(ingredients).set({
        name: input.name,
        unit: input.unit,
        reorderPoint: String(input.reorderPoint),
        unitCost: String(input.unitCost),
        updatedAt: new Date(),
      }).where(and(eq(ingredients.id, input.id!), eq(ingredients.ownerId, ownerId), eq(ingredients.isArchived, false)));
      const [updated] = await tx.select().from(ingredients).where(and(eq(ingredients.id, input.id!), eq(ingredients.ownerId, ownerId))).limit(1);
      return updated;
    });
  }

  return db.transaction(async tx => {
    await tx.select({ id: bakerySettings.id }).from(bakerySettings).where(eq(bakerySettings.ownerId, ownerId)).limit(1).for("update");
    const openingStock = number(input.openingStock);
    const [inserted] = await tx.insert(ingredients).values({
      ownerId,
      name: input.name,
      unit: input.unit,
      currentStock: String(openingStock),
      reorderPoint: String(input.reorderPoint),
      unitCost: String(input.unitCost),
    }).$returningId();
    if (openingStock > 0) {
      await tx.insert(stockMovements).values({
        ownerId,
        ingredientId: inserted.id,
        movementType: "adjustment",
        quantityDelta: String(openingStock),
        referenceType: "opening_stock",
        referenceId: inserted.id,
        note: "Opening stock",
      });
    }
    const [created] = await tx.select().from(ingredients).where(and(eq(ingredients.id, inserted.id), eq(ingredients.ownerId, ownerId))).limit(1);
    return created;
  });
}

export async function archiveIngredient(ownerId: number, id: number) {
  const db = await requireDb();
  const [existing] = await db.select({ id: ingredients.id }).from(ingredients)
    .where(and(eq(ingredients.id, id), eq(ingredients.ownerId, ownerId))).limit(1);
  if (!existing) missing("Ingredient not found.");
  const [activeUse] = await db.select({ id: recipeIngredients.id }).from(recipeIngredients)
    .innerJoin(recipes, and(eq(recipes.id, recipeIngredients.recipeId), eq(recipes.ownerId, ownerId)))
    .where(and(eq(recipeIngredients.ownerId, ownerId), eq(recipeIngredients.ingredientId, id), isNull(recipes.archivedAt))).limit(1);
  if (activeUse) throw new TRPCError({ code: "CONFLICT", message: "This ingredient is still used by an active recipe. Update or archive that recipe first." });
  await db.update(ingredients).set({ isArchived: true, updatedAt: new Date() })
    .where(and(eq(ingredients.id, id), eq(ingredients.ownerId, ownerId)));
  return { success: true };
}

export async function moveStock(ownerId: number, input: {
  ingredientId: number;
  movementType: "purchase" | "adjustment" | "waste";
  quantity: number;
  note?: string;
  updatedUnitCost?: number;
}) {
  const db = await requireDb();
  await getSettings(ownerId);
  return db.transaction(async tx => {
    await tx.select({ id: bakerySettings.id }).from(bakerySettings).where(eq(bakerySettings.ownerId, ownerId)).limit(1).for("update");
    const [ingredient] = await tx.select().from(ingredients)
      .where(and(eq(ingredients.id, input.ingredientId), eq(ingredients.ownerId, ownerId), eq(ingredients.isArchived, false))).limit(1).for("update");
    if (!ingredient) missing("Ingredient not found.");
    const magnitude = Math.abs(input.quantity);
    const delta = input.movementType === "purchase" ? magnitude : input.movementType === "waste" ? -magnitude : input.quantity;
    const nextStock = number(ingredient.currentStock) + delta;
    if (nextStock < -0.0005) {
      throw new TRPCError({ code: "BAD_REQUEST", message: `This movement would leave ${ingredient.name} below zero. Record a purchase or correct the quantity first.` });
    }
    await tx.update(ingredients).set({
      currentStock: String(Math.max(0, nextStock)),
      unitCost: input.updatedUnitCost === undefined ? ingredient.unitCost : String(input.updatedUnitCost),
      updatedAt: new Date(),
    }).where(and(eq(ingredients.id, ingredient.id), eq(ingredients.ownerId, ownerId)));
    await tx.insert(stockMovements).values({
      ownerId,
      ingredientId: ingredient.id,
      movementType: input.movementType,
      quantityDelta: String(delta),
      note: input.note?.trim() || null,
    });
    const [updated] = await tx.select().from(ingredients).where(and(eq(ingredients.id, ingredient.id), eq(ingredients.ownerId, ownerId))).limit(1);
    return updated;
  });
}

export async function listMovements(ownerId: number, limit = 40) {
  const db = await requireDb();
  return db.select({
    id: stockMovements.id,
    movementType: stockMovements.movementType,
    quantityDelta: stockMovements.quantityDelta,
    note: stockMovements.note,
    createdAt: stockMovements.createdAt,
    ingredientId: ingredients.id,
    ingredientName: ingredients.name,
    unit: ingredients.unit,
  }).from(stockMovements)
    .innerJoin(ingredients, and(eq(ingredients.id, stockMovements.ingredientId), eq(ingredients.ownerId, ownerId)))
    .where(eq(stockMovements.ownerId, ownerId))
    .orderBy(desc(stockMovements.createdAt)).limit(limit);
}

export async function listRecipes(ownerId: number, includeArchived = false) {
  const db = await requireDb();
  const baseRecipes = await db.select().from(recipes)
    .where(and(eq(recipes.ownerId, ownerId), includeArchived ? undefined : isNull(recipes.archivedAt)))
    .orderBy(asc(recipes.name));
  if (baseRecipes.length === 0) return [];
  const recipeIds = baseRecipes.map(recipe => recipe.id);
  const parts = await db.select({
    recipeId: recipeIngredients.recipeId,
    ingredientId: ingredients.id,
    ingredientName: ingredients.name,
    unit: ingredients.unit,
    quantityPerBatch: recipeIngredients.quantityPerBatch,
    currentStock: ingredients.currentStock,
    unitCost: ingredients.unitCost,
    isArchived: ingredients.isArchived,
  }).from(recipeIngredients)
    .innerJoin(ingredients, and(eq(ingredients.id, recipeIngredients.ingredientId), eq(ingredients.ownerId, ownerId)))
    .where(and(eq(recipeIngredients.ownerId, ownerId), inArray(recipeIngredients.recipeId, recipeIds)));

  const partsByRecipe = new Map<number, typeof parts>();
  for (const part of parts) {
    const list = partsByRecipe.get(part.recipeId) ?? [];
    list.push(part);
    partsByRecipe.set(part.recipeId, list);
  }
  return baseRecipes.map(recipe => {
    const linked = (partsByRecipe.get(recipe.id) ?? []).map(part => ({
      ingredientId: part.ingredientId,
      ingredientName: part.ingredientName,
      unit: part.unit,
      quantityPerBatch: number(part.quantityPerBatch),
      currentStock: number(part.currentStock),
      unitCost: number(part.unitCost),
      isArchived: part.isArchived,
    }));
    const batchCost = recipeCost(linked);
    const unitCost = recipe.yieldQuantity === "0" ? 0 : batchCost / number(recipe.yieldQuantity);
    const target = number(recipe.targetMargin);
    return {
      ...recipe,
      ingredients: linked,
      batchCost,
      unitCost,
      margin: marginPercent(number(recipe.sellingPrice), unitCost),
      suggestedPrice: suggestedPrice(unitCost, target),
    };
  });
}

export async function saveRecipe(ownerId: number, input: {
  id?: number;
  name: string;
  category: string;
  yieldQuantity: number;
  yieldUnit: string;
  sellingPrice: number;
  targetMargin: number;
  notes?: string;
  ingredients: Array<{ ingredientId: number; quantityPerBatch: number }>;
}) {
  const db = await requireDb();
  if (input.ingredients.length === 0) throw new TRPCError({ code: "BAD_REQUEST", message: "Add at least one ingredient to this recipe." });
  const ids = [...new Set(input.ingredients.map(item => item.ingredientId))];
  if (ids.length !== input.ingredients.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Each ingredient can appear only once in a recipe." });

  await getSettings(ownerId);
  return db.transaction(async tx => {
    await tx.select({ id: bakerySettings.id }).from(bakerySettings).where(eq(bakerySettings.ownerId, ownerId)).limit(1).for("update");
    const validIngredients = await tx.select({ id: ingredients.id }).from(ingredients)
      .where(and(eq(ingredients.ownerId, ownerId), eq(ingredients.isArchived, false), inArray(ingredients.id, ids))).for("update");
    if (validIngredients.length !== ids.length) throw new TRPCError({ code: "BAD_REQUEST", message: "One or more selected ingredients are unavailable." });

    let recipeId = input.id;
    const values = {
      ownerId,
      name: input.name,
      category: input.category,
      yieldQuantity: String(input.yieldQuantity),
      yieldUnit: input.yieldUnit,
      sellingPrice: String(input.sellingPrice),
      targetMargin: String(input.targetMargin),
      notes: input.notes?.trim() || null,
    };
    if (recipeId) {
      const [existing] = await tx.select({ id: recipes.id, yieldUnit: recipes.yieldUnit }).from(recipes)
        .where(and(eq(recipes.id, recipeId), eq(recipes.ownerId, ownerId), isNull(recipes.archivedAt))).limit(1).for("update");
      if (!existing) missing("Recipe not found.");
      if (input.yieldUnit !== existing.yieldUnit) {
        const [batchHistory] = await tx.select({ id: productionBatches.id }).from(productionBatches)
          .where(and(eq(productionBatches.ownerId, ownerId), eq(productionBatches.recipeId, recipeId))).limit(1).for("update");
        if (batchHistory) throw new TRPCError({ code: "CONFLICT", message: "This recipe’s yield unit is used by production history and cannot be changed. Keep the same unit to preserve the meaning of recorded targets and actual yields." });
      }
      const [activeBatch] = await tx.select({ id: productionBatches.id }).from(productionBatches)
        .where(and(eq(productionBatches.ownerId, ownerId), eq(productionBatches.recipeId, recipeId), inArray(productionBatches.status, ["planned", "mixing", "baking", "ready"]))).limit(1).for("update");
      if (activeBatch) throw new TRPCError({ code: "CONFLICT", message: "This recipe is locked while a production batch is planned or underway. Cancel the planned batch or finish active production before editing it." });
      await tx.update(recipes).set({ ...values, updatedAt: new Date() })
        .where(and(eq(recipes.id, recipeId), eq(recipes.ownerId, ownerId)));
      await tx.delete(recipeIngredients).where(and(eq(recipeIngredients.ownerId, ownerId), eq(recipeIngredients.recipeId, recipeId)));
    } else {
      const [created] = await tx.insert(recipes).values(values).$returningId();
      recipeId = created.id;
    }
    await tx.insert(recipeIngredients).values(input.ingredients.map(item => ({
      ownerId,
      recipeId: recipeId!,
      ingredientId: item.ingredientId,
      quantityPerBatch: String(item.quantityPerBatch),
    })));
    return { id: recipeId };
  });
}

export async function archiveRecipe(ownerId: number, id: number) {
  const db = await requireDb();
  const [existing] = await db.select({ id: recipes.id }).from(recipes)
    .where(and(eq(recipes.id, id), eq(recipes.ownerId, ownerId), isNull(recipes.archivedAt))).limit(1);
  if (!existing) missing("Recipe not found.");
  const [openOrder] = await db.select({ id: orderItems.id }).from(orderItems)
    .innerJoin(orders, and(eq(orders.id, orderItems.orderId), eq(orders.ownerId, ownerId)))
    .where(and(eq(orderItems.ownerId, ownerId), eq(orderItems.recipeId, id), inArray(orders.status, ["new", "confirmed", "in_production", "ready"]))).limit(1);
  const [activeBatch] = await db.select({ id: productionBatches.id }).from(productionBatches)
    .where(and(eq(productionBatches.ownerId, ownerId), eq(productionBatches.recipeId, id), inArray(productionBatches.status, ["planned", "mixing", "baking", "ready"]))).limit(1);
  if (openOrder || activeBatch) throw new TRPCError({ code: "CONFLICT", message: "Complete or cancel this recipe’s open orders and active production batches before archiving it." });
  await db.update(recipes).set({ archivedAt: new Date(), updatedAt: new Date() })
    .where(and(eq(recipes.id, id), eq(recipes.ownerId, ownerId)));
  return { success: true };
}

export async function listOrders(ownerId: number, filters: { from?: string; to?: string; status?: "new" | "confirmed" | "in_production" | "ready" | "completed" | "cancelled" } = {}) {
  const db = await requireDb();
  const rows = await db.select().from(orders).where(and(
    eq(orders.ownerId, ownerId),
    filters.from ? gte(orders.dueDate, filters.from) : undefined,
    filters.to ? lte(orders.dueDate, filters.to) : undefined,
    filters.status ? eq(orders.status, filters.status) : undefined,
  )).orderBy(asc(orders.dueDate), desc(orders.createdAt));
  if (rows.length === 0) return [];
  const ids = rows.map(row => row.id);
  const lineRows = await db.select({
    id: orderItems.id,
    orderId: orderItems.orderId,
    recipeId: orderItems.recipeId,
    recipeName: recipes.name,
    quantity: orderItems.quantity,
    unitPriceAtOrder: orderItems.unitPriceAtOrder,
    unitCostAtOrder: orderItems.unitCostAtOrder,
  }).from(orderItems)
    .innerJoin(recipes, and(eq(recipes.id, orderItems.recipeId), eq(recipes.ownerId, ownerId)))
    .where(and(eq(orderItems.ownerId, ownerId), inArray(orderItems.orderId, ids)));
  const byOrder = new Map<number, typeof lineRows>();
  for (const line of lineRows) {
    const list = byOrder.get(line.orderId) ?? [];
    list.push(line);
    byOrder.set(line.orderId, list);
  }
  return rows.map(order => {
    const items = byOrder.get(order.id) ?? [];
    const total = items.reduce((sum, line) => sum + number(line.quantity) * number(line.unitPriceAtOrder), 0);
    const cost = items.reduce((sum, line) => sum + number(line.quantity) * number(line.unitCostAtOrder), 0);
    return { ...order, items, total, cost, grossProfit: total - cost, margin: marginPercent(total, cost) };
  });
}

export async function saveOrder(ownerId: number, input: {
  id?: number;
  customerName: string;
  dueDate: string;
  notes?: string;
  items: Array<{ recipeId: number; quantity: number }>;
}) {
  const db = await requireDb();
  if (input.items.length === 0) throw new TRPCError({ code: "BAD_REQUEST", message: "Add at least one item to this order." });
  await getSettings(ownerId);
  const recipeIds = [...new Set(input.items.map(item => item.recipeId))];
  const activeRecipes = await listRecipes(ownerId);
  const selected = activeRecipes.filter(recipe => recipeIds.includes(recipe.id));
  if (selected.length !== recipeIds.length) throw new TRPCError({ code: "BAD_REQUEST", message: "One or more selected recipes are unavailable." });
  const recipeById = new Map(selected.map(recipe => [recipe.id, recipe]));

  return db.transaction(async tx => {
    await tx.select({ id: bakerySettings.id }).from(bakerySettings).where(eq(bakerySettings.ownerId, ownerId)).limit(1).for("update");
    let orderId = input.id;
    if (orderId) {
      const [existing] = await tx.select().from(orders)
        .where(and(eq(orders.id, orderId), eq(orders.ownerId, ownerId))).limit(1).for("update");
      if (!existing) missing("Order not found.");
      if (existing.status === "completed" || existing.status === "cancelled") {
        throw new TRPCError({ code: "CONFLICT", message: "Completed or cancelled orders can no longer be edited." });
      }
      if (existing.status === "in_production" || existing.status === "ready") {
        const savedLines = await tx.select({ recipeId: orderItems.recipeId, quantity: orderItems.quantity }).from(orderItems)
          .where(and(eq(orderItems.orderId, orderId), eq(orderItems.ownerId, ownerId))).for("update");
        const aggregate = (rows: Array<{ recipeId: number; quantity: string | number }>) => {
          const totals = new Map<number, number>();
          for (const row of rows) totals.set(row.recipeId, (totals.get(row.recipeId) ?? 0) + number(row.quantity));
          return totals;
        };
        const savedByRecipe = aggregate(savedLines);
        const proposedByRecipe = aggregate(input.items);
        const sameItems = savedByRecipe.size === proposedByRecipe.size && [...savedByRecipe].every(([recipeId, quantity]) =>
          Math.abs(quantity - (proposedByRecipe.get(recipeId) ?? Number.NaN)) < 0.0005,
        );
        if (existing.dueDate !== input.dueDate || !sameItems) {
          throw new TRPCError({ code: "CONFLICT", message: "Production has started. The due date and recipe quantities are locked; only the customer label and notes may be changed." });
        }
        await tx.update(orders).set({ customerName: input.customerName, notes: input.notes?.trim() || null, updatedAt: new Date() })
          .where(and(eq(orders.id, orderId), eq(orders.ownerId, ownerId)));
        return { id: orderId };
      }
      await tx.update(orders).set({ customerName: input.customerName, dueDate: input.dueDate, notes: input.notes?.trim() || null, updatedAt: new Date() })
        .where(and(eq(orders.id, orderId), eq(orders.ownerId, ownerId)));
      await tx.delete(orderItems).where(and(eq(orderItems.orderId, orderId), eq(orderItems.ownerId, ownerId)));
    } else {
      const [created] = await tx.insert(orders).values({
        ownerId,
        customerName: input.customerName,
        dueDate: input.dueDate,
        notes: input.notes?.trim() || null,
        status: "new",
      }).$returningId();
      orderId = created.id;
    }
    await tx.insert(orderItems).values(input.items.map(item => {
      const recipe = recipeById.get(item.recipeId)!;
      return {
        ownerId,
        orderId: orderId!,
        recipeId: item.recipeId,
        quantity: String(item.quantity),
        unitPriceAtOrder: recipe.sellingPrice,
        unitCostAtOrder: String(recipe.unitCost),
      };
    }));
    return { id: orderId };
  });
}

const orderTransitions: Record<string, string[]> = {
  new: ["confirmed", "cancelled"],
  confirmed: ["in_production", "ready", "cancelled"],
  in_production: ["ready", "cancelled"],
  ready: ["in_production", "completed"],
  completed: [],
  cancelled: [],
};

export async function updateOrderStatus(ownerId: number, id: number, status: "new" | "confirmed" | "in_production" | "ready" | "completed" | "cancelled") {
  const db = await requireDb();
  return db.transaction(async tx => {
    const [existing] = await tx.select().from(orders).where(and(eq(orders.id, id), eq(orders.ownerId, ownerId))).limit(1).for("update");
    if (!existing) missing("Order not found.");
    if (!orderTransitions[existing.status]?.includes(status) && existing.status !== status) {
      throw new TRPCError({ code: "CONFLICT", message: `Order cannot move from ${existing.status.replaceAll("_", " ")} to ${status.replaceAll("_", " ")}.` });
    }
    await tx.update(orders).set({ status, updatedAt: new Date() }).where(and(eq(orders.id, id), eq(orders.ownerId, ownerId)));
    return { success: true };
  });
}

async function demandForDate(ownerId: number, date: string) {
  const db = await requireDb();
  const openOrders = await db.select({ id: orders.id }).from(orders).where(and(
    eq(orders.ownerId, ownerId),
    lte(orders.dueDate, date),
    inArray(orders.status, ["new", "confirmed", "in_production", "ready"]),
  ));
  if (openOrders.length === 0) return [] as Array<{ recipeId: number; quantity: number }>;
  const lines = await db.select({ recipeId: orderItems.recipeId, quantity: orderItems.quantity }).from(orderItems)
    .where(and(eq(orderItems.ownerId, ownerId), inArray(orderItems.orderId, openOrders.map(order => order.id))));
  return lines.map(line => ({ recipeId: line.recipeId, quantity: number(line.quantity) }));
}

export async function getPlanPreview(ownerId: number, date: string) {
  const db = await requireDb();
  const [settings] = await Promise.all([getSettings(ownerId)]);
  const [allRecipes, allIngredients, demand, planRows] = await Promise.all([
    listRecipes(ownerId),
    listIngredients(ownerId),
    demandForDate(ownerId, date),
    db.select().from(productionPlans).where(and(eq(productionPlans.ownerId, ownerId), eq(productionPlans.planDate, date))).limit(1),
  ]);
  const recipeInputs = allRecipes.map(recipe => ({
    id: recipe.id,
    name: recipe.name,
    yieldQuantity: number(recipe.yieldQuantity),
    yieldUnit: recipe.yieldUnit,
    ingredients: recipe.ingredients.filter(part => !part.isArchived).map(part => ({
      ingredientId: part.ingredientId,
      ingredientName: part.ingredientName,
      unit: part.unit,
      quantityPerBatch: part.quantityPerBatch,
      currentStock: part.currentStock,
      unitCost: part.unitCost,
    })),
  }));
  const recommendations = buildPlanRecommendations(demand, recipeInputs, settings.dailyBatchCapacity);
  const plan = planRows[0] ?? null;
  const batches = plan ? await db.select({
    id: productionBatches.id,
    planId: productionBatches.planId,
    recipeId: productionBatches.recipeId,
    recipeName: recipes.name,
    demandQuantity: productionBatches.demandQuantity,
    batchCount: productionBatches.batchCount,
    targetQuantity: productionBatches.targetQuantity,
    actualYield: productionBatches.actualYield,
    plannedTime: productionBatches.plannedTime,
    status: productionBatches.status,
    notes: productionBatches.notes,
    completedAt: productionBatches.completedAt,
    yieldUnit: recipes.yieldUnit,
  }).from(productionBatches)
    .innerJoin(recipes, and(eq(recipes.id, productionBatches.recipeId), eq(recipes.ownerId, ownerId)))
    .where(and(eq(productionBatches.ownerId, ownerId), eq(productionBatches.planId, plan.id)))
    .orderBy(asc(recipes.name)) : [];
  return { date, settings, recommendations, plan, batches, recipeCount: allRecipes.length, ingredientCount: allIngredients.length };
}

export async function savePlan(ownerId: number, input: {
  date: string;
  notes?: string;
  items: Array<{ batchId?: number; recipeId: number; demandQuantity?: number; batchCount: number; plannedTime?: string }>;
}) {
  const db = await requireDb();
  if (input.items.length === 0) throw new TRPCError({ code: "BAD_REQUEST", message: "Add at least one batch to the production plan." });
  if (new Set(input.items.map(item => item.batchId).filter((id): id is number => id !== undefined)).size !== input.items.filter(item => item.batchId !== undefined).length) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "A saved batch can appear only once in a plan update." });
  }
  const preview = await getPlanPreview(ownerId, input.date);
  const recipeIds = [...new Set(input.items.map(item => item.recipeId))];
  const demandByRecipe = new Map(preview.recommendations.lines.map(line => [line.recipeId, line.demandQuantity]));
  return db.transaction(async tx => {
    await tx.select({ id: bakerySettings.id }).from(bakerySettings).where(eq(bakerySettings.ownerId, ownerId)).limit(1).for("update");
    const currentRecipes = await tx.select({ id: recipes.id, name: recipes.name, yieldQuantity: recipes.yieldQuantity, yieldUnit: recipes.yieldUnit }).from(recipes)
      .where(and(eq(recipes.ownerId, ownerId), isNull(recipes.archivedAt), inArray(recipes.id, recipeIds))).for("update");
    const recipeById = new Map(currentRecipes.map(recipe => [recipe.id, recipe]));
    if (recipeById.size !== recipeIds.length) throw new TRPCError({ code: "BAD_REQUEST", message: "One of the plan recipes is no longer available." });
    for (const item of input.items) {
      if (item.batchCount < 1 || item.batchCount > 500) throw new TRPCError({ code: "BAD_REQUEST", message: "Batch counts must be between 1 and 500." });
    }
    let planId = preview.plan?.id;
    if (planId) {
      const [currentPlan] = await tx.select().from(productionPlans).where(and(eq(productionPlans.id, planId), eq(productionPlans.ownerId, ownerId))).limit(1).for("update");
      if (!currentPlan) missing("Production plan not found.");
      if (currentPlan.status === "completed" && !input.items.some(item => item.batchId === undefined)) {
        throw new TRPCError({ code: "CONFLICT", message: "This plan is complete. Add a new supplemental batch to reopen production for this date." });
      }
      await tx.update(productionPlans).set({ status: "active", notes: input.notes?.trim() || null, updatedAt: new Date() })
        .where(and(eq(productionPlans.id, planId), eq(productionPlans.ownerId, ownerId)));
    } else {
      const [created] = await tx.insert(productionPlans).values({ ownerId, planDate: input.date, status: "active", notes: input.notes?.trim() || null }).$returningId();
      planId = created.id;
    }

    for (const item of input.items) {
      const recipe = recipeById.get(item.recipeId)!;
      const targetQuantity = item.batchCount * number(recipe.yieldQuantity);
      if (item.batchId !== undefined) {
        const [existing] = await tx.select().from(productionBatches)
          .where(and(eq(productionBatches.id, item.batchId), eq(productionBatches.ownerId, ownerId), eq(productionBatches.planId, planId))).limit(1).for("update");
        if (!existing) missing("Saved production batch not found.");
        if (existing.recipeId !== item.recipeId) throw new TRPCError({ code: "BAD_REQUEST", message: "A saved batch cannot be reassigned to a different recipe." });
        if (existing.status !== "planned") throw new TRPCError({ code: "CONFLICT", message: `${recipe.name} has already started; its planned quantity can no longer be changed.` });
        await tx.update(productionBatches).set({
          demandQuantity: String(item.demandQuantity ?? demandByRecipe.get(item.recipeId) ?? 0),
          batchCount: item.batchCount,
          targetQuantity: String(targetQuantity),
          plannedTime: item.plannedTime || null,
          updatedAt: new Date(),
        }).where(and(eq(productionBatches.id, existing.id), eq(productionBatches.ownerId, ownerId)));
      } else {
        await tx.insert(productionBatches).values({
          ownerId,
          planId: planId!,
          recipeId: item.recipeId,
          demandQuantity: String(item.demandQuantity ?? demandByRecipe.get(item.recipeId) ?? 0),
          batchCount: item.batchCount,
          targetQuantity: String(targetQuantity),
          plannedTime: item.plannedTime || null,
          status: "planned",
        });
      }
    }
    return { planId };
  });
}

export async function listBatches(ownerId: number, date?: string) {
  const db = await requireDb();
  const rows = await db.select({
    id: productionBatches.id,
    planId: productionBatches.planId,
    recipeId: productionBatches.recipeId,
    recipeName: recipes.name,
    category: recipes.category,
    yieldUnit: recipes.yieldUnit,
    demandQuantity: productionBatches.demandQuantity,
    batchCount: productionBatches.batchCount,
    targetQuantity: productionBatches.targetQuantity,
    actualYield: productionBatches.actualYield,
    plannedTime: productionBatches.plannedTime,
    status: productionBatches.status,
    notes: productionBatches.notes,
    completedAt: productionBatches.completedAt,
    planDate: productionPlans.planDate,
  }).from(productionBatches)
    .innerJoin(productionPlans, and(eq(productionPlans.id, productionBatches.planId), eq(productionPlans.ownerId, ownerId)))
    .innerJoin(recipes, and(eq(recipes.id, productionBatches.recipeId), eq(recipes.ownerId, ownerId)))
    .where(and(eq(productionBatches.ownerId, ownerId), date ? eq(productionPlans.planDate, date) : undefined))
    .orderBy(asc(productionPlans.planDate), asc(productionBatches.plannedTime), asc(recipes.name));
  return rows;
}

const batchTransitions: Record<string, string[]> = {
  planned: ["mixing", "cancelled"],
  mixing: ["baking", "cancelled"],
  baking: ["ready", "cancelled"],
  ready: ["completed", "baking", "cancelled"],
  completed: [],
  cancelled: [],
};

export async function updateBatch(ownerId: number, input: {
  id: number;
  status: "planned" | "mixing" | "baking" | "ready" | "completed" | "cancelled";
  actualYield?: number;
  notes?: string;
}) {
  const db = await requireDb();
  return db.transaction(async tx => {
    const [batch] = await tx.select().from(productionBatches)
      .where(and(eq(productionBatches.id, input.id), eq(productionBatches.ownerId, ownerId))).limit(1).for("update");
    if (!batch) missing("Production batch not found.");
    if (batch.status === "completed" && input.status === "completed") return { success: true, alreadyCompleted: true };
    if (!batchTransitions[batch.status]?.includes(input.status) && batch.status !== input.status) {
      throw new TRPCError({ code: "CONFLICT", message: `Batch cannot move from ${batch.status} to ${input.status}.` });
    }

    if (input.status === "completed") {
      if (!input.actualYield || input.actualYield <= 0) throw new TRPCError({ code: "BAD_REQUEST", message: "Enter the actual yield before completing this batch." });
      const parts = await tx.select({
        ingredientId: ingredients.id,
        ingredientName: ingredients.name,
        quantityPerBatch: recipeIngredients.quantityPerBatch,
        currentStock: ingredients.currentStock,
      }).from(recipeIngredients)
        .innerJoin(ingredients, and(eq(ingredients.id, recipeIngredients.ingredientId), eq(ingredients.ownerId, ownerId), eq(ingredients.isArchived, false)))
        .where(and(eq(recipeIngredients.ownerId, ownerId), eq(recipeIngredients.recipeId, batch.recipeId))).for("update");
      const usages = parts.map(part => ({ ...part, used: number(part.quantityPerBatch) * batch.batchCount, next: number(part.currentStock) - number(part.quantityPerBatch) * batch.batchCount }));
      const shortage = usages.find(item => item.next < -0.0005);
      if (shortage) {
        throw new TRPCError({ code: "CONFLICT", message: `Not enough ${shortage.ingredientName} to complete this batch. Add stock or correct the recipe quantity first.` });
      }
      for (const item of usages) {
        await tx.update(ingredients).set({ currentStock: String(Math.max(0, item.next)), updatedAt: new Date() })
          .where(and(eq(ingredients.id, item.ingredientId), eq(ingredients.ownerId, ownerId)));
        await tx.insert(stockMovements).values({
          ownerId,
          ingredientId: item.ingredientId,
          movementType: "production",
          quantityDelta: String(-item.used),
          referenceType: "batch",
          referenceId: batch.id,
          note: `Production usage for batch ${batch.id}`,
        });
      }
    }

    await tx.update(productionBatches).set({
      status: input.status,
      actualYield: input.status === "completed" ? String(input.actualYield) : batch.actualYield,
      completedAt: input.status === "completed" ? new Date() : batch.completedAt,
      notes: input.notes === undefined ? batch.notes : input.notes.trim() || null,
      updatedAt: new Date(),
    }).where(and(eq(productionBatches.id, batch.id), eq(productionBatches.ownerId, ownerId)));

    const remaining = await tx.select({ status: productionBatches.status }).from(productionBatches)
      .where(and(eq(productionBatches.planId, batch.planId), eq(productionBatches.ownerId, ownerId)));
    const planStatus = remaining.length > 0 && remaining.every(row => row.status === "completed") ? "completed" : "active";
    await tx.update(productionPlans).set({ status: planStatus, updatedAt: new Date() })
      .where(and(eq(productionPlans.id, batch.planId), eq(productionPlans.ownerId, ownerId)));
    return { success: true, alreadyCompleted: false };
  });
}

export async function getDashboardSnapshot(ownerId: number, date: string) {
  const db = await requireDb();
  const [settings, todaysOrders, batches, allIngredients, planRows] = await Promise.all([
    getSettings(ownerId),
    listOrders(ownerId, { to: date }),
    listBatches(ownerId, date),
    listIngredients(ownerId),
    db.select().from(productionPlans).where(and(eq(productionPlans.ownerId, ownerId), eq(productionPlans.planDate, date))).limit(1),
  ]);
  const openOrders = todaysOrders.filter(order => ["new", "confirmed", "in_production", "ready"].includes(order.status));
  const lowStock = allIngredients.filter(item => number(item.currentStock) <= number(item.reorderPoint));
  const completedBatches = batches.filter(batch => batch.status === "completed");
  const activeBatches = batches.filter(batch => !["completed", "cancelled"].includes(batch.status));
  const committedValue = openOrders.reduce((sum, order) => sum + order.total, 0);
  const committedCost = openOrders.reduce((sum, order) => sum + order.cost, 0);
  const dueUnits = openOrders.reduce((sum, order) => sum + order.items.reduce((lineSum, item) => lineSum + number(item.quantity), 0), 0);
  const plannedUnits = batches.reduce((sum, batch) => sum + number(batch.targetQuantity), 0);
  return {
    date,
    settings,
    orderCount: openOrders.length,
    dueUnits,
    committedValue,
    committedCost,
    committedMargin: marginPercent(committedValue, committedCost),
    plannedUnits,
    completedUnits: completedBatches.reduce((sum, batch) => sum + number(batch.actualYield), 0),
    activeBatches,
    lowStock,
    plan: planRows[0] ?? null,
    orders: openOrders.slice(0, 5),
    totalRecipes: (await listRecipes(ownerId)).length,
    totalIngredients: allIngredients.length,
  };
}

export async function getReport(ownerId: number, from: string, to: string) {
  const db = await requireDb();
  const settings = await getSettings(ownerId);
  const { start, end } = localDateRangeUtc(from, to, settings.timezone);
  const [rangeOrders, batches, movements, allIngredients] = await Promise.all([
    listOrders(ownerId, { from, to }),
    listBatches(ownerId),
    db.select({
      id: stockMovements.id,
      movementType: stockMovements.movementType,
      quantityDelta: stockMovements.quantityDelta,
      createdAt: stockMovements.createdAt,
      ingredientId: ingredients.id,
      ingredientName: ingredients.name,
      unit: ingredients.unit,
    }).from(stockMovements)
      .innerJoin(ingredients, and(eq(ingredients.id, stockMovements.ingredientId), eq(ingredients.ownerId, ownerId)))
      .where(and(
        eq(stockMovements.ownerId, ownerId),
        gte(stockMovements.createdAt, start),
        lte(stockMovements.createdAt, end),
      )).orderBy(desc(stockMovements.createdAt)),
    listIngredients(ownerId),
  ]);
  const completedOrders = rangeOrders.filter(order => order.status === "completed");
  const openOrders = rangeOrders.filter(order => !["completed", "cancelled"].includes(order.status));
  const rangeBatches = batches.filter(batch => batch.planDate >= from && batch.planDate <= to);
  const completedBatches = rangeBatches.filter(batch => batch.status === "completed");
  const usage = movements.filter(row => row.movementType === "production");
  const waste = movements.filter(row => row.movementType === "waste");
  const aggregateMovements = (rows: typeof movements) => {
    const grouped = new Map<number, { ingredientId: number; name: string; unit: string; quantity: number }>();
    for (const movement of rows) {
      const entry = grouped.get(movement.ingredientId) ?? { ingredientId: movement.ingredientId, name: movement.ingredientName, unit: movement.unit, quantity: 0 };
      entry.quantity += Math.abs(number(movement.quantityDelta));
      grouped.set(movement.ingredientId, entry);
    }
    return [...grouped.values()].sort((a, b) => b.quantity - a.quantity);
  };
  return {
    from,
    to,
    orderCount: rangeOrders.filter(order => order.status !== "cancelled").length,
    completedOrderCount: completedOrders.length,
    openOrderCount: openOrders.length,
    committedSales: openOrders.reduce((sum, order) => sum + order.total, 0),
    completedSales: completedOrders.reduce((sum, order) => sum + order.total, 0),
    completedCosts: completedOrders.reduce((sum, order) => sum + order.cost, 0),
    grossProfit: completedOrders.reduce((sum, order) => sum + order.grossProfit, 0),
    grossMargin: marginPercent(completedOrders.reduce((sum, order) => sum + order.total, 0), completedOrders.reduce((sum, order) => sum + order.cost, 0)),
    plannedBatchCount: rangeBatches.length,
    completedBatchCount: completedBatches.length,
    actualOutput: completedBatches.reduce((sum, batch) => sum + number(batch.actualYield), 0),
    wasteQuantity: waste.reduce((sum, row) => sum + Math.abs(number(row.quantityDelta)), 0),
    lowStock: allIngredients.filter(item => number(item.currentStock) <= number(item.reorderPoint)),
    usageByIngredient: aggregateMovements(usage),
    wasteByIngredient: aggregateMovements(waste),
  };
}
