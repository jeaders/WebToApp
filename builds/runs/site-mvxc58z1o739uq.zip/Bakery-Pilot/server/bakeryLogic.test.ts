import { describe, expect, it } from "vitest";
import { buildPlanRecommendations, localDateRangeUtc, marginPercent, recipeCost, suggestedPrice } from "../shared/bakeryLogic";
import { todayISO } from "../client/src/lib/format";

describe("Bakery Pilot calculations", () => {
  it("rolls ingredient costs into a batch and computes gross margin and suggested price", () => {
    const ingredients = [
      { ingredientId: 1, ingredientName: "Flour", unit: "kg", quantityPerBatch: 2, currentStock: 8, unitCost: 1.5 },
      { ingredientId: 2, ingredientName: "Yeast", unit: "g", quantityPerBatch: 20, currentStock: 120, unitCost: 0.01 },
    ];
    const batchCost = recipeCost(ingredients);
    expect(batchCost).toBeCloseTo(3.2);
    expect(marginPercent(8, 3.2)).toBeCloseTo(60);
    expect(suggestedPrice(3.2, 0.6)).toBeCloseTo(8);
  });

  it("rounds demand up to full batches and aggregates ingredient shortages", () => {
    const result = buildPlanRecommendations(
      [
        { recipeId: 1, quantity: 13 },
        { recipeId: 1, quantity: 2 },
        { recipeId: 2, quantity: 4 },
      ],
      [
        {
          id: 1,
          name: "Country loaf",
          yieldQuantity: 8,
          yieldUnit: "pcs",
          ingredients: [
            { ingredientId: 10, ingredientName: "Flour", unit: "kg", quantityPerBatch: 3, currentStock: 5, unitCost: 1.2 },
          ],
        },
        {
          id: 2,
          name: "Brioche",
          yieldQuantity: 4,
          yieldUnit: "pcs",
          ingredients: [
            { ingredientId: 10, ingredientName: "Flour", unit: "kg", quantityPerBatch: 2, currentStock: 5, unitCost: 1.2 },
            { ingredientId: 11, ingredientName: "Eggs", unit: "pcs", quantityPerBatch: 6, currentStock: 4, unitCost: 0.3 },
          ],
        },
      ],
      3,
    );

    expect(result.lines).toEqual([
      { recipeId: 2, recipeName: "Brioche", demandQuantity: 4, yieldQuantity: 4, yieldUnit: "pcs", recommendedBatches: 1, recommendedQuantity: 4 },
      { recipeId: 1, recipeName: "Country loaf", demandQuantity: 15, yieldQuantity: 8, yieldUnit: "pcs", recommendedBatches: 2, recommendedQuantity: 16 },
    ]);
    expect(result.totalBatches).toBe(3);
    expect(result.capacityExceeded).toBe(false);
    expect(result.shortages).toEqual([
      { ingredientId: 10, ingredientName: "Flour", unit: "kg", needed: 8, available: 5, shortfall: 3 },
      { ingredientId: 11, ingredientName: "Eggs", unit: "pcs", needed: 6, available: 4, shortfall: 2 },
    ]);
  });

  it("flags capacity overflow and handles missing demand safely", () => {
    const result = buildPlanRecommendations(
      [{ recipeId: 7, quantity: 9 }],
      [{ id: 7, name: "Scone", yieldQuantity: 3, yieldUnit: "pcs", ingredients: [] }],
      2,
    );
    expect(result.capacityExceeded).toBe(true);
    expect(result.totalBatches).toBe(3);
    expect(result.uncoveredDemand).toBe(false);
  });

  it("uses bakery-local day boundaries across spring and autumn DST changes", () => {
    const spring = localDateRangeUtc("2026-03-08", "2026-03-08", "America/New_York");
    const autumn = localDateRangeUtc("2026-11-01", "2026-11-01", "America/New_York");

    expect(spring.start.toISOString()).toBe("2026-03-08T05:00:00.000Z");
    expect(spring.end.getTime() - spring.start.getTime() + 1).toBe(23 * 60 * 60 * 1000);
    expect(autumn.start.toISOString()).toBe("2026-11-01T04:00:00.000Z");
    expect(autumn.end.getTime() - autumn.start.getTime() + 1).toBe(25 * 60 * 60 * 1000);
  });

  it("initializes day views from the bakery timezone instead of the browser timezone", () => {
    const justAfterUtcMidnight = new Date("2026-10-28T01:30:00.000Z");
    expect(todayISO("America/Los_Angeles", justAfterUtcMidnight)).toBe("2026-10-27");
    expect(todayISO("Europe/Amsterdam", justAfterUtcMidnight)).toBe("2026-10-28");
  });
});
