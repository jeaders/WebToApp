CREATE INDEX `production_batch_plan_idx` ON `production_batches` (`planId`);--> statement-breakpoint
ALTER TABLE `production_batches` DROP INDEX `production_batch_plan_recipe_uq`;--> statement-breakpoint
ALTER TABLE `bakery_settings` MODIFY COLUMN `timezone` varchar(64) NOT NULL DEFAULT 'UTC';
