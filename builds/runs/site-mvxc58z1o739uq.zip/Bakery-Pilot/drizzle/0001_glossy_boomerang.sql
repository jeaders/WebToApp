CREATE TABLE `bakery_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`bakeryName` varchar(140) NOT NULL DEFAULT 'My bakery',
	`currency` varchar(3) NOT NULL DEFAULT 'USD',
	`timezone` varchar(64) NOT NULL DEFAULT 'America/New_York',
	`dailyBatchCapacity` int NOT NULL DEFAULT 24,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `bakery_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `bakery_settings_owner_uq` UNIQUE(`ownerId`)
);
--> statement-breakpoint
CREATE TABLE `ingredients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`name` varchar(140) NOT NULL,
	`unit` varchar(16) NOT NULL,
	`currentStock` decimal(12,3) NOT NULL DEFAULT '0',
	`reorderPoint` decimal(12,3) NOT NULL DEFAULT '0',
	`unitCost` decimal(12,4) NOT NULL DEFAULT '0',
	`isArchived` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ingredients_id` PRIMARY KEY(`id`),
	CONSTRAINT `ingredients_owner_name_uq` UNIQUE(`ownerId`,`name`)
);
--> statement-breakpoint
CREATE TABLE `order_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`orderId` int NOT NULL,
	`recipeId` int NOT NULL,
	`quantity` decimal(12,3) NOT NULL,
	`unitPriceAtOrder` decimal(12,4) NOT NULL,
	`unitCostAtOrder` decimal(12,4) NOT NULL,
	CONSTRAINT `order_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`customerName` varchar(140) NOT NULL,
	`dueDate` date NOT NULL,
	`status` enum('new','confirmed','in_production','ready','completed','cancelled') NOT NULL DEFAULT 'new',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `production_batches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`planId` int NOT NULL,
	`recipeId` int NOT NULL,
	`demandQuantity` decimal(12,3) NOT NULL DEFAULT '0',
	`batchCount` int NOT NULL DEFAULT 1,
	`targetQuantity` decimal(12,3) NOT NULL,
	`actualYield` decimal(12,3),
	`plannedTime` varchar(5),
	`batchStatus` enum('planned','mixing','baking','ready','completed','cancelled') NOT NULL DEFAULT 'planned',
	`notes` text,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `production_batches_id` PRIMARY KEY(`id`),
	CONSTRAINT `production_batch_plan_recipe_uq` UNIQUE(`planId`,`recipeId`)
);
--> statement-breakpoint
CREATE TABLE `production_plans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`planDate` date NOT NULL,
	`planStatus` enum('draft','active','completed') NOT NULL DEFAULT 'draft',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `production_plans_id` PRIMARY KEY(`id`),
	CONSTRAINT `production_plan_owner_date_uq` UNIQUE(`ownerId`,`planDate`)
);
--> statement-breakpoint
CREATE TABLE `recipe_ingredients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`recipeId` int NOT NULL,
	`ingredientId` int NOT NULL,
	`quantityPerBatch` decimal(12,3) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `recipe_ingredients_id` PRIMARY KEY(`id`),
	CONSTRAINT `recipe_ingredient_uq` UNIQUE(`recipeId`,`ingredientId`)
);
--> statement-breakpoint
CREATE TABLE `recipes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`name` varchar(140) NOT NULL,
	`category` varchar(48) NOT NULL DEFAULT 'Bread',
	`yieldQuantity` decimal(12,3) NOT NULL,
	`yieldUnit` varchar(16) NOT NULL DEFAULT 'pcs',
	`sellingPrice` decimal(12,4) NOT NULL DEFAULT '0',
	`targetMargin` decimal(5,4) NOT NULL DEFAULT '0.65',
	`notes` text,
	`archivedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `recipes_id` PRIMARY KEY(`id`),
	CONSTRAINT `recipes_owner_name_uq` UNIQUE(`ownerId`,`name`)
);
--> statement-breakpoint
CREATE TABLE `stock_movements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`ingredientId` int NOT NULL,
	`movementType` enum('purchase','adjustment','waste','production') NOT NULL,
	`quantityDelta` decimal(12,3) NOT NULL,
	`referenceType` varchar(32),
	`referenceId` int,
	`note` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stock_movements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `bakery_settings` ADD CONSTRAINT `bakery_settings_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `ingredients` ADD CONSTRAINT `ingredients_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `order_items` ADD CONSTRAINT `order_items_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `order_items` ADD CONSTRAINT `order_items_orderId_orders_id_fk` FOREIGN KEY (`orderId`) REFERENCES `orders`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `order_items` ADD CONSTRAINT `order_items_recipeId_recipes_id_fk` FOREIGN KEY (`recipeId`) REFERENCES `recipes`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `orders` ADD CONSTRAINT `orders_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `production_batches` ADD CONSTRAINT `production_batches_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `production_batches` ADD CONSTRAINT `production_batches_planId_production_plans_id_fk` FOREIGN KEY (`planId`) REFERENCES `production_plans`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `production_batches` ADD CONSTRAINT `production_batches_recipeId_recipes_id_fk` FOREIGN KEY (`recipeId`) REFERENCES `recipes`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `production_plans` ADD CONSTRAINT `production_plans_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `recipe_ingredients` ADD CONSTRAINT `recipe_ingredients_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `recipe_ingredients` ADD CONSTRAINT `recipe_ingredients_recipeId_recipes_id_fk` FOREIGN KEY (`recipeId`) REFERENCES `recipes`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `recipe_ingredients` ADD CONSTRAINT `recipe_ingredients_ingredientId_ingredients_id_fk` FOREIGN KEY (`ingredientId`) REFERENCES `ingredients`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `recipes` ADD CONSTRAINT `recipes_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `stock_movements` ADD CONSTRAINT `stock_movements_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `stock_movements` ADD CONSTRAINT `stock_movements_ingredientId_ingredients_id_fk` FOREIGN KEY (`ingredientId`) REFERENCES `ingredients`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `ingredients_owner_idx` ON `ingredients` (`ownerId`,`isArchived`);--> statement-breakpoint
CREATE INDEX `order_items_owner_order_idx` ON `order_items` (`ownerId`,`orderId`);--> statement-breakpoint
CREATE INDEX `orders_owner_due_idx` ON `orders` (`ownerId`,`dueDate`);--> statement-breakpoint
CREATE INDEX `production_batch_owner_status_idx` ON `production_batches` (`ownerId`,`batchStatus`);--> statement-breakpoint
CREATE INDEX `production_plan_owner_date_idx` ON `production_plans` (`ownerId`,`planDate`);--> statement-breakpoint
CREATE INDEX `recipe_ingredients_owner_idx` ON `recipe_ingredients` (`ownerId`,`recipeId`);--> statement-breakpoint
CREATE INDEX `recipes_owner_idx` ON `recipes` (`ownerId`,`archivedAt`);--> statement-breakpoint
CREATE INDEX `stock_movements_owner_date_idx` ON `stock_movements` (`ownerId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `stock_movements_ingredient_idx` ON `stock_movements` (`ownerId`,`ingredientId`);