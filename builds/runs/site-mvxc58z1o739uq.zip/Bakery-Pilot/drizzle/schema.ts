import {
  boolean,
  date,
  decimal,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Manus OAuth identities. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** One operational profile per signed-in bakery owner. */
export const bakerySettings = mysqlTable(
  "bakery_settings",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    bakeryName: varchar("bakeryName", { length: 140 }).notNull().default("My bakery"),
    currency: varchar("currency", { length: 3 }).notNull().default("USD"),
    timezone: varchar("timezone", { length: 64 }).notNull().default("UTC"),
    dailyBatchCapacity: int("dailyBatchCapacity").notNull().default(24),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({ ownerUnique: uniqueIndex("bakery_settings_owner_uq").on(table.ownerId) }),
);

export const ingredients = mysqlTable(
  "ingredients",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 140 }).notNull(),
    unit: varchar("unit", { length: 16 }).notNull(),
    currentStock: decimal("currentStock", { precision: 12, scale: 3 }).notNull().default("0"),
    reorderPoint: decimal("reorderPoint", { precision: 12, scale: 3 }).notNull().default("0"),
    unitCost: decimal("unitCost", { precision: 12, scale: 4 }).notNull().default("0"),
    isArchived: boolean("isArchived").notNull().default(false),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    ownerNameUnique: uniqueIndex("ingredients_owner_name_uq").on(table.ownerId, table.name),
    ownerIndex: index("ingredients_owner_idx").on(table.ownerId, table.isArchived),
  }),
);

export const recipes = mysqlTable(
  "recipes",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 140 }).notNull(),
    category: varchar("category", { length: 48 }).notNull().default("Bread"),
    yieldQuantity: decimal("yieldQuantity", { precision: 12, scale: 3 }).notNull(),
    yieldUnit: varchar("yieldUnit", { length: 16 }).notNull().default("pcs"),
    sellingPrice: decimal("sellingPrice", { precision: 12, scale: 4 }).notNull().default("0"),
    targetMargin: decimal("targetMargin", { precision: 5, scale: 4 }).notNull().default("0.65"),
    notes: text("notes"),
    archivedAt: timestamp("archivedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    ownerNameUnique: uniqueIndex("recipes_owner_name_uq").on(table.ownerId, table.name),
    ownerIndex: index("recipes_owner_idx").on(table.ownerId, table.archivedAt),
  }),
);

export const recipeIngredients = mysqlTable(
  "recipe_ingredients",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    recipeId: int("recipeId").notNull().references(() => recipes.id, { onDelete: "cascade" }),
    ingredientId: int("ingredientId").notNull().references(() => ingredients.id, { onDelete: "restrict" }),
    quantityPerBatch: decimal("quantityPerBatch", { precision: 12, scale: 3 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    recipeIngredientUnique: uniqueIndex("recipe_ingredient_uq").on(table.recipeId, table.ingredientId),
    ownerIndex: index("recipe_ingredients_owner_idx").on(table.ownerId, table.recipeId),
  }),
);

export const orders = mysqlTable(
  "orders",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    customerName: varchar("customerName", { length: 140 }).notNull(),
    dueDate: date("dueDate", { mode: "string" }).notNull(),
    status: mysqlEnum("status", ["new", "confirmed", "in_production", "ready", "completed", "cancelled"]).notNull().default("new"),
    notes: text("notes"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({ ownerDueIndex: index("orders_owner_due_idx").on(table.ownerId, table.dueDate) }),
);

export const orderItems = mysqlTable(
  "order_items",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    orderId: int("orderId").notNull().references(() => orders.id, { onDelete: "cascade" }),
    recipeId: int("recipeId").notNull().references(() => recipes.id, { onDelete: "restrict" }),
    quantity: decimal("quantity", { precision: 12, scale: 3 }).notNull(),
    unitPriceAtOrder: decimal("unitPriceAtOrder", { precision: 12, scale: 4 }).notNull(),
    unitCostAtOrder: decimal("unitCostAtOrder", { precision: 12, scale: 4 }).notNull(),
  },
  table => ({ ownerOrderIndex: index("order_items_owner_order_idx").on(table.ownerId, table.orderId) }),
);

export const productionPlans = mysqlTable(
  "production_plans",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    planDate: date("planDate", { mode: "string" }).notNull(),
    status: mysqlEnum("planStatus", ["draft", "active", "completed"]).notNull().default("draft"),
    notes: text("notes"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    ownerDateUnique: uniqueIndex("production_plan_owner_date_uq").on(table.ownerId, table.planDate),
    ownerDateIndex: index("production_plan_owner_date_idx").on(table.ownerId, table.planDate),
  }),
);

export const productionBatches = mysqlTable(
  "production_batches",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    planId: int("planId").notNull().references(() => productionPlans.id, { onDelete: "cascade" }),
    recipeId: int("recipeId").notNull().references(() => recipes.id, { onDelete: "restrict" }),
    demandQuantity: decimal("demandQuantity", { precision: 12, scale: 3 }).notNull().default("0"),
    batchCount: int("batchCount").notNull().default(1),
    targetQuantity: decimal("targetQuantity", { precision: 12, scale: 3 }).notNull(),
    actualYield: decimal("actualYield", { precision: 12, scale: 3 }),
    plannedTime: varchar("plannedTime", { length: 5 }),
    status: mysqlEnum("batchStatus", ["planned", "mixing", "baking", "ready", "completed", "cancelled"]).notNull().default("planned"),
    notes: text("notes"),
    completedAt: timestamp("completedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    planIndex: index("production_batch_plan_idx").on(table.planId),
    ownerStatusIndex: index("production_batch_owner_status_idx").on(table.ownerId, table.status),
  }),
);

export const stockMovements = mysqlTable(
  "stock_movements",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    ingredientId: int("ingredientId").notNull().references(() => ingredients.id, { onDelete: "restrict" }),
    movementType: mysqlEnum("movementType", ["purchase", "adjustment", "waste", "production"]).notNull(),
    quantityDelta: decimal("quantityDelta", { precision: 12, scale: 3 }).notNull(),
    referenceType: varchar("referenceType", { length: 32 }),
    referenceId: int("referenceId"),
    note: text("note"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    ownerDateIndex: index("stock_movements_owner_date_idx").on(table.ownerId, table.createdAt),
    ingredientIndex: index("stock_movements_ingredient_idx").on(table.ownerId, table.ingredientId),
  }),
);
