# Bakery Pilot — Build outcomes

## Reference audit and independent concept framing
- [x] Document the supplied Replit URL as inaccessible, distinguish observed facts from inferred product decisions, and define Bakery Pilot as an independent concept build rather than a verified reproduction.
- [x] Record the core user job, end-to-end contract, inferred route map, data objects, design direction, and unresolved assumptions in `research/reference-audit.md`.

## Secure bakery workspace and owner data isolation
- [x] Use the supplied Manus OAuth application flow; protect operational routes and show a real logged-out/loading/error state rather than a fabricated user.
- [x] Scope every bakery business record and every read/write server-side to the authenticated owner's user ID; prevent cross-owner access.
- [x] Persist business data in the managed database through the project’s Drizzle and tRPC conventions.

## Orders and demand capture
- [x] Support creating, editing, viewing, filtering, and progressing customer orders through explicit fulfillment statuses, including due dates, item quantities, and notes where applicable.
- [x] Validate order fields and recipe references; make empty order lists, invalid input, failed loads, and successful saves understandable and recoverable.
- [x] Derive open demand by recipe and date from actual saved orders.

## Recipe and ingredient costing
- [x] Support recipes with ingredient links and quantities, unit consistency, yield, current batch cost, per-unit cost, margin targets, and suggested selling price.
- [x] Recalculate cost and margin from current stored ingredient prices; do not hardcode recipe results.
- [x] Support recipe creation, editing, viewing, and safe archival, with empty, validation, error, and success states.

## Ingredient inventory and auditable movements
- [x] Track ingredient names, units, on-hand quantity, reorder thresholds, current unit cost, and active/inactive state.
- [x] Record purchases, adjustments, waste, and production usage as auditable stock movements with timestamps and references/notes where applicable.
- [x] Surface low-stock and shortage risks; keep quantities and movement history consistent after each supported action.

## Daily operations and demand-to-bake planning
- [x] Show the selected date’s order demand, planned production, priorities, ingredient constraints, batch progress, key actions, and useful operating indicators on the daily dashboard.
- [x] Translate open orders and recipe yields into required quantities and recommended batch counts for a selected day.
- [x] Highlight ingredient shortages and missing setup; allow the owner to refine and save the final plan instead of presenting recommendations as immutable.
- [x] Make planning calculations deterministic and explainable from persisted orders, recipes, inventory, and plan data; support no-demand and incomplete-setup states.

## Production planning and execution
- [x] Create and track production batches with recipe, target quantity, planned date/time, status, actual yield, and ingredient consumption.
- [x] Provide explicit, valid status transitions and reflect progress on the dashboard and date-based summaries.
- [x] Apply ingredient use/waste as stock movements and preserve useful production history; handle stale stock or failed persistence with a clear retry path.

## Cost, margin, and operating summaries
- [x] Calculate order selling totals, ingredient costs, gross profit, and gross margin from actual saved order and recipe data.
- [x] Provide date-based views of order volume, production output, ingredient use and waste, inventory risks, revenue, costs, and gross margin.
- [x] Label date ranges, currency, and units clearly; display empty or partial/error states without inventing metrics or treating sample data as real.

## Responsive, accessible product surface and recovery states
- [x] Deliver coherent navigation and operational workflows on desktop and mobile; collapse navigation, stack content, keep primary actions reachable, and prevent dense tables from clipping.
- [x] Make empty, loading, validation, provider/server error, confirmation, and success states explicit across core flows, with retry or a next step when appropriate.
- [x] Use semantic labels/headings, keyboard-operable controls, visible focus, sufficient contrast, and reduced-motion behavior.

## Build verification and handoff
- [x] Run TypeScript diagnostics, `pnpm check`, `pnpm test`, and a production build; fix actionable failures.
- [x] Verify the route manifest and inspect the implemented desktop/mobile surfaces and server logs; test calculations and owner scoping without leaving fabricated business records in the user's workspace.
- [x] Configure the project logo metadata, commit the completed intended files to the canonical `main` branch, and confirm the resulting checkpoint; the user explicitly requested public publication.

## Public deployment and handoff
- [ ] Publish the completed, tested Bakery Pilot build and provide the working public app URL the user explicitly requested; report the URL only after successful publication is confirmed.
  - Blocked: the publication confirmation completed with `decision: deny`. Do not resubmit until the user gives fresh explicit approval.
