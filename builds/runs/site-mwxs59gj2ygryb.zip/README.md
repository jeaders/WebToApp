# Airplane Mode Macro (Android, Kotlin)

Single-purpose Android macro automation app that executes a fixed chain (`Airplane Mode ON → Wait N seconds → Airplane Mode OFF`) on schedule without root or Shizuku.

## Minimum APK Size Optimizations
- No Room, no WorkManager, no Shizuku, no reflection-heavy JSON libraries (`org.json` + `SharedPreferences` only).
- Vector drawables only (no multi-density PNG raster bloat).
- R8 full-mode shrinking + resource shrinking (`isMinifyEnabled = true`, `isShrinkResources = true`) and `resourceConfigurations += listOf("en", "fr")` in `app/build.gradle.kts`.

## Build Steps
1. Open `/android` in Android Studio (JDK 17, AGP 8.7+, compileSdk 35, minSdk 24).
2. Build the debug APK:
   ```bash
   ./gradlew assembleDebug
   ```
   Output: `app/build/outputs/apk/debug/app-debug.apk` (version `1.0.0`).
3. For the smallest release APK:
   ```bash
   ./gradlew assembleRelease
   ```

## Enabling Automation

### Tier 1: Accessibility Service (Normal Users)
1. Open **Settings → Accessibility → Downloaded Apps → Airplane Mode Macro**.
2. Switch the service **ON**.
3. On Android 12+, allow **Alarms & Reminders** when prompted so `AlarmManager.setExactAndAllowWhileIdle` fires on time.
4. On Android 13+, grant **Notifications** so toggle alerts and the `"Turn off now"` action appear.

### Tier 2: Device Owner (Optional, Android 11+ / API 30+)
On a freshly provisioned device without existing accounts, grant Device Owner via ADB so toggles run silently via `DevicePolicyManager.setGlobalSetting` without opening the Quick Settings shade:
```bash
adb shell dpm set-device-owner com.airplanemacro.app/.admin.AirplaneDeviceAdminReceiver
```

## Per-OEM Notes
- **Google Pixel (Stock Android 13–15):** Verified. Uses double shade expansion when the Airplane Mode tile sits on the full Quick Settings panel, and swipes left once if placed on page 2.
- **Samsung One UI:** Verified. Keep the Airplane Mode tile on page 1 or page 2 of Quick Settings. Disable "Put app to sleep" in **Device Care → Battery → Background usage limits** so scheduled alarms are not deferred.
- **Xiaomi HyperOS / MIUI:** Verified. Enable **Autostart** for Airplane Mode Macro and set battery saver to **No restrictions**. On MIUI, also enable "Display pop-up windows while running in the background" if Quick Settings expansion is restricted.
- **Custom ROMs (LineageOS / GrapheneOS):** If a custom ROM renames the Quick Settings tile label or `contentDescription` outside `"airplane mode"`, `"mode avion"`, `"الطيران"`, `"flugmodus"`, `"modo avión"`, or `"vliegtuigmodus"`, add the localized label to `AIRPLANE_LABELS` in `AirplaneAccessibilityService.kt`.

## Distribution Note
Google Play policies restrict `AccessibilityService` usage to accessibility tools and typically reject automation apps that tap Quick Settings tiles. Distribute the signed APK directly (GitHub Releases / sideload) or use Device Owner provisioning for managed devices.
