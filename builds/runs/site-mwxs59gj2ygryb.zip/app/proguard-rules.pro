# Keep Parcelable / JSON reflection-free models and receivers intact
-keep class com.airplanemacro.app.model.** { *; }
