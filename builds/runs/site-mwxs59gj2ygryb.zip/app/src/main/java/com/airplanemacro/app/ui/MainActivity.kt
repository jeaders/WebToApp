package com.airplanemacro.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.airplanemacro.app.R
import com.airplanemacro.app.data.MacroRepository
import com.airplanemacro.app.execution.MacroNotifier
import com.airplanemacro.app.execution.MacroRunner
import com.airplanemacro.app.model.DeviceEvents
import com.airplanemacro.app.model.Trigger
import com.airplanemacro.app.scheduler.MacroScheduler

class MainActivity : AppCompatActivity() {

    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        MacroNotifier.ensureChannels(this)
        requestPostNotificationsIfNeeded()

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, MacroEditorFragment())
                .commit()
        }

        val macro = MacroRepository(this).loadMacro()
        MacroScheduler.scheduleMacro(this)

        val trigger = macro.trigger
        if (macro.enabled && trigger is Trigger.DeviceEvent && trigger.event == DeviceEvents.APP_OPENED) {
            MacroRunner.triggerExecution(this)
        }
    }

    private fun requestPostNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
