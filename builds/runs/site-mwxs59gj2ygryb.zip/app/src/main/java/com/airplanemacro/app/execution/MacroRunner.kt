package com.airplanemacro.app.execution

import android.content.Context
import android.content.Intent
import android.os.Build
import com.airplanemacro.app.admin.AirplaneDeviceAdminReceiver
import com.airplanemacro.app.data.MacroRepository
import com.airplanemacro.app.model.Macro
import com.airplanemacro.app.scheduler.MacroScheduler
import com.airplanemacro.app.service.AirplaneAccessibilityService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

object MacroRunner {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var activeJob: Job? = null

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    fun hasAnyAutomationTier(context: Context): Boolean {
        return AirplaneDeviceAdminReceiver.isDeviceOwner(context) ||
            AirplaneAccessibilityService.isServiceEnabled(context)
    }

    fun triggerExecution(context: Context, bypassEnabledCheck: Boolean = false): Boolean {
        val macro = MacroRepository(context).loadMacro()
        if (!bypassEnabledCheck && !macro.enabled) return false
        if (_isRunning.value) return true

        val waitSec = macro.effectiveWaitSeconds()
        if (waitSec > 5L) {
            _isRunning.value = true
            val intent = Intent(context, MacroExecutionService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } else {
            activeJob?.cancel()
            activeJob = scope.launch {
                runChain(context.applicationContext, macro)
            }
        }
        return true
    }

    fun stopExecution(context: Context) {
        activeJob?.cancel()
        activeJob = null
        context.stopService(Intent(context, MacroExecutionService::class.java))
        MacroScheduler.cancelScheduledAlarms(context)
        _isRunning.value = false
    }

    suspend fun runChain(context: Context, macro: Macro) {
        _isRunning.value = true
        var wasCancelled = false
        try {
            val onResult = setAirplaneState(context, true)
            if (onResult.isFailure) {
                MacroNotifier.showFailureNotification(
                    context,
                    onResult.exceptionOrNull()?.message ?: "Unable to enable Airplane Mode"
                )
                return
            }
            MacroNotifier.showToggleNotification(context, airplaneOn = true)

            delay(macro.effectiveWaitSeconds() * 1000L)

            val offResult = setAirplaneState(context, false)
            if (offResult.isFailure) {
                MacroNotifier.showFailureNotification(
                    context,
                    offResult.exceptionOrNull()?.message ?: "Unable to disable Airplane Mode"
                )
                return
            }
            MacroNotifier.showToggleNotification(context, airplaneOn = false)
        } catch (ce: CancellationException) {
            wasCancelled = true
            throw ce
        } finally {
            _isRunning.value = false
            // Re-arm the next trigger cycle (e.g. next 30s wait) if the switch is still ON
            if (!wasCancelled) {
                val latest = MacroRepository(context).loadMacro()
                if (latest.enabled) {
                    MacroScheduler.scheduleMacro(context)
                }
            }
        }
    }

    suspend fun setAirplaneState(context: Context, on: Boolean): Result<Unit> {
        if (AirplaneDeviceAdminReceiver.isDeviceOwner(context)) {
            if (AirplaneDeviceAdminReceiver.setAirplaneMode(context, on)) {
                return Result.success(Unit)
            }
        }

        val service = AirplaneAccessibilityService.instance
            ?: return Result.failure(
                IllegalStateException("Accessibility Service is not running")
            )
        return service.toggleAirplaneMode(on)
    }
}
