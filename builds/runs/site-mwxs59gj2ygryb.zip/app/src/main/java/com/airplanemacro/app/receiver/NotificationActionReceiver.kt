package com.airplanemacro.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.airplanemacro.app.execution.MacroNotifier
import com.airplanemacro.app.execution.MacroRunner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_TURN_OFF_NOW) {
            val pending = goAsync()
            CoroutineScope(Dispatchers.Main.immediate).launch {
                try {
                    val result = MacroRunner.setAirplaneState(context.applicationContext, false)
                    if (result.isSuccess) {
                        MacroNotifier.showToggleNotification(context, airplaneOn = false)
                    }
                } finally {
                    pending.finish()
                }
            }
        }
    }

    companion object {
        const val ACTION_TURN_OFF_NOW = "com.airplanemacro.app.ACTION_TURN_OFF_NOW"
    }
}
