package com.airplanemacro.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.airplanemacro.app.execution.MacroRunner
import com.airplanemacro.app.scheduler.MacroScheduler

class MacroAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val started = MacroRunner.triggerExecution(context)
        // If constraints prevented execution, re-arm the next trigger check if still enabled
        if (!started) {
            MacroScheduler.scheduleMacro(context)
        }
    }
}
