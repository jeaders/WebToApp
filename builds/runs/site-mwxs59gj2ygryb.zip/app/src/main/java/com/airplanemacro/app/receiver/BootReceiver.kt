package com.airplanemacro.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.airplanemacro.app.data.MacroRepository
import com.airplanemacro.app.execution.MacroRunner
import com.airplanemacro.app.model.DeviceEvents
import com.airplanemacro.app.model.Trigger
import com.airplanemacro.app.scheduler.MacroScheduler

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_LOCKED_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            MacroScheduler.scheduleMacro(context)
            val macro = MacroRepository(context).loadMacro()
            val trigger = macro.trigger
            if (macro.enabled && trigger is Trigger.DeviceEvent && trigger.event == DeviceEvents.BOOT) {
                MacroRunner.triggerExecution(context)
            }
        }
    }
}
