package com.airplanemacro.app.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.airplanemacro.app.R
import com.airplanemacro.app.data.MacroRepository
import com.airplanemacro.app.databinding.FragmentMacroEditorBinding
import com.airplanemacro.app.execution.MacroRunner
import com.airplanemacro.app.model.Macro
import com.airplanemacro.app.model.Trigger
import com.airplanemacro.app.model.TriggerFormatters
import com.airplanemacro.app.scheduler.MacroScheduler
import kotlinx.coroutines.launch

class MacroEditorFragment : Fragment() {

    private var _binding: FragmentMacroEditorBinding? = null
    private val binding get() = _binding!!

    private lateinit var repository: MacroRepository
    private lateinit var macro: Macro
    private var searchQuery: String = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMacroEditorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        repository = MacroRepository(requireContext())
        macro = repository.loadMacro()

        setupToolbar()
        setupPanels()
        setupStartStopButton()
        setupSearch()
        setupLocalVariables()
        render()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionBanner()
    }

    private fun setupToolbar() {
        binding.btnBack.setOnClickListener { openOnboarding() }

        binding.btnSave.setOnClickListener {
            persistAndSchedule()
            Toast.makeText(requireContext(), R.string.saved_toast, Toast.LENGTH_SHORT).show()
        }

        binding.btnSearch.setOnClickListener {
            binding.searchBarContainer.isVisible = !binding.searchBarContainer.isVisible
            if (!binding.searchBarContainer.isVisible) {
                binding.etSearch.setText("")
            } else {
                binding.etSearch.requestFocus()
            }
        }

        binding.btnCloseSearch.setOnClickListener {
            binding.etSearch.setText("")
            binding.searchBarContainer.isVisible = false
        }

        binding.btnOverflow.setOnClickListener { anchor ->
            PopupMenu(requireContext(), anchor).apply {
                menu.add(0, 1, 0, getString(R.string.menu_run_now))
                menu.add(
                    0,
                    2,
                    1,
                    if (macro.enabled) "Disable macro" else "Enable macro"
                )
                menu.add(0, 3, 2, getString(R.string.menu_onboarding))
                setOnMenuItemClickListener { item ->
                    when (item.itemId) {
                        1 -> {
                            if (!MacroRunner.hasAnyAutomationTier(requireContext())) {
                                openOnboarding()
                            } else {
                                MacroRunner.triggerExecution(requireContext(), bypassEnabledCheck = true)
                            }
                            true
                        }
                        2 -> {
                            macro = macro.copy(enabled = !macro.enabled)
                            persistAndSchedule()
                            render()
                            true
                        }
                        3 -> {
                            openOnboarding()
                            true
                        }
                        else -> false
                    }
                }
                show()
            }
        }
    }

    private fun setupPanels() {
        binding.btnAddTrigger.setOnClickListener { openTriggerPicker() }
        binding.btnAddAction.setOnClickListener {
            Toast.makeText(requireContext(), R.string.fixed_actions_hint, Toast.LENGTH_SHORT).show()
        }
        binding.btnReorderActions.setOnClickListener {
            Toast.makeText(requireContext(), R.string.fixed_actions_hint, Toast.LENGTH_SHORT).show()
        }
        binding.rowActionWait.setOnClickListener { showWaitDurationDialog() }
    }

    private fun setupStartStopButton() {
        viewLifecycleOwner.lifecycleScope.launch {
            MacroRunner.isRunning.collect {
                updateTriggerSwitchUi()
            }
        }

        binding.switchMacroEnabled.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked == macro.enabled) return@setOnCheckedChangeListener

            if (isChecked) {
                if (!MacroRunner.hasAnyAutomationTier(requireContext())) {
                    binding.switchMacroEnabled.isChecked = false
                    openOnboarding()
                    return@setOnCheckedChangeListener
                }
                macro = macro.copy(enabled = true)
                persistAndSchedule()
                render()
            } else {
                macro = macro.copy(enabled = false)
                MacroRunner.stopExecution(requireContext())
                repository.saveMacro(macro)
                render()
            }
        }
    }

    private fun updateTriggerSwitchUi() {
        if (binding.switchMacroEnabled.isChecked != macro.enabled) {
            binding.switchMacroEnabled.isChecked = macro.enabled
        }
        if (macro.enabled) {
            binding.tvTriggerSwitchTitle.setText(R.string.switch_trigger_on)
            binding.tvTriggerSwitchSub.text = if (MacroRunner.isRunning.value) {
                "Executing Airplane Mode chain…"
            } else {
                getString(R.string.switch_trigger_sub_on)
            }
        } else {
            binding.tvTriggerSwitchTitle.setText(R.string.switch_trigger_off)
            binding.tvTriggerSwitchSub.setText(R.string.switch_trigger_sub_off)
        }
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString()?.trim()?.lowercase().orEmpty()
                render()
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun setupLocalVariables() {
        binding.localVariablesHeader.setOnClickListener {
            binding.localVariablesBody.isVisible = !binding.localVariablesBody.isVisible
        }
        binding.btnAddLocalVar.setOnClickListener {
            showWaitOverrideDialog()
        }
    }

    private fun render() {
        binding.tvToolbarTitle.text = if (macro.enabled) {
            getString(R.string.macro_default_name)
        } else {
            "${getString(R.string.macro_default_name)} (Paused)"
        }

        renderTrigger()
        renderActions()
        renderLocalVariables()
        updateTriggerSwitchUi()
        updatePermissionBanner()
    }

    private fun renderTrigger() {
        binding.triggersListContainer.removeAllViews()
        binding.tvTriggersCount.text = "1"

        val itemView = layoutInflater.inflate(R.layout.item_trigger, binding.triggersListContainer, false)
        val icon = itemView.findViewById<ImageView>(R.id.iv_trigger_icon)
        val title = itemView.findViewById<TextView>(R.id.tv_trigger_title)
        val detail = itemView.findViewById<TextView>(R.id.tv_trigger_detail)

        when (val t = macro.trigger) {
            is Trigger.RegularInterval -> {
                icon.setImageResource(R.drawable.ic_stopwatch)
                title.text = getString(R.string.trigger_regular_interval)
                detail.text = "Interval: ${TriggerFormatters.formatInterval(t.millis)}"
            }
            is Trigger.TimeOfDay -> {
                icon.setImageResource(R.drawable.ic_clock_zzz)
                title.text = getString(R.string.trigger_time_of_day)
                detail.text = "${TriggerFormatters.formatTime(t.hour, t.minute)} · ${TriggerFormatters.formatDaysMask(t.daysMask)}"
            }
            is Trigger.DeviceEvent -> {
                icon.setImageResource(R.drawable.ic_device_event)
                title.text = getString(R.string.trigger_device_event)
                detail.text = t.event.replace('_', ' ')
            }
        }

        val matches = searchQuery.isEmpty() ||
            title.text.toString().lowercase().contains(searchQuery) ||
            detail.text.toString().lowercase().contains(searchQuery)
        itemView.isVisible = matches
        itemView.setOnClickListener { openTriggerPicker() }
        binding.triggersListContainer.addView(itemView)
    }

    private fun renderActions() {
        val waitSec = macro.effectiveWaitSeconds()
        binding.tvActionsCount.text = "3"
        binding.tvActionWaitLabel.text = getString(R.string.action_wait_seconds, waitSec)
        binding.tvActionWaitHint.text = if (macro.localVariables.containsKey("wait_seconds")) {
            "Local var"
        } else {
            "Edit"
        }

        binding.rowActionOn.isVisible = searchQuery.isEmpty() ||
            getString(R.string.action_airplane_on).lowercase().contains(searchQuery)
        binding.rowActionWait.isVisible = searchQuery.isEmpty() ||
            binding.tvActionWaitLabel.text.toString().lowercase().contains(searchQuery)
        binding.rowActionOff.isVisible = searchQuery.isEmpty() ||
            getString(R.string.action_airplane_off).lowercase().contains(searchQuery)
    }

    private fun renderLocalVariables() {
        binding.localVariablesList.removeAllViews()
        macro.localVariables.forEach { (key, value) ->
            val row = layoutInflater.inflate(R.layout.item_local_variable, binding.localVariablesList, false)
            row.findViewById<TextView>(R.id.tv_var_key).text = key
            row.findViewById<TextView>(R.id.tv_var_value).text = value
            row.findViewById<ImageButton>(R.id.btn_delete_var).setOnClickListener {
                val updated = macro.localVariables.toMutableMap().apply { remove(key) }
                macro = macro.copy(localVariables = updated)
                persistAndSchedule()
                render()
            }
            binding.localVariablesList.addView(row)
        }
    }

    private fun updatePermissionBanner() {
        val hasTier = MacroRunner.hasAnyAutomationTier(requireContext())
        val needsExactAlarm = !MacroScheduler.canScheduleExactAlarms(requireContext()) &&
            (macro.trigger is Trigger.RegularInterval || macro.trigger is Trigger.TimeOfDay)

        when {
            !hasTier -> {
                binding.bannerPermission.isVisible = true
                binding.tvBannerTitle.setText(R.string.banner_accessibility_title)
                binding.tvBannerBody.setText(R.string.banner_accessibility_body)
                binding.btnBannerEnable.setOnClickListener {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
            needsExactAlarm && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                binding.bannerPermission.isVisible = true
                binding.tvBannerTitle.setText(R.string.banner_exact_alarm_title)
                binding.tvBannerBody.setText(R.string.banner_exact_alarm_body)
                binding.btnBannerEnable.setOnClickListener {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                }
            }
            else -> binding.bannerPermission.isVisible = false
        }
    }

    private fun openTriggerPicker() {
        TriggerPickerBottomSheet.newInstance(macro.trigger) { newTrigger ->
            macro = macro.copy(trigger = newTrigger)
            persistAndSchedule()
            render()
        }.show(childFragmentManager, "trigger_picker")
    }

    private fun showWaitDurationDialog() {
        val input = EditText(requireContext()).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(macro.waitSeconds.toString())
        }
        AlertDialog.Builder(requireContext())
            .setTitle("Wait Duration (seconds)")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val sec = input.text.toString().toLongOrNull()?.coerceIn(1L, 86_400L) ?: 5L
                macro = macro.copy(waitSeconds = sec)
                persistAndSchedule()
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showWaitOverrideDialog() {
        val input = EditText(requireContext()).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(macro.localVariables["wait_seconds"] ?: macro.waitSeconds.toString())
        }
        AlertDialog.Builder(requireContext())
            .setTitle("Override wait_seconds")
            .setView(input)
            .setPositiveButton("Set") { _, _ ->
                val sec = input.text.toString().toLongOrNull()?.coerceIn(1L, 86_400L) ?: 5L
                val updated = macro.localVariables.toMutableMap().apply {
                    put("wait_seconds", sec.toString())
                }
                macro = macro.copy(localVariables = updated)
                persistAndSchedule()
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openOnboarding() {
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, OnboardingFragment())
            .addToBackStack("onboarding")
            .commit()
    }

    private fun persistAndSchedule() {
        repository.saveMacro(macro)
        MacroScheduler.scheduleMacro(requireContext())
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
