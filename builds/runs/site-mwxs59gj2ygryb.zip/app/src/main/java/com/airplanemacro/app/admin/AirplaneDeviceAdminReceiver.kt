package com.airplanemacro.app.admin

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build

class AirplaneDeviceAdminReceiver : DeviceAdminReceiver() {
    companion object {
        fun isDeviceOwner(context: Context): Boolean {
            val dpm = context.getSystemService(DevicePolicyManager::class.java) ?: return false
            return dpm.isDeviceOwnerApp(context.packageName)
        }

        fun setAirplaneMode(context: Context, on: Boolean): Boolean {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
            val dpm = context.getSystemService(DevicePolicyManager::class.java) ?: return false
            if (!dpm.isDeviceOwnerApp(context.packageName)) return false
            val adminComponent = ComponentName(context, AirplaneDeviceAdminReceiver::class.java)
            return runCatching {
                dpm.setGlobalSetting(adminComponent, "airplane_mode_on", if (on) "1" else "0")
                context.sendBroadcast(
                    Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED).putExtra("state", on)
                )
                true
            }.getOrDefault(false)
        }
    }
}
