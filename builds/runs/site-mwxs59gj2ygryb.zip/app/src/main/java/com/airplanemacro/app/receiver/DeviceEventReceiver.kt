package com.airplanemacro.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import com.airplanemacro.app.data.MacroRepository
import com.airplanemacro.app.execution.MacroRunner
import com.airplanemacro.app.model.DeviceEvents
import com.airplanemacro.app.model.Macro
import com.airplanemacro.app.model.Trigger

class DeviceEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_SCREEN_ON) {
            val macro = MacroRepository(context).loadMacro()
            val trigger = macro.trigger
            if (macro.enabled && trigger is Trigger.DeviceEvent && trigger.event == DeviceEvents.SCREEN_ON) {
                MacroRunner.triggerExecution(context)
            }
        }
    }

    companion object {
        private var registered = false
        private val instance = DeviceEventReceiver()

        fun syncRegistration(appContext: Context, macro: Macro) {
            val needsScreenOn = macro.enabled &&
                macro.trigger is Trigger.DeviceEvent &&
                macro.trigger.event == DeviceEvents.SCREEN_ON

            if (needsScreenOn && !registered) {
                appContext.registerReceiver(instance, IntentFilter(Intent.ACTION_SCREEN_ON))
                registered = true
            } else if (!needsScreenOn && registered) {
                runCatching { appContext.unregisterReceiver(instance) }
                registered = false
            }
        }
    }
}
