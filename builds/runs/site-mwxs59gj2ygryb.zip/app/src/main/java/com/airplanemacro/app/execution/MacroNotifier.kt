package com.airplanemacro.app.execution

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.airplanemacro.app.R
import com.airplanemacro.app.receiver.NotificationActionReceiver

object MacroNotifier {
    const val CHANNEL_STATUS = "macro_status"
    const val CHANNEL_ALERTS = "macro_alerts"
    const val NOTIF_ID_FG = 1001
    private const val NOTIF_ID_TOGGLE = 1002
    private const val NOTIF_ID_ERROR = 1003

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_STATUS,
                context.getString(R.string.notif_channel_status),
                NotificationManager.IMPORTANCE_LOW
            )
        )
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ALERTS,
                context.getString(R.string.notif_channel_alerts),
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )
    }

    fun buildForegroundNotification(context: Context, waitSeconds: Long): Notification {
        ensureChannels(context)
        return NotificationCompat.Builder(context, CHANNEL_STATUS)
            .setSmallIcon(R.drawable.ic_airplane)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(context.getString(R.string.notif_running_chain, waitSeconds))
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    fun showToggleNotification(context: Context, airplaneOn: Boolean) {
        if (!canPost(context)) return
        ensureChannels(context)
        val nm = context.getSystemService(NotificationManager::class.java) ?: return

        val title = context.getString(
            if (airplaneOn) R.string.notif_airplane_on else R.string.notif_airplane_off
        )
        val builder = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_airplane)
            .setContentTitle(title)
            .setAutoCancel(true)

        if (airplaneOn) {
            val turnOffIntent = Intent(context, NotificationActionReceiver::class.java).apply {
                action = NotificationActionReceiver.ACTION_TURN_OFF_NOW
            }
            val pi = PendingIntent.getBroadcast(
                context,
                201,
                turnOffIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(0, context.getString(R.string.notif_turn_off_now), pi)
        }

        nm.notify(NOTIF_ID_TOGGLE, builder.build())
    }

    fun showFailureNotification(context: Context, reason: String) {
        if (!canPost(context)) return
        ensureChannels(context)
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        val notif = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_airplane)
            .setContentTitle(context.getString(R.string.notif_failed_title))
            .setContentText(reason)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIF_ID_ERROR, notif)
    }

    private fun canPost(context: Context): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
    }
}
