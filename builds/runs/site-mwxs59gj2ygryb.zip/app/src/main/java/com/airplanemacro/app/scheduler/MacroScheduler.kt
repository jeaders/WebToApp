package com.airplanemacro.app.scheduler

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.airplanemacro.app.data.MacroRepository
import com.airplanemacro.app.model.Macro
import com.airplanemacro.app.model.Trigger
import com.airplanemacro.app.receiver.DeviceEventReceiver
import com.airplanemacro.app.receiver.MacroAlarmReceiver
import java.util.Calendar

object MacroScheduler {
    private const val ALARM_REQUEST_CODE = 5001

    fun canScheduleExactAlarms(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val am = context.getSystemService(AlarmManager::class.java) ?: return false
        return am.canScheduleExactAlarms()
    }

    fun scheduleMacro(context: Context) {
        val macro = MacroRepository(context).loadMacro()
        cancelScheduledAlarms(context)
        DeviceEventReceiver.syncRegistration(context.applicationContext, macro)
        if (!macro.enabled) return

        when (val trigger = macro.trigger) {
            is Trigger.RegularInterval -> {
                val triggerAt = System.currentTimeMillis() + trigger.millis.coerceAtLeast(1_000L)
                setExactAlarm(context, triggerAt)
            }
            is Trigger.TimeOfDay -> {
                val nextAt = computeNextTimeOfDayMillis(trigger) ?: return
                setExactAlarm(context, nextAt)
            }
            is Trigger.DeviceEvent -> {
                // Handled dynamically via BootReceiver & DeviceEventReceiver
            }
        }
    }

    fun cancelScheduledAlarms(context: Context) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        am.cancel(alarmPendingIntent(context))
    }

    private fun setExactAlarm(context: Context, triggerAtMillis: Long) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val pi = alarmPendingIntent(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        }
    }

    fun computeNextTimeOfDayMillis(trigger: Trigger.TimeOfDay): Long? {
        if (trigger.daysMask == 0) return null
        val now = Calendar.getInstance()
        for (dayOffset in 0..7) {
            val candidate = (now.clone() as Calendar).apply {
                add(Calendar.DAY_OF_YEAR, dayOffset)
                set(Calendar.HOUR_OF_DAY, trigger.hour.coerceIn(0, 23))
                set(Calendar.MINUTE, trigger.minute.coerceIn(0, 59))
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (candidate.timeInMillis <= now.timeInMillis) continue
            val dayBit = calendarDayToBit(candidate.get(Calendar.DAY_OF_WEEK))
            if ((trigger.daysMask and dayBit) != 0) {
                return candidate.timeInMillis
            }
        }
        return null
    }

    private fun calendarDayToBit(dayOfWeek: Int): Int = when (dayOfWeek) {
        Calendar.MONDAY -> 1 shl 0
        Calendar.TUESDAY -> 1 shl 1
        Calendar.WEDNESDAY -> 1 shl 2
        Calendar.THURSDAY -> 1 shl 3
        Calendar.FRIDAY -> 1 shl 4
        Calendar.SATURDAY -> 1 shl 5
        Calendar.SUNDAY -> 1 shl 6
        else -> 1
    }

    private fun alarmPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, MacroAlarmReceiver::class.java)
        return PendingIntent.getBroadcast(
            context,
            ALARM_REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
