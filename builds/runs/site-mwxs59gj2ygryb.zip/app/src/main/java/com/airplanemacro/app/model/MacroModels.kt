package com.airplanemacro.app.model

data class Macro(
    val id: Long,
    val name: String,
    val trigger: Trigger,
    val waitSeconds: Long = 5,
    val enabled: Boolean = false,
    val localVariables: Map<String, String> = emptyMap()
) {
    fun effectiveWaitSeconds(): Long {
        val override = localVariables["wait_seconds"]?.toLongOrNull()
        return (override ?: waitSeconds).coerceIn(1L, 86_400L)
    }
}

sealed interface Trigger {
    data class RegularInterval(val millis: Long) : Trigger
    data class TimeOfDay(val hour: Int, val minute: Int, val daysMask: Int) : Trigger
    data class DeviceEvent(val event: String) : Trigger
}

object DeviceEvents {
    const val BOOT = "BOOT"
    const val SCREEN_ON = "SCREEN_ON"
    const val APP_OPENED = "APP_OPENED"
}

object TriggerFormatters {
    fun formatInterval(millis: Long): String {
        val totalSeconds = (millis / 1000L).coerceAtLeast(1L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return String.format("%02d:%02d:%02d", hours, minutes, seconds)
    }

    fun formatTime(hour: Int, minute: Int): String =
        String.format("%02d:%02d", hour.coerceIn(0, 23), minute.coerceIn(0, 59))

    fun formatDaysMask(mask: Int): String {
        val labels = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        val selected = labels.filterIndexed { index, _ -> (mask and (1 shl index)) != 0 }
        return if (selected.size == 7) "Every day" else if (selected.isEmpty()) "No days" else selected.joinToString(" ")
    }
}
