package com.airplanemacro.app.execution

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.airplanemacro.app.data.MacroRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class MacroExecutionService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val macro = MacroRepository(this).loadMacro()
        startForeground(
            MacroNotifier.NOTIF_ID_FG,
            MacroNotifier.buildForegroundNotification(this, macro.effectiveWaitSeconds())
        )
        serviceScope.launch {
            try {
                MacroRunner.runChain(applicationContext, macro)
            } finally {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }
}
