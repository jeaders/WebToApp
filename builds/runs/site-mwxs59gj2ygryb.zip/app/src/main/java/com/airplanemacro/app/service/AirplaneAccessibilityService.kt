package com.airplanemacro.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

class AirplaneAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Node traversal is driven on-demand during macro execution.
    }

    override fun onInterrupt() {
        // Required override; no persistent state to tear down.
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        super.onDestroy()
    }

    suspend fun toggleAirplaneMode(targetOn: Boolean): Result<Unit> = executionMutex.withLock {
        val outcome = withTimeoutOrNull(12_000L) {
            // Already in desired state according to system settings
            if (isAirplaneModeOn(this@AirplaneAccessibilityService) == targetOn) {
                return@withTimeoutOrNull Result.success(Unit)
            }

            // Expand notification shade (Android 13+ may need double expand for full QS panel)
            performGlobalAction(GLOBAL_ACTION_EXPAND_NOTIFICATION_SHADE)
            delay(700L)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && findAirplaneTile() == null) {
                performGlobalAction(GLOBAL_ACTION_EXPAND_NOTIFICATION_SHADE)
                delay(700L)
            }

            var toggled = false
            var swipedToPage2 = false

            for (attempt in 1..3) {
                val tile = findAirplaneTile()
                if (tile != null) {
                    val alreadySelected = tile.isSelected || tile.isChecked
                    if (alreadySelected == targetOn) {
                        toggled = true
                        break
                    }
                    if (clickNodeOrAncestor(tile)) {
                        delay(450L)
                        toggled = true
                        break
                    }
                }

                if (attempt == 1 && !swipedToPage2) {
                    swipedToPage2 = swipeQuickSettingsLeft()
                    delay(800L)
                } else {
                    delay(800L)
                }
            }

            collapseShadeSafely()

            if (toggled) {
                Result.success(Unit)
            } else {
                Result.failure(IllegalStateException("Airplane Mode tile not found in Quick Settings"))
            }
        }

        return outcome ?: run {
            collapseShadeSafely()
            Result.failure(IllegalStateException("Timed out toggling Airplane Mode"))
        }
    }

    private fun findAirplaneTile(): AccessibilityNodeInfo? {
        val windowsToSearch = buildList {
            rootInActiveWindow?.let { add(it) }
            windows?.forEach { window ->
                window.root?.let { root -> add(root) }
            }
        }
        for (root in windowsToSearch) {
            val match = dfsFindAirplaneNode(root)
            if (match != null) return match
        }
        return null
    }

    private fun dfsFindAirplaneNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        val text = node.text?.toString()?.lowercase().orEmpty()
        val desc = node.contentDescription?.toString()?.lowercase().orEmpty()
        if (AIRPLANE_LABELS.any { keyword -> text.contains(keyword) || desc.contains(keyword) }) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            val found = dfsFindAirplaneNode(child)
            if (found != null) return found
        }
        return null
    }

    private fun clickNodeOrAncestor(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
            current = current.parent
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun swipeQuickSettingsLeft(): Boolean {
        val metrics = resources.displayMetrics
        val startX = metrics.widthPixels * 0.85f
        val endX = metrics.widthPixels * 0.15f
        val y = metrics.heightPixels * 0.25f

        val path = Path().apply {
            moveTo(startX, y)
            lineTo(endX, y)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 260L))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun collapseShadeSafely() {
        val collapsed = performGlobalAction(GLOBAL_ACTION_COLLAPSE_NOTIFICATION_SHADE)
        if (!collapsed) {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    companion object {
        @Volatile
        var instance: AirplaneAccessibilityService? = null
            private set

        private val executionMutex = Mutex()

        private val AIRPLANE_LABELS = listOf(
            "airplane mode",
            "mode avion",
            "الطيران",
            "flugmodus",
            "modo avión",
            "vliegtuigmodus"
        )

        fun isServiceEnabled(context: Context): Boolean {
            if (instance != null) return true
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val serviceId = "${context.packageName}/${AirplaneAccessibilityService::class.java.name}"
            return enabledServices.split(':').any { it.equals(serviceId, ignoreCase = true) }
        }

        fun isAirplaneModeOn(context: Context): Boolean {
            return Settings.Global.getInt(
                context.contentResolver,
                Settings.Global.AIRPLANE_MODE_ON,
                0
            ) != 0
        }
    }
}
