package com.airplanemacro.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import com.airplanemacro.app.databinding.BottomSheetTriggerPickerBinding
import com.airplanemacro.app.model.DeviceEvents
import com.airplanemacro.app.model.Trigger
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class TriggerPickerBottomSheet(
    private val currentTrigger: Trigger,
    private val onTriggerSelected: (Trigger) -> Unit
) : BottomSheetDialogFragment() {

    private var _binding: BottomSheetTriggerPickerBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetTriggerPickerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        when (currentTrigger) {
            is Trigger.RegularInterval -> {
                binding.rbInterval.isChecked = true
                binding.etIntervalSeconds.setText((currentTrigger.millis / 1000L).toString())
            }
            is Trigger.TimeOfDay -> {
                binding.rbTimeOfDay.isChecked = true
                binding.etHour.setText(currentTrigger.hour.toString())
                binding.etMinute.setText(currentTrigger.minute.toString())
                setMaskCheckboxes(currentTrigger.daysMask)
            }
            is Trigger.DeviceEvent -> {
                binding.rbDeviceEvent.isChecked = true
                when (currentTrigger.event) {
                    DeviceEvents.SCREEN_ON -> binding.rbEventScreenOn.isChecked = true
                    DeviceEvents.APP_OPENED -> binding.rbEventAppOpened.isChecked = true
                    else -> binding.rbEventBoot.isChecked = true
                }
            }
        }
        syncVisibility()

        binding.rgTriggerType.setOnCheckedChangeListener { _, _ -> syncVisibility() }

        binding.btnApplyTrigger.setOnClickListener {
            val trigger = when (binding.rgTriggerType.checkedRadioButtonId) {
                binding.rbTimeOfDay.id -> Trigger.TimeOfDay(
                    hour = binding.etHour.text.toString().toIntOrNull()?.coerceIn(0, 23) ?: 7,
                    minute = binding.etMinute.text.toString().toIntOrNull()?.coerceIn(0, 59) ?: 30,
                    daysMask = readMaskCheckboxes()
                )
                binding.rbDeviceEvent.id -> {
                    val event = when (binding.rgDeviceEvent.checkedRadioButtonId) {
                        binding.rbEventScreenOn.id -> DeviceEvents.SCREEN_ON
                        binding.rbEventAppOpened.id -> DeviceEvents.APP_OPENED
                        else -> DeviceEvents.BOOT
                    }
                    Trigger.DeviceEvent(event)
                }
                else -> {
                    val sec = binding.etIntervalSeconds.text.toString().toLongOrNull()?.coerceAtLeast(1L) ?: 30L
                    Trigger.RegularInterval(millis = sec * 1000L)
                }
            }
            onTriggerSelected(trigger)
            dismiss()
        }
    }

    private fun syncVisibility() {
        binding.groupInterval.isVisible = binding.rbInterval.isChecked
        binding.groupTimeOfDay.isVisible = binding.rbTimeOfDay.isChecked
        binding.rgDeviceEvent.isVisible = binding.rbDeviceEvent.isChecked
    }

    private fun setMaskCheckboxes(mask: Int) {
        val boxes = listOf(
            binding.cbMon, binding.cbTue, binding.cbWed, binding.cbThu,
            binding.cbFri, binding.cbSat, binding.cbSun
        )
        boxes.forEachIndexed { idx, box -> box.isChecked = (mask and (1 shl idx)) != 0 }
    }

    private fun readMaskCheckboxes(): Int {
        val boxes = listOf(
            binding.cbMon, binding.cbTue, binding.cbWed, binding.cbThu,
            binding.cbFri, binding.cbSat, binding.cbSun
        )
        var mask = 0
        boxes.forEachIndexed { idx, box -> if (box.isChecked) mask = mask or (1 shl idx) }
        return if (mask == 0) 0b1111111 else mask
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        fun newInstance(current: Trigger, onSelected: (Trigger) -> Unit) =
            TriggerPickerBottomSheet(current, onSelected)
    }
}
