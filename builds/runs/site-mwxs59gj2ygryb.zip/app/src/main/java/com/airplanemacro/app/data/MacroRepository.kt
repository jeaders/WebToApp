package com.airplanemacro.app.data

import android.content.Context
import com.airplanemacro.app.model.Macro
import com.airplanemacro.app.model.Trigger
import org.json.JSONObject

class MacroRepository(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadMacro(): Macro {
        val raw = prefs.getString(KEY_MACRO_JSON, null) ?: return defaultMacro()
        return runCatching { fromJson(JSONObject(raw)) }.getOrElse { defaultMacro() }
    }

    fun saveMacro(macro: Macro) {
        prefs.edit().putString(KEY_MACRO_JSON, toJson(macro).toString()).apply()
    }

    private fun defaultMacro(): Macro = Macro(
        id = 1L,
        name = "Mode avion",
        trigger = Trigger.RegularInterval(millis = 30_000L),
        waitSeconds = 5L,
        enabled = false,
        localVariables = emptyMap()
    )

    private fun toJson(macro: Macro): JSONObject {
        val obj = JSONObject()
        obj.put("id", macro.id)
        obj.put("name", macro.name)
        obj.put("waitSeconds", macro.waitSeconds)
        obj.put("enabled", macro.enabled)

        val triggerObj = JSONObject()
        when (val t = macro.trigger) {
            is Trigger.RegularInterval -> {
                triggerObj.put("type", "interval")
                triggerObj.put("millis", t.millis)
            }
            is Trigger.TimeOfDay -> {
                triggerObj.put("type", "time_of_day")
                triggerObj.put("hour", t.hour)
                triggerObj.put("minute", t.minute)
                triggerObj.put("daysMask", t.daysMask)
            }
            is Trigger.DeviceEvent -> {
                triggerObj.put("type", "device_event")
                triggerObj.put("event", t.event)
            }
        }
        obj.put("trigger", triggerObj)

        val varsObj = JSONObject()
        macro.localVariables.forEach { (k, v) -> varsObj.put(k, v) }
        obj.put("localVariables", varsObj)

        return obj
    }

    private fun fromJson(obj: JSONObject): Macro {
        val triggerObj = obj.getJSONObject("trigger")
        val trigger: Trigger = when (triggerObj.optString("type")) {
            "time_of_day" -> Trigger.TimeOfDay(
                hour = triggerObj.optInt("hour", 7),
                minute = triggerObj.optInt("minute", 30),
                daysMask = triggerObj.optInt("daysMask", 0b0011111)
            )
            "device_event" -> Trigger.DeviceEvent(
                event = triggerObj.optString("event", "BOOT")
            )
            else -> Trigger.RegularInterval(
                millis = triggerObj.optLong("millis", 30_000L).coerceAtLeast(1_000L)
            )
        }

        val varsMap = mutableMapOf<String, String>()
        val varsObj = obj.optJSONObject("localVariables")
        if (varsObj != null) {
            val keys = varsObj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                varsMap[key] = varsObj.optString(key)
            }
        }

        return Macro(
            id = obj.optLong("id", 1L),
            name = obj.optString("name", "Mode avion"),
            trigger = trigger,
            waitSeconds = obj.optLong("waitSeconds", 5L),
            enabled = obj.optBoolean("enabled", false),
            localVariables = varsMap
        )
    }

    companion object {
        private const val PREFS_NAME = "airplane_macro_prefs"
        private const val KEY_MACRO_JSON = "macro_json"
    }
}
