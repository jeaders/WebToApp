import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.smarthr.portal',
  appName: 'Smart HR Portal',
  webDir: 'www',
  bundledWebRuntime: false,
  plugins: {
    SplashScreen: {
      launchShowDuration: 1800,
      backgroundColor: '#f4f7fb',
      showSpinner: false
    },
    StatusBar: {
      backgroundColor: '#123b2a',
      style: 'LIGHT'
    }
  }
};
export default config;
