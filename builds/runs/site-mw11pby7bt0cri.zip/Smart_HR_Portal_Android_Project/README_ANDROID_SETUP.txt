SMART HR PORTAL - ANDROID APP PROJECT
====================================

This is the Android app source project prepared from the current Smart HR Portal demo.
It uses Capacitor to package the portal as a hybrid Android application with a native Android project, app identity, app icon support and splash-screen configuration. It is NOT a finished APK yet.

WHAT IS INCLUDED
- Smart HR Portal web assets bundled locally in www/ (the app does not need a website URL to load its UI)
- Capacitor Android project configuration
- App ID: com.smarthr.portal
- App name: Smart HR Portal
- Splash screen and status-bar configuration
- App icons from the current portal mobile package

REQUIREMENTS TO BUILD THE APK
- A Windows, Mac or Linux computer
- Node.js 20 or newer
- Android Studio (current stable version)
- Android SDK installed through Android Studio
- Internet connection for the first dependency download

BUILD STEPS
1. Extract this ZIP on your computer.
2. Open a terminal / Command Prompt in the extracted Smart_HR_Portal_Android_Project folder.
3. Run: npm install
4. Run: npx cap add android
5. Run: npx cap sync android
6. Run: npx cap open android
7. Android Studio opens the native project. Allow Gradle sync and install any SDK components it requests.
8. In Android Studio select Build > Build Bundle(s) / APK(s) > Build APK(s).
9. After the build succeeds, Android Studio shows a notification with a link to the APK. The usual debug APK location is:
   android/app/build/outputs/apk/debug/app-debug.apk
10. Copy app-debug.apk to your Android phone and tap it to install. If Android asks, allow installation from that file manager/browser source.

IMPORTANT TESTING / SECURITY NOTES
- This portal demo currently stores its data in browser-style local storage on the device. It does not yet use a central backend/database, so different users/devices will not share records.
- Do not enter real employee salary, tax, bank, identity or other confidential data in this demo APK.
- Before using it with real employees, connect a secure backend and database, add server-side authentication and role permissions, HTTPS, audit logs, backups and payroll validation.
- Demo credentials should be changed before any distribution.

TROUBLESHOOTING
- If `npm` is not recognized, install Node.js and reopen the terminal.
- If Android Studio asks for SDK components, install them from its SDK Manager.
- If Gradle sync fails, check the internet connection and use the Gradle / Android Gradle Plugin versions recommended by the installed Android Studio.
- If you update www/index.html later, run `npx cap sync android` again before rebuilding.

This package is source code and setup material, not an APK file. The APK is produced only after the Android build completes successfully.
